<?php
declare(strict_types=1);
require_once __DIR__ . '/../zip_extracted/src/bootstrap.php';
PageAccess::requireSuperAdminDashboard();
?>
<!DOCTYPE html>
<html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1"><meta name="theme-color" content="#f8f9ff"><title>System Overview | KinKeep Vault</title><link rel="preconnect" href="https://fonts.googleapis.com"><link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&family=Material+Symbols+Outlined:wght,FILL@100..700,0..1&display=swap" rel="stylesheet"><link rel="stylesheet" href="system-pages.css"></head>
<body><aside class="sidebar admin-sidebar">
  <!-- Sidebar: brand and current role -->
  <a class="brand" href="system-overview.html">
    <span class="brand-icon material-symbols-outlined">family_restroom</span>
    <span>
      <span class="brand-name">KinKeep Vault</span>
      <span class="brand-caption">Heritage &amp; Lineage</span>
    </span>
  </a>
  <div class="role-box">
    <span><span class="material-symbols-outlined">verified_user</span>Active Role</span>
    <span class="role-pill system-label">Super Admin</span>
  </div>

  <!-- Sidebar: links for this role only -->
  <nav class="side-nav" aria-label="System administration navigation">
    <div class="admin-nav-label">Super Administrator</div>
      <a class="active" aria-current="page" href="system-overview.html"><span class="material-symbols-outlined">shield</span>System Overview</a>
      <a href="family-entities.html"><span class="material-symbols-outlined">corporate_fare</span>Family Entities</a>
      <a href="administrators.html"><span class="material-symbols-outlined">supervisor_account</span>Administrators</a>
      <a href="system-security.html"><span class="material-symbols-outlined">encrypted</span>System Security</a>
      <a href="system-logs.html"><span class="material-symbols-outlined">history</span>System Logs</a>
      <a href="backup-and-restore.html"><span class="material-symbols-outlined">cloud_sync</span>Backup &amp; Restore</a>
      <a href="system-settings.html"><span class="material-symbols-outlined">tune</span>System Settings</a>
  </nav>

  <!-- Sidebar: signed-in user -->
<div class="sidebar-footer"><div class="user-mini"><span class="avatar-sm">SA</span><span><strong>System Administrator</strong><small>Platform owner</small></span></div></div>
</aside>
<div class="workspace"><header class="topbar"><div style="display:flex;align-items:center;gap:9px"><button class="icon-button menu-toggle" aria-label="Open navigation"><span class="material-symbols-outlined">menu</span></button><span class="crumb">Super Administrator / System Overview</span></div><div class="top-actions"><button class="icon-button" aria-label="Notifications" data-toast="System health is normal."><span class="material-symbols-outlined">notifications</span></button><span class="avatar-sm">SA</span></div></header><main class="page-wrap">
<div class="page-heading"><div><p class="eyebrow">Platform operations · global view</p><h1>System Overview</h1><p class="subtitle">Monitor platform health, managed family archives and global service activity.</p></div><div class="heading-actions"><span class="system-status"><span class="material-symbols-outlined" style="font-size:14px">check_circle</span>All systems operational</span></div></div>
<section class="system-hero" style="margin-bottom:16px"><div><p class="eyebrow" style="color:#b7efeb">KinKeep Vault · control center</p><h2>Platform services are healthy</h2><p>Last health check: 10 Oct 2026, 12:15 EAT · no active platform-wide incidents</p></div><span class="system-hero-icon material-symbols-outlined">monitor_heart</span></section>
<div class="system-grid four" style="margin-bottom:16px"><div class="system-stat"><span class="system-stat-icon material-symbols-outlined">corporate_fare</span><div><strong aria-live="polite">Loading...</strong><small>Family archives</small></div></div><div class="system-stat"><span class="system-stat-icon material-symbols-outlined">groups</span><div><strong aria-live="polite">Loading...</strong><small>User accounts</small></div></div><div class="system-stat"><span class="system-stat-icon material-symbols-outlined">database</span><div><strong>2.8 TB</strong><small>Protected storage</small></div></div><div class="system-stat"><span class="system-stat-icon material-symbols-outlined">monitoring</span><div><strong>99.98%</strong><small>30-day availability</small></div></div></div>
<div class="system-grid two" style="align-items:start"><div class="system-stack">
<section class="system-card"><div class="system-card-head"><div><h2>Service health</h2><p>Core platform components</p></div><span class="system-status">Operational</span></div><div class="system-setting"><span><strong>Authentication &amp; sessions</strong><p>Sign-in, verification and session services</p></span><span class="system-status">Healthy</span></div><div class="system-setting"><span><strong>Family API</strong><p>Member, relationship and permission workflows</p></span><span class="system-status">Healthy</span></div><div class="system-setting"><span><strong>Database</strong><p>Primary database and connection pool</p></span><span class="system-status">Healthy</span></div><div class="system-setting"><span><strong>Private media storage</strong><p>Uploads and archival object access</p></span><span class="system-status">Healthy</span></div><div class="system-setting"><span><strong>Email delivery</strong><p>Verification and password-reset messages</p></span><span class="system-status warning">Monitor</span></div></section>
<section class="system-card"><div class="system-card-head"><div><h2>Platform activity</h2><p>Recent global control-plane events</p></div><a class="btn small" href="system-logs.html">View system logs</a></div><div class="system-timeline"><div class="system-event"><strong>Family archive provisioned</strong><small>09:42 EAT · Kileo Family Heritage · completed</small></div><div class="system-event"><strong>Scheduled backup completed</strong><small>08:00 EAT · 128 archives · integrity checked</small></div><div class="system-event"><strong>Administrator access reviewed</strong><small>Yesterday · global administrator roster</small></div><div class="system-event"><strong>Security policy updated</strong><small>09 Oct 2026 · login lockout threshold</small></div></div></section>
</div><div class="system-stack">
<section class="system-card"><div class="system-card-head"><div><h2>Infrastructure capacity</h2><p>Aggregate system resource usage</p></div><span class="pill blue">Within limits</span></div><div class="system-setting"><span><strong>Application nodes</strong><p>4 active · 1 standby</p></span><strong>42%</strong></div><div class="system-progress"><span style="width:42%"></span></div><div class="system-setting" style="margin-top:14px"><span><strong>Database capacity</strong><p>Primary storage allocation</p></span><strong>61%</strong></div><div class="system-progress"><span style="width:61%"></span></div><div class="system-setting" style="margin-top:14px"><span><strong>Media storage</strong><p>Across all private family archives</p></span><strong>68%</strong></div><div class="system-progress"><span style="width:68%"></span></div></section>
<section class="system-card"><div class="system-card-head"><div><h2>Needs attention</h2><p>Items for the platform operations team</p></div><span class="system-status warning">2 notices</span></div><div class="system-setting"><span><strong>Email delivery monitoring</strong><p>Delivery latency increased for one provider.</p></span><a class="btn small" href="system-security.html">Review</a></div><div class="system-setting"><span><strong>Two backups need restore drills</strong><p>Scheduled restore verification is due.</p></span><a class="btn small" href="backup-and-restore.html">Review</a></div><div class="system-setting"><span><strong>No active security incidents</strong><p>Global incident queue is clear.</p></span><span class="system-status">Clear</span></div></section>
<div class="system-grid two"><a class="btn" href="family-entities.html"><span class="material-symbols-outlined">corporate_fare</span>Manage family entities</a><a class="btn" href="backup-and-restore.html"><span class="material-symbols-outlined">backup</span>Backup &amp; restore</a></div>
</div></div>
</main></div><div class="system-toast" role="status" aria-live="polite"></div><script src="system-pages.js"></script></body></html>
