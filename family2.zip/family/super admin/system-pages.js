/* FILE ORGANIZATION
 * 1. Sidebar open/close behavior
 * 2. Toast notifications
 * 3. Search/filter helpers
 * 4. Page-specific interactions (where present)
 */

const sidebar = document.querySelector('.sidebar');
const menuToggle = document.querySelector('.menu-toggle');
const toast = document.querySelector('.system-toast');
let toastTimeout;

async function logoutCurrentUser() {
  try {
    const tokenResponse = await fetch('../zip_extracted/public/index.php', {
      credentials: 'same-origin',
      headers: { Accept: 'application/json' }
    });
    const tokenJson = await tokenResponse.json().catch(() => null);
    if (!tokenResponse.ok || !tokenJson?.success || typeof tokenJson.csrf_token !== 'string' || tokenJson.csrf_token.length < 32) {
      throw new Error('Could not obtain a valid security token.');
    }
    const logoutResponse = await fetch('../zip_extracted/public/api/auth/logout.php', {
      method: 'POST',
      credentials: 'same-origin',
      headers: {
        Accept: 'application/json',
        'X-CSRF-Token': tokenJson.csrf_token,
        'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8'
      },
      body: new URLSearchParams({ csrf_token: tokenJson.csrf_token }).toString()
    });
    const logoutJson = await logoutResponse.json().catch(() => null);
    if (logoutResponse.ok && logoutJson?.success) {
      window.location.href = '../super admin/login.php';
      return;
    }
    throw new Error(logoutJson?.error || 'Logout failed.');
  } catch (error) {
    console.error('Logout failed:', error);
    window.location.href = '../super admin/login.php';
  }
}

function ensureSidebarLogoutButton() {
  if (!sidebar || sidebar.querySelector('.sidebar-logout')) return;
  const footer = sidebar.querySelector('.sidebar-footer');
  const button = document.createElement('button');
  button.type = 'button';
  button.className = 'sidebar-logout';
  button.innerHTML = '<span class="material-symbols-outlined">logout</span>Log out';
  button.addEventListener('click', logoutCurrentUser);
  if (footer) {
    footer.appendChild(button);
  } else {
    sidebar.appendChild(button);
  }
}

ensureSidebarLogoutButton();

function showToast(message) {
  if (!toast) return;
  toast.textContent = message;
  toast.classList.add('visible');
  window.clearTimeout(toastTimeout);
  toastTimeout = window.setTimeout(() => toast.classList.remove('visible'), 3000);
}

menuToggle?.addEventListener('click', () => sidebar?.classList.toggle('open'));

document.addEventListener('click', (event) => {
  if (sidebar?.classList.contains('open') &&
      !sidebar.contains(event.target) &&
      !event.target.closest('.menu-toggle')) {
    sidebar.classList.remove('open');
  }
});

document.querySelectorAll('button[aria-label="Notifications"]').forEach((button) => {
  button.removeAttribute('data-toast');
  button.title = 'Notifications are unavailable: no notification feed is connected.';
});

document.querySelectorAll('[data-toast]').forEach((button) => {
  button.addEventListener('click', () => {
    if (button.dataset.toast) showToast(button.dataset.toast);
  });
});

document.querySelectorAll('[data-filter]').forEach((input) => {
  input.addEventListener('input', () => {
    document.querySelectorAll(input.dataset.filter).forEach((row) => {
      row.hidden = !row.textContent.toLowerCase().includes(input.value.toLowerCase());
    });
  });
});

const adminApiBase = '../zip_extracted/public/api/superadmin/';
let adminCsrfToken;

async function requestAdminApi(path, options = {}) {
    const response = await fetch(adminApiBase + path, {
        ...options,
        credentials: 'same-origin',
        headers: { 'Accept': 'application/json', ...(options.headers || {}) },
    });

    let result;
    try {
        result = await response.json();
    } catch {
        throw new Error(`The server returned an invalid response (HTTP ${response.status}).`);
    }
    if (!response.ok || !result.success) {
        throw new Error(result.error || `Request failed (HTTP ${response.status}).`);
    }
    return result;
}

async function getAdminCsrfToken() {
    if (!adminCsrfToken) {
        const result = await requestAdminApi('overview.php');
        if (typeof result.csrf_token !== 'string' || result.csrf_token.length < 32) {
            throw new Error('Could not obtain a valid security token. Refresh and sign in again.');
        }
        adminCsrfToken = result.csrf_token;
    }
    return adminCsrfToken;
}

async function postAdminApi(path, payload) {
    const token = await getAdminCsrfToken();
    return requestAdminApi(path, {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
            'X-CSRF-Token': token
        },
        body: JSON.stringify(payload)
    });
}

function makeCell(row, value) {
    const cell = document.createElement('td');
    cell.textContent = value == null || value === '' ? '—' : String(value);
    row.append(cell);
    return cell;
}

function formatDate(value) {
    if (!value) return '—';
    const date = new Date(`${value.replace(' ', 'T')}${value.includes('Z') ? '' : ''}`);
    return Number.isNaN(date.getTime()) ? value : date.toLocaleString();
}

function setStatistic(label, value) {
    document.querySelectorAll('.system-stat').forEach((card) => {
        if (card.querySelector('small')?.textContent.trim() === label) {
            const target = card.querySelector('strong');
            if (target) target.textContent = String(value);
        }
    });
}

function setTableMessage(tbody, columns, message) {
    const row = document.createElement('tr');
    const cell = document.createElement('td');
    cell.colSpan = columns;
    cell.textContent = message;
    row.append(cell);
    tbody.replaceChildren(row);
}

function addPagination(container, page, pages, onChange) {
    container.replaceChildren();
    const summary = document.createElement('span');
    summary.textContent = pages ? `Page ${page} of ${pages}` : 'No pages';
    const actions = document.createElement('div');
    actions.className = 'admin-row-actions';
    for (const [label, next] of [['Previous', page - 1], ['Next', page + 1]]) {
        const button = document.createElement('button');
        button.className = 'btn small';
        button.type = 'button';
        button.textContent = label;
        button.disabled = next < 1 || next > pages;
        button.addEventListener('click', () => onChange(next));
        actions.append(button);
    }
    container.append(summary, actions);
}

function downloadCsv(filename, rows) {
    const csv = rows.map((row) => row.map((value) => {
        let text = String(value ?? '');
        if (/^[=+\-@]/.test(text)) text = `'${text}`;
        return `"${text.replaceAll('"', '""')}"`;
    }).join(',')).join('\r\n');
    const link = document.createElement('a');
    link.href = URL.createObjectURL(new Blob([csv], { type: 'text/csv;charset=utf-8' }));
    link.download = filename;
    link.click();
    window.setTimeout(() => URL.revokeObjectURL(link.href), 1000);
}

function setButtonBusy(button, busy, label) {
    if (!button) return;
    if (busy) {
        button.dataset.originalText = button.textContent.trim();
        button.disabled = true;
        button.textContent = label;
    } else {
        button.disabled = false;
        if (button.dataset.originalText) {
            button.textContent = button.dataset.originalText;
            delete button.dataset.originalText;
        }
    }
}

function familyPage() {
    const tbody = document.querySelector('.system-table tbody');
    if (!tbody) return;
    const search = document.querySelector('input[aria-label="Search family entities"]');
    const sort = document.querySelector('select[aria-label="Sort family entities"]');
    const tabs = [...document.querySelectorAll('.admin-tabs button')];
    const createButton = [...document.querySelectorAll('.page-heading button')].find((button) => button.textContent.includes('Provision family'));
    const exportButton = [...document.querySelectorAll('.page-heading button')].find((button) => button.textContent.includes('Export entities'));
    [createButton, exportButton].filter(Boolean).forEach((button) => button.removeAttribute('data-toast'));
    document.querySelector('.page-heading .subtitle')?.replaceChildren(
        document.createTextNode('Review family archive records, current status, creation time and active member counts.')
    );
    document.querySelectorAll('.admin-tabs button').forEach((button) => button.removeAttribute('data-toast'));
    const familySubtitle = document.querySelector('.page-heading .subtitle');
    if (familySubtitle) familySubtitle.textContent = 'Review family archive records, current status, creation time and active member counts.';
    document.querySelectorAll('select[aria-label="Sort family entities"] option').forEach((option) => {
        if (option.textContent.includes('Storage')) {
            option.disabled = true;
            option.textContent = 'Storage (unavailable)';
        }
    });
    for (const label of ['Total entities', 'Active archives', 'Suspended']) setStatistic(label, 'Loading...');
    setStatistic('Provisioning', 'Not tracked');
    tabs.forEach((tab, index) => {
        tab.dataset.status = ['', 'active', 'provisioning', 'suspended'][index] || '';
        tab.textContent = index === 2 ? 'Provisioning (not tracked)' : 'Loading...';
    });
    const toolbar = tbody.closest('.system-table-wrap');
    if (search) {
        search.placeholder = 'Search family name';
        search.setAttribute('aria-label', 'Search family name');
    }
    const createdOption = sort?.options[0];
    if (createdOption) createdOption.textContent = 'Recently created';
    const pager = document.createElement('div');
    pager.style.cssText = 'display:flex;justify-content:space-between;align-items:center;margin-top:13px;color:#626c7b;font-size:11px';
    toolbar?.after(pager);
    let page = 1;
    let status = '';
    let records = [];
    let timer;

    async function load() {
        setTableMessage(tbody, 7, 'Loading family records...');
        const params = new URLSearchParams({ page: String(page), per_page: '25' });
        if (search?.value.trim()) params.set('q', search.value.trim());
        if (status) params.set('status', status);
        if (sort?.value === 'Name A–Z') params.set('sort', 'name');
        try {
            const result = await requestAdminApi(`families.php?${params}`);
            records = result.families;
            setStatistic('Total entities', result.statistics.total.toLocaleString());
            setStatistic('Active archives', result.statistics.active.toLocaleString());
            setStatistic('Provisioning', 'Not tracked');
            setStatistic('Suspended', result.statistics.suspended.toLocaleString());
            tabs.forEach((tab, index) => {
                const key = ['', 'active', 'provisioning', 'suspended'][index] || '';
                const count = key === 'active' ? result.statistics.active
                    : key === 'suspended' ? result.statistics.suspended
                        : key === 'provisioning' ? 0 : result.statistics.total;
                const name = key || 'all';
                tab.dataset.status = name;
                tab.textContent = key === 'provisioning'
                    ? 'Provisioning (not tracked)'
                    : `${name[0].toUpperCase()}${name.slice(1)} ${count.toLocaleString()}`;
                if (key === 'provisioning') tab.disabled = true;
            });
            tbody.replaceChildren();
            if (!records.length) {
                setTableMessage(tbody, 7, 'No family records match this view.');
            }
            for (const family of records) {
                const row = document.createElement('tr');
                row.className = 'entity-row';
                const identity = document.createElement('td');
                const person = document.createElement('div');
                person.className = 'system-person';
                const avatar = document.createElement('span');
                avatar.className = 'avatar-sm';
                avatar.textContent = family.family_name.split(/\s+/).slice(0, 2).map((part) => part[0]).join('').toUpperCase();
                const details = document.createElement('span');
                const name = document.createElement('strong');
                name.textContent = family.family_name;
                const id = document.createElement('small');
                id.textContent = `Family ID · ${family.id}`;
                details.append(name, id);
                person.append(avatar, details);
                identity.append(person);
                row.append(identity);
                makeCell(row, family.family_admin || 'Not assigned');
                makeCell(row, Number(family.active_members).toLocaleString());
                makeCell(row, 'Unavailable');
                makeCell(row, family.status);
                makeCell(row, formatDate(family.created_at));
                const actions = document.createElement('td');
                const edit = document.createElement('button');
                edit.type = 'button';
                edit.className = 'btn small';
                edit.textContent = 'Edit';
                edit.addEventListener('click', async () => {
                    const nextName = window.prompt('Family name', family.family_name);
                    if (nextName === null || !nextName.trim()) return;
                    const nextStatus = window.prompt('Status: active, suspended, or archived', family.status);
                    if (nextStatus === null || !['active', 'suspended', 'archived'].includes(nextStatus.trim())) {
                        if (nextStatus !== null) showToast('Choose active, suspended, or archived.');
                        return;
                    }
                    if (!window.confirm('Save the family name and status changes?')) return;
                    try {
                        await postAdminApi('families.php', {
                            action: 'update', family_id: family.id,
                            family_name: nextName.trim(), status: nextStatus.trim()
                        });
                        showToast('Family record updated.');
                        await load();
                    } catch (error) {
                        showToast(error.message);
                    }
                });
                const admins = document.createElement('button');
                admins.type = 'button';
                admins.className = 'btn small';
                admins.textContent = 'Admins';
                admins.setAttribute('aria-label', `Manage administrators for ${family.family_name}`);
                admins.addEventListener('click', async () => {
                    try {
                        const result = await requestAdminApi(
                            `families.php?family_id=${encodeURIComponent(family.id)}&admin_candidates=1`
                        );
                        const invitationOptions = await requestAdminApi(
                            `family_admin_invitations.php?family_id=${encodeURIComponent(family.id)}`
                        );
                        const candidates = result.candidates;
                        const hasEligibleAdmin = candidates.some((candidate) => candidate.role === 'admin');
                        const dialog = document.createElement('dialog');
                        dialog.setAttribute('aria-labelledby', 'family-admin-dialog-title');
                        dialog.style.cssText = 'max-width:520px;width:calc(100% - 32px);padding:22px;border:1px solid #dce4ef;border-radius:12px;box-shadow:0 16px 48px rgba(0,29,55,.2)';
                        const heading = document.createElement('h2');
                        heading.id = 'family-admin-dialog-title';
                        heading.textContent = `Family administrators: ${family.family_name}`;
                        const description = document.createElement('p');
                        description.textContent = hasEligibleAdmin
                            ? 'Role changes are limited to this family. This does not grant global Super Admin access.'
                            : 'The first administrator must accept an invitation before receiving privileges. This does not grant global Super Admin access.';
                        dialog.append(heading, description);

                        function addRoleForm(title, eligible, action, buttonLabel, confirmText) {
                            const form = document.createElement('form');
                            form.style.cssText = 'display:grid;gap:8px;margin:16px 0';
                            const label = document.createElement('label');
                            label.textContent = title;
                            const select = document.createElement('select');
                            select.className = 'btn';
                            select.required = true;
                            const placeholder = document.createElement('option');
                            placeholder.value = '';
                            placeholder.textContent = eligible.length ? 'Choose a family member' : 'No eligible members';
                            select.append(placeholder);
                            for (const candidate of eligible) {
                                const option = document.createElement('option');
                                option.value = String(candidate.member_id);
                                option.textContent = `${candidate.first_name} ${candidate.last_name} — ${candidate.email} (member ${candidate.member_id})`;
                                select.append(option);
                            }
                            label.append(select);
                            const submit = document.createElement('button');
                            submit.type = 'submit';
                            submit.className = 'btn small';
                            submit.textContent = buttonLabel;
                            submit.disabled = eligible.length === 0;
                            form.append(label, submit);
                            form.addEventListener('submit', async (event) => {
                                event.preventDefault();
                                if (!select.value || !window.confirm(confirmText)) return;
                                setButtonBusy(submit, true, 'Saving...');
                                try {
                                    await postAdminApi('families.php', {
                                        action,
                                        family_id: family.id,
                                        member_id: Number(select.value)
                                    });
                                    dialog.close();
                                    showToast(action === 'assign_family_admin'
                                        ? 'Family administrator assigned.'
                                        : 'Family administrator removed.');
                                    await load();
                                } catch (error) {
                                    showToast(error.message);
                                } finally {
                                    setButtonBusy(submit, false);
                                }
                            });
                            dialog.append(form);
                        }

                        addRoleForm(
                            'Assign an administrator',
                            hasEligibleAdmin
                                ? candidates.filter((candidate) => candidate.role !== 'admin')
                                : [],
                            'assign_family_admin',
                            'Assign',
                            'Assign this member as a Family Admin?'
                        );
                        addRoleForm(
                            'Remove an administrator',
                            candidates.filter((candidate) => candidate.role === 'admin'),
                            'remove_family_admin',
                            'Remove admin role',
                            'Demote this Family Admin to Family Member? The last administrator cannot be removed.'
                        );

                        const inviteSection = document.createElement('section');
                        inviteSection.style.cssText = 'display:grid;gap:8px;margin:16px 0;padding-top:14px;border-top:1px solid #dce4ef';
                        const inviteTitle = document.createElement('h3');
                        inviteTitle.textContent = 'Invite the first Family Admin';
                        const inviteDescription = document.createElement('p');
                        inviteDescription.textContent = !invitationOptions.family_active
                            ? 'Invitations are unavailable because this family is not active.'
                            : invitationOptions.has_eligible_admin
                                ? 'This family already has an eligible administrator. First-admin invitations are unavailable.'
                                : 'Choose an existing active account. The invitee must sign in and explicitly accept. No email will be sent.';
                        const inviteForm = document.createElement('form');
                        inviteForm.style.cssText = 'display:grid;gap:8px';
                        const inviteSelect = document.createElement('select');
                        inviteSelect.className = 'btn';
                        inviteSelect.required = true;
                        const invitePlaceholder = document.createElement('option');
                        invitePlaceholder.value = '';
                        invitePlaceholder.textContent = invitationOptions.eligible_users.length
                            ? 'Choose an existing account'
                            : 'No eligible accounts available';
                        inviteSelect.append(invitePlaceholder);
                        for (const account of invitationOptions.eligible_users) {
                            const option = document.createElement('option');
                            option.value = String(account.id);
                            option.textContent = account.email;
                            inviteSelect.append(option);
                        }
                        const inviteSubmit = document.createElement('button');
                        inviteSubmit.type = 'submit';
                        inviteSubmit.className = 'btn small';
                        inviteSubmit.textContent = 'Create invitation';
                        inviteSubmit.disabled = !invitationOptions.family_active
                            || invitationOptions.has_eligible_admin
                            || invitationOptions.eligible_users.length === 0;
                        inviteForm.append(inviteSelect, inviteSubmit);
                        inviteForm.addEventListener('submit', async (event) => {
                            event.preventDefault();
                            if (!inviteSelect.value || !window.confirm(
                                'Create a seven-day Family Admin invitation? No email will be sent; the account holder will see it after signing in.'
                            )) return;
                            setButtonBusy(inviteSubmit, true, 'Creating...');
                            try {
                                await postAdminApi('family_admin_invitations.php', {
                                    family_id: family.id,
                                    user_id: Number(inviteSelect.value)
                                });
                                dialog.close();
                                showToast('Invitation created. The recipient can review it after sign-in; no email was sent.');
                            } catch (error) {
                                showToast(error.message);
                            } finally {
                                setButtonBusy(inviteSubmit, false);
                            }
                        });
                        inviteSection.append(inviteTitle, inviteDescription, inviteForm);
                        dialog.append(inviteSection);

                        const close = document.createElement('button');
                        close.type = 'button';
                        close.className = 'btn small';
                        close.textContent = 'Close';
                        close.addEventListener('click', () => dialog.close());
                        dialog.append(close);
                        dialog.addEventListener('close', () => dialog.remove(), { once: true });
                        document.body.append(dialog);
                        dialog.showModal();
                    } catch (error) {
                        showToast(error.message);
                    }
                });
                actions.append(edit, admins);
                row.append(actions);
                tbody.append(row);
            }
            addPagination(pager, result.pagination.page, result.pagination.pages, (nextPage) => {
                page = nextPage;
                load();
            });
        } catch (error) {
            setTableMessage(tbody, 7, 'Family records could not be loaded.');
            for (const label of ['Total entities', 'Active archives', 'Suspended']) setStatistic(label, 'Unavailable');
            tabs.forEach((tab, index) => {
                tab.textContent = index === 2 ? 'Provisioning (not tracked)' : 'Unavailable';
            });
            showToast(error.message);
        }
    }

    tabs.forEach((tab) => tab.addEventListener('click', () => {
        if (tab.disabled) return;
        status = tab.dataset.status === 'all' ? '' : tab.dataset.status;
        page = 1;
        load();
    }));
    search?.addEventListener('input', () => {
        window.clearTimeout(timer);
        timer = window.setTimeout(() => { page = 1; load(); }, 250);
    });
    sort?.addEventListener('change', () => { page = 1; load(); });
    createButton?.addEventListener('click', async () => {
        const name = window.prompt('Enter the new family name');
        if (name === null || !name.trim()) return;
        if (!window.confirm(`Create the family record “${name.trim()}”? No family member or administrator account will be created.`)) return;
        setButtonBusy(createButton, true, 'Creating...');
        try {
            await postAdminApi('families.php', { action: 'create', family_name: name.trim() });
            showToast('Family record created.');
            page = 1;
            await load();
        } catch (error) {
            showToast(error.message);
        } finally {
            setButtonBusy(createButton, false);
        }
    });
    exportButton?.addEventListener('click', () => {
        downloadCsv('family-entities.csv', [
            ['ID', 'Family', 'Status', 'Active members', 'Family administrator', 'Created'],
            ...records.map((family) => [family.id, family.family_name, family.status, family.active_members, family.family_admin, family.created_at])
        ]);
    });
    load();
}

function registeredUserManagement() {
    const search = document.querySelector('#registered-user-search');
    const resultsBody = document.querySelector('#registered-user-results');
    const status = document.querySelector('#registered-user-status');
    const editor = document.querySelector('#registered-user-editor');
    const selectedLabel = document.querySelector('#registered-user-selected');
    const familySelect = document.querySelector('#family-role-family');
    const inviteFamilySelect = document.querySelector('#family-invite-family');
    const membershipsBody = document.querySelector('#registered-user-memberships');
    const form = document.querySelector('#family-role-form');
    const invitationForm = document.querySelector('#family-invitation-form');
    const invitationRows = document.querySelector('#family-invitation-rows');
    const invitationStatus = document.querySelector('#family-invitation-status');
    const invitationDeliveryNote = document.querySelector('#family-invitation-delivery-note');
    const invitationPager = document.querySelector('#family-invitation-pager');
    const invitationSubmit = document.querySelector('#family-invite-submit');
    if (!search || !resultsBody || !status || !editor || !familySelect || !inviteFamilySelect
        || !membershipsBody || !form || !invitationForm || !invitationRows
        || !invitationStatus || !invitationDeliveryNote || !invitationPager || !invitationSubmit) return;

    let selectedAccount = null;
    let debounce;
    let mailDeliveryEnabled = false;
    const setStatus = (message) => { status.textContent = message; };

    async function loadFamilies() {
        try {
            const first = await requestAdminApi('families.php?status=active&page=1&per_page=100');
            const families = [...first.families];
            for (let page = 2; page <= first.pagination.pages; page += 1) {
                const next = await requestAdminApi(`families.php?status=active&page=${page}&per_page=100`);
                families.push(...next.families);
            }
            for (const select of [familySelect, inviteFamilySelect]) {
                select.replaceChildren(new Option('Select a family', ''));
                for (const family of families) {
                    select.add(new Option(family.family_name, String(family.id)));
                }
                if (!families.length) select.replaceChildren(new Option('No active families available', ''));
            }
        } catch (error) {
            familySelect.replaceChildren(new Option('Families could not be loaded', ''));
            inviteFamilySelect.replaceChildren(new Option('Families could not be loaded', ''));
            setStatus(error.message);
        }
    }

    async function loadInvitations(page = 1) {
        setTableMessage(invitationRows, 7, 'Loading invitations…');
        try {
            const response = await requestAdminApi(`family_invitations.php?page=${page}&per_page=25`);
            mailDeliveryEnabled = response.delivery_enabled === true;
            invitationSubmit.disabled = !mailDeliveryEnabled;
            invitationDeliveryNote.textContent = mailDeliveryEnabled
                ? 'Email invitation delivery is enabled. Links are single-use, expire after seven days, and are accepted only by the matching verified account.'
                : 'Email invitation sending and resending are disabled in development mail-log mode. No invitation link is written to the development log. Revocation remains available.';
            invitationRows.replaceChildren();
            if (!response.invitations.length) {
                setTableMessage(invitationRows, 7, 'No family invitations found.');
            }
            for (const invitation of response.invitations) {
                const row = document.createElement('tr');
                makeCell(row, invitation.family_name);
                makeCell(row, invitation.invitee_email);
                makeCell(row, invitation.invited_role === 'admin' ? 'Family Admin' : 'Family Member');
                makeCell(row, invitation.status);
                makeCell(row, formatDate(invitation.created_at));
                makeCell(row, formatDate(invitation.expires_at));
                const actions = document.createElement('td');
                if (invitation.status === 'pending' || invitation.status === 'expired') {
                    const resend = document.createElement('button');
                    resend.type = 'button';
                    resend.className = 'btn small';
                    resend.textContent = 'Resend';
                    resend.disabled = !mailDeliveryEnabled;
                    resend.addEventListener('click', () => changeInvitation(invitation, 'resend', resend));
                    actions.append(resend);
                }
                if (invitation.status === 'pending') {
                    const revoke = document.createElement('button');
                    revoke.type = 'button';
                    revoke.className = 'btn small';
                    revoke.style.marginLeft = '6px';
                    revoke.textContent = 'Revoke';
                    revoke.addEventListener('click', () => changeInvitation(invitation, 'revoke', revoke));
                    actions.append(revoke);
                }
                if (!actions.childElementCount) {
                    actions.textContent = '—';
                }
                row.append(actions);
                invitationRows.append(row);
            }
            addPagination(invitationPager, page, response.pagination.pages, loadInvitations);
        } catch (error) {
            invitationSubmit.disabled = true;
            setTableMessage(invitationRows, 7, 'Family invitations could not be loaded.');
            invitationDeliveryNote.textContent = 'Mail delivery configuration could not be checked; sending remains disabled.';
            invitationStatus.textContent = error.message;
        }
    }

    async function changeInvitation(invitation, action, button) {
        if (action === 'revoke'
            && !window.confirm(`Revoke the invitation for ${invitation.invitee_email}?`)) return;
        button.disabled = true;
        invitationStatus.textContent = action === 'resend' ? 'Resending invitation…' : 'Revoking invitation…';
        try {
            const response = await postAdminApi('family_invitations.php', {
                action,
                invitation_id: invitation.id
            });
            invitationStatus.textContent = response.message;
            await loadInvitations();
        } catch (error) {
            invitationStatus.textContent = error.message;
            button.disabled = false;
        }
    }

    invitationForm.addEventListener('submit', async (event) => {
        event.preventDefault();
        if (!mailDeliveryEnabled) {
            invitationStatus.textContent = 'Email delivery is disabled while mail is in development log mode.';
            return;
        }
        invitationSubmit.disabled = true;
        invitationStatus.textContent = 'Creating and sending invitation…';
        try {
            const response = await postAdminApi('family_invitations.php', {
                action: 'create',
                family_id: Number(inviteFamilySelect.value),
                email: document.querySelector('#family-invite-email').value.trim(),
                role: document.querySelector('#family-invite-role').value
            });
            invitationStatus.textContent = response.message;
            invitationForm.reset();
            await loadInvitations();
        } catch (error) {
            invitationStatus.textContent = error.message;
        } finally {
            invitationSubmit.disabled = !mailDeliveryEnabled;
        }
    });

    function renderMemberships(account) {
        membershipsBody.replaceChildren();
        if (!account.memberships.length) {
            setTableMessage(membershipsBody, 4, 'No family assignments found.');
            return;
        }
        for (const membership of account.memberships) {
            const row = document.createElement('tr');
            makeCell(row, membership.family_name);
            makeCell(row, membership.member_status);
            makeCell(row, membership.role || 'Unassigned');
            const actions = document.createElement('td');
            const manage = document.createElement('button');
            manage.type = 'button';
            manage.className = 'btn small';
            manage.textContent = 'Manage role';
            manage.disabled = membership.member_status === 'removed' || membership.member_status === 'suspended';
            manage.addEventListener('click', () => {
                familySelect.value = String(membership.family_id);
                if (membership.role === 'admin' || membership.role === 'member') {
                    document.querySelector('#family-role-value').value = membership.role;
                } else {
                    document.querySelector('#family-role-value').value = '';
                }
            });
            const revoke = document.createElement('button');
            revoke.type = 'button';
            revoke.className = 'btn small';
            revoke.style.marginLeft = '6px';
            revoke.textContent = 'Revoke';
            revoke.disabled = membership.member_status === 'removed';
            revoke.addEventListener('click', async () => {
                if (!window.confirm(`Revoke this account's access to ${membership.family_name}?`)) return;
                revoke.disabled = true;
                try {
                    const response = await postAdminApi('accounts.php', {
                        action: 'revoke',
                        user_id: account.id,
                        family_id: membership.family_id
                    });
                    setStatus(response.message);
                    await searchAccounts(search.value.trim(), account.id);
                } catch (error) {
                    setStatus(error.message);
                    revoke.disabled = false;
                }
            });
            actions.append(manage, revoke);
            row.append(actions);
            membershipsBody.append(row);
        }
    }

    function selectAccount(account) {
        selectedAccount = account;
        editor.hidden = false;
        selectedLabel.textContent = `${account.email} · User ID ${account.id}`;
        renderMemberships(account);
    }

    async function searchAccounts(query, retainId = null) {
        if (query.length < 2) {
            resultsBody.replaceChildren();
            setTableMessage(resultsBody, 6, 'Search for a registered user by email or phone (at least two characters).');
            editor.hidden = true;
            selectedAccount = null;
            setStatus('');
            return;
        }

        setStatus('Searching registered accounts…');
        setTableMessage(resultsBody, 6, 'Searching…');
        try {
            const response = await requestAdminApi(`accounts.php?q=${encodeURIComponent(query)}`);
            resultsBody.replaceChildren();
            if (!response.accounts.length) {
                setTableMessage(resultsBody, 6, 'No matching registered accounts found.');
                editor.hidden = true;
                selectedAccount = null;
                setStatus('');
                return;
            }
            let retainedAccount = null;
            for (const account of response.accounts) {
                const row = document.createElement('tr');
                makeCell(row, account.email);
                makeCell(row, account.phone || '—');
                makeCell(row, account.status);
                makeCell(row, account.email_verified ? 'Yes' : 'No');
                makeCell(row, account.memberships.length
                    ? account.memberships.map((membership) => `${membership.family_name} (${membership.role || 'unassigned'} · ${membership.member_status})`).join('; ')
                    : 'None');
                const actionCell = document.createElement('td');
                const selectButton = document.createElement('button');
                selectButton.type = 'button';
                selectButton.className = 'btn small';
                selectButton.textContent = 'Select';
                selectButton.addEventListener('click', () => selectAccount(account));
                actionCell.append(selectButton);
                row.append(actionCell);
                resultsBody.append(row);
                if (account.id === retainId) retainedAccount = account;
            }
            const currentId = retainId || selectedAccount?.id;
            if (!retainedAccount && currentId) {
                retainedAccount = response.accounts.find((account) => account.id === currentId) || null;
            }
            if (retainedAccount) selectAccount(retainedAccount);
            else if (selectedAccount && !response.accounts.some((account) => account.id === selectedAccount.id)) {
                editor.hidden = true;
                selectedAccount = null;
            }
            setStatus(`${response.accounts.length} matching account${response.accounts.length === 1 ? '' : 's'} shown (maximum 50).`);
        } catch (error) {
            setTableMessage(resultsBody, 6, 'Registered user search is unavailable.');
            editor.hidden = true;
            selectedAccount = null;
            setStatus(error.message);
        }
    }

    search.addEventListener('input', () => {
        window.clearTimeout(debounce);
        debounce = window.setTimeout(() => searchAccounts(search.value.trim()), 250);
    });

    form.addEventListener('submit', async (event) => {
        event.preventDefault();
        if (!selectedAccount) {
            setStatus('Select a registered account first.');
            return;
        }
        const saveButton = form.querySelector('button[type="submit"]');
        saveButton.disabled = true;
        setStatus('Saving family access…');
        try {
            const response = await postAdminApi('accounts.php', {
                action: 'assign',
                user_id: selectedAccount.id,
                family_id: Number(familySelect.value),
                role: document.querySelector('#family-role-value').value,
                first_name: document.querySelector('#family-member-first').value,
                last_name: document.querySelector('#family-member-last').value
            });
            setStatus(response.message);
            await searchAccounts(search.value.trim(), selectedAccount.id);
        } catch (error) {
            setStatus(error.message);
        } finally {
            saveButton.disabled = false;
        }
    });

    loadFamilies();
    loadInvitations();
}

function administratorsPage() {
    registeredUserManagement();
    const tbody = document.querySelector('input[aria-label="Search administrators"]')
        ?.closest('.system-card')
        ?.querySelector('.system-table tbody');
    if (!tbody) return;
    const search = document.querySelector('input[aria-label="Search administrators"]');
    const inviteButton = [...document.querySelectorAll('.page-heading button')].find((button) => button.textContent.includes('Invite family user'));
    const exportButton = [...document.querySelectorAll('.page-heading button')].find((button) => button.textContent.includes('Export access list'));
    [inviteButton, exportButton].filter(Boolean).forEach((button) => button.removeAttribute('data-toast'));
    document.querySelector('.page-heading .subtitle')?.replaceChildren(
        document.createTextNode('Review global Super Admin accounts and family-scoped administrator assignments. Unsupported account changes remain unavailable.')
    );
    if (exportButton) exportButton.textContent = 'Export this page';
    document.querySelectorAll('.system-stat').forEach((card) => {
        const label = card.querySelector('small');
        if (label?.textContent.trim() === 'MFA enabled') label.textContent = 'MFA flags (not verified)';
    });
    for (const label of ['Platform administrators', 'Family administrators', 'MFA flags (not verified)', 'Last access review']) {
        setStatistic(label, 'Loading...');
    }
    document.querySelectorAll('.system-setting').forEach((line) => {
        const text = line.textContent.toLowerCase();
        const description = line.querySelector('p');
        const status = line.querySelector('.system-status');
        if (/multi-factor|mfa/.test(text)) {
            if (status) status.textContent = 'Not implemented';
            if (description) description.textContent = 'No complete MFA verification flow is implemented.';
        } else if (/quarterly access review/.test(text)) {
            if (status) status.textContent = 'Not tracked';
            if (description) description.textContent = 'No access-review schedule or completion records exist.';
        } else if (/session idle timeout/.test(text)) {
            if (description) description.textContent = 'Configured session idle timeout';
            const value = line.querySelectorAll('strong')[1];
            if (value) value.textContent = 'Loading...';
        }
    });
    const policyStatus = [...document.querySelectorAll('.system-card')]
        .find((card) => card.querySelector('h2')?.textContent.trim() === 'Privileged access policy')
        ?.querySelector('.system-card-head .system-status');
    if (policyStatus) policyStatus.textContent = 'Loading configuration';
    const recentStatusCard = [...document.querySelectorAll('.system-card')]
        .find((card) => card.querySelector('h2')?.textContent.trim() === 'Recent privileged access');
    let recentLoading;
    if (recentStatusCard) {
        recentStatusCard.querySelectorAll('.system-kv').forEach((item) => item.remove());
        recentLoading = document.createElement('p');
        recentLoading.textContent = 'Loading recorded administrator audit events...';
        recentStatusCard.append(recentLoading);
    }
    const section = tbody.closest('.system-card');
    let familyTbody;
    const familySection = document.createElement('section');
    familySection.className = 'system-card';
    familySection.style.marginTop = '16px';
    const familyHead = document.createElement('div');
    familyHead.className = 'system-card-head';
    const familyHeading = document.createElement('div');
    const familyTitle = document.createElement('h2');
    familyTitle.textContent = 'Family administrators';
    const familyDescription = document.createElement('p');
    familyDescription.textContent = 'Family-scoped assignments; these do not grant global Super Admin access.';
    familyHeading.append(familyTitle, familyDescription);
    familyHead.append(familyHeading);
    const familyWrap = document.createElement('div');
    familyWrap.className = 'system-table-wrap';
    const familyTable = document.createElement('table');
    familyTable.className = 'system-table';
    const familyThead = document.createElement('thead');
    const familyHeaderRow = document.createElement('tr');
    for (const label of ['Account', 'Family', 'Family role', 'Account status', 'Last sign-in']) {
        const th = document.createElement('th');
        th.textContent = label;
        familyHeaderRow.append(th);
    }
    familyThead.append(familyHeaderRow);
    familyTbody = document.createElement('tbody');
    familyTable.append(familyThead, familyTbody);
    familyWrap.append(familyTable);
    familySection.append(familyHead, familyWrap);
    section?.after(familySection);
    const globalPager = document.createElement('div');
    globalPager.style.cssText = 'display:flex;justify-content:space-between;align-items:center;margin-top:13px;color:#626c7b;font-size:11px';
    section?.querySelector('.system-table-wrap')?.after(globalPager);
    const familyPager = document.createElement('div');
    familyPager.style.cssText = globalPager.style.cssText;
    familyWrap.after(familyPager);
    let globalRecords = [];
    let familyRecords = [];
    let globalPage = 1;
    let familyPage = 1;
    let timer;
    async function load() {
        setTableMessage(tbody, 7, 'Loading administrator accounts...');
        setTableMessage(familyTbody, 5, 'Loading family administrator assignments...');
        const params = new URLSearchParams({ page: String(globalPage), per_page: '25' });
        params.set('family_page', String(familyPage));
        if (search?.value.trim()) params.set('q', search.value.trim());
        try {
            const result = await requestAdminApi(`administrators.php?${params}`);
            globalRecords = result.platform_administrators;
            familyRecords = result.family_administrators;
            setStatistic('Platform administrators', result.statistics.platform_administrators.toLocaleString());
            setStatistic('Family administrators', result.statistics.family_administrator_assignments.toLocaleString());
            setStatistic('MFA flags (not verified)', `${result.statistics.mfa_flagged_platform_accounts.toLocaleString()} flags; flow unavailable`);
            setStatistic('Last access review', 'Unavailable');
            tbody.replaceChildren();
            if (!globalRecords.length) setTableMessage(tbody, 7, 'No platform administrator accounts found.');
            for (const account of globalRecords) {
                const row = document.createElement('tr');
                row.className = 'admin-row';
                const person = document.createElement('td');
                const personWrap = document.createElement('div');
                personWrap.className = 'system-person';
                const avatar = document.createElement('span');
                avatar.className = 'avatar-sm';
                avatar.textContent = account.email.slice(0, 2).toUpperCase();
                const details = document.createElement('span');
                const email = document.createElement('strong');
                email.textContent = account.email;
                const id = document.createElement('small');
                id.textContent = `User ID · ${account.id}`;
                details.append(email, id);
                personWrap.append(avatar, details);
                person.append(personWrap);
                row.append(person);
                makeCell(row, 'Super Admin');
                makeCell(row, 'MFA flow unavailable');
                makeCell(row, formatDate(account.last_login_at));
                makeCell(row, 'Not tracked');
                makeCell(row, account.status);
                makeCell(row, 'Read only');
                tbody.append(row);
            }
            familyTbody.replaceChildren();
            if (!familyRecords.length) setTableMessage(familyTbody, 5, 'No family administrator assignments found.');
            for (const assignment of familyRecords) {
                const row = document.createElement('tr');
                row.className = 'admin-row';
                makeCell(row, assignment.email || `${assignment.first_name} ${assignment.last_name} (no linked account)`);
                makeCell(row, assignment.family_name);
                makeCell(row, assignment.role);
                makeCell(row, assignment.account_status || 'No linked account');
                makeCell(row, formatDate(assignment.last_login_at));
                familyTbody.append(row);
            }
            addPagination(globalPager, globalPage, result.pagination.platform_pages, (nextPage) => {
                globalPage = nextPage;
                load();
            });
            addPagination(familyPager, familyPage, result.pagination.family_pages, (nextPage) => {
                familyPage = nextPage;
                load();
            });
            const policyLines = document.querySelectorAll('.system-setting');
            policyLines.forEach((line) => {
                if (/multi-factor|MFA/i.test(line.textContent)) {
                    const status = line.querySelector('.system-status');
                    if (status) status.textContent = 'Not implemented';
                    const description = line.querySelector('p');
                    if (description) description.textContent = 'A complete MFA verification flow is not implemented.';
                }
                if (/quarterly access review/i.test(line.textContent)) {
                    const status = line.querySelector('.system-status');
                    const description = line.querySelector('p');
                    if (status) status.textContent = 'Not tracked';
                    if (description) description.textContent = 'No access-review schedule or completion records exist.';
                }
                if (/session idle timeout/i.test(line.textContent)) {
                    const description = line.querySelector('p');
                    const value = line.querySelectorAll('strong')[1];
                    if (description) description.textContent = 'Configured session idle timeout';
                    if (value) value.textContent = 'Loading...';
                }
            });
            const policyCard = [...document.querySelectorAll('.system-card')]
                .find((card) => card.querySelector('h2')?.textContent.trim() === 'Privileged access policy');
            const timeoutLine = [...(policyCard?.querySelectorAll('.system-setting') || [])]
                .find((line) => line.textContent.includes('Session idle timeout'));
            const timeoutValue = timeoutLine?.querySelectorAll('strong')[1];
            try {
                const securityResult = await requestAdminApi('security.php');
                if (timeoutValue) {
                    timeoutValue.textContent = `${Math.round(securityResult.security.session_idle_timeout_seconds / 60)} minutes`;
                }
                const recentCard = [...document.querySelectorAll('.system-card')]
                    .find((card) => card.querySelector('h2')?.textContent.trim() === 'Recent privileged access');
                if (recentCard) {
                    const logs = await requestAdminApi('logs.php?category=admin&page=1&per_page=5');
                    recentLoading?.remove();
                    if (!logs.logs.length) {
                        const empty = document.createElement('p');
                        empty.textContent = 'No matching audit events recorded.';
                        recentCard.append(empty);
                    } else {
                        for (const event of logs.logs.slice(0, 3)) {
                            const item = document.createElement('div');
                            item.className = 'system-kv';
                            const label = document.createElement('span');
                            label.textContent = event.action.replaceAll('_', ' ');
                            const value = document.createElement('strong');
                            value.textContent = formatDate(event.created_at);
                            item.append(label, value);
                            recentCard.append(item);
                        }
                    }
                }
                if (policyStatus) policyStatus.textContent = 'Session policy loaded';
            } catch (error) {
                console.error('Supplementary administrator details unavailable:', error);
                if (timeoutValue) timeoutValue.textContent = 'Unavailable';
                if (policyStatus) policyStatus.textContent = 'Unavailable';
                showToast('Some supplementary administrator details are unavailable.');
                if (recentLoading) recentLoading.textContent = 'Recorded administrator audit events unavailable.';
            }
        } catch (error) {
            setTableMessage(tbody, 7, 'Administrator accounts could not be loaded.');
            setTableMessage(familyTbody, 5, 'Family administrator assignments could not be loaded.');
            for (const label of ['Platform administrators', 'Family administrators', 'MFA flags (not verified)', 'Last access review']) {
                setStatistic(label, 'Unavailable');
            }
            if (policyStatus) policyStatus.textContent = 'Unavailable';
            if (recentLoading) recentLoading.textContent = 'Recorded administrator audit events unavailable.';
            showToast(error.message);
        }
    }
    search?.addEventListener('input', () => {
        window.clearTimeout(timer);
        timer = window.setTimeout(() => {
            globalPage = 1;
            familyPage = 1;
            load();
        }, 250);
    });
    inviteButton?.addEventListener('click', (event) => {
        event.preventDefault();
        document.querySelector('#family-invitation-management')?.scrollIntoView({ behavior: 'smooth', block: 'start' });
        document.querySelector('#family-invite-email')?.focus({ preventScroll: true });
    });
    exportButton?.addEventListener('click', () => {
        downloadCsv('administrators.csv', [
            ['User ID', 'Email', 'Global role', 'Status', 'Last sign-in'],
            ...globalRecords.map((account) => [account.id, account.email, 'Super Admin', account.status, account.last_login_at]),
            ...familyRecords.map((account) => [account.user_id, account.email || '', `Family Admin · ${account.family_name}`, account.account_status, account.last_login_at])
        ]);
    });
    load();
}

function securityPage() {
    document.querySelector('.page-heading .subtitle')?.replaceChildren(
        document.createTextNode('Review authentication, session, login-attempt and audit information available in the backend.')
    );
    const eventList = document.querySelector('.system-timeline');
    const cards = [...document.querySelectorAll('.system-stat')];
    cards.forEach((card, index) => {
        const labels = ['Active account locks', 'Failed sign-ins (24h)', 'Super Admin MFA flags', 'MFA verification flow'];
        const label = card.querySelector('small');
        const value = card.querySelector('strong');
        if (label) label.textContent = labels[index] || label.textContent;
        if (value) value.textContent = 'Loading...';
    });
    document.querySelector('.page-heading .system-status')?.replaceChildren(document.createTextNode('Live status loading...'));
    document.querySelectorAll('.system-setting .system-status').forEach((status) => {
        status.textContent = 'Loading...';
    });
    document.querySelectorAll('.system-setting p').forEach((description) => {
        description.textContent = 'Loading verified backend configuration...';
    });
    const controlsStatus = [...document.querySelectorAll('.system-card')]
        .find((card) => card.querySelector('h2')?.textContent.trim() === 'Global protection controls')
        ?.querySelector('.system-card-head .system-status');
    if (controlsStatus) controlsStatus.textContent = 'Loading...';
    for (const title of ['Security review checklist', 'Incident response']) {
        const card = [...document.querySelectorAll('.system-card')]
            .find((item) => item.querySelector('h2')?.textContent.trim() === title);
        card?.querySelectorAll('.system-setting p, .system-kv strong, .system-setting .material-symbols-outlined').forEach((value) => {
            value.textContent = 'Unavailable: no review schedule or incident-response records are configured.';
        });
    }
    const control = new Map([
        ['HTTPS and secure cookie policy', 'secure_cookie'],
        ['Administrator MFA', 'mfa'],
        ['Login throttling and lockout', 'throttling'],
        ['Private file storage', 'private_storage'],
        ['Audit event recording', 'audit']
    ]);
    const controlsCard = [...document.querySelectorAll('.system-card')]
        .find((card) => card.querySelector('h2')?.textContent.trim() === 'Global protection controls');
    if (controlsCard) {
        const sessionLine = document.createElement('div');
        sessionLine.className = 'system-setting';
        const description = document.createElement('span');
        const title = document.createElement('strong');
        title.textContent = 'Session cookie flags';
        const detail = document.createElement('p');
        detail.textContent = 'Loading verified session configuration...';
        description.append(title, detail);
        const status = document.createElement('span');
        status.className = 'system-status';
        status.textContent = 'Loading...';
        sessionLine.append(description, status);
        controlsCard.append(sessionLine);
    }
    async function load() {
        try {
            const result = await requestAdminApi('security.php');
            const security = result.security;
            setStatistic('Active account locks', security.active_locked_accounts.toLocaleString());
            setStatistic('Failed sign-ins (24h)', security.failed_login_attempts_24h.toLocaleString());
            setStatistic('Super Admin MFA flags', security.mfa_flagged_super_admin_accounts.toLocaleString());
            setStatistic('MFA verification flow', 'Unavailable');
            const values = {
                secure_cookie: security.secure_cookie_configured && security.https_request ? 'Configured for HTTPS'
                    : 'HTTPS secure-cookie protection unavailable',
                mfa: 'Verification flow not implemented',
                throttling: security.login_throttling_enabled
                    ? `Enabled · ${security.login_throttle_limit} failures / ${security.login_throttle_window_minutes} minutes`
                    : 'Unavailable',
                private_storage: security.private_storage_outside_web_root
                    ? 'Verified outside web root' : 'Not verified outside web root',
                audit: security.audit_logging_available ? 'Available' : 'Unavailable'
            };
            const sessionLine = [...(controlsCard?.querySelectorAll('.system-setting') || [])]
                .find((line) => line.querySelector('strong')?.textContent.trim() === 'Session cookie flags');
            if (sessionLine) {
                sessionLine.querySelector('.system-status').textContent =
                    `SameSite ${security.same_site_cookie || 'unknown'}`;
                sessionLine.querySelector('p').textContent =
                    `HttpOnly ${security.http_only_cookie_configured ? 'enabled' : 'not enabled'}; Secure ${security.secure_cookie_configured ? 'enabled' : 'not enabled'}.`;
            }
            document.querySelectorAll('.system-setting').forEach((line) => {
                const key = control.get(line.querySelector('strong')?.textContent.trim());
                const status = line.querySelector('.system-status');
                const description = line.querySelector('p');
                if (key && status) status.textContent = values[key];
                if (key === 'mfa' && description) description.textContent = values.mfa;
                if (key === 'secure_cookie' && description) {
                    description.textContent = `Secure cookie: ${security.secure_cookie_configured ? 'configured' : 'not configured'}; current request HTTPS: ${security.https_request ? 'yes' : 'no'}.`;
                }
                if (key === 'throttling' && description) {
                    description.textContent = `Account lockout after ${security.login_throttle_limit} failures within ${security.login_throttle_window_minutes} minutes.`;
                }
                if (key === 'private_storage' && description) {
                    description.textContent = security.private_storage_outside_web_root
                        ? 'Configured path resolves outside the web document root.'
                        : 'Private storage location could not be verified outside the web root.';
                }
                if (key === 'audit' && description) {
                    description.textContent = security.audit_logging_available
                        ? 'Audit records are available for read-only review.'
                        : 'Audit records are unavailable.';
                }
            });
            if (controlsStatus) controlsStatus.textContent = 'Configuration checked';
            if (eventList) {
                eventList.replaceChildren();
                if (!result.recent_security_events.length) {
                    const empty = document.createElement('p');
                    empty.textContent = 'No recorded authentication events.';
                    eventList.append(empty);
                }
                document.querySelector('.page-heading .system-status')?.replaceChildren(
                    document.createTextNode('Security configuration loaded')
                );
                for (const event of result.recent_security_events) {
                    const item = document.createElement('div');
                    item.className = 'system-event';
                    const name = document.createElement('strong');
                    name.textContent = event.action.replaceAll('_', ' ');
                    const detail = document.createElement('small');
                    detail.textContent = `${formatDate(event.created_at)} · ${event.target_type || 'Authentication'}`;
                    item.append(name, detail);
                    eventList.append(item);
                }
            }
        } catch (error) {
            cards.forEach((card) => {
                const value = card.querySelector('strong');
                if (value) value.textContent = 'Unavailable';
            });
            document.querySelectorAll('.system-setting .system-status').forEach((status) => {
                status.textContent = 'Unavailable';
            });
            document.querySelectorAll('.system-setting p').forEach((description) => {
                description.textContent = 'Backend configuration unavailable.';
            });
            if (controlsStatus) controlsStatus.textContent = 'Unavailable';
            if (eventList) {
                eventList.replaceChildren();
                const unavailable = document.createElement('p');
                unavailable.textContent = 'Authentication events are unavailable.';
                eventList.append(unavailable);
            }
            document.querySelector('.page-heading .system-status')?.replaceChildren(
                document.createTextNode('Security data unavailable')
            );
            showToast(error.message);
        }
    }
    document.querySelectorAll('[data-toast]').forEach((button) => {
        if (/schedule/i.test(button.textContent)) {
            button.disabled = true;
            button.removeAttribute('data-toast');
        }
    });
    load();
}

function logsPage() {
    const tbody = document.querySelector('.system-table tbody');
    if (!tbody) return;
    const search = document.querySelector('input[aria-label="Search platform logs"]');
    const category = document.querySelector('select[aria-label="Log event category"]');
    const rangeButton = [...document.querySelectorAll('.system-toolbar button')].find((button) => button.textContent.includes('Last 7 days'));
    rangeButton?.removeAttribute('data-toast');
    const dateFilters = document.createElement('div');
    dateFilters.className = 'system-toolbar';
    const from = document.createElement('input');
    from.type = 'date';
    from.className = 'btn';
    from.setAttribute('aria-label', 'Log start date');
    const to = document.createElement('input');
    to.type = 'date';
    to.className = 'btn';
    to.setAttribute('aria-label', 'Log end date');
    dateFilters.append(from, to);
    category?.closest('.system-toolbar')?.after(dateFilters);
    if (category) {
        [...category.options].forEach((option, index) => {
            if (index === 0) option.value = 'all';
            if (index === 1) option.value = 'security';
            if (index === 2) option.value = 'admin';
            if (index > 2) {
                option.disabled = true;
                option.textContent += ' (not available)';
            }
        });
    }
    document.querySelectorAll('.system-stat').forEach((card) => {
        const label = card.querySelector('small');
        if (label?.textContent.trim() === 'Privileged actions') label.textContent = 'Super Admin actions';
    });
    for (const label of ['Events this month', 'Super Admin actions', 'Security events', 'Critical incidents']) setStatistic(label, 'Loading...');
    const buttons = [...document.querySelectorAll('.admin-row-actions button')];
    const previous = buttons.find((button) => button.textContent.trim() === 'Previous');
    const next = buttons.find((button) => button.textContent.trim() === 'Next');
    const exportButton = [...document.querySelectorAll('.page-heading button')].find((button) => button.textContent.includes('Export logs'));
    exportButton?.removeAttribute('data-toast');
    if (exportButton) exportButton.textContent = 'Export this page';
    document.querySelector('.page-heading .subtitle')?.replaceChildren(
        document.createTextNode('Review recorded audit and authentication events. Infrastructure health and backup events are not monitored here.')
    );
    const severityHeader = tbody.closest('table')?.querySelector('thead th:nth-child(2)');
    if (severityHeader) severityHeader.textContent = 'Category';
    const summary = tbody.closest('.system-table-wrap')?.nextElementSibling?.querySelector('span');
    let page = 1;
    let pages = 0;
    let records = [];
    let timer;
    async function load() {
        setTableMessage(tbody, 6, 'Loading audit records...');
        const params = new URLSearchParams({ page: String(page), per_page: '25' });
        if (search?.value.trim()) params.set('q', search.value.trim());
        if (category?.value && category.value !== 'all') params.set('category', category.value);
        if (from?.value) params.set('from', from.value);
        if (to?.value) params.set('to', to.value);
        try {
            const result = await requestAdminApi(`logs.php?${params}`);
            records = result.logs;
            pages = result.pagination.pages;
            tbody.replaceChildren();
            if (!records.length) setTableMessage(tbody, 6, 'No audit records match these filters.');
            for (const entry of records) {
                const row = document.createElement('tr');
                row.className = 'log-row';
                makeCell(row, formatDate(entry.created_at));
                const categoryCell = makeCell(row, /login_failed|account_locked|login_success|otp_failed|otp_locked|otp_verified|password_reset_completed/.test(entry.action) ? 'Security' : 'Audit');
                const badge = document.createElement('span');
                badge.className = 'system-status';
                badge.textContent = categoryCell.textContent;
                categoryCell.replaceChildren(badge);
                makeCell(row, entry.action.replaceAll('_', ' '));
                makeCell(row, entry.actor_user_id ? `User #${entry.actor_user_id}` : 'System');
                makeCell(row, entry.family_name || 'Global');
                makeCell(row, entry.target_type ? `${entry.target_type} #${entry.target_id ?? ''}` : `Audit #${entry.id}`);
                tbody.append(row);
            }
            if (summary) summary.textContent = result.pagination.total
                ? `Showing ${records.length} of ${result.pagination.total.toLocaleString()} records`
                : 'No audit records';
            if (previous) previous.disabled = page <= 1;
            if (next) next.disabled = page >= pages;
            const currentPage = document.querySelector('[data-log-page]');
            if (currentPage) currentPage.textContent = pages ? `Page ${page} of ${pages}` : 'No pages';
            for (const card of document.querySelectorAll('.system-stat')) {
                const label = card.querySelector('small')?.textContent.trim();
                const value = card.querySelector('strong');
                if (label === 'Events this month' && value) value.textContent = result.statistics.events_this_month.toLocaleString();
                if (label === 'Super Admin actions' && value) value.textContent = result.statistics.superadmin_actions_this_month.toLocaleString();
                if (label === 'Security events' && value) value.textContent = result.statistics.security_events_this_month.toLocaleString();
                if (label === 'Critical incidents' && value) value.textContent = 'Unavailable';
            }
        } catch (error) {
            setTableMessage(tbody, 6, 'Audit records could not be loaded.');
            if (summary) summary.textContent = 'Audit records unavailable';
            for (const label of ['Events this month', 'Super Admin actions', 'Security events', 'Critical incidents']) setStatistic(label, 'Unavailable');
            showToast(error.message);
        }
    }
    previous?.addEventListener('click', () => { if (page > 1) { page -= 1; load(); } });
    next?.addEventListener('click', () => { if (page < pages) { page += 1; load(); } });
    rangeButton?.addEventListener('click', () => {
        const today = new Date();
        const start = new Date(today);
        start.setDate(start.getDate() - 6);
        const toIsoDate = (date) => {
            const local = new Date(date.getTime() - date.getTimezoneOffset() * 60000);
            return local.toISOString().slice(0, 10);
        };
        from.value = toIsoDate(start);
        to.value = toIsoDate(today);
        page = 1;
        load();
    });
    [search, category, from, to].filter(Boolean).forEach((input) => {
        input.addEventListener(input === search ? 'input' : 'change', () => {
            window.clearTimeout(timer);
            timer = window.setTimeout(() => { page = 1; load(); }, 200);
        });
    });
    exportButton?.addEventListener('click', () => {
        downloadCsv('system-audit-logs.csv', [
            ['ID', 'Timestamp', 'Action', 'Actor user ID', 'Family', 'Target type', 'Target ID'],
            ...records.map((entry) => [entry.id, entry.created_at, entry.action, entry.actor_user_id, entry.family_name, entry.target_type, entry.target_id])
        ]);
    });
    load();
}

function markUnavailablePage() {
    const subtitle = document.querySelector('.page-heading .subtitle');
    if (subtitle) {
        subtitle.textContent = location.pathname.endsWith('/backup-and-restore.html')
            ? 'No supported backup or restore engine is configured for this installation.'
            : 'No database-backed system settings are configured for this installation.';
    }
    document.querySelectorAll('[data-toast]').forEach((control) => control.removeAttribute('data-toast'));
    document.querySelectorAll('[data-unavailable-control]').forEach((control) => {
        control.disabled = true;
        control.removeAttribute('data-toast');
    });
    document.querySelectorAll('button:not(.menu-toggle)').forEach((button) => {
        if (!button.closest('.side-nav')) button.disabled = true;
    });
    document.querySelectorAll('input, select, textarea').forEach((control) => {
        control.disabled = true;
        if (control.type === 'checkbox') control.checked = false;
        if (control.matches('input:not([type="checkbox"]), textarea')) control.value = '';
    });
    document.querySelectorAll('.system-table tbody').forEach((tbody) => {
        const row = document.createElement('tr');
        const cell = document.createElement('td');
        cell.colSpan = tbody.closest('table')?.querySelectorAll('thead th').length || 1;
        cell.textContent = 'Unavailable: no backend data source is implemented.';
        row.append(cell);
        tbody.replaceChildren(row);
    });
    document.querySelectorAll('.system-setting p').forEach((description) => {
        description.textContent = 'Not represented by a supported backend setting.';
    });
    document.querySelectorAll('.system-stat strong, .system-kv strong, .system-setting strong').forEach((value) => {
        value.textContent = 'Unavailable';
    });
    const notice = document.querySelector('.system-notice');
    if (notice) {
        notice.replaceChildren();
        const icon = document.createElement('span');
        icon.className = 'material-symbols-outlined';
        icon.textContent = 'info';
        const text = document.createElement('span');
        text.textContent = location.pathname.endsWith('/backup-and-restore.html')
            ? 'Backup and restore are unavailable: no verified backup engine, snapshot history, or safe restore workflow exists in the backend. No operation will be simulated.'
            : 'System settings are unavailable: there is no database-backed settings model or safe supported update endpoint. Private configuration cannot be edited from this page.';
        notice.append(icon, text);
    }
    document.querySelectorAll('.system-hero h2, .system-hero p:not(.eyebrow)').forEach((value) => {
        value.textContent = 'Unavailable — no backend operation is implemented.';
    });
}

async function loadSuperAdminOverview() {
    const metricCards = new Map();
    document.querySelectorAll('.system-stat').forEach((card) => {
        const label = card.querySelector('small')?.textContent.trim();
        const value = card.querySelector('strong');

        if (value && (label === 'Family archives' || label === 'User accounts')) {
            metricCards.set(label, value);
            value.textContent = 'Loading...';
        }
    });

    if (!metricCards.size) return;
    const storageCard = [...document.querySelectorAll('.system-stat')]
        .find((card) => card.querySelector('small')?.textContent.trim() === 'Protected storage');
    if (storageCard) {
        storageCard.querySelector('small').textContent = 'Tracked media storage';
        storageCard.querySelector('strong').textContent = 'Loading...';
    }
    const availabilityCard = [...document.querySelectorAll('.system-stat')]
        .find((card) => card.querySelector('small')?.textContent.trim() === '30-day availability');
    if (availabilityCard) {
        availabilityCard.querySelector('small').textContent = 'Availability monitoring';
        availabilityCard.querySelector('strong').textContent = 'Unavailable';
    }
    const headingStatus = document.querySelector('.page-heading .system-status');
    if (headingStatus) headingStatus.textContent = 'Live data loading...';
    const hero = document.querySelector('.system-hero');
    const heroTitle = hero?.querySelector('h2');
    const heroDescription = hero?.querySelector('p:not(.eyebrow)');
    if (heroTitle) heroTitle.textContent = 'Loading database status';
    if (heroDescription) heroDescription.textContent = 'Infrastructure monitoring and uptime measurements are unavailable.';
    const capacityCard = [...document.querySelectorAll('.system-card')]
        .find((card) => card.querySelector('h2')?.textContent.trim() === 'Infrastructure capacity');
    capacityCard?.querySelectorAll('.system-setting > strong').forEach((value) => {
        value.textContent = 'Unavailable';
    });
    capacityCard?.querySelectorAll('.system-progress').forEach((bar) => { bar.hidden = true; });
    const attention = [...document.querySelectorAll('.system-card')]
        .find((card) => card.querySelector('h2')?.textContent.trim() === 'Needs attention');
    attention?.querySelectorAll('.system-setting').forEach((row) => {
        row.replaceChildren();
        const message = document.createElement('p');
        message.textContent = 'Operational alerts are unavailable: no monitoring source is configured.';
        row.append(message);
    });
    const activityList = [...document.querySelectorAll('.system-card')]
        .find((card) => card.querySelector('h2')?.textContent.trim() === 'Platform activity')
        ?.querySelector('.system-timeline');
    if (activityList) {
        activityList.replaceChildren();
        const loading = document.createElement('p');
        loading.textContent = 'Loading audit events...';
        activityList.append(loading);
    }
    try {
        const response = await fetch(
            '../zip_extracted/public/api/admin/overview.php',
            {
                method: 'GET',
                credentials: 'same-origin',
                headers: {
                    'Accept': 'application/json'
                }
            }
        );

        if (!response.ok) {
            throw new Error(
                `Overview API returned HTTP ${response.status}`
            );
        }

        const result = await response.json();

        if (!result.success || !result.statistics) {
            throw new Error('Invalid overview API response');
        }

        const stats = result.statistics;

        const families = stats.total_families;
        const userAccounts = stats.total_user_accounts;
        if (
            !Number.isSafeInteger(families) || families < 0 ||
            !Number.isSafeInteger(userAccounts) || userAccounts < 0
        ) {
            throw new Error('Invalid overview statistics');
        }

        metricCards.get('Family archives').textContent = families.toLocaleString();
        metricCards.get('User accounts').textContent = userAccounts.toLocaleString();

        const mediaBytes = stats.tracked_media_bytes;
        if (!Number.isSafeInteger(mediaBytes) || mediaBytes < 0) {
            throw new Error('Invalid tracked media storage statistic');
        }
        if (storageCard) {
            const units = [
                ['GB', 1024 ** 3],
                ['MB', 1024 ** 2],
                ['KB', 1024],
                ['bytes', 1]
            ];
            const [unit, divisor] = units.find(([, size]) => mediaBytes >= size) || units[3];
            storageCard.querySelector('strong').textContent = unit === 'bytes'
                ? `${mediaBytes.toLocaleString()} bytes`
                : `${(mediaBytes / divisor).toFixed(2)} ${unit}`;
        }
        if (availabilityCard) {
            availabilityCard.querySelector('strong').textContent = 'Unavailable';
        }
        if (headingStatus) headingStatus.textContent = 'Live data loaded';
        if (heroTitle) heroTitle.textContent = 'Database-backed overview';

        const serviceRows = [...document.querySelectorAll('.system-setting')];
        serviceRows.forEach((row) => {
            const name = row.querySelector('strong')?.textContent.trim();
            const status = row.querySelector('.system-status');
            if (!status) return;
            status.textContent = name === 'Database' ? 'Available' : 'Not measured';
        });

        if (activityList) {
            activityList.replaceChildren();
            if (!Array.isArray(result.recent_activity) || result.recent_activity.length === 0) {
                const empty = document.createElement('p');
                empty.textContent = 'No audit events have been recorded.';
                activityList.append(empty);
            } else {
                for (const event of result.recent_activity) {
                    const item = document.createElement('div');
                    item.className = 'system-event';
                    const title = document.createElement('strong');
                    title.textContent = event.action.replaceAll('_', ' ');
                    const detail = document.createElement('small');
                    const actor = event.actor_user_id
                        ? `${event.actor_is_admin ? 'Super Admin' : 'User'} #${event.actor_user_id}`
                        : 'System';
                    detail.textContent = `${formatDate(event.created_at)} · ${event.family_name || 'Global'} · ${actor}`;
                    item.append(title, detail);
                    activityList.append(item);
                }
            }
        }

        console.info('Super Admin statistics loaded successfully.');
    } catch (error) {
        metricCards.forEach((value) => {
            value.textContent = 'Unavailable';
        });
        if (storageCard) storageCard.querySelector('strong').textContent = 'Unavailable';
        document.querySelectorAll('.system-setting .system-status').forEach((status) => {
            status.textContent = 'Unavailable';
        });
        if (activityList) {
            activityList.replaceChildren();
            const unavailable = document.createElement('p');
            unavailable.textContent = 'Audit events are unavailable.';
            activityList.append(unavailable);
        }
        if (headingStatus) headingStatus.textContent = 'Overview data unavailable';
        if (heroTitle) heroTitle.textContent = 'Live database status unavailable';
        showToast('Could not load dashboard statistics. Sign in as an active Super Admin and refresh.');
        console.error(
            'Could not load Super Admin overview:',
            error
        );
    }
}
if (location.pathname.endsWith('/family-entities.html')) familyPage();
if (location.pathname.endsWith('/administrators.html')) administratorsPage();
if (location.pathname.endsWith('/system-security.html')) securityPage();
if (location.pathname.endsWith('/system-logs.html')) logsPage();
if (location.pathname.endsWith('/backup-and-restore.html') || location.pathname.endsWith('/system-settings.html')) markUnavailablePage();

if (document.readyState === 'loading') {
    document.addEventListener(
        'DOMContentLoaded',
        loadSuperAdminOverview
    );
} else {
    loadSuperAdminOverview();
}