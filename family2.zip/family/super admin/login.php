<?php
declare(strict_types=1);

require_once __DIR__ . '/../zip_extracted/src/bootstrap.php';

$user = Auth::user();

$csrfToken = Security::csrfToken();
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=de bvice-width, initial-scale=1">
  <meta name="theme-color" content="#001d37">
  <title>Sign In | KinKeep Vault</title>
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&family=Material+Symbols+Outlined:wght,FILL@100..700,0..1&display=swap" rel="stylesheet">
  <link rel="stylesheet" href="system-pages.css">
  <link rel="stylesheet" href="login.css">
</head>
<body class="system-login">
  <main class="login-layout">
    <section class="login-panel" aria-labelledby="login-title">
      <div class="login-card">

        <span class="role-pill system-label">
          <span class="material-symbols-outlined" aria-hidden="true">verified_user</span>
          Secure account access
        </span>

        <h2 id="login-title">Welcome back</h2>
        <p class="login-subtitle">
          Sign in to continue to your KinKeep Vault account.
        </p>

        <form id="super-admin-login" novalidate>
          <input
            type="hidden"
            name="csrf_token"
            value="<?= htmlspecialchars($csrfToken, ENT_QUOTES, 'UTF-8') ?>"
          >

          <div class="login-field">
            <label for="email">Email address or phone number</label>
            <input
              id="email"
              name="email"
              type="text"
              autocomplete="username"
              placeholder="name@example.com"
              required
              autofocus
            >
          </div>

       
<div class="login-field">
  <label for="password">Password</label>

  <div class="password-input-wrap">
    <input
      id="password"
      name="password"
      type="password"
      autocomplete="current-password"
      placeholder="Enter your password"
      required
    >

    <button
      id="password-visibility"
      class="password-toggle"
      type="button"
      aria-label="Show password"
      aria-pressed="false"
      aria-controls="password"
    >
      <span class="material-symbols-outlined" aria-hidden="true">visibility</span>
    </button>
  </div>
</div>


          <p id="login-error" class="login-error" role="alert" hidden></p>

          <button id="login-submit" class="login-submit" type="submit">
            <span>Sign in securely</span>
            <span class="material-symbols-outlined" aria-hidden="true">arrow_forward</span>
          </button>
        </form>

        <section id="mfa-challenge" hidden aria-labelledby="mfa-challenge-title">
          <h3 id="mfa-challenge-title">Authenticator verification</h3>
          <p class="login-subtitle">Enter the current six-digit code from your authenticator app.</p>
          <form id="mfa-challenge-form" novalidate>
            <div class="login-field">
              <label for="authenticator-code">Authenticator code</label>
              <input id="authenticator-code" name="code" type="text" inputmode="numeric"
                autocomplete="one-time-code" pattern="[0-9]{6}" maxlength="6" required>
            </div>
            <p id="mfa-challenge-error" class="login-error" role="alert" hidden></p>
            <button id="mfa-challenge-submit" class="login-submit" type="submit">
              <span>Verify and sign in</span>
              <span class="material-symbols-outlined" aria-hidden="true">arrow_forward</span>
            </button>
          </form>
        </section>

        <section id="role-selection" hidden aria-labelledby="role-selection-title">
          <h3 id="role-selection-title">Choose where to continue</h3>
          <p id="role-selection-message" class="login-subtitle" role="status"></p>
          <div id="role-destinations" class="role-destinations"></div>
        </section>

        <p class="login-security">
          <span class="material-symbols-outlined" aria-hidden="true">lock</span>
          Your connection is protected with secure authentication.
        </p>
      </div>

      <a class="login-back" href="../zip_extracted/public/index.php">
        <span class="material-symbols-outlined" aria-hidden="true">arrow_back</span>
        Back to KinKeep Vault
      </a>
    </section>
  </main>

  <script>
    const form = document.querySelector('#super-admin-login');
    const submitButton = document.querySelector('#login-submit');
    const errorMessage = document.querySelector('#login-error');
    const roleSelection = document.querySelector('#role-selection');
    const roleSelectionMessage = document.querySelector('#role-selection-message');
    const roleDestinations = document.querySelector('#role-destinations');
    const loginSubtitle = document.querySelector('.login-subtitle');
    const mfaChallenge = document.querySelector('#mfa-challenge');
    const mfaForm = document.querySelector('#mfa-challenge-form');
    const mfaCode = document.querySelector('#authenticator-code');
    const mfaError = document.querySelector('#mfa-challenge-error');
    const mfaSubmit = document.querySelector('#mfa-challenge-submit');
    const loginHashParams = new URLSearchParams(window.location.hash.slice(1));
    const invitationToken = loginHashParams.get('invitation') || loginHashParams.get('token') || '';
    const invitationReturn = /^[a-f0-9]{64}$/i.test(invitationToken)
      ? `../accept-invitation.html#invitation=${encodeURIComponent(invitationToken)}`
      : '';

    function showLoginError(message) {
      errorMessage.textContent = message;
      errorMessage.hidden = false;
    }

    async function getAccountContext() {
      const response = await fetch('../zip_extracted/public/api/auth/me.php', {
        method: 'GET',
        credentials: 'same-origin',
        headers: { Accept: 'application/json' },
        cache: 'no-store'
      });
      const result = await response.json().catch(() => null);
      if (!response.ok || result?.success !== true || !result.user || !Array.isArray(result.families)) {
        throw new Error('Could not confirm your authorized account destinations. Please sign in again or contact support.');
      }
      return result;
    }

    function showDestinations(context) {
      const destinations = [];
      const hasFamilyConflict = context.families.some((family) => family.authorization_conflict === true);
      if (context.user.is_admin === true) {
        destinations.push({
          label: 'Super Admin dashboard',
          href: '../super%20admin/system-overview.html'
        });
      }

      for (const family of context.families) {
        if (family.authorization_conflict === true) {
          continue;
        }
        const familyId = Number(family.id);
        if (!Number.isSafeInteger(familyId) || familyId < 1 || typeof family.family_name !== 'string') {
          continue;
        }
        const query = `?family_id=${encodeURIComponent(familyId)}`;
        if (family.role === 'admin') {
          destinations.push({
            label: `Family Admin · ${family.family_name}`,
            href: `../family%20admin/admin-console.html${query}`
          });
        } else if (family.role === 'member') {
          destinations.push({
            label: `Family Member · ${family.family_name}`,
            href: `../family%20member/dashboard.html${query}`
          });
        }
      }

      if (!destinations.length && context.families.length === 0) {
        destinations.push({
          label: 'Find or join a family',
          href: '../family%20member/membership-onboarding.php'
        });
        roleSelectionMessage.textContent = 'Your account is active, but it has no approved family membership yet. Continue to find a family and request access.';
      } else if (!destinations.length) {
        roleSelectionMessage.textContent = hasFamilyConflict
          ? 'Family access records are inconsistent, so no family dashboard is available. Contact your family administrator.'
          : 'No supported dashboard role is available for this account. Viewer access is read-only and does not include a member dashboard. Contact your family administrator.';
      } else if (hasFamilyConflict) {
        roleSelectionMessage.textContent = 'Some family access records are inconsistent and have been omitted. Select another authorized destination or contact your family administrator.';
      } else {
        roleSelectionMessage.textContent = destinations.length === 1
          ? 'Your authorized destination is ready.'
          : 'This account has access to multiple roles or families. Select the one you want to open.';
      }

      roleDestinations.replaceChildren();
      for (const destination of destinations) {
        const link = document.createElement('a');
        link.className = 'login-submit role-destination';
        link.href = destination.href;
        link.textContent = destination.label;
        roleDestinations.append(link);
      }

      document.querySelector('#super-admin-login').hidden = true;
      loginSubtitle.hidden = true;
      roleSelection.hidden = false;
      if (destinations.length === 1) {
        window.location.assign(destinations[0].href);
      }
    }

    async function continueToAuthorizedDestination() {
      if (invitationReturn) {
        window.location.assign(invitationReturn);
        return;
      }
      submitButton.disabled = true;
      errorMessage.hidden = true;
      try {
        showDestinations(await getAccountContext());
      } catch (error) {
        showLoginError(error instanceof Error ? error.message : 'Could not confirm account access.');
        form.hidden = false;
        loginSubtitle.hidden = false;
        roleSelection.hidden = true;
        submitButton.disabled = false;
      }
    }

    form.addEventListener('submit', async (event) => {
      event.preventDefault();
      errorMessage.hidden = true;
      submitButton.disabled = true;

      try {
        const response = await fetch('../zip_extracted/public/api/auth/login.php', {
          method: 'POST',
          credentials: 'same-origin',
          headers: {
            'Content-Type': 'application/json',
            'X-CSRF-Token': form.elements.csrf_token.value
          },
          body: JSON.stringify({
            identifier: form.elements.email.value.trim(),
            password: form.elements.password.value,
            ...(invitationReturn ? { invitation_token: invitationToken } : {})
          })
        });

        const result = await response.json();

        if (!response.ok || !result.success) {
          if (response.status === 429) {
            throw new Error('Too many sign-in attempts. Please try again later.');
          }
          throw new Error(result.error || 'Unable to sign in. Check your credentials and try again.');
        }

        form.elements.password.value = '';
        if (result.verification_required === true && invitationReturn) {
          window.location.assign(`../verify-email.html#invitation=${encodeURIComponent(invitationToken)}`);
          return;
        }
        if (result.mfa_required === true) {
          form.hidden = true;
          loginSubtitle.hidden = true;
          roleSelection.hidden = true;
          mfaChallenge.hidden = false;
          mfaCode.focus();
          return;
        }
        await continueToAuthorizedDestination();
      } catch (error) {
        showLoginError(error instanceof Error
          ? error.message
          : 'A network error occurred. Please try again.');
        submitButton.disabled = false;
      }
    });

    mfaForm.addEventListener('submit', async (event) => {
      event.preventDefault();
      mfaError.hidden = true;
      mfaSubmit.disabled = true;
      try {
        const response = await fetch('../zip_extracted/public/api/auth/mfa_verify.php', {
          method: 'POST',
          credentials: 'same-origin',
          headers: {
            'Content-Type': 'application/json',
            'X-CSRF-Token': form.elements.csrf_token.value
          },
          body: JSON.stringify({ code: mfaCode.value.trim() })
        });
        const result = await response.json();
        mfaCode.value = '';
        if (!response.ok || !result.success) {
          throw new Error(result.error || `Verification failed (HTTP ${response.status}).`);
        }
        mfaChallenge.hidden = true;
        await continueToAuthorizedDestination();
      } catch (error) {
        const message = error instanceof Error ? error.message : 'Could not verify authenticator code.';
        if (message.includes('HTTP 401') || message.includes('HTTP 429')
            || /expired|sign in again|too many attempts/i.test(message)) {
          mfaChallenge.hidden = true;
          form.hidden = false;
          loginSubtitle.hidden = false;
          submitButton.disabled = false;
          showLoginError(message);
        } else {
          mfaError.textContent = message;
          mfaError.hidden = false;
        }
        mfaCode.value = '';
        if (!mfaChallenge.hidden) mfaCode.focus();
      } finally {
        mfaSubmit.disabled = false;
      }
    });

    if (new URLSearchParams(window.location.search).get('access') === 'denied') {
      showLoginError('You are not authorized to open that dashboard. Sign in with an account that has the required active role.');
    }

    if (<?= $user && $user['status'] === 'active' ? 'true' : 'false' ?>) {
      form.hidden = true;
      loginSubtitle.hidden = true;
      roleSelection.hidden = false;
      roleSelectionMessage.textContent = 'Checking your active session and authorized destinations…';
      continueToAuthorizedDestination();
    }

    
const passwordInput = document.querySelector('#password');
const passwordVisibilityButton = document.querySelector('#password-visibility');

passwordVisibilityButton.addEventListener('click', () => {
  const willShowPassword = passwordInput.type === 'password';

  passwordInput.type = willShowPassword ? 'text' : 'password';

  passwordVisibilityButton.setAttribute(
    'aria-label',
    willShowPassword ? 'Hide password' : 'Show password'
  );

  passwordVisibilityButton.setAttribute(
    'aria-pressed',
    String(willShowPassword)
  );

  passwordVisibilityButton.querySelector('.material-symbols-outlined').textContent =
    willShowPassword ? 'visibility_off' : 'visibility';
});

  </script>
</body>
</html>
