<?php
declare(strict_types=1);

require_once __DIR__ . '/../zip_extracted/src/bootstrap.php';
PageAccess::requireSuperAdminDashboard();

$page = basename((string) parse_url($_SERVER['REQUEST_URI'] ?? '', PHP_URL_PATH));
$allowedPages = [
    'administrators.html',
    'backup-and-restore.html',
    'family-entities.html',
    'system-logs.html',
    'system-security.html',
    'system-settings.html',
];

if (!in_array($page, $allowedPages, true) || !is_file(__DIR__ . DIRECTORY_SEPARATOR . $page)) {
    http_response_code(404);
    header('Content-Type: text/plain; charset=UTF-8');
    exit('Not Found');
}

header('Content-Type: text/html; charset=UTF-8');
require __DIR__ . DIRECTORY_SEPARATOR . $page;
