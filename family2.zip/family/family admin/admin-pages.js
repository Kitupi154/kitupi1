﻿/* FILE ORGANIZATION
 * 1. Sidebar open/close behavior
 * 2. Toast notifications
 * 3. Search/filter helpers
 * 4. Page-specific interactions (where present)
 */

const sidebar = document.querySelector('.sidebar');
const menuToggle = document.querySelector('.menu-toggle');
const toast = document.querySelector('.toast');
let toastTimeout;

async function logoutCurrentUser() {
  try {
    const tokenResponse = await fetch('../zip_extracted/public/index.php', {
      credentials: 'same-origin',
      headers: { Accept: 'application/json' }
    });
    const tokenJson = await tokenResponse.json().catch(() => null);
    if (!tokenResponse.ok || !tokenJson?.success || typeof tokenJson.csrf_token !== 'string' || tokenJson.csrf_token.length < 32) {
      throw new Error('Could not obtain a valid security token.');
    }
    const logoutResponse = await fetch('../zip_extracted/public/api/auth/logout.php', {
      method: 'POST',
      credentials: 'same-origin',
      headers: {
        Accept: 'application/json',
        'X-CSRF-Token': tokenJson.csrf_token,
        'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8'
      },
      body: new URLSearchParams({ csrf_token: tokenJson.csrf_token }).toString()
    });
    const logoutJson = await logoutResponse.json().catch(() => null);
    if (logoutResponse.ok && logoutJson?.success) {
      window.location.href = '../super admin/login.php';
      return;
    }
    throw new Error(logoutJson?.error || 'Logout failed.');
  } catch (error) {
    console.error('Logout failed:', error);
    window.location.href = '../super admin/login.php';
  }
}

function ensureSidebarLogoutButton() {
  if (!sidebar || sidebar.querySelector('.sidebar-logout')) return;
  const footer = sidebar.querySelector('.sidebar-footer');
  const button = document.createElement('button');
  button.type = 'button';
  button.className = 'sidebar-logout';
  button.innerHTML = '<span class="material-symbols-outlined">logout</span>Log out';
  button.addEventListener('click', logoutCurrentUser);
  if (footer) {
    footer.appendChild(button);
  } else {
    sidebar.appendChild(button);
  }
}

ensureSidebarLogoutButton();

menuToggle?.addEventListener('click', () => sidebar?.classList.toggle('open'));

document.addEventListener('click', (event) => {
  if (sidebar?.classList.contains('open') &&
      !sidebar.contains(event.target) &&
      !event.target.closest('.menu-toggle')) {
    sidebar.classList.remove('open');
  }
});

document.querySelectorAll('[data-toast]').forEach((button) => {
  button.addEventListener('click', () => {
    if (button.dataset.rosterFilter) return;
    if (!button.dataset.toast) return;
    if (!toast) return;
    toast.textContent = button.dataset.toast;
    toast.classList.add('visible');
    window.clearTimeout(toastTimeout);
    toastTimeout = window.setTimeout(() => toast.classList.remove('visible'), 2800);
  });
});

document.querySelectorAll('[data-filter]').forEach((input) => {
  const selector = input.dataset.filter;
  input.addEventListener('input', () => {
    document.querySelectorAll(selector).forEach((item) => {
      item.hidden = !item.textContent.toLowerCase().includes(input.value.toLowerCase());
    });
  });
});

document.querySelectorAll('[data-tab-group]').forEach((group) => {
  const buttons = group.querySelectorAll('[data-tab-target]');
  buttons.forEach((button) => {
    button.addEventListener('click', () => {
      buttons.forEach((tab) => {
        tab.classList.toggle('selected', tab === button);
        tab.setAttribute('aria-selected', String(tab === button));
      });
      const panelSelector = button.dataset.tabTarget;
      group.querySelectorAll('[data-tab-panel]').forEach((panel) => {
        panel.hidden = panel.dataset.tabPanel !== panelSelector;
      });
    });
  });
});

function membershipQueuePage() {
      const tableBody = document.querySelector('.admin-table tbody');
      const table = tableBody?.closest('table');
      const toolbar = table?.closest('.admin-card')?.querySelector('.admin-toolbar');
      if (!tableBody || !table || !toolbar) return;

      const apiBase = '../zip_extracted/public/api/';
      const message = document.createElement('p');
      message.className = 'subtitle';
      message.setAttribute('role', 'status');
      message.style.margin = '8px 0';
      const familyLabel = document.createElement('label');
      familyLabel.className = 'admin-search';
      familyLabel.append(document.createTextNode('Family '));
      const familySelect = document.createElement('select');
      familySelect.className = 'btn';
      familySelect.setAttribute('aria-label', 'Family to review requests for');
      familyLabel.append(familySelect);
      toolbar.prepend(familyLabel);
      toolbar.after(message);
      const notificationButton = document.querySelector('button[aria-label="Notifications"]');
      notificationButton?.removeAttribute('data-toast');
      if (notificationButton) {
        notificationButton.title = 'Membership request count is loaded from the database.';
      }
      const stats = [...document.querySelectorAll('.admin-stat')];
      stats.forEach((stat, index) => {
        const value = stat.querySelector('strong');
        if (value) value.textContent = index === 0 ? 'Loading...' : 'â€”';
      });

      const search = document.querySelector('input[aria-label="Search requests"]');
      const exportButton = [...document.querySelectorAll('.page-heading button')]
        .find((button) => button.textContent.includes('Export queue'));
      const enrollButton = [...document.querySelectorAll('.page-heading button')]
        .find((button) => button.textContent.includes('Enroll member'));
      if (exportButton) {
        exportButton.removeAttribute('data-toast');
        exportButton.disabled = true;
        exportButton.title = 'Load an authorized pending request list before exporting.';
      }
      if (enrollButton) {
        enrollButton.removeAttribute('data-toast');
        enrollButton.addEventListener('click', () => {
          location.href = 'member-roster.html?open=enroll';
        });
      }
      let csrfToken;
      let activeRequests = [];
      let requestsLoaded = false;

      async function request(path, options = {}) {
        const response = await fetch(apiBase + path, {
          ...options,
          credentials: 'same-origin',
          headers: { Accept: 'application/json', ...(options.headers || {}) }
        });
        let result;
        try {
          result = await response.json();
        } catch {
          throw new Error(`The server returned an invalid response (HTTP ${response.status}).`);
        }
        if (!response.ok || !result.success) {
          throw new Error(result.error || `Request failed (HTTP ${response.status}).`);
        }
        return result;
      }

      function setQueueMessage(text) {
        const row = document.createElement('tr');
        const cell = document.createElement('td');
        cell.colSpan = 7;
        cell.textContent = text;
        row.append(cell);
        tableBody.replaceChildren(row);
      }

      function renderRows() {
        tableBody.replaceChildren();
        const term = search?.value.trim().toLowerCase() || '';
        const requests = activeRequests.filter((item) =>
          `${item.first_name} ${item.middle_name || ''} ${item.last_name} ${item.email || ''} ${item.claimed_relationship}`
            .toLowerCase().includes(term)
        );
        if (!requests.length) {
          setQueueMessage(term ? 'No requests match this search.' : 'There are no pending requests for this family.');
          return;
        }

        for (const item of requests) {
          const row = document.createElement('tr');
          row.className = 'enrollment-row';
          const applicantCell = document.createElement('td');
          const applicant = document.createElement('div');
          applicant.className = 'admin-person';
          const initials = document.createElement('span');
          initials.className = 'avatar-sm';
          initials.textContent = `${item.first_name[0] || ''}${item.last_name[0] || ''}`.toUpperCase();
          const identity = document.createElement('span');
          const name = document.createElement('strong');
          name.textContent = `${item.first_name} ${item.middle_name ? `${item.middle_name} ` : ''}${item.last_name}`;
          const email = document.createElement('small');
          email.textContent = item.email || 'No email on profile';
          identity.append(name, email);
          applicant.append(initials, identity);
          applicantCell.append(applicant);
          row.append(applicantCell);

          const relationship = document.createElement('td');
          relationship.textContent = item.claimed_relationship;
          row.append(relationship);
          const target = document.createElement('td');
          target.textContent = item.target_member_name || 'â€”';
          row.append(target);
          const evidence = document.createElement('td');
          evidence.textContent = 'No evidence attached';
          row.append(evidence);
          const submitted = document.createElement('td');
          submitted.textContent = item.created_at;
          row.append(submitted);
          const age = document.createElement('td');
          const submittedAt = new Date(String(item.created_at).replace(' ', 'T'));
          const days = Number.isNaN(submittedAt.getTime())
            ? null
            : Math.max(0, Math.floor((Date.now() - submittedAt.getTime()) / 86400000));
          age.textContent = days === null ? 'â€”' : days === 0 ? 'Under 1 day' : `${days} days`;
          row.append(age);

          const actions = document.createElement('td');
          const actionGroup = document.createElement('div');
          actionGroup.className = 'admin-row-actions';
          const approve = document.createElement('button');
          approve.type = 'button';
          approve.className = 'btn small teal';
          approve.textContent = 'Approve';
          const reject = document.createElement('button');
          reject.type = 'button';
          reject.className = 'btn small danger';
          reject.textContent = 'Reject';
          const review = document.createElement('button');
          review.type = 'button';
          review.className = 'btn small';
          review.textContent = 'Review';
          review.addEventListener('click', () => {
            window.alert(item.reason || 'No additional reason was provided.');
          });

          async function decide(decision, button) {
            if (!window.confirm(`${decision === 'approved' ? 'Approve' : 'Reject'} this membership request?`)) return;
            approve.disabled = true;
            reject.disabled = true;
            button.textContent = 'Saving...';
            try {
              await request('family/membership_decision.php', {
                method: 'POST',
                headers: {
                  'Content-Type': 'application/json',
                  'X-CSRF-Token': csrfToken
                },
                body: JSON.stringify({
                  family_id: Number(familySelect.value),
                  request_id: Number(item.id),
                  decision
                })
              });
              message.textContent = `Request ${decision}.`;
              await loadRequests();
            } catch (error) {
              message.textContent = error.message;
              approve.disabled = false;
              reject.disabled = false;
              button.textContent = decision === 'approved' ? 'Approve' : 'Reject';
            }
          }

          approve.addEventListener('click', () => decide('approved', approve));
          reject.addEventListener('click', () => decide('rejected', reject));
          actionGroup.append(approve, review, reject);
          actions.append(actionGroup);
          row.append(actions);
          tableBody.append(row);
        }
      }

      function exportRequests() {
        const term = search?.value.trim().toLowerCase() || '';
        const requests = activeRequests.filter((item) =>
          `${item.first_name} ${item.middle_name || ''} ${item.last_name} ${item.email || ''} ${item.claimed_relationship}`
            .toLowerCase().includes(term)
        );
        if (!requestsLoaded || !familySelect.value) return;
        downloadAdminCsv('enrollment-requests.csv', [
          'request_id', 'family_id', 'applicant_member_id', 'first_name',
          'middle_name', 'last_name', 'email', 'claimed_relationship',
          'target_member_id', 'target_member_name', 'reason', 'submitted_at', 'status'
        ], requests.map((item) => [
          item.id, item.family_id, item.applicant_member_id, item.first_name,
          item.middle_name, item.last_name, item.email, item.claimed_relationship,
          item.target_member_id, item.target_member_name, item.reason, item.created_at, 'pending'
        ]));
      }
      exportButton?.addEventListener('click', exportRequests);

      async function loadRequests() {
        if (!familySelect.value) {
          activeRequests = [];
          requestsLoaded = false;
          if (exportButton) exportButton.disabled = true;
          setQueueMessage('No Family Admin assignment is available for this account.');
          return;
        }
        requestsLoaded = false;
        if (exportButton) exportButton.disabled = true;
        setQueueMessage('Loading membership requests...');
        const requestedFamilyId = familySelect.value;
        try {
          const result = await request(
            `family/membership_requests.php?family_id=${encodeURIComponent(requestedFamilyId)}`
          );
          if (requestedFamilyId !== familySelect.value) return;
          activeRequests = result.requests;
          requestsLoaded = true;
          if (exportButton) exportButton.disabled = false;
          const pendingStat = stats[0]?.querySelector('strong');
          if (pendingStat) pendingStat.textContent = String(activeRequests.length);
          renderRows();
        } catch (error) {
          if (requestedFamilyId !== familySelect.value) return;
          activeRequests = [];
          requestsLoaded = false;
          if (exportButton) exportButton.disabled = true;
          const pendingStat = stats[0]?.querySelector('strong');
          if (pendingStat) pendingStat.textContent = 'Unavailable';
          setQueueMessage(error.message);
        }
      }

      search?.addEventListener('input', renderRows);
      familySelect.addEventListener('change', loadRequests);

      (async () => {
        try {
          const auth = await request('auth/me.php');
          if (typeof auth.csrf_token !== 'string' || auth.csrf_token.length < 32) {
            throw new Error('Could not obtain a valid security token. Refresh and sign in again.');
          }
          csrfToken = auth.csrf_token;
          const result = await request('family/my_family.php');
          const adminFamilies = result.families.filter((family) =>
            family.role === 'admin' && family.status === 'active'
          );
          familySelect.replaceChildren();
          for (const family of adminFamilies) {
            const option = document.createElement('option');
            option.value = String(family.id);
            option.textContent = family.family_name;
            familySelect.append(option);
          }
          if (!adminFamilies.length) {
            familySelect.disabled = true;
            message.textContent = 'No active Family Admin assignment is available for this account.';
            setQueueMessage(message.textContent);
            return;
          }
          await loadRequests();
        } catch (error) {
          familySelect.disabled = true;
          message.textContent = error.message;
          setQueueMessage(error.message);
        }
      })();
    }

function memberRosterPage() {
  const tableBody = document.querySelector('.admin-table tbody');
  const table = tableBody?.closest('table');
  const headingActions = document.querySelector('.page-heading .heading-actions');
  const card = table?.closest('.admin-card');
  if (!tableBody || !table || !headingActions || !card) return;

  const apiBase = '../zip_extracted/public/api/';
  const message = document.createElement('p');
  message.className = 'subtitle';
  message.setAttribute('role', 'status');
  message.setAttribute('aria-live', 'polite');
  message.style.margin = '8px 0';
  card.prepend(message);
  const initialRow = document.createElement('tr');
  const initialCell = document.createElement('td');
  initialCell.colSpan = 7;
  initialCell.textContent = 'Checking Family Admin access...';
  initialRow.append(initialCell);
  tableBody.replaceChildren(initialRow);

  const familyLabel = document.createElement('label');
  familyLabel.className = 'admin-search';
  familyLabel.append(document.createTextNode('Family '));
  const familySelect = document.createElement('select');
  familySelect.className = 'btn';
  familySelect.setAttribute('aria-label', 'Family to manage members for');
  familyLabel.append(familySelect);
  card.querySelector('.admin-toolbar')?.prepend(familyLabel);

  const addButton = document.createElement('button');
  addButton.type = 'button';
  addButton.className = 'btn primary';
  addButton.textContent = 'Add member profile';
  headingActions.append(addButton);
  const exportButton = [...headingActions.querySelectorAll('button')]
    .find((button) => button.textContent.includes('Export roster'));
  if (exportButton) {
    exportButton.removeAttribute('data-toast');
    exportButton.disabled = true;
    exportButton.title = 'Load an authorized roster before exporting.';
  }
  const enrollLink = [...headingActions.querySelectorAll('a')]
    .find((link) => link.textContent.includes('Enroll member'));
  if (enrollLink) enrollLink.href = 'member-roster.html?open=enroll';

  const addDialog = document.createElement('dialog');
  addDialog.className = 'admin-card';
  const addHeading = document.createElement('h2');
  addHeading.textContent = 'Add family member profile';
  const addMessage = document.createElement('p');
  addMessage.className = 'subtitle';
  addMessage.setAttribute('role', 'status');
  const addForm = document.createElement('form');
  const addFields = document.createElement('div');
  addFields.className = 'admin-toolbar';
  const createInput = (form, name, labelText, type = 'text', required = false) => {
    const label = document.createElement('label');
    label.className = 'admin-search';
    label.append(document.createTextNode(labelText));
    const input = document.createElement('input');
    input.name = name;
    input.type = type;
    input.required = required;
    if (type === 'text') input.maxLength = 100;
    label.append(input);
    form.append(label);
    return input;
  };
  const createFirst = createInput(addFields, 'first_name', 'First name', 'text', true);
  createInput(addFields, 'middle_name', 'Middle name');
  createInput(addFields, 'preferred_name', 'Preferred name');
  createInput(addFields, 'last_name', 'Last name', 'text', true);
  const genderLabel = document.createElement('label');
  genderLabel.className = 'admin-search';
  genderLabel.append(document.createTextNode('Gender'));
  const genderSelect = document.createElement('select');
  genderSelect.name = 'gender';
  for (const [value, label] of [
    ['unspecified', 'Unspecified'],
    ['female', 'Female'],
    ['male', 'Male'],
    ['other', 'Other']
  ]) {
    const option = document.createElement('option');
    option.value = value;
    option.textContent = label;
    genderSelect.append(option);
  }
  genderLabel.append(genderSelect);
  addFields.append(genderLabel);
  createInput(addFields, 'date_of_birth', 'Date of birth', 'date');
  createInput(addFields, 'invitee_email', 'Invitee email', 'email');
  addForm.append(addFields);
  const addActions = document.createElement('div');
  addActions.className = 'admin-row-actions';
  const saveNewButton = document.createElement('button');
  saveNewButton.type = 'submit';
  saveNewButton.className = 'btn primary';
  saveNewButton.textContent = 'Create profile';
  const cancelAddButton = document.createElement('button');
  cancelAddButton.type = 'button';
  cancelAddButton.className = 'btn';
  cancelAddButton.textContent = 'Close';
  addActions.append(saveNewButton, cancelAddButton);
  addForm.append(addActions);
  addDialog.append(addHeading, addMessage, addForm);
  document.body.append(addDialog);

  const profileDialog = document.createElement('dialog');
  profileDialog.className = 'admin-card';
  const profileHeading = document.createElement('h2');
  profileHeading.textContent = 'Member profile';
  const profileMessage = document.createElement('p');
  profileMessage.className = 'subtitle';
  profileMessage.setAttribute('role', 'status');
  const profileContent = document.createElement('div');
  const profileActions = document.createElement('div');
  profileActions.className = 'admin-row-actions';
  const closeProfileButton = document.createElement('button');
  closeProfileButton.type = 'button';
  closeProfileButton.className = 'btn';
  closeProfileButton.textContent = 'Close';
  profileActions.append(closeProfileButton);
  profileDialog.append(profileHeading, profileMessage, profileContent, profileActions);
  document.body.append(profileDialog);

  let csrfToken = '';
  let members = [];
  let identityStatuses = new Map();
  let identityStatusAvailable = false;
  let relationshipCounts = new Map();
  let relationshipDataAvailable = false;
  let selectedFamilyId = '';
  let statusFilter = 'all';
  let membersLoaded = false;
  const search = document.querySelector('input[aria-label="Search members"]');
  const initialSearch = new URLSearchParams(window.location.search).get('q');
  if (search && initialSearch) search.value = initialSearch.slice(0, 100);
  const statValues = [...document.querySelectorAll('.admin-stat strong')];
  const statusTabs = [...document.querySelectorAll('.admin-tabs button')];
  const statusTabValues = ['all', 'active', 'pending', 'unclaimed'];
  const statusTabLabels = ['All', 'Active', 'Pending', 'Unclaimed'];
  statValues.forEach((value) => { value.textContent = 'â€”'; });
  statusTabs.forEach((button, index) => {
    button.dataset.rosterFilter = statusTabValues[index] || 'all';
    button.removeAttribute('data-toast');
    button.textContent = `${statusTabLabels[index] || 'All'} â€”`;
    button.addEventListener('click', () => {
      statusFilter = button.dataset.rosterFilter;
      statusTabs.forEach((tab) => {
        const selected = tab === button;
        tab.classList.toggle('selected', selected);
        tab.setAttribute('aria-selected', String(selected));
      });
      currentPage = 0;
      renderMembers();
    });
  });
  const roleFilter = document.querySelector('select[aria-label="Filter by family role"]');
  if (roleFilter) {
    const roleValues = ['all', 'admin', 'member', 'viewer'];
    [...roleFilter.options].forEach((option, index) => {
      option.value = roleValues[index] || 'all';
    });
    roleFilter.disabled = false;
    roleFilter.title = 'Filter profiles by their role within the selected family.';
  }
  const pagination = table.parentElement?.nextElementSibling;
  const paginationLabel = pagination?.querySelector('span');
  const paginationButtons = [...(pagination?.querySelectorAll('button') || [])];
  const previousPageButton = paginationButtons.find((button) => button.textContent.trim() === 'Previous');
  const nextPageButton = paginationButtons.find((button) => button.textContent.trim() === 'Next');
  const pageSize = 10;
  let currentPage = 0;
  if (paginationLabel) paginationLabel.textContent = 'Loading family members...';
  for (const button of [previousPageButton, nextPageButton]) {
    button?.removeAttribute('data-toast');
    if (button) button.disabled = true;
  }

  async function request(path, options = {}) {
    const response = await fetch(apiBase + path, {
      ...options,
      credentials: 'same-origin',
      headers: { Accept: 'application/json', ...(options.headers || {}) }
    });
    let result;
    try {
      result = await response.json();
    } catch {
      throw new Error(`The server returned an invalid response (HTTP ${response.status}).`);
    }
    if (!response.ok || !result.success) {
      throw new Error(result.error || `Request failed (HTTP ${response.status}).`);
    }
    return result;
  }

  function setRosterMessage(text, isError = false) {
    message.textContent = text;
    message.setAttribute('role', isError ? 'alert' : 'status');
  }

  function getVisibleMembers() {
    const term = search?.value.trim().toLowerCase() || '';
    return members.filter((member) =>
      (statusFilter === 'all' || member.member_status === statusFilter) &&
      (!roleFilter || roleFilter.value === 'all' || member.role === roleFilter.value) &&
      `${member.first_name} ${member.middle_name || ''} ${member.preferred_name || ''} ${member.last_name}`
        .toLowerCase().includes(term)
    );
  }

  function renderMembers() {
    tableBody.replaceChildren();
    const visibleMembers = getVisibleMembers();
    const pageCount = Math.ceil(visibleMembers.length / pageSize);
    currentPage = pageCount ? Math.min(currentPage, pageCount - 1) : 0;
    const startIndex = currentPage * pageSize;
    const endIndex = Math.min(startIndex + pageSize, visibleMembers.length);
    if (paginationLabel) {
      paginationLabel.textContent = visibleMembers.length
        ? `Showing ${startIndex + 1} to ${endIndex} of ${visibleMembers.length} members`
        : 'Showing 0 to 0 of 0 members';
    }
    if (previousPageButton) previousPageButton.disabled = !membersLoaded || currentPage === 0;
    if (nextPageButton) nextPageButton.disabled = !membersLoaded || currentPage + 1 >= pageCount;

    if (!visibleMembers.length) {
      const row = document.createElement('tr');
      const cell = document.createElement('td');
      cell.colSpan = 7;
      cell.textContent = members.length
        ? 'No members match this search.'
        : 'There are no member profiles for this family.';
      row.append(cell);
      tableBody.append(row);
      return;
    }

    for (const member of visibleMembers.slice(startIndex, endIndex)) {
      const row = document.createElement('tr');
      row.className = 'roster-row';

      const memberCell = document.createElement('td');
      const person = document.createElement('div');
      person.className = 'admin-person';
      const avatar = document.createElement('span');
      avatar.className = 'avatar-sm';
      avatar.textContent = `${member.first_name?.[0] || ''}${member.last_name?.[0] || ''}`.toUpperCase();
      const identity = document.createElement('span');
      const name = document.createElement('strong');
      const legalName = `${member.first_name || ''} ${member.middle_name ? `${member.middle_name} ` : ''}${member.last_name || ''}`.trim();
      name.textContent = member.preferred_name ? `${member.preferred_name} (${legalName})` : legalName;
      const email = document.createElement('small');
      email.textContent = 'Open profile to see information available to your role';
      identity.append(name, email);
      person.append(avatar, identity);
      memberCell.append(person);
      row.append(memberCell);

      const relationshipCell = document.createElement('td');
      if (!relationshipDataAvailable) {
        relationshipCell.textContent = 'Unavailable';
      } else {
        const linkCount = relationshipCounts.get(String(member.id)) || 0;
        relationshipCell.textContent = linkCount
          ? `${linkCount} approved link${linkCount === 1 ? '' : 's'}`
          : 'No approved links';
      }
      row.append(relationshipCell);

      const identityCell = document.createElement('td');
      const verificationStatus = identityStatusAvailable
        ? (identityStatuses.get(String(member.id)) || 'not submitted')
        : 'unavailable';
      const identityPill = document.createElement('span');
      identityPill.className = `pill ${verificationStatus === 'verified' ? 'teal' : verificationStatus === 'pending' ? 'gold' : verificationStatus === 'rejected' ? 'red' : 'blue'}`;
      identityPill.textContent = verificationStatus.replaceAll('_', ' ');
      identityCell.append(identityPill);
      row.append(identityCell);

      const statusCell = document.createElement('td');
      const status = document.createElement('span');
      status.className = 'pill';
      const memberStatus = String(member.member_status || 'unknown');
      status.classList.add(memberStatus === 'active' ? 'teal' :
        memberStatus === 'pending' ? 'gold' : 'blue');
      status.textContent = memberStatus.replaceAll('_', ' ');
      statusCell.append(status);
      row.append(statusCell);

      const roleCell = document.createElement('td');
      roleCell.textContent = member.role
        ? member.role.charAt(0).toUpperCase() + member.role.slice(1)
        : 'Unassigned';
      row.append(roleCell);
      const joinedCell = document.createElement('td');
      joinedCell.textContent = member.created_at || 'â€”';
      row.append(joinedCell);

      const actionsCell = document.createElement('td');
      const viewButton = document.createElement('button');
      viewButton.type = 'button';
      viewButton.className = 'btn small';
      viewButton.textContent = 'View';
      viewButton.addEventListener('click', () => viewProfile(String(member.id), viewButton));
      actionsCell.append(viewButton);
      row.append(actionsCell);
      tableBody.append(row);
    }
  }

  exportButton?.addEventListener('click', () => {
    if (!membersLoaded || !selectedFamilyId) return;
    downloadAdminCsv('member-roster.csv', [
      'member_id', 'family_id', 'first_name', 'middle_name', 'preferred_name', 'last_name',
      'member_status', 'joined_at'
    ], getVisibleMembers().map((member) => [
      member.id, selectedFamilyId, member.first_name, member.middle_name,
      member.preferred_name, member.last_name, member.member_status, member.created_at
    ]));
  });
  previousPageButton?.addEventListener('click', () => {
    if (currentPage === 0) return;
    currentPage -= 1;
    renderMembers();
  });
  nextPageButton?.addEventListener('click', () => {
    if (currentPage + 1 >= Math.ceil(getVisibleMembers().length / pageSize)) return;
    currentPage += 1;
    renderMembers();
  });

  async function loadMembers() {
    selectedFamilyId = familySelect.value;
    const requestedFamilyId = selectedFamilyId;
    currentPage = 0;
    if (previousPageButton) previousPageButton.disabled = true;
    if (nextPageButton) nextPageButton.disabled = true;
    if (!selectedFamilyId) {
      members = [];
      membersLoaded = false;
      if (exportButton) exportButton.disabled = true;
      renderMembers();
      return;
    }
    membersLoaded = false;
    if (exportButton) exportButton.disabled = true;
    tableBody.replaceChildren();
    const loadingRow = document.createElement('tr');
    const loadingCell = document.createElement('td');
    loadingCell.colSpan = 7;
    loadingCell.textContent = 'Loading family members...';
    loadingRow.append(loadingCell);
    tableBody.append(loadingRow);
    try {
      const result = await request(
        `members/list.php?family_id=${encodeURIComponent(selectedFamilyId)}`
      );
      if (requestedFamilyId !== familySelect.value) return;
      members = Array.isArray(result.members) ? result.members : [];
      identityStatuses = new Map();
      identityStatusAvailable = false;
      relationshipCounts = new Map();
      relationshipDataAvailable = false;
      try {
        const identityResult = await request(
          `identity/family_status.php?family_id=${encodeURIComponent(selectedFamilyId)}`
        );
        if (requestedFamilyId !== familySelect.value) return;
        for (const verification of identityResult.verifications || []) {
          const id = String(verification.member_id ?? '');
          if (id && !identityStatuses.has(id)) {
            identityStatuses.set(id, String(verification.status || 'pending'));
          }
        }
        identityStatusAvailable = true;
      } catch {
        identityStatuses = new Map();
      }
      try {
        const relationshipResult = await request(
          `relationships/list.php?family_id=${encodeURIComponent(selectedFamilyId)}`
        );
        if (requestedFamilyId !== familySelect.value) return;
        for (const relationship of relationshipResult.relationships || []) {
          if (relationship.status !== 'approved'
              || Number(relationship.family_id) !== Number(selectedFamilyId)) continue;
          for (const memberId of [relationship.person_id, relationship.related_person_id]) {
            const key = String(memberId ?? '');
            if (key) relationshipCounts.set(key, (relationshipCounts.get(key) || 0) + 1);
          }
        }
        relationshipDataAvailable = true;
      } catch {
        relationshipCounts = new Map();
      }
      if (requestedFamilyId !== familySelect.value) return;
      membersLoaded = true;
      if (exportButton) exportButton.disabled = false;
      const counts = {
        total: members.length,
        verified: identityStatusAvailable
          ? members.filter((member) => identityStatuses.get(String(member.id)) === 'verified').length
          : null,
        pending: members.filter((member) => member.member_status === 'pending').length,
        unclaimed: members.filter((member) => member.member_status === 'unclaimed').length
      };
      if (statValues[0]) statValues[0].textContent = String(counts.total);
      if (statValues[1]) statValues[1].textContent = counts.verified === null ? 'â€”' : String(counts.verified);
      if (statValues[2]) statValues[2].textContent = String(counts.pending);
      if (statValues[3]) statValues[3].textContent = String(counts.unclaimed);
      const tabCounts = [counts.total,
        members.filter((member) => member.member_status === 'active').length,
        counts.pending,
        counts.unclaimed];
      statusTabs.forEach((button, index) => {
        button.textContent = `${statusTabLabels[index] || 'All'} ${tabCounts[index] ?? 0}`;
      });
      setRosterMessage(`${counts.total} member profile${counts.total === 1 ? '' : 's'} loaded.${identityStatusAvailable ? '' : ' Identity review status is unavailable.'}${relationshipDataAvailable ? '' : ' Approved relationship counts are unavailable.'}`);
      renderMembers();
    } catch (error) {
      if (requestedFamilyId !== familySelect.value) return;
      members = [];
      membersLoaded = false;
      if (exportButton) exportButton.disabled = true;
      if (paginationLabel) paginationLabel.textContent = 'Roster unavailable';
      if (previousPageButton) previousPageButton.disabled = true;
      if (nextPageButton) nextPageButton.disabled = true;
      for (const value of statValues) value.textContent = 'â€”';
      statusTabs.forEach((button, index) => {
        button.textContent = `${statusTabLabels[index] || 'All'} â€”`;
      });
      tableBody.replaceChildren();
      const row = document.createElement('tr');
      const cell = document.createElement('td');
      cell.colSpan = 7;
      cell.textContent = error.message;
      row.append(cell);
      tableBody.append(row);
      setRosterMessage(error.message, true);
    }
  }

  async function viewProfile(memberId, button) {
    button.disabled = true;
    profileMessage.textContent = 'Loading profile...';
    profileContent.replaceChildren();
    profileActions.replaceChildren(closeProfileButton);
    profileDialog.showModal();
    try {
      const result = await request(
        `members/profile.php?member_id=${encodeURIComponent(memberId)}`
      );
      if (String(result.member?.family_id) !== selectedFamilyId) {
        throw new Error('This profile is not part of the selected family.');
      }
      renderProfile(result.member);
    } catch (error) {
      profileMessage.textContent = error.message;
    } finally {
      button.disabled = false;
    }
  }

  function renderProfile(member) {
    profileContent.replaceChildren();
    profileActions.replaceChildren(closeProfileButton);
    const fullDetails = member.profile_detail_access === true
      || member.profile_detail_access === 1
      || member.profile_detail_access === '1';
    profileMessage.textContent = fullDetails
      ? ''
      : 'Only basic directory details are available. The profile owner must grant access to personal details.';
    const details = document.createElement('dl');
    details.className = 'admin-kv';
    const fields = [
      ['First name', member.first_name],
      ['Middle name', member.middle_name],
      ['Preferred name', member.preferred_name],
      ['Last name', member.last_name],
      ['Family', member.family_name],
      ['Status', member.member_status]
    ];
    if (fullDetails) fields.splice(3, 0,
      ['Gender', member.gender],
      ['Date of birth', member.date_of_birth],
      ['Email', member.email],
      ['Phone', member.phone],
      ['Bio', member.bio]
    );
    for (const [label, value] of fields) {
      const term = document.createElement('dt');
      term.textContent = label;
      const description = document.createElement('dd');
      description.textContent = value || 'â€”';
      details.append(term, description);
    }
    profileContent.append(details);
    const editButton = document.createElement('button');
    editButton.type = 'button';
    editButton.className = 'btn primary';
    editButton.textContent = fullDetails ? 'Edit profile' : 'Edit directory name';
    editButton.addEventListener('click', () => renderProfileEditor(member, fullDetails));
    profileActions.prepend(editButton);
  }

  function renderProfileEditor(member, fullDetails) {
    profileContent.replaceChildren();
    profileMessage.textContent = '';
    const form = document.createElement('form');
    const fields = document.createElement('div');
    fields.className = 'admin-toolbar';
    const fieldsToEdit = [
      ['first_name', 'First name'],
      ['middle_name', 'Middle name'],
      ['preferred_name', 'Preferred name'],
      ['last_name', 'Last name']
    ];
    if (fullDetails) fieldsToEdit.push(['bio', 'Bio'], ['phone', 'Phone'], ['email', 'Email']);
    for (const [name, label] of fieldsToEdit) {
      const input = name === 'bio'
        ? document.createElement('textarea')
        : document.createElement('input');
      const fieldLabel = document.createElement('label');
      fieldLabel.className = 'admin-search';
      fieldLabel.append(document.createTextNode(label));
      input.name = name;
      if (name === 'bio') {
        input.maxLength = 5000;
        input.rows = 3;
      } else {
        input.type = name === 'email' ? 'email' : 'text';
        input.maxLength = name === 'email' ? 190 : name === 'phone' ? 30 : 100;
      }
      input.value = member[name] || '';
      if (name === 'first_name' || name === 'last_name') input.required = true;
      fieldLabel.append(input);
      fields.append(fieldLabel);
    }
    form.append(fields);
    const actions = document.createElement('div');
    actions.className = 'admin-row-actions';
    const saveButton = document.createElement('button');
    saveButton.type = 'submit';
    saveButton.className = 'btn primary';
    saveButton.textContent = 'Save profile';
    const cancelButton = document.createElement('button');
    cancelButton.type = 'button';
    cancelButton.className = 'btn';
    cancelButton.textContent = 'Cancel';
    actions.append(saveButton, cancelButton);
    form.append(actions);
    profileContent.append(form);

    cancelButton.addEventListener('click', () => renderProfile(member));
    form.addEventListener('submit', async (event) => {
      event.preventDefault();
      saveButton.disabled = true;
      saveButton.textContent = 'Saving...';
      profileMessage.textContent = '';
      try {
        if (String(member.family_id) !== familySelect.value) {
          throw new Error('The selected family changed. Reload the profile before saving.');
        }
        const body = Object.fromEntries(new FormData(form).entries());
        body.member_id = String(member.id);
        await request('members/update.php', {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            'X-CSRF-Token': csrfToken
          },
          body: JSON.stringify(body)
        });
        profileMessage.textContent = 'Profile updated successfully.';
        await loadMembers();
        renderProfile({ ...member, ...body });
      } catch (error) {
        profileMessage.textContent = error.message;
        saveButton.disabled = false;
        saveButton.textContent = 'Save profile';
      }
    });
  }

  function openAddDialog() {
    addMessage.textContent = '';
    addDialog.showModal();
    createFirst.focus();
  }
  addButton.addEventListener('click', openAddDialog);
  cancelAddButton.addEventListener('click', () => addDialog.close());
  closeProfileButton.addEventListener('click', () => profileDialog.close());
  familySelect.addEventListener('change', loadMembers);
  search?.addEventListener('input', () => { currentPage = 0; renderMembers(); });
  roleFilter?.addEventListener('change', () => { currentPage = 0; renderMembers(); });

  addForm.addEventListener('submit', async (event) => {
    event.preventDefault();
    if (!familySelect.value) return;
    saveNewButton.disabled = true;
    saveNewButton.textContent = 'Creating...';
    addMessage.textContent = '';
    try {
      const body = Object.fromEntries(new FormData(addForm).entries());
      body.family_id = Number(familySelect.value);
      const data = await request('members/create.php', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'X-CSRF-Token': csrfToken
        },
        body: JSON.stringify(body)
      });
      addMessage.textContent = data.message || 'Member profile created successfully.';
      addForm.reset();
      await loadMembers();
    } catch (error) {
      addMessage.textContent = error.message;
    } finally {
      saveNewButton.disabled = false;
      saveNewButton.textContent = 'Create profile';
    }
  });

  (async () => {
    addButton.disabled = true;
    try {
      const auth = await request('auth/me.php');
      if (typeof auth.csrf_token !== 'string' || auth.csrf_token.length < 32) {
        throw new Error('Could not obtain a valid security token. Refresh and sign in again.');
      }
      csrfToken = auth.csrf_token;
      const result = await request('family/my_family.php');
      const adminFamilies = result.families.filter((family) =>
        family.role === 'admin' && family.status === 'active'
      );
      familySelect.replaceChildren();
      for (const family of adminFamilies) {
        const option = document.createElement('option');
        option.value = String(family.id);
        option.textContent = family.family_name;
        familySelect.append(option);
      }
      if (!adminFamilies.length) {
        familySelect.disabled = true;
        addButton.disabled = true;
        setRosterMessage('No active Family Admin assignment is available for this account.', true);
        tableBody.replaceChildren();
        return;
      }
      addButton.disabled = false;
      const requestedFamilyId = new URLSearchParams(window.location.search).get('family_id');
      if (requestedFamilyId && adminFamilies.some((family) => String(family.id) === requestedFamilyId)) {
        familySelect.value = requestedFamilyId;
      }
      await loadMembers();
      if (new URLSearchParams(location.search).get('open') === 'enroll') {
        history.replaceState(null, '', location.pathname);
        openAddDialog();
      }
    } catch (error) {
      familySelect.disabled = true;
      addButton.disabled = true;
      tableBody.replaceChildren();
      setRosterMessage(error.message, true);
    }
  })();
}

if (location.pathname.endsWith('/enrollment-requests.html')) {
  membershipQueuePage();
}

if (location.pathname.endsWith('/member-roster.html')) {
  memberRosterPage();
}

const ADMIN_API_BASE = '../zip_extracted/public/api/';

async function adminApiRequest(path, options = {}) {
  const response = await fetch(ADMIN_API_BASE + path, {
    ...options,
    credentials: 'same-origin',
    headers: { Accept: 'application/json', ...(options.headers || {}) }
  });
  let result;
  try {
    result = await response.json();
  } catch {
    throw new Error(`The server returned an invalid response (HTTP ${response.status}).`);
  }
  if (!response.ok || !result.success) {
    throw new Error(result.error || `Request failed (HTTP ${response.status}).`);
  }
  return result;
}

async function getAdminFamilies() {
  const result = await adminApiRequest('family/my_family.php');
  return result.families.filter((family) =>
    family.status === 'active' && family.role === 'admin'
  );
}

function setAdminNotice(container, text, isError = false) {
  const notice = document.createElement('p');
  notice.className = 'subtitle';
  notice.setAttribute('role', isError ? 'alert' : 'status');
  notice.textContent = text;
  container.prepend(notice);
  return notice;
}

function disableUnbackedAdminAction(button, reason) {
  if (!button) return;
  button.removeAttribute('data-toast');
  button.disabled = false;
  button.disabled = true;
  button.title = reason;
}

function downloadAdminCsv(filename, headers, rows) {
  const escapeCell = (value) => {
    const rawText = value == null ? '' : String(value);
    const text = /^[\t\r\n ]*[=+\-@]/.test(rawText) ? `'${rawText}` : rawText;
    return `"${text.replaceAll('"', '""')}"`;
  };
  const content = [headers, ...rows]
    .map((row) => row.map(escapeCell).join(','))
    .join('\r\n');
  const blob = new Blob(['\uFEFF', content], { type: 'text/csv;charset=utf-8' });
  const url = URL.createObjectURL(blob);
  const link = document.createElement('a');
  link.href = url;
  link.download = filename;
  link.hidden = true;
  document.body.append(link);
  link.click();
  link.remove();
  window.setTimeout(() => URL.revokeObjectURL(url), 0);
}

function adminRelationshipPage() {
  const proposalCard = [...document.querySelectorAll('.admin-card')]
    .find((card) => card.querySelector('h2')?.textContent.trim() === 'Relationship proposals');
  const proposalList = proposalCard?.querySelector('.stack');
  const addButton = [...document.querySelectorAll('.page-heading button')]
    .find((button) => button.textContent.includes('Add relationship'));
  if (!proposalCard || !proposalList || !addButton) return;

  proposalList.replaceChildren();
  const proposalNotice = setAdminNotice(proposalCard, 'Loading relationship proposals...');
  const stats = [...document.querySelectorAll('.admin-stat')];
  const approvedStat = stats.find((stat) => stat.querySelector('small')?.textContent.includes('Approved'));
  const pendingStat = stats.find((stat) => stat.querySelector('small')?.textContent.includes('Pending'));
  const generationsStat = stats.find((stat) => stat.querySelector('small')?.textContent.includes('Generations'));
  const conflictsStat = stats.find((stat) => stat.querySelector('small')?.textContent.includes('Conflict'));
  const approvedValue = approvedStat?.querySelector('strong');
  const pendingValue = pendingStat?.querySelector('strong');
  const generationsValue = generationsStat?.querySelector('strong');
  const conflictsValue = conflictsStat?.querySelector('strong');
  if (generationsValue) generationsValue.textContent = 'â€”';
  if (conflictsValue) conflictsValue.textContent = 'â€”';
  const generationsLabel = generationsStat?.querySelector('small');
  const conflictsLabel = conflictsStat?.querySelector('small');
  if (generationsLabel) generationsLabel.textContent = 'Maximum parent/child depth';
  if (conflictsLabel) conflictsLabel.textContent = 'Structural conflicts detected';
  const pendingPill = proposalCard.querySelector('.pill');
  if (pendingPill) pendingPill.textContent = 'Loading...';
  const overview = [...document.querySelectorAll('.admin-card')]
    .find((card) => card.querySelector('h2')?.textContent.trim() === 'Lineage overview');
  const lineage = overview?.querySelector('.tree-lineage');
  if (overview) {
    const subtitle = overview.querySelector('.admin-card-header p');
    if (subtitle) subtitle.textContent = 'Approved relationships in active Family Admin families';
  }
  if (lineage) {
    lineage.replaceChildren();
  }
  const dataQuality = [...document.querySelectorAll('.admin-card')]
    .find((card) => card.querySelector('h2')?.textContent.trim() === 'Data quality review');
  if (dataQuality) {
    dataQuality.querySelectorAll('.admin-setting').forEach((item) => item.remove());
    const subtitle = dataQuality.querySelector('.admin-card-header p');
    if (subtitle) subtitle.textContent = 'Derived from approved parent and child links; spouse and guardian links do not define generation depth.';
    setAdminNotice(dataQuality, 'Potential structural issues are calculated from authorized relationship records.');
  }
  const treeButton = [...document.querySelectorAll('.page-heading button')]
    .find((button) => button.textContent.includes('View tree'));
  if (treeButton) {
    treeButton.removeAttribute('data-toast');
    treeButton.addEventListener('click', () => overview?.scrollIntoView({ behavior: 'smooth' }));
    treeButton.title = 'View approved relationships listed below.';
  }

  const dialog = document.createElement('dialog');
  dialog.className = 'admin-card';
  const title = document.createElement('h2');
  title.textContent = 'Submit relationship proposal';
  const status = document.createElement('p');
  status.className = 'subtitle';
  status.setAttribute('role', 'status');
  const form = document.createElement('form');
  form.style.cssText = 'display:grid;gap:12px';
  const familySelect = document.createElement('select');
  familySelect.className = 'btn';
  familySelect.setAttribute('aria-label', 'Family');
  const personSelect = document.createElement('select');
  personSelect.className = 'btn';
  personSelect.setAttribute('aria-label', 'First family member');
  const relatedSelect = document.createElement('select');
  relatedSelect.className = 'btn';
  relatedSelect.setAttribute('aria-label', 'Related family member');
  const typeSelect = document.createElement('select');
  typeSelect.className = 'btn';
  typeSelect.setAttribute('aria-label', 'Relationship type');
  for (const [value, label] of [
    ['parent', 'Parent'],
    ['child', 'Child'],
    ['spouse', 'Spouse'],
    ['guardian', 'Guardian']
  ]) {
    const option = document.createElement('option');
    option.value = value;
    option.textContent = label;
    typeSelect.append(option);
  }
  const addSelectField = (labelText, control) => {
    const label = document.createElement('label');
    label.className = 'admin-search';
    label.append(document.createTextNode(labelText), control);
    form.append(label);
  };
  addSelectField('Family', familySelect);
  addSelectField('Person', personSelect);
  addSelectField('Related person', relatedSelect);
  addSelectField('Relationship type', typeSelect);
  const actions = document.createElement('div');
  actions.className = 'admin-row-actions';
  const submit = document.createElement('button');
  submit.type = 'submit';
  submit.className = 'btn primary';
  submit.textContent = 'Submit proposal';
  const close = document.createElement('button');
  close.type = 'button';
  close.className = 'btn';
  close.textContent = 'Close';
  actions.append(submit, close);
  form.append(actions, status);
  dialog.append(title, form);
  document.body.append(dialog);

  let csrfToken = '';
  let families = [];
  let relationshipRows = [];
  let reviewAvailable = false;
  const valueText = (value) => value == null ? '' : String(value);
  const memberName = (relationship, prefix) => [
    relationship[`${prefix}_first_name`],
    relationship[`${prefix}_last_name`]
  ].map(valueText).filter(Boolean).join(' ') || 'Unknown member';

  function addMessage(container, text, isError = false) {
    const message = document.createElement('p');
    message.className = 'subtitle';
    message.setAttribute('role', isError ? 'alert' : 'status');
    message.textContent = text;
    container.append(message);
  }

  function deriveLineageHealth(approvedRows) {
    const familiesById = new Map();
    let duplicateAssertions = 0;
    let selfLinks = 0;
    for (const row of approvedRows) {
      let parentId;
      let childId;
      if (row.relationship_type === 'parent') {
        parentId = String(row.person_id);
        childId = String(row.related_person_id);
      } else if (row.relationship_type === 'child') {
        parentId = String(row.related_person_id);
        childId = String(row.person_id);
      } else {
        continue;
      }
      if (!parentId || !childId || parentId === 'undefined' || childId === 'undefined') continue;
      if (parentId === childId) {
        selfLinks++;
        continue;
      }
      const familyId = String(row.family_id);
      if (!familiesById.has(familyId)) {
        familiesById.set(familyId, { adjacency: new Map(), indegree: new Map(), edgeKeys: new Set() });
      }
      const graph = familiesById.get(familyId);
      const edgeKey = `${parentId}:${childId}`;
      if (graph.edgeKeys.has(edgeKey)) {
        duplicateAssertions++;
        continue;
      }
      graph.edgeKeys.add(edgeKey);
      if (!graph.adjacency.has(parentId)) graph.adjacency.set(parentId, new Set());
      graph.adjacency.get(parentId).add(childId);
      graph.indegree.set(parentId, graph.indegree.get(parentId) || 0);
      graph.indegree.set(childId, (graph.indegree.get(childId) || 0) + 1);
    }

    let maxDepth = 0;
    let cyclicMembers = 0;
    for (const graph of familiesById.values()) {
      const depth = new Map([...graph.indegree.keys()].map((memberId) => [memberId, 1]));
      const queue = [...graph.indegree.entries()]
        .filter(([, incoming]) => incoming === 0)
        .map(([memberId]) => memberId);
      let processed = 0;
      while (queue.length) {
        const parentId = queue.shift();
        processed++;
        maxDepth = Math.max(maxDepth, depth.get(parentId) || 1);
        for (const childId of graph.adjacency.get(parentId) || []) {
          depth.set(childId, Math.max(depth.get(childId) || 1, (depth.get(parentId) || 1) + 1));
          graph.indegree.set(childId, graph.indegree.get(childId) - 1);
          if (graph.indegree.get(childId) === 0) queue.push(childId);
        }
      }
      cyclicMembers += graph.indegree.size - processed;
    }
    return {
      maxDepth,
      duplicateAssertions,
      selfLinks,
      cyclicMembers,
      conflicts: duplicateAssertions + selfLinks + cyclicMembers
    };
  }

  function renderDataQuality(approvedRows, pendingRows) {
    if (generationsValue || conflictsValue) {
      const health = deriveLineageHealth(approvedRows);
      if (generationsValue) generationsValue.textContent = health.cyclicMembers ? 'Review' : String(health.maxDepth);
      if (conflictsValue) conflictsValue.textContent = String(health.conflicts);
      const indicatorValues = [health.duplicateAssertions, health.selfLinks, health.cyclicMembers, pendingRows.length];
      const indicatorNames = ['Duplicate parent/child assertions', 'Self-referential links', 'Members affected by parent/child cycles', 'Pending proposals'];
      if (dataQuality) {
        dataQuality.querySelectorAll('.admin-setting').forEach((item) => item.remove());
        for (let index = 0; index < indicatorValues.length; index++) {
          const row = document.createElement('div');
          row.className = 'admin-setting';
          const detail = document.createElement('span');
          const heading = document.createElement('strong');
          heading.textContent = indicatorNames[index];
          const description = document.createElement('p');
          description.textContent = index === 3
            ? 'Relationship proposals awaiting an administrator decision.'
            : 'Calculated from approved parent and child assertions only.';
          detail.append(heading, description);
          const badge = document.createElement('span');
          badge.className = `pill ${indicatorValues[index] ? 'gold' : 'teal'}`;
          badge.textContent = indicatorValues[index] ? `${indicatorValues[index]} review` : 'Clear';
          row.append(detail, badge);
          dataQuality?.append(row);
        }
      }
    }
  }

  function renderRelationships() {
    proposalList.replaceChildren();
    if (lineage) lineage.replaceChildren();
    const pending = relationshipRows.filter((relationship) => relationship.status === 'pending');
    const approved = relationshipRows.filter((relationship) => relationship.status === 'approved');
    renderDataQuality(approved, pending);
    if (approvedValue) approvedValue.textContent = String(approved.length);
    if (pendingValue) pendingValue.textContent = String(pending.length);
    if (pendingPill) pendingPill.textContent = `${pending.length} pending`;

    if (!pending.length) addMessage(proposalList, 'There are no pending relationship proposals.');
    for (const relationship of pending) {
      const article = document.createElement('article');
      article.className = 'member-card';
      article.style.alignItems = 'flex-start';
      const content = document.createElement('div');
      content.style.width = '100%';
      const person = document.createElement('div');
      person.className = 'admin-person';
      const identity = document.createElement('span');
      identity.className = 'avatar-sm';
      identity.textContent = memberName(relationship, 'person').split(/\s+/).map((part) => part[0] || '').join('').slice(0, 2).toUpperCase();
      const identityText = document.createElement('span');
      const name = document.createElement('strong');
      name.textContent = memberName(relationship, 'person');
      const status = document.createElement('small');
      const family = families.find((item) => Number(item.id) === Number(relationship.family_id));
      status.textContent = `Pending proposal${family ? ` Â· ${valueText(family.family_name)}` : ''}`;
      identityText.append(name, status);
      person.append(identity, identityText);
      const link = document.createElement('div');
      link.className = 'admin-kv';
      const linkLabel = document.createElement('span');
      linkLabel.textContent = 'Proposed link';
      const linkValue = document.createElement('strong');
      linkValue.textContent = `${memberName(relationship, 'person')} â†’ ${memberName(relationship, 'related')} (${valueText(relationship.relationship_type) || 'unspecified'})`;
      link.append(linkLabel, linkValue);
      content.append(person, link);
      if (relationship.created_at) {
        const submitted = document.createElement('div');
        submitted.className = 'admin-kv';
        const submittedLabel = document.createElement('span');
        submittedLabel.textContent = 'Submitted';
        const submittedValue = document.createElement('strong');
        submittedValue.textContent = valueText(relationship.created_at);
        submitted.append(submittedLabel, submittedValue);
        content.append(submitted);
      }
      const actions = document.createElement('div');
      actions.className = 'admin-row-actions';
      actions.style.marginTop = '11px';
      for (const [decision, label, className] of [
        ['approved', 'Approve', 'btn small teal'],
        ['rejected', 'Reject', 'btn small danger']
      ]) {
        const button = document.createElement('button');
        button.type = 'button';
        button.className = className;
        button.textContent = label;
        button.disabled = !reviewAvailable;
        button.addEventListener('click', () => decideRelationship(relationship, decision, button));
        actions.append(button);
      }
      content.append(actions);
      article.append(content);
      proposalList.append(article);
    }

    if (lineage) {
      if (!approved.length) addMessage(lineage, 'No approved relationships are available for these families.');
      for (const relationship of approved) {
        const entry = document.createElement('div');
        entry.className = 'tree-entry';
        const link = document.createElement('strong');
        link.textContent = `${memberName(relationship, 'person')} â†’ ${memberName(relationship, 'related')}`;
        const details = document.createElement('small');
        const family = families.find((item) => Number(item.id) === Number(relationship.family_id));
        details.textContent = `${valueText(relationship.relationship_type) || 'Relationship'} Â· Approved${family ? ` Â· ${valueText(family.family_name)}` : ''}`;
        entry.append(link, details);
        lineage.append(entry);
      }
    }
  }

  async function decideRelationship(relationship, decision, button) {
    if (relationship.status !== 'pending' || !reviewAvailable) return;
    const person = memberName(relationship, 'person');
    const related = memberName(relationship, 'related');
    const verb = decision === 'approved' ? 'approve' : 'reject';
    if (!window.confirm(`Are you sure you want to ${verb} the relationship proposal ${person} â†’ ${related}?`)) return;
    const family = families.find((item) => Number(item.id) === Number(relationship.family_id));
    if (!family || family.status !== 'active' || family.role !== 'admin') return;
    button.disabled = true;
    proposalNotice.textContent = `Saving decision for ${person} â†’ ${related}...`;
    proposalNotice.setAttribute('role', 'status');
    try {
      await adminApiRequest('relationships/decision.php', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'X-CSRF-Token': csrfToken
        },
        body: JSON.stringify({
          family_id: Number(family.id),
          relationship_id: Number(relationship.id),
          decision
        })
      });
      await loadRelationshipRows();
      proposalNotice.textContent = `Proposal ${decision}. Relationship data refreshed.`;
    } catch (error) {
      proposalNotice.textContent = error.message;
      proposalNotice.setAttribute('role', 'alert');
      button.disabled = false;
    }
  }

  async function loadRelationshipRows() {
    const results = await Promise.all(families.map(async (family) => {
      const result = await adminApiRequest(
        `relationships/list.php?family_id=${encodeURIComponent(family.id)}`
      );
      if (!Array.isArray(result.relationships)) {
        throw new Error('The relationship list response is incomplete.');
      }
      return result.relationships;
    }));
    relationshipRows = results.flat().filter((relationship) =>
      relationship.status === 'pending' || relationship.status === 'approved'
    );
    renderRelationships();
  }

  function populateMemberOptions() {
    const family = families.find((item) => String(item.id) === familySelect.value);
    const members = (family?.members || []).filter((member) => member.member_status === 'active');
    for (const select of [personSelect, relatedSelect]) {
      select.replaceChildren();
      for (const member of members) {
        const option = document.createElement('option');
        option.value = String(member.id);
        option.textContent = `${member.first_name} ${member.last_name}`;
        select.append(option);
      }
    }
    submit.disabled = members.length < 2;
  }
  familySelect.addEventListener('change', populateMemberOptions);
  addButton.removeAttribute('data-toast');
  addButton.addEventListener('click', () => {
    if (!families.length || !csrfToken) return;
    status.textContent = '';
    populateMemberOptions();
    dialog.showModal();
  });
  close.addEventListener('click', () => dialog.close());
  form.addEventListener('submit', async (event) => {
    event.preventDefault();
    if (!familySelect.value || personSelect.value === relatedSelect.value) {
      status.textContent = 'Select two different active family members.';
      return;
    }
    submit.disabled = true;
    submit.textContent = 'Submitting...';
    try {
      const result = await adminApiRequest('relationships/create.php', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'X-CSRF-Token': csrfToken
        },
        body: JSON.stringify({
          family_id: Number(familySelect.value),
          person_id: Number(personSelect.value),
          related_person_id: Number(relatedSelect.value),
          relationship_type: typeSelect.value
        })
      });
      status.textContent = result.message || 'Relationship proposal submitted.';
      form.reset();
      dialog.close();
      await loadRelationshipRows();
      proposalNotice.textContent = 'Proposal submitted. Relationship data refreshed.';
    } catch (error) {
      status.textContent = error.message;
    } finally {
      submit.disabled = false;
      submit.textContent = 'Submit proposal';
    }
  });

  (async () => {
    try {
      const auth = await adminApiRequest('auth/me.php');
      if (typeof auth.csrf_token !== 'string' || auth.csrf_token.length < 32) {
        throw new Error('A valid security token is not available. Reload and sign in again.');
      }
      csrfToken = auth.csrf_token;
      families = await getAdminFamilies();
      reviewAvailable = families.length > 0;
      familySelect.replaceChildren();
      for (const family of families) {
        const option = document.createElement('option');
        option.value = String(family.id);
        option.textContent = valueText(family.family_name) || `Family ${family.id}`;
        familySelect.append(option);
      }
      if (!families.length) {
        addButton.disabled = true;
        addButton.title = 'An active Family Admin family is required to create or review proposals.';
        proposalNotice.textContent = 'No active Family Admin assignment is available.';
        proposalNotice.setAttribute('role', 'alert');
        if (approvedValue) approvedValue.textContent = '0';
        if (pendingValue) pendingValue.textContent = '0';
        if (pendingPill) pendingPill.textContent = '0 pending';
        addMessage(proposalList, 'No active Family Admin family is available to load proposals.');
        if (lineage) addMessage(lineage, 'No active Family Admin family is available to load approved relationships.');
        return;
      }
      populateMemberOptions();
      await loadRelationshipRows();
      proposalNotice.textContent = `${relationshipRows.length} relationship record${relationshipRows.length === 1 ? '' : 's'} loaded.`;
    } catch (error) {
      reviewAvailable = false;
      addButton.disabled = true;
      addButton.title = 'Relationship proposals are unavailable until family authorization and data load successfully.';
      proposalNotice.textContent = error.message;
      proposalNotice.setAttribute('role', 'alert');
      proposalList.replaceChildren();
      addMessage(proposalList, 'Relationship proposals could not be loaded. Review actions are unavailable.', true);
      if (lineage) {
        lineage.replaceChildren();
        addMessage(lineage, 'Approved relationships could not be loaded.', true);
      }
      if (approvedValue) approvedValue.textContent = 'â€”';
      if (pendingValue) pendingValue.textContent = 'â€”';
      if (pendingPill) pendingPill.textContent = 'Unavailable';
    }
  })();
}

function adminAuditPage() {
  const tableBody = document.querySelector('.admin-table tbody');
  if (!tableBody) return;
  const table = tableBody.closest('table');
  const toolbar = table?.closest('.admin-card')?.querySelector('.admin-toolbar');
  if (!toolbar) return;

  const familyLabel = document.createElement('label');
  familyLabel.className = 'admin-search';
  familyLabel.append(document.createTextNode('Family '));
  const familySelect = document.createElement('select');
  familySelect.className = 'btn';
  familySelect.setAttribute('aria-label', 'Family audit log');
  familyLabel.append(familySelect);
  toolbar.prepend(familyLabel);
  const search = document.querySelector('input[aria-label="Search audit log"]');
  const category = document.querySelector('select[aria-label="Filter event category"]');
  const dateButton = [...toolbar.querySelectorAll('button')].find((button) => button.textContent.includes('Last 30 days'));
  const dateRanges = [30, 7, 90, 0];
  let dateRangeIndex = 0;
  if (dateButton) {
    dateButton.removeAttribute('data-toast');
    dateButton.title = 'Change the audit date range';
    dateButton.addEventListener('click', () => {
      dateRangeIndex = (dateRangeIndex + 1) % dateRanges.length;
      const days = dateRanges[dateRangeIndex];
      dateButton.textContent = days === 0 ? 'All time' : `Last ${days} days`;
      resetAndLoad();
    });
  }
  const pager = toolbar.closest('.admin-card');
  const previousButton = [...(pager?.querySelectorAll('button') || [])]
    .find((button) => button.textContent.trim() === 'Previous');
  const nextButton = [...(pager?.querySelectorAll('button') || [])]
    .find((button) => button.textContent.trim() === 'Next');
  const exportButton = [...document.querySelectorAll('.page-heading button')]
    .find((button) => button.textContent.includes('Export logs'));
  if (exportButton) {
    exportButton.removeAttribute('data-toast');
    exportButton.disabled = true;
    exportButton.title = 'Load an authorized audit event list before exporting.';
  }
  let logs = [];
  let logsLoaded = false;
  let hasMoreLogs = false;
  let loadSequence = 0;
  const cursors = [null];
  let cursorIndex = 0;
  const stats = [...document.querySelectorAll('.admin-stat strong')];
  stats.forEach((value) => { value.textContent = 'â€”'; });
  const statLabels = [...document.querySelectorAll('.admin-stat small')];
  if (statLabels[0]) statLabels[0].textContent = 'Events on this page';
  const message = setAdminNotice(table.closest('.admin-card'), 'Loading family audit events...');
  const footerSummary = table.closest('.admin-card')
    ?.querySelector('div[style*="justify-content:space-between"] span');
  if (footerSummary) footerSummary.textContent = 'Loading recent events...';

  function getVisibleLogs() { return logs; }

  function render() {
    tableBody.replaceChildren();
    const visible = getVisibleLogs();
    if (!visible.length) {
      const row = document.createElement('tr');
      const cell = document.createElement('td');
      cell.colSpan = 6;
      cell.textContent = logs.length ? 'No events match these filters.' : 'No audit events were returned for this family.';
      row.append(cell);
      tableBody.append(row);
      return;
    }
    for (const log of visible) {
      const row = document.createElement('tr');
      row.className = 'audit-row';
      for (const value of [
        log.created_at || 'â€”',
        log.actor_user_id ? `User #${log.actor_user_id}` : 'System',
        log.action || 'â€”',
        log.target_type ? `${log.target_type}${log.target_id ? ` #${log.target_id}` : ''}` : 'â€”',
        'â€”',
        'â€”'
      ]) {
        const cell = document.createElement('td');
        cell.textContent = value;
        row.append(cell);
      }
      tableBody.append(row);
    }
  }
  exportButton?.addEventListener('click', () => {
    if (!logsLoaded || !familySelect.value) return;
    downloadAdminCsv('family-audit-logs.csv', [
      'event_id', 'family_id', 'actor_user_id', 'action',
      'target_type', 'target_id', 'created_at'
    ], getVisibleLogs().map((log) => [
      log.id, familySelect.value, log.actor_user_id, log.action,
      log.target_type, log.target_id, log.created_at
    ]));
  });

  async function loadLogs() {
    if (!familySelect.value) return;
    const requestedFamilyId = familySelect.value;
    const sequence = ++loadSequence;
    logsLoaded = false;
    if (exportButton) exportButton.disabled = true;
    if (previousButton) previousButton.disabled = true;
    if (nextButton) nextButton.disabled = true;
    tableBody.replaceChildren();
    const loading = document.createElement('tr');
    const cell = document.createElement('td');
    cell.colSpan = 6;
    cell.textContent = 'Loading audit events...';
    loading.append(cell);
    tableBody.append(loading);
    try {
      const cursor = cursors[cursorIndex];
      const params = new URLSearchParams({
        family_id: requestedFamilyId,
        limit: '50',
        days: String(dateRanges[dateRangeIndex]),
        category: category?.value || 'All activity',
        q: search?.value.trim() || ''
      });
      if (cursor) params.set('before_id', cursor);
      const result = await adminApiRequest(
        `audit/list.php?${params.toString()}`
      );
      if (sequence !== loadSequence || requestedFamilyId !== familySelect.value) return;
      logs = Array.isArray(result.logs) ? result.logs : [];
      hasMoreLogs = result.has_more === true;
      logsLoaded = true;
      if (exportButton) exportButton.disabled = false;
      if (previousButton) previousButton.disabled = cursorIndex === 0;
      if (nextButton) nextButton.disabled = !hasMoreLogs;
      if (stats[0]) stats[0].textContent = String(logs.length);
      message.textContent = `${logs.length} matching event${logs.length === 1 ? '' : 's'} loaded on this page.`;
      if (footerSummary) footerSummary.textContent = `${logs.length} event${logs.length === 1 ? '' : 's'} on page ${cursorIndex + 1}`;
      render();
    } catch (error) {
      if (sequence !== loadSequence || requestedFamilyId !== familySelect.value) return;
      logs = [];
      logsLoaded = false;
      if (exportButton) exportButton.disabled = true;
      if (previousButton) previousButton.disabled = true;
      if (nextButton) nextButton.disabled = true;
      message.textContent = error.message;
      message.setAttribute('role', 'alert');
      if (footerSummary) footerSummary.textContent = 'Audit events unavailable.';
      render();
    }
  }
  function resetAndLoad() {
    cursors.splice(0, cursors.length, null);
    cursorIndex = 0;
    hasMoreLogs = false;
    loadLogs();
  }
  previousButton?.removeAttribute('data-toast');
  nextButton?.removeAttribute('data-toast');
  previousButton?.addEventListener('click', () => {
    if (cursorIndex === 0) return;
    cursorIndex -= 1;
    loadLogs();
  });
  nextButton?.addEventListener('click', () => {
    if (!hasMoreLogs) return;
    cursors[cursorIndex + 1] = logs.length ? String(logs[logs.length - 1].id) : null;
    cursorIndex += 1;
    loadLogs();
  });
  familySelect.addEventListener('change', () => {
    resetAndLoad();
  });
  let searchTimer;
  search?.addEventListener('input', () => {
    clearTimeout(searchTimer);
    searchTimer = setTimeout(resetAndLoad, 250);
  });
  category?.addEventListener('change', resetAndLoad);
  (async () => {
    try {
      const families = await getAdminFamilies();
      familySelect.replaceChildren();
      for (const family of families) {
        const option = document.createElement('option');
        option.value = String(family.id);
        option.textContent = family.family_name;
        familySelect.append(option);
      }
      if (!families.length) throw new Error('No active Family Admin assignment is available.');
      await loadLogs();
    } catch (error) {
      message.textContent = error.message;
      message.setAttribute('role', 'alert');
    }
  })();
}

function adminPermissionStatusPage() {
  const body = document.querySelector('.admin-table tbody');
  const card = document.querySelector('.admin-table')?.closest('.admin-card');
  if (!body || !card) return;
  body.replaceChildren();
  document.querySelectorAll('.admin-stat strong').forEach((value) => { value.textContent = 'Loadingâ€¦'; });
  const grantsCard = [...document.querySelectorAll('.admin-card')].find((item) => item.querySelector('h2')?.textContent.trim() === 'Active family grants');
  grantsCard?.querySelectorAll('.admin-setting').forEach((item) => item.remove());
  const search = document.querySelector('[aria-label="Search permission requests"]');
  const familySelect = document.createElement('select'); familySelect.className = 'btn'; familySelect.setAttribute('aria-label', 'Permission family');
  const label = document.createElement('label'); label.className = 'admin-search'; label.append(document.createTextNode('Family '), familySelect);
  document.querySelector('.page-heading .heading-actions')?.prepend(label);
  const notice = setAdminNotice(card, 'Loading family permission requests...');
  const stats = [...document.querySelectorAll('.admin-stat strong')]; let rows = [];
  function render() {
    body.replaceChildren(); const term = search?.value.trim().toLowerCase() || '';
    const filtered = rows.filter((item) => `${item.requester_first_name} ${item.requester_last_name} ${item.owner_first_name} ${item.owner_last_name} ${item.resource_type} ${item.purpose || ''} ${item.status}`.toLowerCase().includes(term));
    if (!filtered.length) { const tr = document.createElement('tr'); const td = document.createElement('td'); td.colSpan = 7; td.textContent = rows.length ? 'No requests match this search.' : 'No permission requests found for this family.'; tr.append(td); body.append(tr); return; }
    for (const item of filtered) { const tr = document.createElement('tr'); tr.className = 'permission-row';
      const values = [`${item.requester_first_name} ${item.requester_last_name}`, `${item.owner_first_name} ${item.owner_last_name}`, `${item.resource_type}${item.resource_id ? ` #${item.resource_id}` : ''}`, item.purpose || 'No purpose supplied', item.created_at || 'â€”', item.status === 'pending' ? 'Awaiting owner' : item.status === 'approved' ? 'Owner approved' : item.status];
      values.forEach((value) => { const td = document.createElement('td'); td.textContent = value; tr.append(td); });
      const action = document.createElement('td'); action.textContent = item.status === 'pending' ? 'Owner decides' : 'Read only'; tr.append(action); body.append(tr);
    }
  }
  async function load() {
    notice.textContent = 'Loading family permission requests...';
    try { const result = await adminApiRequest(`permissions/admin_list.php?family_id=${encodeURIComponent(familySelect.value)}`); rows = result.permissions || [];
      const now = new Date(); const values = [rows.filter((x) => x.status === 'pending').length, rows.filter((x) => x.status === 'approved' && (!x.expires_at || new Date(x.expires_at.replace(' ', 'T')) > now)).length, rows.filter((x) => x.expires_at && new Date(x.expires_at.replace(' ', 'T')).getMonth() === now.getMonth()).length, rows.filter((x) => x.status === 'revoked').length];
      values.forEach((value, i) => { if (stats[i]) stats[i].textContent = String(value); });
      if (grantsCard) {
        for (const grant of rows.filter((item) => item.status === 'approved')) {
          const row = document.createElement('div'); row.className = 'admin-setting';
          const details = document.createElement('span'); const title = document.createElement('strong'); title.textContent = `${grant.resource_type} Â· ${grant.owner_first_name} â†’ ${grant.requester_first_name}`;
          const sub = document.createElement('p'); sub.textContent = grant.expires_at ? `Expires ${grant.expires_at}` : 'No expiry set'; details.append(title, sub);
          const pill = document.createElement('span'); pill.className = 'pill teal'; pill.textContent = 'Owner approved'; row.append(details, pill); grantsCard.append(row);
        }
      }
      notice.textContent = 'Family Admins can review request status. Only each information owner can approve, deny, or revoke access.'; render();
    } catch (error) { notice.textContent = error.message; notice.setAttribute('role', 'alert'); }
  }
  search?.addEventListener('input', render); familySelect.addEventListener('change', load);
  getAdminFamilies().then((families) => { for (const family of families) { const option = document.createElement('option'); option.value = family.id; option.textContent = family.family_name; familySelect.append(option); }
    if (!families.length) throw new Error('No active Family Admin assignment is available.'); load();
  }).catch((error) => { notice.textContent = error.message; notice.setAttribute('role', 'alert'); });
}

function adminIdentityStatusPage() {
  const body = document.querySelector('.admin-table tbody'); const card = document.querySelector('.admin-table')?.closest('.admin-card');
  if (!body || !card) return;
  body.replaceChildren();
  document.querySelectorAll('.admin-stat strong').forEach((value) => { value.textContent = 'Loadingâ€¦'; });
  const search = document.querySelector('[aria-label="Search verification queue"]');
  const familySelect = document.createElement('select'); familySelect.className = 'btn'; familySelect.setAttribute('aria-label', 'Verification family');
  const label = document.createElement('label'); label.className = 'admin-search'; label.append(document.createTextNode('Family '), familySelect);
  document.querySelector('.page-heading .heading-actions')?.prepend(label);
  const notice = setAdminNotice(card, 'Loading identity verification status...'); const stats = [...document.querySelectorAll('.admin-stat strong')]; let rows = [];
  function render() { body.replaceChildren(); const term = search?.value.trim().toLowerCase() || ''; const filtered = rows.filter((item) => `${item.first_name} ${item.last_name} ${item.document_type} ${item.status}`.toLowerCase().includes(term));
    if (!filtered.length) { const tr = document.createElement('tr'); const td = document.createElement('td'); td.colSpan = 7; td.textContent = rows.length ? 'No submissions match this search.' : 'No identity verification submissions found.'; tr.append(td); body.append(tr); return; }
    for (const item of filtered) { const tr = document.createElement('tr'); tr.className = 'verification-row'; [`${item.first_name} ${item.last_name}`, item.document_type, 'Not shown', item.submitted_at || 'â€”', item.reviewed_at ? 'Super Admin' : 'â€”', item.status, 'Status view only'].forEach((value) => { const td = document.createElement('td'); td.textContent = value; tr.append(td); }); body.append(tr); }
  }
  async function load() { notice.textContent = 'Loading identity verification status...'; try { const result = await adminApiRequest(`identity/family_status.php?family_id=${encodeURIComponent(familySelect.value)}`); rows = result.verifications || [];
      const count = (status) => rows.filter((item) => item.status === status).length; [count('pending'), count('verified'), 0, count('verified') + count('rejected')].forEach((value, i) => { if (stats[i]) stats[i].textContent = String(value); });
      notice.textContent = 'Status-only view. Identity numbers, evidence, and rejection details are not exposed; only Super Admins decide verification.'; render();
    } catch (error) { notice.textContent = error.message; notice.setAttribute('role', 'alert'); } }
  search?.addEventListener('input', render); familySelect.addEventListener('change', load);
  getAdminFamilies().then((families) => { for (const family of families) { const option = document.createElement('option'); option.value = family.id; option.textContent = family.family_name; familySelect.append(option); }
    if (!families.length) throw new Error('No active Family Admin assignment is available.'); load();
  }).catch((error) => { notice.textContent = error.message; notice.setAttribute('role', 'alert'); });
}

function adminVaultPage() {
  const heading = document.querySelector('.page-heading');
  if (!heading) return;
  const buttons = [...heading.querySelectorAll('button')];
  const exportButton = buttons.find((button) => button.textContent.includes('Export inventory'));
  const backupButton = buttons.find((button) => button.textContent.includes('Create backup'));
  if (!exportButton || !backupButton) return;
  const familySelect = document.createElement('select'); familySelect.className = 'btn'; familySelect.setAttribute('aria-label', 'Vault family');
  const familyLabel = document.createElement('label'); familyLabel.className = 'admin-search'; familyLabel.append(document.createTextNode('Family '), familySelect); heading.querySelector('.heading-actions')?.prepend(familyLabel);
  const notice = setAdminNotice(heading, 'Loading family vault inventory...');
  const banner = document.querySelector('.banner');
  if (banner) { const title = banner.querySelector('h2'); const description = banner.querySelector('p'); const badge = banner.querySelector('.pill');
    if (title) title.textContent = 'Family archive inventory';
    if (description) description.textContent = 'Storage counts and file metadata are loaded for your selected family. Private files and identity data are excluded from archives.';
    if (badge) badge.textContent = 'Scoped';
  }
  const stats = [...document.querySelectorAll('.admin-stat strong')];
  const inventoryCard = [...document.querySelectorAll('.admin-card')].find((card) => card.querySelector('h2')?.textContent.includes('Vault services'));
  const backupCard = [...document.querySelectorAll('.admin-card')].find((card) => card.querySelector('h2')?.textContent.includes('Recent backups'));
  const historyRows = backupCard?.querySelectorAll('.vault-row'); historyRows?.forEach((row) => row.remove());
  const historyButton = [...(backupCard?.querySelectorAll('button') || [])].find((button) => button.textContent.includes('View history'));
  if (backupCard?.querySelector('h2')) backupCard.querySelector('h2').textContent = 'Recent archive activity';
  const backupDescription = backupCard?.querySelector('.admin-card-header p'); if (backupDescription) backupDescription.textContent = 'Download an on-demand archive or merge a previously downloaded archive.';
  const historyStatus = document.createElement('p');
  historyStatus.className = 'subtitle';
  historyStatus.setAttribute('role', 'status');
  const archiveHistory = document.createElement('div');
  archiveHistory.className = 'stack';
  if (backupCard) backupCard.append(historyStatus, archiveHistory);
  if (historyButton) {
    historyButton.removeAttribute('data-toast');
    historyButton.disabled = true;
    historyButton.textContent = 'View archive activity';
    historyButton.title = 'Load family-scoped archive export and restore events.';
    historyButton.addEventListener('click', async () => {
      historyButton.disabled = true;
      historyStatus.setAttribute('role', 'status');
      historyStatus.textContent = 'Loading archive activity...';
      archiveHistory.replaceChildren();
      try {
        const params = new URLSearchParams({
          family_id: familySelect.value,
          limit: '20',
          days: '0',
          q: 'family_export_'
        });
        const result = await adminApiRequest(`audit/list.php?${params.toString()}`);
        const events = (Array.isArray(result.logs) ? result.logs : [])
          .filter((event) => ['family_export_created', 'family_export_restored'].includes(event.action));
        if (!events.length) {
          historyStatus.textContent = 'No archive activity has been recorded for this family. Archive files are not stored on the server.';
          return;
        }
        historyStatus.textContent = `${events.length} recent archive event${events.length === 1 ? '' : 's'}. Archive contents are not retained here.`;
        for (const event of events) {
          const row = document.createElement('div');
          row.className = 'vault-row';
          const label = document.createElement('strong');
          label.textContent = event.action === 'family_export_created' ? 'Archive exported' : 'Archive restored';
          const time = document.createElement('small');
          time.textContent = String(event.created_at || 'Time unavailable');
          row.append(label, time);
          archiveHistory.append(row);
        }
      } catch (error) {
        historyStatus.textContent = `Archive activity is unavailable: ${error.message}`;
        historyStatus.setAttribute('role', 'alert');
      } finally {
        historyButton.disabled = false;
      }
    });
  }
  const restoreCheck = [...(backupCard?.querySelectorAll('button') || [])].find((button) => button.textContent.includes('Run restore check'));
  if (restoreCheck) { restoreCheck.removeAttribute('data-toast'); restoreCheck.textContent = 'Restore family archive'; }
  const restoreInput = document.createElement('input'); restoreInput.type = 'file'; restoreInput.accept = '.kkv,application/octet-stream'; restoreInput.hidden = true; restoreInput.setAttribute('aria-label', 'Choose encrypted family archive to restore'); document.body.append(restoreInput);
  let csrfToken = '';
  async function postVault(action, file = null) {
    const form = new FormData(); form.set('action', action); form.set('family_id', familySelect.value); if (file) form.set('archive', file);
    return fetch(`${ADMIN_API_BASE}family/vault.php`, { method: 'POST', credentials: 'same-origin', headers: { 'X-CSRF-Token': csrfToken, Accept: 'application/json, application/zip' }, body: form });
  }
  async function load() {
    notice.textContent = 'Loading family vault inventory...'; exportButton.disabled = backupButton.disabled = true; if (historyButton) historyButton.disabled = true;
    try {
      const result = await adminApiRequest(`family/vault.php?family_id=${encodeURIComponent(familySelect.value)}`);
      const summary = result.summary || {}; const bytes = Number(summary.shared_media_bytes || 0);
      const human = (value) => { let n = value; const units = ['B', 'KB', 'MB', 'GB', 'TB']; let i = 0; while (n >= 1024 && i < units.length - 1) { n /= 1024; i++; } return `${n.toFixed(i ? 1 : 0)} ${units[i]}`; };
      if (stats[0]) stats[0].textContent = human(bytes); if (stats[1]) stats[1].textContent = 'AES-256-GCM';
      if (stats[2]) stats[2].textContent = String(Number(summary.member_count || 0) + Number(summary.relationship_count || 0) + Number(summary.shared_media_count || 0));
      if (stats[3]) stats[3].textContent = 'On demand';
      const kv = [...(inventoryCard?.querySelectorAll('.admin-kv') || [])];
      if (kv[0]?.querySelector('strong')) kv[0].querySelector('strong').textContent = 'Private storage checked';
      if (kv[1]?.querySelector('strong')) kv[1].querySelector('strong').textContent = 'Disabled';
      if (kv[2]?.querySelector('strong')) kv[2].querySelector('strong').textContent = 'SHA-256 checked on export';
      if (kv[3]?.querySelector('strong')) kv[3].querySelector('strong').textContent = 'AES-256-GCM encrypted';
      const distCard = [...document.querySelectorAll('.admin-card')].find((card) => card.querySelector('h2')?.textContent.includes('Storage distribution'));
      if (distCard) {
        distCard.querySelectorAll('.admin-setting').forEach((row) => row.remove());
        const distribution = document.createElement('div'); distribution.className = 'admin-setting';
        const details = document.createElement('span'); const title = document.createElement('strong'); title.textContent = 'Family-visible files';
        const description = document.createElement('p'); description.textContent = 'Private and permissioned content is excluded from this inventory.'; details.append(title, description);
        const size = document.createElement('strong'); size.textContent = human(bytes); distribution.append(details, size); distCard.append(distribution);
        const bars = distCard.querySelectorAll('div[style*="height:13px"] span'); bars.forEach((bar) => { bar.style.width = '100%'; });
        const badge = distCard.querySelector('.pill'); if (badge) badge.textContent = 'Family-visible';
      }
      notice.textContent = 'Inventory includes active family profiles and family-visible files only. Private files and identity verification data are excluded.';
      if (historyButton) historyButton.disabled = false;
      exportButton.disabled = backupButton.disabled = false;
    } catch (error) { notice.textContent = error.message; notice.setAttribute('role', 'alert'); }
  }
  async function exportArchive() {
    if (!familySelect.value || !csrfToken) return;
    backupButton.disabled = true; notice.textContent = 'Preparing family archive...';
    try { const response = await postVault('export'); if (!response.ok) { const body = await response.json().catch(() => ({})); throw new Error(body.error || `Archive export failed (HTTP ${response.status}).`); }
      const blob = await response.blob(); const url = URL.createObjectURL(blob); const link = document.createElement('a'); link.href = url; link.download = `kinkeep-family-${familySelect.value}.kkv`; link.click(); window.setTimeout(() => URL.revokeObjectURL(url), 1000);
      notice.textContent = 'Encrypted family archive downloaded. Identity secrets and private media were excluded.';
    } catch (error) { notice.textContent = error.message; notice.setAttribute('role', 'alert'); } finally { backupButton.disabled = false; }
  }
  exportButton.removeAttribute('data-toast'); exportButton.addEventListener('click', async () => {
    try { const result = await adminApiRequest(`family/vault.php?family_id=${encodeURIComponent(familySelect.value)}`); downloadAdminCsv('family-vault-inventory.csv', ['media_type', 'file_count', 'bytes'], (result.inventory || []).map((item) => [item.media_type, item.file_count, item.bytes])); }
    catch (error) { notice.textContent = error.message; notice.setAttribute('role', 'alert'); }
  });
  backupButton.removeAttribute('data-toast'); backupButton.addEventListener('click', exportArchive);
  restoreCheck?.addEventListener('click', () => restoreInput.click());
  restoreInput.addEventListener('change', async () => {
    const file = restoreInput.files?.[0]; if (!file) return;
    if (!window.confirm('Merge this archive into the selected family? Existing records will not be replaced or deleted. Only family-visible media and approved relationships are restored.')) { restoreInput.value = ''; return; }
    restoreCheck.disabled = true; notice.textContent = 'Validating and merging archive...';
    try { const response = await postVault('restore', file); const result = await response.json(); if (!response.ok || !result.success) throw new Error(result.error || `Restore failed (HTTP ${response.status}).`);
      notice.textContent = `${result.message}. Added ${result.members_added} profiles, ${result.relationships_added} relationships, and ${result.media_added} media files.`; await load();
    } catch (error) { notice.textContent = error.message; notice.setAttribute('role', 'alert'); } finally { restoreCheck.disabled = false; restoreInput.value = ''; }
  });
  familySelect.addEventListener('change', load);
  (async () => { try { const auth = await adminApiRequest('auth/me.php'); csrfToken = auth.csrf_token || ''; if (csrfToken.length < 32) throw new Error('Refresh and sign in again to obtain a security token.');
      const families = await getAdminFamilies(); for (const family of families) { const option = document.createElement('option'); option.value = family.id; option.textContent = family.family_name; familySelect.append(option); }
      if (!families.length) throw new Error('No active Family Admin assignment is available.');
      const requestedFamilyId = new URLSearchParams(window.location.search).get('family_id');
      if (requestedFamilyId && families.some((family) => String(family.id) === requestedFamilyId)) familySelect.value = requestedFamilyId;
      await load();
    } catch (error) { notice.textContent = error.message; notice.setAttribute('role', 'alert'); } })();
}

function adminSettingsPage() {
  const saveButton = [...document.querySelectorAll('.page-heading button')]
    .find((button) => button.textContent.includes('Save changes'));
  const familyName = document.querySelector('#family-name');
  const familyIdentity = [...document.querySelectorAll('.admin-card')]
    .find((card) => card.querySelector('h2')?.textContent.trim() === 'Family identity');
  const administratorCard = [...document.querySelectorAll('.admin-card')]
    .find((card) => card.querySelector('h2')?.textContent.trim() === 'Family administrators');
  const inviteButton = [...document.querySelectorAll('.admin-card button')]
    .find((button) => button.textContent.includes('Invite administrator'));
  if (!saveButton || !familyName || !familyIdentity || !administratorCard || !inviteButton) return;

  saveButton.removeAttribute('data-toast');
  saveButton.disabled = true;
  familyName.value = '';
  familyName.disabled = true;
  familyName.maxLength = 190;
  const region = document.querySelector('#family-region');
  const visibility = document.querySelector('[aria-label="Profile visibility"]');
  const expiry = document.querySelector('[aria-label="Default permission duration"]');
  const discoverable = document.querySelector('#family-discoverable');
  if (region) { region.value = ''; region.disabled = true; region.maxLength = 190; }
  if (visibility) visibility.disabled = true;
  if (expiry) expiry.disabled = true;
  if (discoverable) discoverable.disabled = true;
  const auditSetting = document.querySelector('[aria-label="Log administrator actions"]')?.closest('.admin-setting');
  if (auditSetting) {
    const description = auditSetting.querySelector('p');
    if (description) description.textContent = 'Security and audit events are recorded automatically and cannot be disabled here.';
    const toggle = auditSetting.querySelector('.toggle');
    if (toggle) {
      const state = document.createElement('span');
      state.className = 'pill teal';
      state.textContent = 'Always on';
      toggle.replaceWith(state);
    }
  }
  const createdField = [...document.querySelectorAll('.field')]
    .find((field) => field.querySelector('label')?.textContent.trim() === 'Family created');
  const createdValue = createdField?.querySelector('.field-value');
  if (createdValue) createdValue.textContent = 'â€”';
  const codeValue = document.querySelector('#family-code')?.closest('.field')?.querySelector('.field-value');
  if (codeValue) codeValue.textContent = 'Not configured';

  const settingsCards = [...document.querySelectorAll('.admin-card')];
  for (const card of settingsCards) {
    const title = card.querySelector('h2')?.textContent.trim();
    if (title === 'Membership workflow') {
      card.querySelectorAll('.admin-setting').forEach((item) => item.remove());
      setAdminNotice(card, 'Membership requests remain pending until an authorized Family Admin reviews them. Per-family workflow toggles are not supported.');
    }
  }
  const archiveButton = [...document.querySelectorAll('.admin-card button')]
    .find((button) => button.textContent.includes('Archive family'));
  disableUnbackedAdminAction(archiveButton, 'Family Admins cannot archive a family; this remains a Super Admin operation.');

  const status = setAdminNotice(familyIdentity, 'Loading authorized family settings...');
  const adminList = document.createElement('div');
  adminList.dataset.familyAdministratorList = 'true';
  administratorCard.querySelectorAll('.admin-setting').forEach((item) => item.remove());
  administratorCard.append(adminList);
  const countPill = administratorCard.querySelector('.pill');
  inviteButton.removeAttribute('data-toast');
  inviteButton.disabled = true;

  const pageHeadingActions = document.querySelector('.page-heading .heading-actions');
  const familyLabel = document.createElement('label');
  familyLabel.className = 'admin-search';
  familyLabel.append(document.createTextNode('Family '));
  const familySelect = document.createElement('select');
  familySelect.className = 'btn';
  familySelect.setAttribute('aria-label', 'Settings family');
  familyLabel.append(familySelect);
  pageHeadingActions?.prepend(familyLabel);

  const dialog = document.createElement('dialog');
  dialog.className = 'admin-card';
  const dialogTitle = document.createElement('h2');
  dialogTitle.textContent = 'Invite a Family Admin';
  const dialogForm = document.createElement('form');
  const emailLabel = document.createElement('label');
  emailLabel.className = 'admin-search';
  emailLabel.append(document.createTextNode('Verified account email'));
  const emailInput = document.createElement('input');
  emailInput.type = 'email';
  emailInput.name = 'email';
  emailInput.maxLength = 190;
  emailInput.required = true;
  emailInput.autocomplete = 'email';
  emailLabel.append(emailInput);
  const dialogStatus = document.createElement('p');
  dialogStatus.className = 'subtitle';
  dialogStatus.setAttribute('role', 'status');
  const actions = document.createElement('div');
  actions.className = 'admin-row-actions';
  const cancel = document.createElement('button');
  cancel.type = 'button';
  cancel.className = 'btn';
  cancel.textContent = 'Cancel';
  cancel.addEventListener('click', () => dialog.close());
  const submit = document.createElement('button');
  submit.type = 'submit';
  submit.className = 'btn primary';
  submit.textContent = 'Send invitation';
  actions.append(cancel, submit);
  dialogForm.append(emailLabel, dialogStatus, actions);
  dialog.append(dialogTitle, dialogForm);
  document.body.append(dialog);

  let csrfToken = '';
  let currentFamilyId = '';
  function textNode(tag, className, text) {
    const node = document.createElement(tag);
    node.className = className;
    node.textContent = text;
    return node;
  }
  function renderAdministrators(result) {
    adminList.replaceChildren();
    const admins = Array.isArray(result.administrators) ? result.administrators : [];
    if (countPill) countPill.textContent = `${admins.length} active`;
    for (const administrator of admins) {
      const row = document.createElement('div');
      row.className = 'admin-setting';
      const details = document.createElement('span');
      const fullName = [administrator.first_name, administrator.middle_name, administrator.last_name]
        .filter(Boolean).join(' ');
      details.append(
        textNode('strong', '', fullName || 'Family Admin'),
        textNode('p', '', administrator.is_current ? 'Active Â· you' : 'Active Family Admin')
      );
      const badge = textNode('span', 'pill teal', administrator.is_current ? 'You' : 'Active');
      row.append(details, badge);
      adminList.append(row);
    }
    const pending = Array.isArray(result.pending_invitations) ? result.pending_invitations : [];
    for (const invitation of pending) {
      const row = document.createElement('div');
      row.className = 'admin-setting';
      const details = document.createElement('span');
      details.append(
        textNode('strong', '', invitation.email || 'Invited account'),
        textNode('p', '', `Invitation expires ${invitation.expires_at || 'date unavailable'}`)
      );
      const revoke = textNode('button', 'btn small danger', 'Revoke');
      revoke.type = 'button';
      revoke.addEventListener('click', async () => {
        if (!window.confirm('Revoke this pending Family Admin invitation?')) return;
        revoke.disabled = true;
        try {
          await adminApiRequest('family/admins.php', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json', 'X-CSRF-Token': csrfToken },
            body: JSON.stringify({
              action: 'revoke', family_id: Number(currentFamilyId), invitation_id: Number(invitation.id)
            })
          });
          await loadFamilySettings();
        } catch (error) {
          status.textContent = error.message;
          status.setAttribute('role', 'alert');
          revoke.disabled = false;
        }
      });
      row.append(details, revoke);
      adminList.append(row);
    }
    if (!admins.length && !pending.length) {
      adminList.append(textNode('p', 'subtitle', 'No active Family Admins or pending invitations were returned.'));
    }
    inviteButton.disabled = !currentFamilyId;
  }

  async function loadFamilySettings() {
    const requestedFamilyId = familySelect.value;
    if (!requestedFamilyId) return;
    currentFamilyId = requestedFamilyId;
    saveButton.disabled = true;
    inviteButton.disabled = true;
    status.textContent = 'Loading authorized family settings...';
    const query = `?family_id=${encodeURIComponent(requestedFamilyId)}`;
    try {
      const [settings, admins] = await Promise.all([
        adminApiRequest(`family/settings.php${query}`),
        adminApiRequest(`family/admins.php${query}`)
      ]);
      if (requestedFamilyId !== familySelect.value) return;
      familyName.value = String(settings.family.family_name || '');
      familyName.disabled = false;
      if (region) { region.value = String(settings.family.home_region || ''); region.disabled = false; }
      if (visibility) { visibility.value = settings.family.profile_visibility === 'private' ? 'Private' : 'Family members only'; visibility.disabled = false; }
      if (expiry) { expiry.value = `${Number(settings.family.permission_expiry_days || 30)} days`; expiry.disabled = false; }
      if (discoverable) {
        discoverable.checked = Number(settings.family.is_discoverable) === 1;
        discoverable.disabled = false;
      }
      saveButton.disabled = false;
      status.textContent = 'Family identity and privacy defaults are loaded for the selected family.';
      const eyebrow = document.querySelector('.page-heading .eyebrow');
      if (eyebrow) eyebrow.textContent = String(settings.family.family_name || 'Family settings');
      if (createdValue) createdValue.textContent = String(settings.family.created_at || 'â€”');
      renderAdministrators(admins);
      const url = new URL(window.location.href);
      url.searchParams.set('family_id', requestedFamilyId);
      window.history.replaceState({}, '', url);
    } catch (error) {
      if (requestedFamilyId !== familySelect.value) return;
      familyName.value = '';
      familyName.disabled = true;
      if (discoverable) discoverable.disabled = true;
      saveButton.disabled = true;
      status.textContent = error.message;
      status.setAttribute('role', 'alert');
      adminList.replaceChildren(textNode('p', 'subtitle', 'Administrator list unavailable.'));
    }
  }

  saveButton.addEventListener('click', async () => {
    if (!currentFamilyId || !csrfToken) return;
    saveButton.disabled = true;
    try {
      const result = await adminApiRequest('family/settings.php', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', 'X-CSRF-Token': csrfToken },
        body: JSON.stringify({
          family_id: Number(currentFamilyId),
          family_name: familyName.value,
          home_region: region?.value || '',
          profile_visibility: visibility?.value === 'Private' ? 'private' : 'family',
          is_discoverable: discoverable?.checked === true,
          permission_expiry_days: Number.parseInt(expiry?.value || '30', 10)
        })
      });
      status.textContent = result.message || 'Family settings updated.';
      const eyebrow = document.querySelector('.page-heading .eyebrow');
      if (eyebrow) eyebrow.textContent = familyName.value;
    } catch (error) {
      status.textContent = error.message;
      status.setAttribute('role', 'alert');
    } finally {
      saveButton.disabled = false;
    }
  });
  inviteButton.addEventListener('click', () => {
    dialogStatus.textContent = '';
    dialogForm.reset();
    dialog.showModal();
    emailInput.focus();
  });
  dialogForm.addEventListener('submit', async (event) => {
    event.preventDefault();
    submit.disabled = true;
    dialogStatus.textContent = 'Creating invitation...';
    try {
      const result = await adminApiRequest('family/admins.php', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', 'X-CSRF-Token': csrfToken },
        body: JSON.stringify({ family_id: Number(currentFamilyId), email: emailInput.value.trim() })
      });
      dialogStatus.textContent = result.message || 'Invitation created.';
      emailInput.value = '';
      await loadFamilySettings();
    } catch (error) {
      dialogStatus.textContent = error.message;
      dialogStatus.setAttribute('role', 'alert');
    } finally {
      submit.disabled = false;
    }
  });
  familySelect.addEventListener('change', loadFamilySettings);

  (async () => {
    try {
      const auth = await adminApiRequest('auth/me.php');
      if (typeof auth.csrf_token !== 'string' || auth.csrf_token.length < 32) {
        throw new Error('Could not obtain a valid security token. Refresh and sign in again.');
      }
      csrfToken = auth.csrf_token;
      const families = await getAdminFamilies();
      familySelect.replaceChildren();
      for (const family of families) {
        const option = document.createElement('option');
        option.value = String(family.id);
        option.textContent = String(family.family_name || `Family ${family.id}`);
        familySelect.append(option);
      }
      if (!families.length) throw new Error('No active Family Admin assignment is available.');
      const requested = new URLSearchParams(window.location.search).get('family_id');
      if (requested && families.some((family) => String(family.id) === requested)) {
        familySelect.value = requested;
      }
      await loadFamilySettings();
    } catch (error) {
      status.textContent = error.message;
      status.setAttribute('role', 'alert');
    }
  })();
}

if (location.pathname.endsWith('/relationships-and-kin.html')) {
  adminRelationshipPage();
}
if (location.pathname.endsWith('/admin-logs.html')) {
  adminAuditPage();
}
if (location.pathname.endsWith('/permission-requests.html') ||
    location.pathname.endsWith('/identity-verification.html') ||
    location.pathname.endsWith('/family-data-vault.html')) {
  if (location.pathname.endsWith('/permission-requests.html')) adminPermissionStatusPage();
  else if (location.pathname.endsWith('/identity-verification.html')) adminIdentityStatusPage();
  else adminVaultPage();
}
if (location.pathname.endsWith('/family-settings.html')) {
  adminSettingsPage();
}

function initializeAdminNotifications() {
  const button = document.querySelector('.top-actions button[aria-label="Notifications"]');
  if (!button) return;
  button.removeAttribute('data-toast');
  button.title = 'Open family action items';

  const badge = document.createElement('span');
  badge.hidden = true;
  badge.style.cssText = 'position:absolute;top:-3px;right:-3px;min-width:16px;padding:1px 4px;border-radius:999px;background:#b42318;color:#fff;font-size:10px;line-height:14px;text-align:center';
  button.style.position = 'relative';
  button.append(badge);

  const dialog = document.createElement('dialog');
  dialog.className = 'admin-card';
  dialog.style.cssText = 'width:min(460px,92vw);max-height:80vh;overflow:auto;border:1px solid #d8dee6;border-radius:14px;padding:20px;box-shadow:0 18px 55px #0003';
  dialog.setAttribute('aria-labelledby', 'admin-notification-title');
  const heading = document.createElement('h2');
  heading.id = 'admin-notification-title';
  heading.textContent = 'Family action items';
  const familySelect = document.createElement('select');
  familySelect.className = 'btn';
  familySelect.setAttribute('aria-label', 'Notification family');
  const status = document.createElement('p');
  status.className = 'subtitle';
  status.setAttribute('role', 'status');
  const list = document.createElement('div');
  list.className = 'admin-stack';
  const close = document.createElement('button');
  close.type = 'button';
  close.className = 'btn';
  close.textContent = 'Close';
  close.addEventListener('click', () => dialog.close());
  dialog.append(heading, familySelect, status, list, close);
  document.body.append(dialog);

  async function loadItems() {
    const familyId = familySelect.value;
    list.replaceChildren();
    badge.hidden = true;
    status.setAttribute('role', 'status');
    status.textContent = 'Loading family action items...';
    if (!familyId) {
      status.textContent = 'No active Family Admin family is available.';
      return;
    }
    try {
      const result = await adminApiRequest(`family/notifications.php?family_id=${encodeURIComponent(familyId)}`);
      const total = Number(result.total) || 0;
      badge.textContent = total > 99 ? '99+' : String(total);
      badge.hidden = total === 0;
      button.setAttribute('aria-label', total ? `Notifications, ${total} family action items` : 'Notifications, no family action items');
      if (!result.items?.length) {
        status.textContent = 'No family items are waiting for your review.';
        return;
      }
      status.textContent = `${total} item${total === 1 ? '' : 's'} need review.`;
      const allowed = new Set(['enrollment-requests.html', 'relationships-and-kin.html']);
      for (const item of result.items) {
        if (!allowed.has(item.url)) continue;
        const link = document.createElement('a');
        link.className = 'btn';
        link.href = item.url;
        link.textContent = `${item.title} (${Number(item.count) || 0})`;
        link.style.cssText = 'display:block;margin:6px 0;text-decoration:none';
        list.append(link);
      }
    } catch (error) {
      status.textContent = `Family action items are unavailable: ${error.message}`;
      status.setAttribute('role', 'alert');
    }
  }

  familySelect.addEventListener('change', loadItems);
  button.addEventListener('click', async () => {
    if (!familySelect.options.length) {
      status.textContent = 'Loading your authorized families...';
      dialog.showModal();
      try {
        const families = await getAdminFamilies();
        for (const family of families) {
          const option = document.createElement('option');
          option.value = String(family.id);
          option.textContent = family.family_name;
          familySelect.append(option);
        }
      } catch (error) {
        status.textContent = `Family list is unavailable: ${error.message}`;
        status.setAttribute('role', 'alert');
        return;
      }
    } else {
      dialog.showModal();
    }
    await loadItems();
  });
}

initializeAdminNotifications();
