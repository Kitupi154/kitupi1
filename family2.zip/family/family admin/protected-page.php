<?php
declare(strict_types=1);

require_once __DIR__ . '/../zip_extracted/src/bootstrap.php';
PageAccess::requireFamilyDashboardRole('admin');

$path = parse_url($_SERVER['REQUEST_URI'] ?? '', PHP_URL_PATH);
$page = is_string($path) ? basename(rawurldecode($path)) : '';
$allowedPages = [
    'enrollment-requests.html',
    'member-roster.html',
    'relationships-and-kin.html',
    'identity-verification.html',
    'family-settings.html',
    'family-data-vault.html',
    'permission-requests.html',
    'admin-logs.html',
];
if (!in_array($page, $allowedPages, true)) {
    http_response_code(404);
    exit;
}

header('Content-Type: text/html; charset=utf-8');
require __DIR__ . DIRECTORY_SEPARATOR . $page;
