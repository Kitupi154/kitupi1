<?php
declare(strict_types=1);
require_once __DIR__ . '/../zip_extracted/src/bootstrap.php';
PageAccess::requireFamilyDashboardRole('admin');
?>
<!DOCTYPE html>

<html lang="en"><head><meta charset="utf-8"/><meta content="width=device-width, initial-scale=1.0" name="viewport"/><meta content="web_dashboard" name="shell-type"/><link href="https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined:opsz,wght,FILL,GRAD@20..48,100..700,0..1,-50..200" rel="stylesheet"/>
<link href="https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined:wght,FILL@100..700,0..1&display=swap" rel="stylesheet"/>
<link href="https://fonts.googleapis.com/css2?family=Inter:wght@100..900&display=swap" rel="stylesheet"/><style>@layer base{html,body{margin:0;padding:0;}body{overscroll-behavior:none;}main>:first-child{margin-top:0!important;}main>:last-child{margin-bottom:0!important;}}::-webkit-scrollbar{display:none;}</style><script src="https://cdn.tailwindcss.com"></script><script id="tailwind-config">tailwind.config={darkMode:"class",theme:{extend:{colors:{"secondary-fixed-dim":"#78d6d5","tertiary":"#291900","inverse-surface":"#213145","secondary":"#006a6a","surface":"#f8f9ff","surface-dim":"#cbdbf5","surface-bright":"#f8f9ff","inverse-on-surface":"#eaf1ff","on-primary-container":"#809abd","surface-container-high":"#dce9ff","on-tertiary-container":"#b7935c","on-primary-fixed-variant":"#2e4867","error":"#ba1a1a","primary-fixed":"#d2e4ff","secondary-fixed":"#94f2f2","tertiary-fixed":"#ffddaf","on-primary-fixed":"#001d37","on-primary":"#ffffff","tertiary-container":"#442c00","surface-variant":"#d3e4fe","primary":"#001d37","surface-container-low":"#eff4ff","outline-variant":"#c3c6ce","on-error":"#ffffff","surface-container-highest":"#d3e4fe","primary-fixed-dim":"#aec9ed","on-tertiary-fixed-variant":"#5d4213","on-secondary":"#ffffff","on-background":"#0b1c30","secondary-container":"#94f2f2","inverse-primary":"#aec9ed","on-surface":"#0b1c30","error-container":"#ffdad6","on-surface-variant":"#43474d","primary-container":"#16324f","on-tertiary-fixed":"#281800","background":"#f8f9ff","surface-container-lowest":"#ffffff","on-secondary-container":"#007070","on-secondary-fixed":"#002020","surface-container":"#e5eeff","on-tertiary":"#ffffff","on-error-container":"#93000a","on-secondary-fixed-variant":"#004f50","outline":"#74777e","surface-tint":"#466080","tertiary-fixed-dim":"#e8c086"},borderRadius:{"DEFAULT":"0.25rem","lg":"0.5rem","xl":"0.75rem","full":"9999px"},spacing:{"space-xl":"2rem","space-sm":"0.5rem","margin":"2rem","space-xs":"0.25rem","gutter":"1.5rem","space-md":"1rem","space-lg":"1.5rem","margin-mobile":"1rem","gutter-mobile":"1rem"},fontFamily:{"body-sm":["Inter"],"body-md":["Inter"],"body-lg":["Inter"],"data-mono":["Inter"],"headline-sm":["Inter"],"headline-md":["Inter"],"headline-xl":["Inter"],"label-sm":["Inter"],"headline-xl-mobile":["Inter"],"headline-lg":["Inter"],"label-md":["Inter"]},fontSize:{"body-sm":["12px",{"lineHeight":"16px","fontWeight":"400"}],"body-md":["14px",{"lineHeight":"20px","fontWeight":"400"}],"body-lg":["16px",{"lineHeight":"24px","fontWeight":"400"}],"data-mono":["13px",{"lineHeight":"18px","letterSpacing":"0.04em","fontWeight":"500"}],"headline-sm":["16px",{"lineHeight":"24px","fontWeight":"600"}],"headline-md":["20px",{"lineHeight":"28px","letterSpacing":"-0.01em","fontWeight":"600"}],"headline-xl":["36px",{"lineHeight":"44px","letterSpacing":"-0.02em","fontWeight":"700"}],"label-sm":["12px",{"lineHeight":"16px","letterSpacing":"0.02em","fontWeight":"600"}],"headline-xl-mobile":["28px",{"lineHeight":"36px","letterSpacing":"-0.01em","fontWeight":"700"}],"headline-lg":["24px",{"lineHeight":"32px","letterSpacing":"-0.015em","fontWeight":"600"}],"label-md":["14px",{"lineHeight":"20px","fontWeight":"500"}]}}}};</script><style>

/* Sidebar styling aligned with the other KinKeep Vault role pages. */
:root {
  --sidebar-primary: #001d37;
  --sidebar-primary-container: #16324f;
  --sidebar-secondary-soft: #d8f4f1;
  --sidebar-surface-low: #eff4ff;
  --sidebar-surface-mid: #e5eeff;
  --sidebar-surface-high: #dce9ff;
  --sidebar-ink: #0b1c30;
  --sidebar-muted: #626c7b;
  --sidebar-line: #dce4ef;
  --sidebar-white: #fff;
  --sidebar-shadow: 0 8px 24px rgba(16, 39, 65, .06);
}
.sidebar {
  position: fixed; inset: 0 auto 0 0; z-index: 50; display: flex; flex-direction: column;
  width: 256px; padding: 16px; overflow-y: auto; background: var(--sidebar-surface-low);
  box-shadow: 1px 0 10px rgba(0, 29, 55, .06); font-family: Inter, Arial, sans-serif;
}
.sidebar, .sidebar * { box-sizing: border-box; }
.sidebar a { color: inherit; text-decoration: none; }
.sidebar .brand { display: flex; align-items: center; gap: 10px; padding: 10px 8px; margin-bottom: 16px; background: var(--sidebar-white); border-radius: 10px; box-shadow: var(--sidebar-shadow); }
.sidebar .brand-icon { display: grid; width: 38px; height: 38px; flex: 0 0 auto; place-items: center; color: white; background: var(--sidebar-primary-container); border-radius: 9px; font-size: 23px; }
.sidebar .brand-name { display: block; color: var(--sidebar-primary); font-size: 15px; font-weight: 700; line-height: 1.25; }
.sidebar .brand-caption { display: block; color: var(--sidebar-muted); font-size: 11px; }
.sidebar .role-box { display: flex; justify-content: space-between; align-items: center; gap: 6px; padding: 9px 10px; margin-bottom: 16px; background: var(--sidebar-surface-mid); border-radius: 9px; }
.sidebar .role-box > span:first-child { display: flex; align-items: center; gap: 6px; font-size: 12px; font-weight: 600; white-space: nowrap; }
.sidebar .role-box .material-symbols-outlined { font-size: 17px; }
.sidebar .role-pill { display: inline-flex; align-items: center; gap: 5px; padding: 3px 9px; color: #005657; background: var(--sidebar-secondary-soft); border-radius: 999px; font-size: 11px; font-weight: 650; white-space: nowrap; }
.sidebar .admin-label { color: #76500f; background: #fff0ce; }
.sidebar .nav-label, .sidebar .admin-nav-label { padding: 9px 7px 5px; color: var(--sidebar-muted); font-size: 10px; font-weight: 700; letter-spacing: .1em; text-transform: uppercase; }
.sidebar .side-nav { display: grid; gap: 3px; }
.sidebar .side-nav a { display: flex; align-items: center; gap: 10px; padding: 8px 10px; color: #536174; border-radius: 8px; font-size: 13px; transition: .15s ease; }
.sidebar .side-nav a:hover { color: var(--sidebar-ink); background: var(--sidebar-surface-high); }
.sidebar .side-nav a.active { color: white; background: var(--sidebar-primary-container); font-weight: 600; }
.sidebar .side-nav .material-symbols-outlined { font-size: 19px; }
.sidebar .sidebar-footer { margin-top: auto; padding-top: 18px; }
.sidebar .user-mini { display: flex; align-items: center; gap: 10px; padding: 11px 7px 2px; border-top: 1px solid var(--sidebar-line); }
.sidebar .avatar-sm { display: grid; width: 36px; height: 36px; flex: 0 0 auto; place-items: center; overflow: hidden; color: #315273; background: #dce9f8; border-radius: 50%; font-size: 12px; font-weight: 700; }
.sidebar .user-mini strong { display: block; color: var(--sidebar-ink); font-size: 12px; }
.sidebar .user-mini small { color: var(--sidebar-muted); font-size: 11px; }
.sidebar-toggle { display: none; }
@media (max-width: 760px) {
  .sidebar { transform: translateX(-100%); transition: transform .2s ease; }
  .sidebar.open { transform: translateX(0); }
  .sidebar-toggle { display: inline-grid; position: fixed; z-index: 45; top: 12px; left: 12px; width: 38px; height: 38px; place-items: center; color: var(--sidebar-primary); background: white; border: 1px solid var(--sidebar-line); border-radius: 9px; box-shadow: var(--sidebar-shadow); cursor: pointer; }
  header { left: 0 !important; padding-left: 60px !important; }
  main { margin-left: 0 !important; width: 100% !important; }
}
@media (min-width: 761px) {
  main { margin-left: 256px !important; width: calc(100% - 256px) !important; }
}



/* =========================================================
   SHARED ROLE SIDEBAR — aligned with member-pages.css
   Sidebar-only overrides; dashboard content/layout untouched.
   ========================================================= */
.sidebar {
  position: fixed !important;
  inset: 0 auto 0 0 !important;
  z-index: 50 !important;
  display: flex !important;
  flex-direction: column !important;
  width: 256px !important;
  padding: 16px !important;
  overflow-y: auto !important;
  background: #eff4ff !important;
  box-shadow: 1px 0 10px rgba(0, 29, 55, .06) !important;
  color: #0b1c30;
  font-family: Inter, Arial, sans-serif !important;
  box-sizing: border-box;
}
.sidebar .brand {
  display: flex !important; align-items: center !important; gap: 10px !important;
  padding: 10px 8px !important; margin: 0 0 16px !important;
  background: #fff !important; border-radius: 10px !important;
  box-shadow: 0 8px 24px rgba(16, 39, 65, .06) !important;
  text-decoration: none !important;
}
.sidebar .brand-icon {
  display: grid !important; width: 38px !important; height: 38px !important;
  flex: 0 0 auto !important; place-items: center !important;
  color: #fff !important; background: #16324f !important; border-radius: 9px !important;
}
.sidebar .brand-name { display: block !important; color: #001d37 !important; font-size: 15px !important; font-weight: 700 !important; line-height: 1.25 !important; }
.sidebar .brand-caption { display: block !important; color: #626c7b !important; font-size: 11px !important; }
.sidebar .role-box {
  display: flex !important; justify-content: space-between !important; align-items: center !important;
  gap: 6px !important; padding: 9px 10px !important; margin: 0 0 16px !important;
  background: #e5eeff !important; border-radius: 9px !important;
}
.sidebar .role-box > span:first-child { display: flex !important; align-items: center !important; gap: 6px !important; font-size: 12px !important; font-weight: 600 !important; }
.sidebar .role-pill { display: inline-flex !important; align-items: center !important; gap: 5px !important; padding: 3px 9px !important; border-radius: 999px !important; font-size: 11px !important; font-weight: 650 !important; white-space: nowrap !important; color: #005657 !important; background: #d8f4f1 !important; }
.sidebar .admin-label { color: #76500f !important; background: #fff0ce !important; }
.sidebar .side-nav { display: grid !important; gap: 3px !important; }
.sidebar .nav-label, .sidebar .admin-nav-label {
  padding: 9px 7px 5px !important; color: #626c7b !important; font-size: 10px !important;
  font-weight: 700 !important; letter-spacing: .1em !important; text-transform: uppercase !important;
}
.sidebar .side-nav a {
  display: flex !important; align-items: center !important; gap: 10px !important;
  padding: 8px 10px !important; color: #536174 !important; border-radius: 8px !important;
  font-size: 13px !important; font-weight: 400 !important; line-height: 1.5 !important;
  text-decoration: none !important; transition: .15s ease !important;
}
.sidebar .side-nav a:hover { color: #0b1c30 !important; background: #dce9ff !important; }
.sidebar .side-nav a.active, .sidebar.admin-sidebar .side-nav a.active {
  color: #fff !important; background: #16324f !important; font-weight: 600 !important;
}
.sidebar .side-nav .material-symbols-outlined { font-size: 19px !important; flex: 0 0 auto; }
.sidebar .sidebar-footer { margin-top: auto !important; padding-top: 18px !important; }
.sidebar .user-mini {
  display: flex !important; align-items: center !important; gap: 10px !important;
  padding: 11px 7px 2px !important; border-top: 1px solid #dce4ef !important;
}
.sidebar .avatar-sm {
  display: grid !important; width: 36px !important; height: 36px !important; flex: 0 0 auto !important;
  place-items: center !important; overflow: hidden !important; color: #315273 !important;
  background: #dce9f8 !important; border-radius: 50% !important; font-weight: 700 !important;
}
.sidebar .user-mini strong { display: block !important; font-size: 12px !important; }
.sidebar .user-mini small { color: #626c7b !important; font-size: 11px !important; }
@media (max-width: 760px) {
  .sidebar { transform: translateX(-100%) !important; transition: transform .2s ease !important; }
  .sidebar.open { transform: translateX(0) !important; }
}

</style></head><body class="bg-surface font-body-md text-body-md text-on-surface">
<button class="sidebar-toggle" type="button" aria-label="Open navigation menu" aria-controls="roleSidebar" aria-expanded="false"><span class="material-symbols-outlined">menu</span></button><aside class="sidebar admin-sidebar" id="roleSidebar" aria-label="Family Admin sidebar">
  <!-- Sidebar 1: Brand -->
  <a class="brand" href="admin-console.php">
    <span class="brand-icon material-symbols-outlined">family_restroom</span>
    <span><span class="brand-name">KinKeep Vault</span><span class="brand-caption">Heritage &amp; Lineage</span></span>
  </a>

  <!-- Sidebar 2: Current role -->
  <div class="role-box">
    <span><span class="material-symbols-outlined">verified_user</span>Active Role</span>
    <span class="role-pill admin-label">Family Admin</span>
  </div>

  <!-- Sidebar 3: Family Admin navigation only -->
  <nav class="side-nav" aria-label="Family administration navigation">
    <div class="admin-nav-label">Family Administrator</div>
    <a class="active" aria-current="page" href="admin-console.php"><span class="material-symbols-outlined">admin_panel_settings</span>Admin Console</a>
    <a href="member-roster.html"><span class="material-symbols-outlined">badge</span>Members Roster</a>
    <a href="enrollment-requests.html"><span class="material-symbols-outlined">how_to_reg</span>Enrollment Requests</a>
    <a href="relationships-and-kin.html"><span class="material-symbols-outlined">hub</span>Relationships &amp; Kin</a>
    <a href="identity-verification.html"><span class="material-symbols-outlined">fingerprint</span>Identity Verification</a>
    <a href="permission-requests.html"><span class="material-symbols-outlined">key</span>Permission Requests</a>
    <a href="family-data-vault.html"><span class="material-symbols-outlined">dataset</span>Family Data Vault</a>
    <a href="admin-logs.html"><span class="material-symbols-outlined">receipt_long</span>Audit Logs</a>
    <a href="family-settings.html"><span class="material-symbols-outlined">settings</span>Family Settings</a>
  </nav>

  <!-- Sidebar 4: Signed-in admin -->
  <div class="sidebar-footer"><div class="user-mini"><span id="sidebarAvatar" class="avatar-sm">—</span><span><strong id="sidebarEmail">Loading account…</strong><small>Family administrator</small></span></div></div>
</aside><div class="pl-64"><header class="fixed top-0 left-64 right-0 h-16 bg-surface/90 backdrop-blur-xl shadow-[0_1px_8px_rgba(0,0,0,0.04)] z-40 flex items-center justify-between px-space-lg"><div class="flex items-center gap-space-md flex-1 max-w-xl"><div class="relative w-full"><span class="material-symbols-outlined absolute left-3 top-1/2 -translate-y-1/2 text-on-surface-variant text-[18px]">search</span><input class="w-full pl-9 pr-space-md py-space-xs bg-surface-container-low rounded-lg font-body-sm text-body-sm text-on-surface placeholder:text-on-surface-variant focus:outline-none focus:ring-1 focus:ring-secondary" placeholder="Search family members" type="search" aria-label="Search family members" title="Press Enter to search the authorized family roster."/></div></div><div class="flex items-center gap-space-md"><div class="hidden md:flex items-center gap-space-xs px-space-sm py-space-xs rounded-lg bg-surface-container-low border border-surface-container"><span class="font-label-sm text-label-sm text-on-surface-variant">Family:</span><select id="familySelector" aria-label="Select active family" class="bg-transparent font-label-sm text-label-sm text-on-surface font-semibold focus:outline-none cursor-pointer"><option value="">Loading families…</option></select></div><button class="relative p-space-xs rounded-lg text-on-surface-variant hover:bg-surface-container hover:text-on-surface" type="button" disabled title="Notifications are unavailable from the Family Admin APIs."><span class="material-symbols-outlined text-[20px]">notifications</span></button><div class="flex items-center gap-space-sm pl-space-xs"><div class="hidden lg:flex flex-col text-right"><span id="signedInEmail" class="font-label-md text-label-md text-on-surface leading-tight">Loading account…</span><span class="font-label-sm text-label-sm text-secondary font-medium leading-tight">Family Administrator</span></div><div class="w-8 h-8 rounded-full bg-primary flex items-center justify-center shrink-0"><span class="material-symbols-outlined text-on-primary text-[18px]">person</span></div></div></div></header><main class="relative pt-16 bg-surface min-h-screen w-full px-space-lg py-space-md"><div class="flex flex-col w-full gap-space-lg pb-space-xl">
<!-- Top Archival Context Bar -->
<div class="flex flex-col md:flex-row md:items-center justify-between gap-space-md p-space-lg bg-surface-container-lowest rounded-xl shadow-sm relative overflow-hidden">
<div class="absolute -right-16 -top-16 w-56 h-56 rounded-full bg-secondary-container/30 pointer-events-none blur-2xl"></div>
<div class="flex flex-col gap-space-xs z-10">
<div class="flex items-center gap-space-sm flex-wrap">
<span class="font-label-sm text-label-sm uppercase tracking-wider text-secondary flex items-center gap-1 font-semibold">
<span class="material-symbols-outlined text-[16px]">verified</span>
          Family Admin Overview
        </span>
<span class="font-label-sm text-label-sm px-space-sm py-0.5 rounded-full bg-secondary-container text-on-secondary-container font-semibold">
          Family Administrator
        </span>
<span class="font-data-mono text-body-sm text-on-surface-variant flex items-center gap-1">
<span class="material-symbols-outlined text-[14px]">lock</span>
          Family ID: <span id="familyId">—</span>
        </span>
</div>
<h2 id="familyTitle" class="font-headline-lg text-headline-lg text-primary tracking-tight">Family Administration</h2>
<p class="font-body-md text-body-md text-on-surface-variant max-w-2xl">
        Family-scoped member and pending enrollment overview.
      </p>
</div>
<div class="flex items-center gap-space-sm z-10 shrink-0">
<button class="px-space-md py-space-xs rounded-lg bg-surface-container hover:bg-surface-container-high text-on-surface font-label-md text-label-md transition-all flex items-center gap-space-xs" type="button" disabled title="Ledger state is unavailable from the Family Admin APIs.">
<span class="material-symbols-outlined text-[18px]">history</span>
        Ledger State: Unavailable
      </button>
<button data-admin-href="member-roster.html?open=enroll" class="px-space-md py-space-xs rounded-lg bg-primary hover:bg-primary-container text-on-primary font-label-md text-label-md transition-all shadow-sm flex items-center gap-space-xs" type="button">
<span class="material-symbols-outlined text-[18px]">person_add</span>
        Direct Enrollment
      </button>
</div>
</div>
<!-- Primary Administrative Metrics Bento -->
<div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-6 gap-space-md">
<!-- Stat 1 -->
<div class="p-space-md rounded-xl bg-surface-container-lowest shadow-sm flex flex-col justify-between hover:shadow-md transition-shadow relative group">
<div class="flex items-center justify-between">
<span class="font-label-sm text-label-sm text-on-surface-variant">Total Member Profiles</span>
<div class="w-8 h-8 rounded-lg bg-surface-container flex items-center justify-center text-primary group-hover:bg-primary-container group-hover:text-on-primary transition-colors">
<span class="material-symbols-outlined text-[18px]">family_restroom</span>
</div>
</div>
<div class="my-space-xs">
<span id="totalMembers" class="font-headline-xl text-headline-xl text-primary font-bold">—</span>
</div>
<div class="flex items-center gap-space-xs font-body-sm text-body-sm text-on-surface-variant">
<span class="w-2 h-2 rounded-full bg-secondary"></span>
<span id="activeMembers" class="text-on-surface font-medium">—</span> Active
        <span class="text-outline-variant">/</span>
<span id="pendingMembers" class="text-on-tertiary-container font-medium">—</span> Pending
      </div>
</div>
<!-- Stat 2 -->
<div class="p-space-md rounded-xl bg-surface-container-lowest shadow-sm flex flex-col justify-between hover:shadow-md transition-shadow relative group">
<div class="flex items-center justify-between">
<span class="font-label-sm text-label-sm text-on-surface-variant">Enrollment Claims</span>
<div class="w-8 h-8 rounded-lg bg-surface-container flex items-center justify-center text-secondary group-hover:bg-secondary group-hover:text-on-secondary transition-colors">
<span class="material-symbols-outlined text-[18px]">how_to_reg</span>
</div>
</div>
<div class="my-space-xs flex items-baseline gap-space-xs">
<span id="pendingRequests" class="font-headline-xl text-headline-xl text-primary font-bold">—</span>
<span class="font-label-sm text-label-sm px-1.5 py-0.5 rounded bg-error-container text-on-error-container font-semibold">Pending</span>
</div>
<span class="font-body-sm text-body-sm text-on-surface-variant truncate">Pending membership requests</span>
</div>
<!-- Stat 3 -->
<div class="p-space-md rounded-xl bg-surface-container-lowest shadow-sm flex flex-col justify-between hover:shadow-md transition-shadow relative group">
<div class="flex items-center justify-between">
<span class="font-label-sm text-label-sm text-on-surface-variant">Identity Reviews</span>
<div class="w-8 h-8 rounded-lg bg-surface-container flex items-center justify-center text-primary-container group-hover:bg-primary group-hover:text-on-primary transition-colors">
<span class="material-symbols-outlined text-[18px]">fingerprint</span>
</div>
</div>
<div class="my-space-xs">
<span class="font-headline-xl text-headline-xl text-primary font-bold">—</span>
</div>
<span class="font-body-sm text-body-sm text-on-surface-variant truncate">Unavailable: no Family Admin API</span>
</div>
<!-- Stat 4 -->
<div class="p-space-md rounded-xl bg-surface-container-lowest shadow-sm flex flex-col justify-between hover:shadow-md transition-shadow relative group">
<div class="flex items-center justify-between">
<span class="font-label-sm text-label-sm text-on-surface-variant">Permission Access</span>
<div class="w-8 h-8 rounded-lg bg-surface-container flex items-center justify-center text-on-tertiary-fixed-variant group-hover:bg-tertiary group-hover:text-on-tertiary transition-colors">
<span class="material-symbols-outlined text-[18px]">key</span>
</div>
</div>
<div class="my-space-xs">
<span class="font-headline-xl text-headline-xl text-primary font-bold">—</span>
</div>
<span class="font-body-sm text-body-sm text-on-surface-variant truncate">Unavailable: no Family Admin API</span>
</div>
<!-- Stat 5 -->
<div class="p-space-md rounded-xl bg-surface-container-lowest shadow-sm flex flex-col justify-between hover:shadow-md transition-shadow relative group">
<div class="flex items-center justify-between">
<span class="font-label-sm text-label-sm text-on-surface-variant">Tracked Lineages</span>
<div class="w-8 h-8 rounded-lg bg-surface-container flex items-center justify-center text-secondary group-hover:bg-secondary group-hover:text-on-secondary transition-colors">
<span class="material-symbols-outlined text-[18px]">account_tree</span>
</div>
</div>
<div class="my-space-xs flex items-baseline gap-1">
<span class="font-headline-lg text-headline-lg text-primary font-bold">—</span>
<span class="font-label-md text-label-md text-on-surface-variant">N/A</span>
</div>
<span class="font-body-sm text-body-sm text-on-surface-variant truncate">Unavailable: no Family Admin API</span>
</div>
<!-- Stat 6 -->
<div class="p-space-md rounded-xl bg-surface-container-lowest shadow-sm flex flex-col justify-between hover:shadow-md transition-shadow relative group">
<div class="flex items-center justify-between">
<span class="font-label-sm text-label-sm text-on-surface-variant">Archived Vault Files</span>
<div class="w-8 h-8 rounded-lg bg-surface-container flex items-center justify-center text-primary group-hover:bg-primary-container group-hover:text-on-primary transition-colors">
<span class="material-symbols-outlined text-[18px]">folder_special</span>
</div>
</div>
<div class="my-space-xs">
<span class="font-headline-xl text-headline-xl text-primary font-bold">—</span>
</div>
<span class="font-body-sm text-body-sm text-on-surface-variant truncate">Unavailable: no Family Admin API</span>
</div>
</div>
<!-- Main Section: Urgent Queue + Governance Split Grid -->
<div class="grid grid-cols-1 xl:grid-cols-12 gap-space-lg">
<!-- Urgent Action Queue (Col 8) -->
<div class="xl:col-span-8 flex flex-col gap-space-md">
<div class="p-space-lg bg-surface-container-lowest rounded-xl shadow-sm flex flex-col gap-space-md">
<div class="flex items-center justify-between flex-wrap gap-space-sm pb-space-sm border-b-0">
<div class="flex items-center gap-space-sm">
<div class="w-9 h-9 rounded-lg bg-error-container text-on-error-container flex items-center justify-center shrink-0">
<span class="material-symbols-outlined text-[20px]">assignment_late</span>
</div>
<div>
<h3 class="font-headline-md text-headline-md text-primary">Pending Membership Requests</h3>
<p id="queueSummary" class="font-body-sm text-body-sm text-on-surface-variant">Loading family requests…</p>
</div>
</div>
<div class="flex items-center gap-space-xs">
<span class="font-data-mono text-body-sm px-space-sm py-1 bg-surface-container rounded-lg text-on-surface">Selected family</span>
</div>
</div>
<div id="pendingQueueList" class="flex flex-col gap-space-md">
<template>
<!-- Queue Item 1 -->
<div class="p-space-md rounded-xl bg-surface-container-low hover:bg-surface-container transition-all flex flex-col lg:flex-row lg:items-center justify-between gap-space-md">
<div class="flex items-start gap-space-md">
<div class="relative shrink-0">
<img class="w-12 h-12 rounded-full object-cover shadow-sm" data-alt="A refined portrait of Mary Kaemba wearing formal archival attire, soft ambient rim light, deep navy studio background, authentic African generational archive aesthetic, clean high definition corporate profile photography." src="https://lh3.googleusercontent.com/aida-public/AB6AXuDprrLh__s-bWWaY3ibkWVQO7h6ix6LrDmS2BdDXpMXNB_-Ig1hkITJwpiYxIszAw-ItUBvjZ_bpZd8OcTPc6KsGwZfFyUlmIBFlJz-Qe7LieaFUqWfHdiOlUyCBJEY-ts1aZO2vlDIKf2mj1YX65jFVlhdyqg0P4TX7qkDRf1N-Fe_Nds0ZdPcn2MnmCrpgE7S28lUaBwntEXbLiCFbDvBpE5G_qTHXLDq1_yxwGAz"/>
<div class="absolute -bottom-1 -right-1 w-5 h-5 rounded-full bg-secondary text-on-secondary flex items-center justify-center text-[10px]">
<span class="material-symbols-outlined text-[12px]">verified</span>
</div>
</div>
<div class="flex flex-col">
<div class="flex items-center gap-space-xs flex-wrap">
<span class="font-headline-sm text-headline-sm text-primary">Mary Kaemba</span>
<span class="font-label-sm text-label-sm px-space-xs py-0.5 rounded-full bg-secondary-container text-on-secondary-container font-medium">Govt ID Verified</span>
<span class="font-data-mono text-body-sm text-on-surface-variant font-medium">#REQ-9021</span>
</div>
<p class="font-body-sm text-body-sm text-on-surface-variant mt-0.5">
                Lineage Assertion: <strong class="text-on-surface font-semibold">Daughter of John Kaemba</strong> Ã¢â‚¬Â¢ Lineage Branch: Elder Mwamba Tier
              </p>
<div class="flex items-center gap-space-sm mt-space-xs font-data-mono text-body-sm text-on-surface-variant">
<span class="flex items-center gap-1"><span class="material-symbols-outlined text-[14px] text-secondary">badge</span> NIDA Card Match 100%</span>
<span>Ã¢â‚¬Â¢</span>
<span class="flex items-center gap-1"><span class="material-symbols-outlined text-[14px]">schedule</span> Submitted 2 hrs ago</span>
</div>
</div>
</div>
<div class="flex items-center gap-space-xs shrink-0 self-end lg:self-center">
<button class="px-space-md py-space-xs rounded-lg bg-surface-container-highest hover:bg-surface-variant text-on-surface font-label-md text-label-md transition-colors flex items-center gap-space-xs" type="button">
<span class="material-symbols-outlined text-[16px]">visibility</span>
              Review
            </button>
<button class="px-space-md py-space-xs rounded-lg bg-primary hover:bg-primary-container text-on-primary font-label-md text-label-md transition-colors shadow-sm flex items-center gap-space-xs" type="button">
<span class="material-symbols-outlined text-[16px]">done</span>
              Approve
            </button>
</div>
</div>
<!-- Queue Item 2 -->
<div class="p-space-md rounded-xl bg-surface-container-low hover:bg-surface-container transition-all flex flex-col lg:flex-row lg:items-center justify-between gap-space-md">
<div class="flex items-start gap-space-md">
<div class="relative shrink-0">
<img class="w-12 h-12 rounded-full object-cover shadow-sm" data-alt="Corporate documentary headshot of Kelvin Kaemba, young adult male in a minimalist slate collared shirt, warm lighting with deep teal rim illumination, high quality identity verification document standard portrait." src="https://lh3.googleusercontent.com/aida-public/AB6AXuC6K7E1P-Abqn-olz4xJuX_-qDeN1SNJgEgdHRrwzy__RBueM2J8YwgtvXo51UGXmBVnUzEas7Z8570WoDfa5O8cWlObn0neF1bV_sSPklAbV18XbLwZi_lS9zWkQbTJbporQAqUS0y8RPZsowaFMGTs9a-6NJIDGIe7q32vfow9p8QnWKQOyLctG2Ri853qJgC0e78aAlV4dzMjBsYSrCvRRFs07kiOJ-beY1tIzbR"/>
<div class="absolute -bottom-1 -right-1 w-5 h-5 rounded-full bg-on-tertiary-container text-surface-container-lowest flex items-center justify-center text-[10px]">
<span class="material-symbols-outlined text-[12px]">pending</span>
</div>
</div>
<div class="flex flex-col">
<div class="flex items-center gap-space-xs flex-wrap">
<span class="font-headline-sm text-headline-sm text-primary">Kelvin Kaemba</span>
<span class="font-label-sm text-label-sm px-space-xs py-0.5 rounded-full bg-surface-container-highest text-on-surface-variant font-medium">Pending NIDA Proof</span>
<span class="font-data-mono text-body-sm text-on-surface-variant font-medium">#IDV-4412</span>
</div>
<p class="font-body-sm text-body-sm text-on-surface-variant mt-0.5">
                Kin Assertion: <strong class="text-on-surface font-semibold">Nephew of Joseph Kaemba</strong> Ã¢â‚¬Â¢ Sibling Branch: Luka Estate
              </p>
<div class="flex items-center gap-space-sm mt-space-xs font-data-mono text-body-sm text-on-surface-variant">
<span class="flex items-center gap-1 text-on-tertiary-container"><span class="material-symbols-outlined text-[14px]">warning</span> Civil Registry Mismatch (Spelling)</span>
<span>Ã¢â‚¬Â¢</span>
<span class="flex items-center gap-1"><span class="material-symbols-outlined text-[14px]">schedule</span> Submitted 5 hrs ago</span>
</div>
</div>
</div>
<div class="flex items-center gap-space-xs shrink-0 self-end lg:self-center">
<button class="px-space-md py-space-xs rounded-lg bg-secondary hover:bg-on-secondary-container text-on-secondary font-label-md text-label-md transition-colors shadow-sm flex items-center gap-space-xs" type="button">
<span class="material-symbols-outlined text-[16px]">description</span>
              Review Docs
            </button>
</div>
</div>
<!-- Queue Item 3 -->
<div class="p-space-md rounded-xl bg-surface-container-low hover:bg-surface-container transition-all flex flex-col lg:flex-row lg:items-center justify-between gap-space-md">
<div class="flex items-start gap-space-md">
<div class="relative shrink-0">
<div class="w-12 h-12 rounded-full bg-primary-container text-on-primary flex items-center justify-center font-headline-sm text-headline-sm font-semibold shadow-sm">
                DK
              </div>
<div class="absolute -bottom-1 -right-1 w-5 h-5 rounded-full bg-surface-tint text-on-primary flex items-center justify-center text-[10px]">
<span class="material-symbols-outlined text-[12px]">hub</span>
</div>
</div>
<div class="flex flex-col">
<div class="flex items-center gap-space-xs flex-wrap">
<span class="font-headline-sm text-headline-sm text-primary">David Kaemba</span>
<span class="font-label-sm text-label-sm px-space-xs py-0.5 rounded-full bg-surface-container-high text-on-surface font-medium">Kinship Claim</span>
<span class="font-data-mono text-body-sm text-on-surface-variant font-medium">#REL-7731</span>
</div>
<p class="font-body-sm text-body-sm text-on-surface-variant mt-0.5">
                Claim: <strong class="text-on-surface font-semibold">Grandson to Mwamba Kaemba</strong> Ã¢â‚¬Â¢ Requires 2 Elder Attestations
              </p>
<div class="flex items-center gap-space-sm mt-space-xs font-data-mono text-body-sm text-on-surface-variant">
<span class="flex items-center gap-1 text-secondary"><span class="material-symbols-outlined text-[14px]">how_to_vote</span> 1/2 Attestations Confirmed</span>
<span>Ã¢â‚¬Â¢</span>
<span class="flex items-center gap-1"><span class="material-symbols-outlined text-[14px]">schedule</span> 1 day waiting</span>
</div>
</div>
</div>
<div class="flex items-center gap-space-xs shrink-0 self-end lg:self-center">
<button class="px-space-md py-space-xs rounded-lg bg-surface-container-highest hover:bg-surface-variant text-on-surface font-label-md text-label-md transition-colors flex items-center gap-space-xs" type="button">
<span class="material-symbols-outlined text-[16px]">fact_check</span>
              Verify Proof
            </button>
</div>
</div>
</template>
</div>
</div>
<!-- Lineage Relationship Graph Quick Overview -->
<div class="p-space-lg bg-surface-container-lowest rounded-xl shadow-sm flex flex-col gap-space-md">
<div class="flex items-center justify-between">
<div class="flex items-center gap-space-sm">
<div class="w-8 h-8 rounded-lg bg-secondary-container text-on-secondary-container flex items-center justify-center shrink-0">
<span class="material-symbols-outlined text-[18px]">family_star</span>
</div>
<span class="font-headline-sm text-headline-sm text-primary">Family Relationship Overview</span>
</div>
<a class="font-label-sm text-label-sm text-secondary font-semibold cursor-pointer hover:underline" href="relationships-and-kin.html">Open Relationships &amp; Kin →</a>
</div>
<div class="grid grid-cols-1 md:grid-cols-4 gap-space-sm">
<div class="p-space-sm rounded-lg bg-surface-container-low flex flex-col">
<span class="font-label-sm text-label-sm text-on-surface-variant">Lineage summary</span>
<span class="font-headline-sm text-headline-sm text-primary font-bold mt-1">Unavailable</span>
<span class="font-body-sm text-body-sm text-secondary">No lineage summary API</span>
</div>
<div class="p-space-sm rounded-lg bg-surface-container-low flex flex-col">
<span class="font-label-sm text-label-sm text-on-surface-variant">Lineage summary</span>
<span class="font-headline-sm text-headline-sm text-primary font-bold mt-1">Unavailable</span>
<span class="font-body-sm text-body-sm text-secondary">No lineage summary API</span>
</div>
<div class="p-space-sm rounded-lg bg-surface-container-low flex flex-col">
<span class="font-label-sm text-label-sm text-on-surface-variant">Lineage summary</span>
<span class="font-headline-sm text-headline-sm text-primary font-bold mt-1">Unavailable</span>
<span class="font-body-sm text-body-sm text-on-tertiary-container">No lineage summary API</span>
</div>
<div class="p-space-sm rounded-lg bg-surface-container-low flex flex-col">
<span class="font-label-sm text-label-sm text-on-surface-variant">Lineage summary</span>
<span class="font-headline-sm text-headline-sm text-primary font-bold mt-1">Unavailable</span>
<span class="font-body-sm text-body-sm text-secondary">No lineage summary API</span>
</div>
</div>
</div>
</div>
<!-- Governance & Security Health Column (Col 4) -->
<div class="xl:col-span-4 flex flex-col gap-space-lg">
<!-- Security & Health Progress Card -->
<div class="p-space-lg bg-surface-container-lowest rounded-xl shadow-sm flex flex-col gap-space-md">
<div class="flex items-center justify-between pb-space-xs">
<div class="flex items-center gap-space-xs">
<span class="material-symbols-outlined text-secondary text-[20px]">shield_with_heart</span>
<h3 class="font-headline-sm text-headline-sm text-primary">Identity Integrity Health</h3>
</div>
<span class="font-headline-sm text-headline-sm text-secondary font-bold">Unavailable</span>
</div>
<!-- Gauge Visual -->
<div class="flex flex-col gap-space-xs">
<div class="w-full bg-surface-container h-3 rounded-full overflow-hidden flex">
<div class="bg-secondary h-full rounded-full transition-all duration-500" style="width: 0%;"></div>
</div>
<div class="flex justify-between font-label-sm text-label-sm text-on-surface-variant">
<span>Identity metrics unavailable</span>
<span>No supporting API</span>
</div>
</div>
<div class="p-space-md rounded-lg bg-surface-container-low flex flex-col gap-space-xs text-body-sm font-body-sm">
<div class="flex items-center gap-space-xs text-on-surface font-medium">
<span class="material-symbols-outlined text-[16px] text-secondary">lock_clock</span>
            Identity integrity unavailable
          </div>
<p class="text-on-surface-variant">
            The current Family Admin APIs do not provide identity verification or cryptographic ledger health data.
          </p>
</div>
<div class="flex flex-col gap-space-xs pt-space-xs">
<div class="flex items-center justify-between text-body-sm font-body-sm">
<span class="text-on-surface-variant">NIDA Verification Sync</span>
<span class="text-secondary font-medium">Unavailable</span>
</div>
<div class="flex items-center justify-between text-body-sm font-body-sm">
<span class="text-on-surface-variant">Generational Chain Hash</span>
<span class="font-data-mono text-on-surface text-body-sm">Unavailable</span>
</div>
<div class="flex items-center justify-between text-body-sm font-body-sm">
<span class="text-on-surface-variant">Last Vault Snapshot</span>
<span class="text-on-surface">Unavailable</span>
</div>
</div>
</div>
<!-- Governance Audit Trail -->
<div class="p-space-lg bg-surface-container-lowest rounded-xl shadow-sm flex flex-col gap-space-md flex-1">
<div class="flex items-center justify-between">
<div class="flex items-center gap-space-xs">
<span class="material-symbols-outlined text-primary text-[20px]">receipt_long</span>
<h3 class="font-headline-sm text-headline-sm text-primary">Governance Audit Trail</h3>
</div>
<span class="font-label-sm text-label-sm text-on-surface-variant font-medium">Unavailable</span>
</div>
<!-- Timeline Log Entries -->
<div class="flex flex-col gap-space-md relative pl-space-sm before:content-[''] before:absolute before:left-3 before:top-2 before:bottom-2 before:w-0.5 before:bg-surface-container">
<template>
<!-- Log 1 -->
<div class="relative pl-space-md flex flex-col gap-0.5">
<div class="absolute -left-[5px] top-1.5 w-2.5 h-2.5 rounded-full bg-secondary"></div>
<span class="font-body-sm text-body-sm text-on-surface font-semibold leading-tight">
              Audit history is unavailable from the Family Admin APIs.
            </span>
<div class="flex items-center gap-space-xs font-data-mono text-body-sm text-on-surface-variant">
<span>Unavailable</span>
<span>Ã¢â‚¬Â¢</span>
<span class="text-secondary">No audit endpoint</span>
</div>
</div>
<!-- Log 2 -->
<div class="relative pl-space-md flex flex-col gap-0.5">
<div class="absolute -left-[5px] top-1.5 w-2.5 h-2.5 rounded-full bg-on-tertiary-container"></div>
<span class="font-body-sm text-body-sm text-on-surface font-semibold leading-tight">
              Audit history is unavailable from the Family Admin APIs.
            </span>
<div class="flex items-center gap-space-xs font-data-mono text-body-sm text-on-surface-variant">
<span>Unavailable</span>
<span>Ã¢â‚¬Â¢</span>
<span>No audit endpoint</span>
</div>
</div>
<!-- Log 3 -->
<div class="relative pl-space-md flex flex-col gap-0.5">
<div class="absolute -left-[5px] top-1.5 w-2.5 h-2.5 rounded-full bg-primary"></div>
<span class="font-body-sm text-body-sm text-on-surface font-semibold leading-tight">
              Audit history is unavailable from the Family Admin APIs.
            </span>
<div class="flex items-center gap-space-xs font-data-mono text-body-sm text-on-surface-variant">
<span>Unavailable</span>
<span>Ã¢â‚¬Â¢</span>
<span>No audit endpoint</span>
</div>
</div>
<!-- Log 4 -->
<div class="relative pl-space-md flex flex-col gap-0.5">
<div class="absolute -left-[5px] top-1.5 w-2.5 h-2.5 rounded-full bg-surface-variant"></div>
<span class="font-body-sm text-body-sm text-on-surface font-semibold leading-tight">
              Audit history is unavailable from the Family Admin APIs.
            </span>
<div class="flex items-center gap-space-xs font-data-mono text-body-sm text-on-surface-variant">
<span>Unavailable</span>
<span>Ã¢â‚¬Â¢</span>
<span>No audit endpoint</span>
</div>
</div>
</template>
<p class="font-body-sm text-body-sm text-on-surface-variant">Audit history is unavailable from the Family Admin APIs.</p>
</div>
<button class="w-full mt-auto py-space-xs rounded-lg bg-surface-container hover:bg-surface-container-high text-on-surface font-label-md text-label-md transition-colors text-center" type="button" disabled title="No Family Admin audit-history API is available.">
          View Comprehensive Audit History
        </button>
</div>
</div>
</div>
<!-- Quick Administrative Command Bar / Actions -->
<div class="p-space-lg bg-surface-container-lowest rounded-xl shadow-sm flex flex-col gap-space-md">
<div class="flex items-center justify-between">
<div class="flex items-center gap-space-xs">
<span class="material-symbols-outlined text-primary text-[20px]">bolt</span>
<h3 class="font-headline-sm text-headline-sm text-primary">Quick Administrative Actions</h3>
</div>
<span class="font-label-sm text-label-sm text-on-surface-variant">Common governance workflows</span>
</div>
<div class="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-5 gap-space-sm">
<!-- Action 1 -->
<button data-admin-href="enrollment-requests.html" class="p-space-md rounded-xl bg-surface-container-low hover:bg-surface-container text-left transition-all flex flex-col justify-between gap-space-md group" type="button">
<div class="w-10 h-10 rounded-lg bg-primary text-on-primary flex items-center justify-center shadow-sm group-hover:scale-105 transition-transform">
<span class="material-symbols-outlined text-[20px]">fact_check</span>
</div>
<div class="flex flex-col">
<span class="font-headline-sm text-headline-sm text-primary group-hover:text-primary-container">Review Membership Queue</span>
<span class="font-body-sm text-body-sm text-on-surface-variant mt-0.5">Open pending requests</span>
</div>
</button>
<!-- Action 2 -->
<button data-admin-href="member-roster.html?open=enroll" class="p-space-md rounded-xl bg-surface-container-low hover:bg-surface-container text-left transition-all flex flex-col justify-between gap-space-md group" type="button">
<div class="w-10 h-10 rounded-lg bg-secondary text-on-secondary flex items-center justify-center shadow-sm group-hover:scale-105 transition-transform">
<span class="material-symbols-outlined text-[20px]">fitbit_push_ups</span>
</div>
<div class="flex flex-col">
<span class="font-headline-sm text-headline-sm text-primary group-hover:text-secondary">Enroll Member</span>
<span class="font-body-sm text-body-sm text-on-surface-variant mt-0.5">Open member enrollment</span>
</div>
</button>
<!-- Action 3 -->
<button data-admin-href="relationships-and-kin.html" class="p-space-md rounded-xl bg-surface-container-low hover:bg-surface-container text-left transition-all flex flex-col justify-between gap-space-md group" type="button">
<div class="w-10 h-10 rounded-lg bg-surface-tint text-on-primary flex items-center justify-center shadow-sm group-hover:scale-105 transition-transform">
<span class="material-symbols-outlined text-[20px]">hub</span>
</div>
<div class="flex flex-col">
<span class="font-headline-sm text-headline-sm text-primary group-hover:text-surface-tint">Open Family Relationships</span>
<span class="font-body-sm text-body-sm text-on-surface-variant mt-0.5">Map sibling & kin lines</span>
</div>
</button>
<!-- Action 4 -->
<button class="p-space-md rounded-xl bg-surface-container-low hover:bg-surface-container text-left transition-all flex flex-col justify-between gap-space-md group" type="button" disabled title="Family ledger export is unavailable from the Family Admin APIs.">
<div class="w-10 h-10 rounded-lg bg-tertiary-container text-on-tertiary-container flex items-center justify-center shadow-sm group-hover:scale-105 transition-transform">
<span class="material-symbols-outlined text-[20px]">cloud_download</span>
</div>
<div class="flex flex-col">
<span class="font-headline-sm text-headline-sm text-primary group-hover:text-tertiary">Export Family Ledger Backup</span>
<span class="font-body-sm text-body-sm text-on-surface-variant mt-0.5">Unavailable: no export API</span>
</div>
</button>
<!-- Action 5 -->
<button data-admin-href="family-settings.html" class="p-space-md rounded-xl bg-surface-container-low hover:bg-surface-container text-left transition-all flex flex-col justify-between gap-space-md group" type="button">
<div class="w-10 h-10 rounded-lg bg-surface-container-high text-on-surface flex items-center justify-center shadow-sm group-hover:scale-105 transition-transform">
<span class="material-symbols-outlined text-[20px]">settings_suggest</span>
</div>
<div class="flex flex-col">
<span class="font-headline-sm text-headline-sm text-primary">Open Family Settings</span>
<span class="font-body-sm text-body-sm text-on-surface-variant mt-0.5">Open settings page</span>
</div>
</button>
</div>
</div>
</div></main></div><script>
  // Sidebar navigation: mobile open/close control.
  (function () {
    const sidebar = document.getElementById('roleSidebar');
    const toggle = document.querySelector('.sidebar-toggle');
    if (!sidebar || !toggle) return;
    toggle.addEventListener('click', function () {
      const isOpen = sidebar.classList.toggle('open');
      toggle.setAttribute('aria-expanded', String(isOpen));
      toggle.setAttribute('aria-label', isOpen ? 'Close navigation menu' : 'Open navigation menu');
      const icon = toggle.querySelector('.material-symbols-outlined');
      if (icon) icon.textContent = isOpen ? 'close' : 'menu';
    });
    sidebar.querySelectorAll('a').forEach(function (link) {
      link.addEventListener('click', function () {
        if (window.matchMedia('(max-width: 760px)').matches) {
          sidebar.classList.remove('open');
          toggle.setAttribute('aria-expanded', 'false');
          toggle.setAttribute('aria-label', 'Open navigation menu');
          const icon = toggle.querySelector('.material-symbols-outlined');
          if (icon) icon.textContent = 'menu';
        }
      });
    });
  }());

  (function () {
    const apiBase = '../zip_extracted/public/api/';
    const familySelector = document.getElementById('familySelector');
    const queueList = document.getElementById('pendingQueueList');
    const queueSummary = document.getElementById('queueSummary');
    const memberCount = document.getElementById('totalMembers');
    const activeCount = document.getElementById('activeMembers');
    const pendingMemberCount = document.getElementById('pendingMembers');
    const pendingRequestCount = document.getElementById('pendingRequests');
    let csrfToken = '';
    let adminFamilies = [];

    if (!familySelector || !queueList || !queueSummary) return;

    const ledgerExportButton = [...document.querySelectorAll('button')]
      .find((button) => button.textContent.includes('Export Family Ledger Backup'));
    if (ledgerExportButton) {
      ledgerExportButton.disabled = false;
      ledgerExportButton.title = 'Open family-scoped archive export and restore tools.';
      const ledgerDescription = ledgerExportButton.querySelector('.font-body-sm');
      if (ledgerDescription) ledgerDescription.textContent = 'Open encrypted family archive tools';
      ledgerExportButton.addEventListener('click', () => {
        const familyQuery = familySelector.value ? `?family_id=${encodeURIComponent(familySelector.value)}` : '';
        window.location.href = `family-data-vault.html${familyQuery}`;
      });
    }

    const globalSearch = document.querySelector('input[aria-label="Search family members"]');
    globalSearch?.addEventListener('keydown', (event) => {
      if (event.key !== 'Enter') return;
      event.preventDefault();
      const term = globalSearch.value.trim();
      const familyQuery = familySelector.value ? `&family_id=${encodeURIComponent(familySelector.value)}` : '';
      window.location.href = `member-roster.html${term ? `?q=${encodeURIComponent(term)}${familyQuery}` : (familyQuery ? `?${familyQuery.slice(1)}` : '')}`;
    });

    queueList.replaceChildren();

    async function request(path) {
      const headers = { Accept: 'application/json' };
      if (csrfToken) headers['X-CSRF-Token'] = csrfToken;
      const response = await fetch(apiBase + path, {
        credentials: 'same-origin',
        headers
      });
      let result;
      try {
        result = await response.json();
      } catch {
        throw new Error(`The server returned an invalid response (HTTP ${response.status}).`);
      }
      if (!response.ok || !result.success) {
        throw new Error(result.error || `Request failed (HTTP ${response.status}).`);
      }
      return result;
    }

    const notificationButton = document.querySelector('.top-actions button[aria-label="Notifications"]');
    if (notificationButton) {
      notificationButton.disabled = false;
      notificationButton.title = 'Open family action items';
      const badge = document.createElement('span');
      badge.hidden = true;
      badge.style.cssText = 'position:absolute;top:-3px;right:-3px;min-width:16px;padding:1px 4px;border-radius:999px;background:#b42318;color:#fff;font-size:10px;line-height:14px;text-align:center';
      notificationButton.style.position = 'relative';
      notificationButton.append(badge);
      const dialog = document.createElement('dialog');
      dialog.className = 'rounded-xl p-space-md';
      dialog.style.cssText = 'width:min(440px,92vw);border:1px solid #c3c6ce;border-radius:14px;padding:20px;box-shadow:0 18px 55px #0003';
      dialog.setAttribute('aria-labelledby', 'adminActionItemsTitle');
      const title = document.createElement('h2');
      title.id = 'adminActionItemsTitle';
      title.textContent = 'Family action items';
      const status = document.createElement('p');
      status.className = 'font-body-sm text-body-sm text-on-surface-variant';
      status.setAttribute('role', 'status');
      const list = document.createElement('div');
      const close = document.createElement('button');
      close.type = 'button';
      close.className = 'px-space-md py-space-xs rounded-lg bg-surface-container hover:bg-surface-container-high text-on-surface font-label-md text-label-md';
      close.textContent = 'Close';
      close.addEventListener('click', () => dialog.close());
      dialog.append(title, status, list, close);
      document.body.append(dialog);
      notificationButton.addEventListener('click', async () => {
        dialog.showModal();
        const familyId = familySelector.value;
        status.setAttribute('role', 'status');
        status.textContent = 'Loading family action items...';
        list.replaceChildren();
        if (!familyId) { status.textContent = 'No active Family Admin family is available.'; return; }
        try {
          const result = await request(`family/notifications.php?family_id=${encodeURIComponent(familyId)}`);
          const total = Number(result.total) || 0;
          badge.textContent = total > 99 ? '99+' : String(total);
          badge.hidden = total === 0;
          notificationButton.setAttribute('aria-label', total ? `Notifications, ${total} family action items` : 'Notifications, no family action items');
          if (!result.items?.length) { status.textContent = 'No family items are waiting for your review.'; return; }
          status.textContent = `${total} item${total === 1 ? '' : 's'} need review.`;
          const allowed = new Set(['enrollment-requests.html', 'relationships-and-kin.html']);
          for (const item of result.items) {
            if (!allowed.has(item.url)) continue;
            const link = document.createElement('a');
            link.href = item.url;
            link.textContent = `${item.title} (${Number(item.count) || 0})`;
            link.className = 'block my-space-xs px-space-md py-space-xs rounded-lg bg-surface-container-low text-primary';
            list.append(link);
          }
        } catch (error) {
          status.textContent = `Family action items are unavailable: ${error.message}`;
          status.setAttribute('role', 'alert');
        }
      });
    }

    function setUnavailableCounts() {
      [memberCount, activeCount, pendingMemberCount, pendingRequestCount].forEach((node) => {
        if (node) node.textContent = '—';
      });
    }

    function setQueueMessage(text) {
      queueList.replaceChildren();
      const message = document.createElement('p');
      message.className = 'p-space-md rounded-xl bg-surface-container-low text-body-sm text-on-surface-variant';
      message.textContent = text;
      queueList.append(message);
    }

    function createTextElement(tagName, className, text) {
      const node = document.createElement(tagName);
      node.className = className;
      node.textContent = text;
      return node;
    }

    function renderRequests(requests) {
      queueList.replaceChildren();
      if (!requests.length) {
        setQueueMessage('There are no pending membership requests for this family.');
        return;
      }

      for (const item of requests) {
        const firstName = String(item.first_name || '');
        const middleName = String(item.middle_name || '');
        const lastName = String(item.last_name || '');
        const fullName = [firstName, middleName, lastName].filter(Boolean).join(' ') || 'Name unavailable';
        const initials = [firstName, lastName].filter(Boolean).map((part) => part.charAt(0)).join('').toUpperCase() || '—';
        const card = document.createElement('div');
        card.className = 'p-space-md rounded-xl bg-surface-container-low hover:bg-surface-container transition-all flex flex-col lg:flex-row lg:items-center justify-between gap-space-md';

        const personGroup = document.createElement('div');
        personGroup.className = 'flex items-start gap-space-md';
        const avatar = createTextElement('div', 'w-12 h-12 rounded-full bg-primary-container text-on-primary flex items-center justify-center font-headline-sm text-headline-sm font-semibold shadow-sm shrink-0', initials);
        const details = document.createElement('div');
        details.className = 'flex flex-col';
        const heading = document.createElement('div');
        heading.className = 'flex items-center gap-space-xs flex-wrap';
        heading.append(
          createTextElement('span', 'font-headline-sm text-headline-sm text-primary', fullName),
          createTextElement('span', 'font-label-sm text-label-sm px-space-xs py-0.5 rounded-full bg-surface-container-highest text-on-surface-variant font-medium', 'Pending membership request'),
          createTextElement('span', 'font-data-mono text-body-sm text-on-surface-variant font-medium', `#REQ-${String(item.id ?? '—')}`)
        );
        const relationship = createTextElement(
          'p',
          'font-body-sm text-body-sm text-on-surface-variant mt-0.5',
          `Claimed relationship: ${String(item.claimed_relationship || 'Not provided')}`
        );
        const metadata = createTextElement(
          'div',
          'flex items-center gap-space-sm mt-space-xs font-data-mono text-body-sm text-on-surface-variant',
          `Target: ${String(item.target_member_name || 'Not specified')} · Submitted: ${String(item.created_at || 'Date unavailable')}`
        );
        details.append(heading, relationship, metadata);
        if (item.reason) {
          details.append(createTextElement('p', 'font-body-sm text-body-sm text-on-surface-variant mt-0.5', `Reason: ${String(item.reason)}`));
        }
        personGroup.append(avatar, details);

        const actions = document.createElement('div');
        actions.className = 'flex items-center gap-space-xs shrink-0 self-end lg:self-center';
        const review = createTextElement('button', 'px-space-md py-space-xs rounded-lg bg-surface-container-highest hover:bg-surface-variant text-on-surface font-label-md text-label-md transition-colors flex items-center gap-space-xs', 'Review in Enrollment Requests');
        review.type = 'button';
        review.addEventListener('click', () => {
          window.location.href = 'enrollment-requests.html';
        });
        actions.append(review);
        card.append(personGroup, actions);
        queueList.append(card);
      }
    }

    async function loadFamilyData() {
      const familyId = familySelector.value;
      if (!familyId) {
        setUnavailableCounts();
        queueSummary.textContent = 'No active Family Admin assignment is available.';
        setQueueMessage('Family-scoped dashboard data is unavailable without an active Family Admin assignment.');
        return;
      }

      const family = familySelector.options[familySelector.selectedIndex];
      const familyName = family ? family.textContent : 'selected family';
      const familyIdLabel = document.getElementById('familyId');
      const familyTitle = document.getElementById('familyTitle');
      if (familyIdLabel) familyIdLabel.textContent = familyId;
      if (familyTitle) familyTitle.textContent = `Family Administration — ${familyName}`;
      setUnavailableCounts();
      queueSummary.textContent = `Loading pending requests for ${familyName}…`;
      setQueueMessage('Loading family data…');

      const [membersResult, requestsResult] = await Promise.allSettled([
        request(`members/list.php?family_id=${encodeURIComponent(familyId)}`),
        request(`family/membership_requests.php?family_id=${encodeURIComponent(familyId)}`)
      ]);
      if (familySelector.value !== familyId) return;

      if (membersResult.status === 'fulfilled' && Array.isArray(membersResult.value.members)) {
        const members = membersResult.value.members;
        if (memberCount) memberCount.textContent = String(members.length);
        if (activeCount) activeCount.textContent = String(members.filter((member) => member.member_status === 'active').length);
        if (pendingMemberCount) pendingMemberCount.textContent = String(members.filter((member) => member.member_status === 'pending').length);
      } else {
        if (memberCount) memberCount.textContent = '—';
        if (activeCount) activeCount.textContent = '—';
        if (pendingMemberCount) pendingMemberCount.textContent = '—';
      }

      if (requestsResult.status === 'fulfilled' && Array.isArray(requestsResult.value.requests)) {
        const requests = requestsResult.value.requests;
        if (pendingRequestCount) pendingRequestCount.textContent = String(requests.length);
        queueSummary.textContent = `${requests.length} pending membership request${requests.length === 1 ? '' : 's'} for ${familyName}.`;
        renderRequests(requests);
      } else {
        if (pendingRequestCount) pendingRequestCount.textContent = '—';
        const error = requestsResult.status === 'rejected' ? requestsResult.reason : null;
        const message = error instanceof Error ? error.message : 'Pending requests are unavailable.';
        queueSummary.textContent = message;
        setQueueMessage(message);
      }
    }

    familySelector.addEventListener('change', loadFamilyData);
    const auditHistoryButton = [...document.querySelectorAll('button')]
      .find((button) => button.textContent.includes('View Comprehensive Audit History'));
    if (auditHistoryButton) {
      auditHistoryButton.disabled = false;
      auditHistoryButton.removeAttribute('title');
      auditHistoryButton.dataset.adminHref = 'admin-logs.html';
      const unavailableMessage = [...document.querySelectorAll('p')]
        .find((paragraph) => paragraph.textContent.includes('Audit history is unavailable from the Family Admin APIs.'));
      if (unavailableMessage) unavailableMessage.textContent = 'Use Audit Logs to review family-scoped administrator events.';
    }
    document.querySelectorAll('[data-admin-href]').forEach((button) => {
      button.addEventListener('click', () => {
        if (!button.disabled) window.location.href = button.dataset.adminHref;
      });
    });

    (async function initializeDashboard() {
      try {
        const auth = await request('auth/me.php');
        if (typeof auth.csrf_token !== 'string' || auth.csrf_token.length < 32) {
          throw new Error('Could not obtain a valid security token. Refresh and sign in again.');
        }
        csrfToken = auth.csrf_token;
        const email = String(auth.user?.email || 'Signed-in account');
        const accountName = document.getElementById('signedInEmail');
        const sidebarName = document.getElementById('sidebarEmail');
        const sidebarAvatar = document.getElementById('sidebarAvatar');
        if (accountName) accountName.textContent = email;
        if (sidebarName) sidebarName.textContent = email;
        if (sidebarAvatar) {
          sidebarAvatar.textContent = email.split('@')[0].split(/[._-]+/).filter(Boolean).slice(0, 2).map((part) => part.charAt(0)).join('').toUpperCase() || '—';
        }

        const result = await request('family/my_family.php');
        adminFamilies = (Array.isArray(result.families) ? result.families : []).filter((family) =>
          family.status === 'active' && family.role === 'admin'
        );
        familySelector.replaceChildren();
        for (const family of adminFamilies) {
          const option = document.createElement('option');
          option.value = String(family.id);
          option.textContent = String(family.family_name || `Family ${family.id}`);
          familySelector.append(option);
        }

        if (!adminFamilies.length) {
          const option = document.createElement('option');
          option.value = '';
          option.textContent = 'No active Family Admin family';
          familySelector.append(option);
          familySelector.disabled = true;
          setUnavailableCounts();
          queueSummary.textContent = 'No active Family Admin assignment is available.';
          setQueueMessage('No active Family Admin assignment is available for this account.');
          return;
        }

        const requestedFamilyId = new URLSearchParams(window.location.search).get('family_id');
        if (requestedFamilyId && adminFamilies.some((family) => String(family.id) === requestedFamilyId)) {
          familySelector.value = requestedFamilyId;
        }
        const selectedFamily = adminFamilies.find((family) => String(family.id) === familySelector.value) || adminFamilies[0];
        familySelector.value = String(selectedFamily.id);
        await loadFamilyData();
      } catch (error) {
        familySelector.disabled = true;
        setUnavailableCounts();
        const message = error instanceof Error ? error.message : 'Family Admin data is unavailable.';
        queueSummary.textContent = message;
        setQueueMessage(message);
      }
    }());
  }());
</script></body></html>
