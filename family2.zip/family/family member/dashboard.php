<?php
declare(strict_types=1);
require_once __DIR__ . '/../zip_extracted/src/bootstrap.php';
PageAccess::requireFamilyDashboardRole('member');
?>
<!DOCTYPE html>

<html lang="en"><head><meta charset="utf-8"/><meta content="width=device-width, initial-scale=1.0" name="viewport"/><meta content="web_dashboard" name="shell-type"/><link href="https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined:opsz,wght,FILL,GRAD@20..48,100..700,0..1,-50..200" rel="stylesheet"/>
<link href="https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined:wght,FILL@100..700,0..1&display=swap" rel="stylesheet"/>
<link href="https://fonts.googleapis.com/css2?family=Inter:wght@100..900&display=swap" rel="stylesheet"/><style>@layer base{html,body{margin:0;padding:0;}body{overscroll-behavior:none;}main>:first-child{margin-top:0!important;}main>:last-child{margin-bottom:0!important;}}::-webkit-scrollbar{display:none;}</style><script src="https://cdn.tailwindcss.com"></script><script id="tailwind-config">tailwind.config={darkMode:"class",theme:{extend:{colors:{"secondary-fixed-dim":"#78d6d5","tertiary":"#291900","inverse-surface":"#213145","secondary":"#006a6a","surface":"#f8f9ff","surface-dim":"#cbdbf5","surface-bright":"#f8f9ff","inverse-on-surface":"#eaf1ff","on-primary-container":"#809abd","surface-container-high":"#dce9ff","on-tertiary-container":"#b7935c","on-primary-fixed-variant":"#2e4867","error":"#ba1a1a","primary-fixed":"#d2e4ff","secondary-fixed":"#94f2f2","tertiary-fixed":"#ffddaf","on-primary-fixed":"#001d37","on-primary":"#ffffff","tertiary-container":"#442c00","surface-variant":"#d3e4fe","primary":"#001d37","surface-container-low":"#eff4ff","outline-variant":"#c3c6ce","on-error":"#ffffff","surface-container-highest":"#d3e4fe","primary-fixed-dim":"#aec9ed","on-tertiary-fixed-variant":"#5d4213","on-secondary":"#ffffff","on-background":"#0b1c30","secondary-container":"#94f2f2","inverse-primary":"#aec9ed","on-surface":"#0b1c30","error-container":"#ffdad6","on-surface-variant":"#43474d","primary-container":"#16324f","on-tertiary-fixed":"#281800","background":"#f8f9ff","surface-container-lowest":"#ffffff","on-secondary-container":"#007070","on-secondary-fixed":"#002020","surface-container":"#e5eeff","on-tertiary":"#ffffff","on-error-container":"#93000a","on-secondary-fixed-variant":"#004f50","outline":"#74777e","surface-tint":"#466080","tertiary-fixed-dim":"#e8c086"},borderRadius:{"DEFAULT":"0.25rem","lg":"0.5rem","xl":"0.75rem","full":"9999px"},spacing:{"space-xl":"2rem","space-sm":"0.5rem","margin":"2rem","space-xs":"0.25rem","gutter":"1.5rem","space-md":"1rem","space-lg":"1.5rem","margin-mobile":"1rem","gutter-mobile":"1rem"},fontFamily:{"body-sm":["Inter"],"body-md":["Inter"],"body-lg":["Inter"],"data-mono":["Inter"],"headline-sm":["Inter"],"headline-md":["Inter"],"headline-xl":["Inter"],"label-sm":["Inter"],"headline-xl-mobile":["Inter"],"headline-lg":["Inter"],"label-md":["Inter"]},fontSize:{"body-sm":["12px",{"lineHeight":"16px","fontWeight":"400"}],"body-md":["14px",{"lineHeight":"20px","fontWeight":"400"}],"body-lg":["16px",{"lineHeight":"24px","fontWeight":"400"}],"data-mono":["13px",{"lineHeight":"18px","letterSpacing":"0.04em","fontWeight":"500"}],"headline-sm":["16px",{"lineHeight":"24px","fontWeight":"600"}],"headline-md":["20px",{"lineHeight":"28px","letterSpacing":"-0.01em","fontWeight":"600"}],"headline-xl":["36px",{"lineHeight":"44px","letterSpacing":"-0.02em","fontWeight":"700"}],"label-sm":["12px",{"lineHeight":"16px","letterSpacing":"0.02em","fontWeight":"600"}],"headline-xl-mobile":["28px",{"lineHeight":"36px","letterSpacing":"-0.01em","fontWeight":"700"}],"headline-lg":["24px",{"lineHeight":"32px","letterSpacing":"-0.015em","fontWeight":"600"}],"label-md":["14px",{"lineHeight":"20px","fontWeight":"500"}]}}}};</script><style>

/* Sidebar styling aligned with the other KinKeep Vault role pages. */
:root {
  --sidebar-primary: #001d37;
  --sidebar-primary-container: #16324f;
  --sidebar-secondary-soft: #d8f4f1;
  --sidebar-surface-low: #eff4ff;
  --sidebar-surface-mid: #e5eeff;
  --sidebar-surface-high: #dce9ff;
  --sidebar-ink: #0b1c30;
  --sidebar-muted: #626c7b;
  --sidebar-line: #dce4ef;
  --sidebar-white: #fff;
  --sidebar-shadow: 0 8px 24px rgba(16, 39, 65, .06);
}
.sidebar {
  position: fixed; inset: 0 auto 0 0; z-index: 50; display: flex; flex-direction: column;
  width: 256px; padding: 16px; overflow-y: auto; background: var(--sidebar-surface-low);
  box-shadow: 1px 0 10px rgba(0, 29, 55, .06); font-family: Inter, Arial, sans-serif;
}
.sidebar, .sidebar * { box-sizing: border-box; }
.sidebar a { color: inherit; text-decoration: none; }
.sidebar .brand { display: flex; align-items: center; gap: 10px; padding: 10px 8px; margin-bottom: 16px; background: var(--sidebar-white); border-radius: 10px; box-shadow: var(--sidebar-shadow); }
.sidebar .brand-icon { display: grid; width: 38px; height: 38px; flex: 0 0 auto; place-items: center; color: white; background: var(--sidebar-primary-container); border-radius: 9px; font-size: 23px; }
.sidebar .brand-name { display: block; color: var(--sidebar-primary); font-size: 15px; font-weight: 700; line-height: 1.25; }
.sidebar .brand-caption { display: block; color: var(--sidebar-muted); font-size: 11px; }
.sidebar .role-box { display: flex; justify-content: space-between; align-items: center; gap: 6px; padding: 9px 10px; margin-bottom: 16px; background: var(--sidebar-surface-mid); border-radius: 9px; }
.sidebar .role-box > span:first-child { display: flex; align-items: center; gap: 6px; font-size: 12px; font-weight: 600; white-space: nowrap; }
.sidebar .role-box .material-symbols-outlined { font-size: 17px; }
.sidebar .role-pill { display: inline-flex; align-items: center; gap: 5px; padding: 3px 9px; color: #005657; background: var(--sidebar-secondary-soft); border-radius: 999px; font-size: 11px; font-weight: 650; white-space: nowrap; }
.sidebar .admin-label { color: #76500f; background: #fff0ce; }
.sidebar .nav-label, .sidebar .admin-nav-label { padding: 9px 7px 5px; color: var(--sidebar-muted); font-size: 10px; font-weight: 700; letter-spacing: .1em; text-transform: uppercase; }
.sidebar .side-nav { display: grid; gap: 3px; }
.sidebar .side-nav a { display: flex; align-items: center; gap: 10px; padding: 8px 10px; color: #536174; border-radius: 8px; font-size: 13px; transition: .15s ease; }
.sidebar .side-nav a:hover { color: var(--sidebar-ink); background: var(--sidebar-surface-high); }
.sidebar .side-nav a.active { color: white; background: var(--sidebar-primary-container); font-weight: 600; }
.sidebar .side-nav .material-symbols-outlined { font-size: 19px; }
.sidebar .sidebar-footer { margin-top: auto; padding-top: 18px; }
.sidebar .user-mini { display: flex; align-items: center; gap: 10px; padding: 11px 7px 2px; border-top: 1px solid var(--sidebar-line); }
.sidebar .avatar-sm { display: grid; width: 36px; height: 36px; flex: 0 0 auto; place-items: center; overflow: hidden; color: #315273; background: #dce9f8; border-radius: 50%; font-size: 12px; font-weight: 700; }
.sidebar .user-mini strong { display: block; color: var(--sidebar-ink); font-size: 12px; }
.sidebar .user-mini small { color: var(--sidebar-muted); font-size: 11px; }
.sidebar-toggle { display: none; }
@media (max-width: 760px) {
  .sidebar { transform: translateX(-100%); transition: transform .2s ease; }
  .sidebar.open { transform: translateX(0); }
  .sidebar-toggle { display: inline-grid; position: fixed; z-index: 45; top: 12px; left: 12px; width: 38px; height: 38px; place-items: center; color: var(--sidebar-primary); background: white; border: 1px solid var(--sidebar-line); border-radius: 9px; box-shadow: var(--sidebar-shadow); cursor: pointer; }
  header { left: 0 !important; padding-left: 60px !important; }
  main { margin-left: 0 !important; width: 100% !important; }
}
@media (min-width: 761px) {
  main { margin-left: 256px !important; width: calc(100% - 256px) !important; }
}



/* =========================================================
   SHARED ROLE SIDEBAR — aligned with member-pages.css
   Sidebar-only overrides; dashboard content/layout untouched.
   ========================================================= */
.sidebar {
  position: fixed !important;
  inset: 0 auto 0 0 !important;
  z-index: 50 !important;
  display: flex !important;
  flex-direction: column !important;
  width: 256px !important;
  padding: 16px !important;
  overflow-y: auto !important;
  background: #eff4ff !important;
  box-shadow: 1px 0 10px rgba(0, 29, 55, .06) !important;
  color: #0b1c30;
  font-family: Inter, Arial, sans-serif !important;
  box-sizing: border-box;
}
.sidebar .brand {
  display: flex !important; align-items: center !important; gap: 10px !important;
  padding: 10px 8px !important; margin: 0 0 16px !important;
  background: #fff !important; border-radius: 10px !important;
  box-shadow: 0 8px 24px rgba(16, 39, 65, .06) !important;
  text-decoration: none !important;
}
.sidebar .brand-icon {
  display: grid !important; width: 38px !important; height: 38px !important;
  flex: 0 0 auto !important; place-items: center !important;
  color: #fff !important; background: #16324f !important; border-radius: 9px !important;
}
.sidebar .brand-name { display: block !important; color: #001d37 !important; font-size: 15px !important; font-weight: 700 !important; line-height: 1.25 !important; }
.sidebar .brand-caption { display: block !important; color: #626c7b !important; font-size: 11px !important; }
.sidebar .role-box {
  display: flex !important; justify-content: space-between !important; align-items: center !important;
  gap: 6px !important; padding: 9px 10px !important; margin: 0 0 16px !important;
  background: #e5eeff !important; border-radius: 9px !important;
}
.sidebar .role-box > span:first-child { display: flex !important; align-items: center !important; gap: 6px !important; font-size: 12px !important; font-weight: 600 !important; }
.sidebar .role-pill { display: inline-flex !important; align-items: center !important; gap: 5px !important; padding: 3px 9px !important; border-radius: 999px !important; font-size: 11px !important; font-weight: 650 !important; white-space: nowrap !important; color: #005657 !important; background: #d8f4f1 !important; }
.sidebar .admin-label { color: #76500f !important; background: #fff0ce !important; }
.sidebar .side-nav { display: grid !important; gap: 3px !important; }
.sidebar .nav-label, .sidebar .admin-nav-label {
  padding: 9px 7px 5px !important; color: #626c7b !important; font-size: 10px !important;
  font-weight: 700 !important; letter-spacing: .1em !important; text-transform: uppercase !important;
}
.sidebar .side-nav a {
  display: flex !important; align-items: center !important; gap: 10px !important;
  padding: 8px 10px !important; color: #536174 !important; border-radius: 8px !important;
  font-size: 13px !important; font-weight: 400 !important; line-height: 1.5 !important;
  text-decoration: none !important; transition: .15s ease !important;
}
.sidebar .side-nav a:hover { color: #0b1c30 !important; background: #dce9ff !important; }
.sidebar .side-nav a.active, .sidebar.admin-sidebar .side-nav a.active {
  color: #fff !important; background: #16324f !important; font-weight: 600 !important;
}
.sidebar .side-nav .material-symbols-outlined { font-size: 19px !important; flex: 0 0 auto; }
.sidebar .sidebar-footer { margin-top: auto !important; padding-top: 18px !important; }
.sidebar .user-mini {
  display: flex !important; align-items: center !important; gap: 10px !important;
  padding: 11px 7px 2px !important; border-top: 1px solid #dce4ef !important;
}
.sidebar .avatar-sm {
  display: grid !important; width: 36px !important; height: 36px !important; flex: 0 0 auto !important;
  place-items: center !important; overflow: hidden !important; color: #315273 !important;
  background: #dce9f8 !important; border-radius: 50% !important; font-weight: 700 !important;
}
.sidebar .user-mini strong { display: block !important; font-size: 12px !important; }
.sidebar .user-mini small { color: #626c7b !important; font-size: 11px !important; }
@media (max-width: 760px) {
  .sidebar { transform: translateX(-100%) !important; transition: transform .2s ease !important; }
  .sidebar.open { transform: translateX(0) !important; }
}

</style></head><body class="bg-surface font-body-md text-body-md text-on-surface">
<button class="sidebar-toggle" type="button" aria-label="Open navigation menu" aria-controls="roleSidebar" aria-expanded="false"><span class="material-symbols-outlined">menu</span></button><aside class="sidebar" id="roleSidebar" aria-label="Family Member sidebar">
  <!-- Sidebar 1: Brand -->
  <a class="brand" href="dashboard.php">
    <span class="brand-icon material-symbols-outlined">family_restroom</span>
    <span><span class="brand-name">KinKeep Vault</span><span class="brand-caption">Heritage &amp; Lineage</span></span>
  </a>

  <!-- Sidebar 2: Current role -->
  <div class="role-box">
    <span><span class="material-symbols-outlined">verified_user</span>Active Role</span>
    <span class="role-pill">Family Member</span>
  </div>

  <!-- Sidebar 3: Family Member navigation only -->
  <nav class="side-nav" aria-label="Member navigation">
    <div class="nav-label">Family Member</div>
    <a class="active" aria-current="page" href="dashboard.php"><span class="material-symbols-outlined">dashboard</span>Dashboard</a>
    <a href="my-profile.html"><span class="material-symbols-outlined">person</span>My Profile</a>
    <a href="my-family.html"><span class="material-symbols-outlined">group</span>My Family</a>
    <a href="family-tree.html"><span class="material-symbols-outlined">account_tree</span>Family Tree</a>
    <a href="documents-and-records.html"><span class="material-symbols-outlined">folder_shared</span>Documents &amp; Records</a>
    <a href="photos-and-videos.html"><span class="material-symbols-outlined">photo_library</span>Photos &amp; Videos</a>
    <a href="access-permissions.html"><span class="material-symbols-outlined">lock_open</span>Access Permissions</a>
    <a href="security-center.html"><span class="material-symbols-outlined">security</span>Security Center</a>
  </nav>

  <!-- Sidebar 4: Signed-in member -->
  <div class="sidebar-footer"><div class="user-mini"><span class="avatar-sm" id="sidebarAvatar">?</span><span><strong id="sidebarName">Loading profile...</strong><small id="sidebarAccountStatus">Loading account status...</small></span></div></div>
</aside><div class="pl-64"><header class="fixed top-0 left-64 right-0 h-16 bg-surface/90 backdrop-blur-xl shadow-[0_1px_8px_rgba(0,0,0,0.04)] z-40 flex items-center justify-between px-space-lg"><div class="flex items-center gap-space-md flex-1 max-w-xl"><div class="relative w-full"><span class="material-symbols-outlined absolute left-3 top-1/2 -translate-y-1/2 text-on-surface-variant text-[18px]">search</span><input class="w-full pl-9 pr-space-md py-space-xs bg-surface-container-low rounded-lg font-body-sm text-body-sm text-on-surface placeholder:text-on-surface-variant focus:outline-none focus:ring-1 focus:ring-secondary" placeholder="Search names in your selected family" type="search" aria-label="Search active family names" maxlength="100"/></div></div><div class="flex items-center gap-space-md"><div id="familySelectorWrap" class="flex items-center gap-space-xs px-space-sm py-space-xs rounded-lg bg-surface-container-low border border-surface-container" hidden><label for="familySelector" class="font-label-sm text-label-sm text-on-surface-variant">Family:</label><select id="familySelector" class="bg-transparent font-label-sm text-label-sm text-on-surface font-semibold focus:outline-none cursor-pointer" aria-label="Select active family"></select></div><button class="relative p-space-xs rounded-lg text-on-surface-variant hover:bg-surface-container hover:text-on-surface" type="button"><span class="material-symbols-outlined text-[20px]">notifications</span></button><div class="flex items-center gap-space-sm pl-space-xs"><div class="hidden lg:flex flex-col text-right"><span id="headerName" class="font-label-md text-label-md text-on-surface leading-tight">Loading profile...</span><span id="headerFamily" class="font-label-sm text-label-sm text-secondary font-medium leading-tight">Family member</span></div><div class="w-8 h-8 rounded-full bg-primary flex items-center justify-center shrink-0"><span class="material-symbols-outlined text-on-primary text-[18px]">person</span></div></div></div></header><main class="relative pt-16 bg-surface min-h-screen w-full px-space-lg py-space-md"><div class="flex flex-col w-full pb-space-xl">
<!-- Top Welcome & Status Banner -->
<div class="relative w-full rounded-xl overflow-hidden bg-gradient-to-r from-primary via-primary-container to-secondary p-space-lg shadow-md mb-space-lg text-on-primary">
<div class="relative z-10 flex flex-col lg:flex-row lg:items-center justify-between gap-space-md">
<div class="flex items-start gap-space-md min-w-0">
<div class="relative shrink-0"><div class="w-16 h-16 rounded-full shadow-sm bg-surface-container flex items-center justify-center text-primary"><span class="material-symbols-outlined text-[34px]">person</span></div></div>
<div class="flex flex-col min-w-0">
<div class="flex flex-wrap items-center gap-space-xs mb-1">
<h1 class="font-headline-lg text-headline-lg text-on-primary tracking-tight truncate">Welcome back, <span id="welcomeName">member</span></h1>
<span class="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full bg-secondary-container text-on-secondary-container font-label-sm text-label-sm">
<span class="material-symbols-outlined text-[14px]">person</span>
              Family Member
            </span>
</div>
<p class="font-body-md text-body-md text-primary-fixed-dim max-w-2xl">
            View your active family membership and profile-specific access requests.
          </p>
</div>
</div>
<div class="flex items-center gap-space-xs shrink-0 bg-surface-container-lowest/10 backdrop-blur-md px-space-md py-space-sm rounded-lg">
<div class="text-right">
<p class="font-label-sm text-label-sm text-surface-variant uppercase tracking-wider">Signed-in account</p>
<p id="accountEmail" class="font-data-mono text-data-mono text-on-primary">Loading...</p>
</div>
<span class="material-symbols-outlined text-secondary-fixed text-[24px] ml-1">person</span>
</div>
</div>
</div>
<!-- Key Metric Statistics Bento -->
<div class="grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-4 gap-space-md mb-space-lg">
<!-- Stat 1 -->
<div class="bg-surface-container-lowest rounded-xl p-space-md shadow-sm hover:shadow-md transition-all flex flex-col justify-between"><div class="flex items-center justify-between mb-space-sm"><span class="font-label-sm text-label-sm uppercase tracking-wider text-on-surface-variant">My Documents</span><div class="w-8 h-8 rounded-lg bg-surface-container-low text-secondary flex items-center justify-center"><span class="material-symbols-outlined text-[20px]">folder_special</span></div></div><div class="flex items-baseline gap-space-xs mb-1"><span class="font-headline-xl text-headline-xl text-primary font-bold">Unavailable</span><span class="font-label-sm text-label-sm text-on-surface-variant">No dashboard data</span></div><p class="font-body-sm text-body-sm text-on-surface-variant truncate">Document totals are not available here.</p></div>
<div class="bg-surface-container-lowest rounded-xl p-space-md shadow-sm hover:shadow-md transition-all flex flex-col justify-between"><div class="flex items-center justify-between mb-space-sm"><span class="font-label-sm text-label-sm uppercase tracking-wider text-on-surface-variant">My Media</span><div class="w-8 h-8 rounded-lg bg-surface-container-low text-secondary flex items-center justify-center"><span class="material-symbols-outlined text-[20px]">perm_media</span></div></div><div class="flex items-baseline gap-space-xs mb-1"><span class="font-headline-xl text-headline-xl text-primary font-bold">Unavailable</span><span class="font-label-sm text-label-sm text-on-surface-variant">No dashboard data</span></div><p class="font-body-sm text-body-sm text-on-surface-variant">Media totals are not available here.</p></div>
<div class="bg-surface-container-lowest rounded-xl p-space-md shadow-sm hover:shadow-md transition-all flex flex-col justify-between"><div class="flex items-center justify-between mb-space-sm"><span id="familyStatTitle" class="font-label-sm text-label-sm uppercase tracking-wider text-on-surface-variant">Active family profiles</span><div class="w-8 h-8 rounded-lg bg-surface-container-low text-secondary flex items-center justify-center"><span class="material-symbols-outlined text-[20px]">diversity_3</span></div></div><div class="flex items-baseline gap-space-xs mb-1"><span id="familyCount" class="font-headline-xl text-headline-xl text-primary font-bold">Unavailable</span><span class="font-label-sm text-label-sm text-secondary">Active profiles</span></div><p id="familyStatDescription" class="font-body-sm text-body-sm text-on-surface-variant truncate">Select an active family to view its profiles.</p></div>
<div class="bg-tertiary-fixed rounded-xl p-space-md shadow-sm hover:shadow-md transition-all flex flex-col justify-between text-on-tertiary-fixed"><div class="flex items-center justify-between mb-space-sm"><span class="font-label-sm text-label-sm uppercase tracking-wider text-on-tertiary-fixed-variant">Pending Requests</span><div class="w-8 h-8 rounded-lg bg-tertiary-fixed-dim text-on-tertiary-fixed flex items-center justify-center"><span class="material-symbols-outlined text-[20px]">lock_clock</span></div></div><div class="flex items-baseline gap-space-xs mb-1"><span id="pendingCount" class="font-headline-xl text-headline-xl text-tertiary font-bold">Unavailable</span><span id="pendingLabel" class="font-label-sm text-label-sm text-on-tertiary-fixed-variant">Loading</span></div><p id="pendingDescription" class="font-body-sm text-body-sm text-on-tertiary-fixed-variant truncate">Only decisions for your own profile are shown.</p></div>
</div>
<!-- Priority Banner: Pending Actions & Privacy Status -->
<div class="grid grid-cols-1 lg:grid-cols-12 gap-space-md mb-space-lg">
<!-- Action Required Card (8 cols) -->
<div class="lg:col-span-8 bg-surface-container-lowest rounded-xl p-space-md shadow-sm flex flex-col justify-between"><div class="flex items-start gap-space-md"><div class="w-12 h-12 rounded-xl bg-surface-container-low text-on-surface-variant shrink-0 flex items-center justify-center"><span class="material-symbols-outlined text-[26px]">notifications</span></div><div class="flex-1 min-w-0"><div class="flex flex-wrap items-center justify-between gap-space-xs mb-1"><span id="permissionStatus" class="font-label-sm text-label-sm font-semibold uppercase tracking-wider text-on-surface-variant">Permission status loading</span></div><h2 class="font-headline-sm text-headline-sm text-primary mb-1">Requests for your profile</h2><p id="permissionDescription" class="font-body-md text-body-md text-on-surface-variant mb-space-sm">Loading permission requests for your active family profile.</p><div class="flex flex-wrap items-center gap-space-sm pt-space-xs"><a class="px-space-md py-space-xs bg-primary hover:bg-primary-container text-on-primary rounded-lg font-label-md text-label-md transition-colors shadow-sm flex items-center gap-space-xs" href="access-permissions.html"><span class="material-symbols-outlined text-[18px]">verified_user</span>Review access permissions</a><span id="permissionScope" class="font-body-sm text-body-sm text-on-surface-variant ml-auto flex items-center gap-1"><span class="material-symbols-outlined text-[16px]">schedule</span>Loading owner-scoped requests</span></div></div></div></div>
<!-- Security & Privacy Status Card (4 cols) -->
<div class="lg:col-span-4 bg-surface-container-low rounded-xl p-space-md shadow-sm flex flex-col justify-between"><div><div class="flex items-center justify-between mb-space-sm"><span class="font-label-sm text-label-sm uppercase tracking-wider text-on-surface-variant font-semibold">Security status</span><span class="inline-flex items-center gap-1 px-2 py-0.5 rounded-full bg-surface-container text-on-surface-variant font-label-sm text-label-sm"><span class="material-symbols-outlined text-[12px]">help</span>Not available</span></div><div class="flex items-center gap-space-sm mb-space-sm"><div class="w-10 h-10 rounded-lg bg-surface-container-lowest text-on-surface-variant flex items-center justify-center shrink-0"><span class="material-symbols-outlined text-[22px]">phonelink_lock</span></div><div><p class="font-label-md text-label-md text-on-surface font-semibold">Security details unavailable</p><p class="font-body-sm text-body-sm text-on-surface-variant">This dashboard does not report MFA or encryption status.</p></div></div><div class="bg-surface-container-lowest rounded-lg p-space-sm mb-space-sm"><div class="flex items-center justify-between text-body-sm font-body-sm mb-1"><span class="text-on-surface-variant">Last vault access:</span><span class="font-semibold text-on-surface">Unavailable</span></div><div class="flex items-center justify-between text-body-sm font-body-sm"><span class="text-on-surface-variant">Access location:</span><span class="text-on-surface">Unavailable</span></div></div></div><div class="pt-space-xs flex items-center justify-between"><a class="font-label-sm text-label-sm text-secondary hover:underline flex items-center gap-1" href="security-center.html"><span>Open Security Center</span><span class="material-symbols-outlined text-[14px]">chevron_right</span></a><span class="material-symbols-outlined text-on-surface-variant text-[18px]">help</span></div></div>
</div>
<!-- Main Body Grid: Family Network & Activity / Quick Actions -->
<div class="grid grid-cols-1 lg:grid-cols-12 gap-space-md">
<!-- Left Column: Immediate Family Summary (7 cols) -->
<div class="lg:col-span-7 flex flex-col gap-space-md">
<div class="bg-surface-container-lowest rounded-xl p-space-md shadow-sm">
<div class="flex items-center justify-between pb-space-sm mb-space-md">
<div class="flex items-center gap-space-xs">
<div class="w-8 h-8 rounded-lg bg-primary text-on-primary flex items-center justify-center">
<span class="material-symbols-outlined text-[18px]">hub</span>
</div>
<div>
<h2 class="font-headline-sm text-headline-sm text-primary">My Family Summary</h2>
<p class="font-body-sm text-body-sm text-on-surface-variant">Active profiles associated with your selected family membership</p>
</div>
</div>
<div class="flex items-center gap-space-xs">
<a class="px-space-sm py-1.5 rounded-lg bg-surface-container hover:bg-surface-container-high text-on-surface font-label-sm text-label-sm transition-all flex items-center gap-1" href="my-family.html"><span class="material-symbols-outlined text-[16px]">group</span>Manage Family</a>
<a class="px-space-sm py-1.5 rounded-lg bg-primary hover:bg-primary-container text-on-primary font-label-sm text-label-sm transition-all flex items-center gap-1" href="family-tree.html">
<span class="material-symbols-outlined text-[16px]">account_tree</span>
              View Tree
            </a>
</div>
</div>
<!-- Family Relations Grid -->
<div class="space-y-space-sm"><div class="bg-surface-container-low rounded-xl p-space-sm"><div class="flex items-center justify-between mb-space-xs px-space-xs"><span id="familyMembersHeading" class="font-label-sm text-label-sm uppercase tracking-wider text-on-surface-variant font-semibold">Family members</span><span id="familyMembersCount" class="font-body-sm text-body-sm text-on-surface-variant">Unavailable</span></div><div id="familyMembers" class="grid grid-cols-1 sm:grid-cols-2 gap-space-xs"><p class="font-body-sm text-body-sm text-on-surface-variant">Loading active family profiles...</p></div></div></div>
</div>
<!-- Quick Action Utilities -->
<div class="bg-surface-container-lowest rounded-xl p-space-md shadow-sm"><h2 class="font-headline-sm text-headline-sm text-primary mb-space-sm">Immediate Vault Actions</h2><div class="grid grid-cols-2 sm:grid-cols-4 gap-space-sm">
<a href="documents-and-records.html" class="flex flex-col items-center justify-center p-space-sm rounded-xl bg-surface-container-low hover:bg-surface-container hover:-translate-y-0.5 transition-all text-center gap-2"><div class="w-10 h-10 rounded-full bg-primary text-on-primary flex items-center justify-center shadow-sm"><span class="material-symbols-outlined text-[20px]">upload_file</span></div><span class="font-label-sm text-label-sm text-on-surface font-medium leading-tight">Open Documents</span></a>
<a href="access-permissions.html" class="flex flex-col items-center justify-center p-space-sm rounded-xl bg-surface-container-low hover:bg-surface-container hover:-translate-y-0.5 transition-all text-center gap-2"><div class="w-10 h-10 rounded-full bg-secondary text-on-secondary flex items-center justify-center shadow-sm"><span class="material-symbols-outlined text-[20px]">contact_page</span></div><span class="font-label-sm text-label-sm text-on-surface font-medium leading-tight">Request or review access</span></a>
<a href="my-profile.html" class="flex flex-col items-center justify-center p-space-sm rounded-xl bg-surface-container-low hover:bg-surface-container hover:-translate-y-0.5 transition-all text-center gap-2"><div class="w-10 h-10 rounded-full bg-primary-container text-on-primary flex items-center justify-center shadow-sm"><span class="material-symbols-outlined text-[20px]">badge</span></div><span class="font-label-sm text-label-sm text-on-surface font-medium leading-tight">View My Profile</span></a>
<a href="security-center.html" class="flex flex-col items-center justify-center p-space-sm rounded-xl bg-surface-container-low hover:bg-surface-container hover:-translate-y-0.5 transition-all text-center gap-2"><div class="w-10 h-10 rounded-full bg-surface-container-high text-on-surface flex items-center justify-center shadow-sm"><span class="material-symbols-outlined text-[20px]">security</span></div><span class="font-label-sm text-label-sm text-on-surface font-medium leading-tight">Security Center</span></a>
</div></div>
</div>
<!-- Right Column: Recent Personal & Vault Activity (5 cols) -->
<div class="lg:col-span-5 flex flex-col gap-space-md">
<!-- Activity Feed Card -->
<div class="bg-surface-container-lowest rounded-xl p-space-md shadow-sm flex flex-col">
<div class="flex items-center justify-between pb-space-sm mb-space-md">
<div class="flex items-center gap-space-xs">
<div class="w-8 h-8 rounded-lg bg-secondary text-on-secondary flex items-center justify-center">
<span class="material-symbols-outlined text-[18px]">history_toggle_off</span>
</div>
<div>
<h2 class="font-headline-sm text-headline-sm text-primary">Recent Personal & Vault Activity</h2>
<p class="font-body-sm text-body-sm text-on-surface-variant">Activity history unavailable</p>
</div>
</div>
<button class="p-1 rounded-lg hover:bg-surface-container text-on-surface-variant" type="button" disabled title="Activity history is not available on this dashboard.">
<span class="material-symbols-outlined text-[20px]">filter_list</span>
</button>
</div>
<p class="font-body-sm text-body-sm text-on-surface-variant bg-surface-container-low rounded-lg p-space-sm" role="status">Activity history is unavailable: no activity data source is connected to this dashboard.</p><div class="mt-space-md pt-space-sm flex justify-center"><button class="font-label-sm text-label-sm text-on-surface-variant transition-colors flex items-center gap-1" type="button" disabled title="No activity-history API is connected to this dashboard."><span>Historical activity unavailable</span><span class="material-symbols-outlined text-[14px]">info</span></button></div>
</div>
<!-- Private Vault Storage Breakdown -->
<div class="bg-surface-container-lowest rounded-xl p-space-md shadow-sm">
<div class="flex items-center justify-between mb-space-sm">
<div>
<span class="font-label-sm text-label-sm uppercase tracking-wider text-on-surface-variant font-semibold">Vault Capacity</span>
<h3 class="font-headline-sm text-headline-sm text-primary">Storage Distribution</h3>
</div>
<span class="font-data-mono text-data-mono font-bold text-on-surface-variant">Unavailable</span>
</div>
<!-- Visual Progress Bar -->
<div class="w-full bg-surface-container-high rounded-full h-3 overflow-hidden flex mb-space-sm">
<div class="bg-surface-container-high h-full w-full" title="Storage distribution unavailable"></div>
</div>
<div class="grid grid-cols-3 gap-space-xs text-center pt-space-xs">
<div class="bg-surface-container-low p-space-xs rounded-lg">
<p class="font-data-mono text-data-mono text-on-surface-variant font-bold">Unavailable</p>
<p class="font-body-sm text-body-sm text-on-surface-variant truncate">Documents</p>
</div>
<div class="bg-surface-container-low p-space-xs rounded-lg">
<p class="font-data-mono text-data-mono text-on-surface-variant font-bold">Unavailable</p>
<p class="font-body-sm text-body-sm text-on-surface-variant truncate">Media</p>
</div>
<div class="bg-surface-container-low p-space-xs rounded-lg">
<p class="font-data-mono text-data-mono text-on-surface-variant font-bold">Unavailable</p>
<p class="font-body-sm text-body-sm text-on-surface-variant truncate">Records</p>
</div>
</div>
</div>
</div>
</div>
</div></main></div><script>
  // Sidebar navigation: mobile open/close control.
  (function () {
    const sidebar = document.getElementById('roleSidebar');
    const toggle = document.querySelector('.sidebar-toggle');
    if (!sidebar || !toggle) return;
    toggle.addEventListener('click', function () {
      const isOpen = sidebar.classList.toggle('open');
      toggle.setAttribute('aria-expanded', String(isOpen));
      toggle.setAttribute('aria-label', isOpen ? 'Close navigation menu' : 'Open navigation menu');
      const icon = toggle.querySelector('.material-symbols-outlined');
      if (icon) icon.textContent = isOpen ? 'close' : 'menu';
    });
    sidebar.querySelectorAll('a').forEach(function (link) {
      link.addEventListener('click', function () {
        if (window.matchMedia('(max-width: 760px)').matches) {
          sidebar.classList.remove('open');
          toggle.setAttribute('aria-expanded', 'false');
          toggle.setAttribute('aria-label', 'Open navigation menu');
          const icon = toggle.querySelector('.material-symbols-outlined');
          if (icon) icon.textContent = 'menu';
        }
      });
    });
  }());
</script><script>
(function () {
  'use strict';
  const apiBase = '../zip_extracted/public/api/';
  const byId = (id) => document.getElementById(id);
  const apiRequest = async (path) => {
    const response = await fetch(apiBase + path, { credentials: 'same-origin', headers: { Accept: 'application/json' } });
    let result;
    try { result = await response.json(); } catch (_) { throw new Error('The server returned an invalid response (HTTP ' + response.status + ').'); }
    if (!response.ok || !result.success) throw new Error(result.error || 'Request failed (HTTP ' + response.status + ').');
    return result;
  };
  const notificationButton = document.querySelector('header button[aria-label="Notifications"]');
  if (notificationButton) {
    notificationButton.setAttribute('aria-label', 'Notifications');
    notificationButton.title = 'Open family action items';
    const badge = document.createElement('span');
    badge.hidden = true;
    badge.style.cssText = 'position:absolute;top:-3px;right:-3px;min-width:16px;padding:1px 4px;border-radius:999px;background:#b42318;color:#fff;font-size:10px;line-height:14px;text-align:center';
    notificationButton.append(badge);
    const dialog = document.createElement('dialog');
    dialog.style.cssText = 'width:min(440px,92vw);border:1px solid #c3c6ce;border-radius:14px;padding:20px;box-shadow:0 18px 55px #0003';
    dialog.setAttribute('aria-labelledby', 'memberActionItemsTitle');
    const title = document.createElement('h2');
    title.id = 'memberActionItemsTitle';
    title.textContent = 'Family action items';
    const status = document.createElement('p');
    status.className = 'font-body-sm text-body-sm text-on-surface-variant';
    status.setAttribute('role', 'status');
    const list = document.createElement('div');
    const close = document.createElement('button');
    close.type = 'button';
    close.className = 'px-space-md py-space-xs rounded-lg bg-surface-container hover:bg-surface-container-high text-on-surface font-label-md text-label-md';
    close.textContent = 'Close';
    close.addEventListener('click', () => dialog.close());
    dialog.append(title, status, list, close);
    document.body.append(dialog);
    notificationButton.addEventListener('click', async () => {
      dialog.showModal();
      status.setAttribute('role', 'status');
      status.textContent = 'Loading family action items...';
      list.replaceChildren();
      if (!selectedFamily) { status.textContent = 'No active family is available for this account.'; return; }
      try {
        const result = await apiRequest(`family/notifications.php?family_id=${encodeURIComponent(selectedFamily.id)}`);
        const total = Number(result.total) || 0;
        badge.textContent = total > 99 ? '99+' : String(total);
        badge.hidden = total === 0;
        notificationButton.setAttribute('aria-label', total ? `Notifications, ${total} family action items` : 'Notifications, no family action items');
        if (!result.items?.length) { status.textContent = 'No access requests are waiting for your decision.'; return; }
        status.textContent = `${total} item${total === 1 ? '' : 's'} need your review.`;
        for (const item of result.items) {
          let href = null;
          if (item.url === 'access-permissions.html') href = 'access-permissions.html';
          else if (item.url === 'enrollment-requests.html') href = '../family%20admin/enrollment-requests.html';
          else if (item.url === 'relationships-and-kin.html') href = '../family%20admin/relationships-and-kin.html';
          if (!href) continue;
          const link = document.createElement('a');
          link.href = href;
          link.textContent = `${item.title} (${Number(item.count) || 0})`;
          link.className = 'block my-space-xs px-space-md py-space-xs rounded-lg bg-surface-container-low text-primary';
          list.append(link);
        }
      } catch (error) {
        status.textContent = `Family action items are unavailable: ${error.message}`;
        status.setAttribute('role', 'alert');
      }
    });
  }
  const display = (value, fallback) => typeof value === 'string' && value.trim() ? value.trim() : fallback;
  const isActive = (member) => String(member.member_status || '').toLowerCase() === 'active';
  const memberSearch = document.querySelector('input[aria-label="Search active family names"]');
  let memberSearchTerm = '';
  memberSearch?.addEventListener('input', () => {
    memberSearchTerm = memberSearch.value.trim().toLocaleLowerCase();
    applyMemberSearch();
  });
  function applyMemberSearch() {
    const container = byId('familyMembers');
    if (!container) return;
    const cards = [...container.children].filter((item) => item.dataset.familyMemberCard === 'true');
    let visible = 0;
    for (const card of cards) {
      const match = !memberSearchTerm || card.textContent.toLocaleLowerCase().includes(memberSearchTerm);
      card.hidden = !match;
      if (match) visible++;
    }
    let empty = container.querySelector('[data-family-search-empty]');
    if (memberSearchTerm && cards.length && visible === 0) {
      if (!empty) {
        empty = document.createElement('p');
        empty.className = 'font-body-sm text-body-sm text-on-surface-variant';
        empty.dataset.familySearchEmpty = 'true';
      }
      empty.textContent = 'No family profile names match this search.';
      container.append(empty);
    } else {
      empty?.remove();
    }
  }
  let selectedFamily = null;
  const activityDialog = document.createElement('dialog');
  activityDialog.style.cssText = 'width:min(560px,94vw);max-height:82vh;overflow:auto;border:1px solid #c3c6ce;border-radius:14px;padding:20px;box-shadow:0 18px 55px #0003';
  activityDialog.setAttribute('aria-labelledby', 'memberActivityHistoryTitle');
  const activityTitle = document.createElement('h2');
  activityTitle.id = 'memberActivityHistoryTitle';
  activityTitle.textContent = 'Your family activity history';
  const activityHistoryStatus = document.createElement('p');
  activityHistoryStatus.className = 'font-body-sm text-body-sm text-on-surface-variant';
  activityHistoryStatus.setAttribute('role', 'status');
  const activityHistoryList = document.createElement('div');
  activityHistoryList.className = 'mt-space-sm space-y-space-xs';
  const activityHistoryActions = document.createElement('div');
  activityHistoryActions.className = 'mt-space-md flex justify-between gap-space-sm';
  const activityHistoryMore = document.createElement('button');
  activityHistoryMore.type = 'button';
  activityHistoryMore.className = 'px-space-md py-space-xs rounded-lg bg-surface-container hover:bg-surface-container-high text-on-surface font-label-md text-label-md';
  activityHistoryMore.textContent = 'Load older activity';
  activityHistoryMore.hidden = true;
  const activityHistoryClose = document.createElement('button');
  activityHistoryClose.type = 'button';
  activityHistoryClose.className = 'px-space-md py-space-xs rounded-lg bg-primary text-on-primary font-label-md text-label-md';
  activityHistoryClose.textContent = 'Close';
  activityHistoryClose.addEventListener('click', () => activityDialog.close());
  activityHistoryActions.append(activityHistoryMore, activityHistoryClose);
  activityDialog.append(activityTitle, activityHistoryStatus, activityHistoryList, activityHistoryActions);
  document.body.append(activityDialog);
  let activityHistoryCursor = null;
  let activityHistoryFamilyId = null;
  async function loadActivityHistory(append = false) {
    if (!selectedFamily) {
      activityHistoryStatus.textContent = 'Select an active family before viewing activity history.';
      return;
    }
    const family = selectedFamily;
    const familyId = String(family.id);
    if (!append) {
      activityHistoryList.replaceChildren();
      activityHistoryCursor = null;
      activityHistoryFamilyId = familyId;
    }
    if (append && activityHistoryFamilyId !== familyId) return;
    activityHistoryStatus.setAttribute('role', 'status');
    activityHistoryStatus.textContent = 'Loading your activity...';
    activityHistoryMore.disabled = true;
    try {
      const params = new URLSearchParams({ family_id: familyId, limit: '25' });
      if (append && activityHistoryCursor) params.set('before_id', activityHistoryCursor);
      const result = await apiRequest(`family/my_activity.php?${params.toString()}`);
      if (selectedFamily !== family) return;
      const events = Array.isArray(result.events) ? result.events : [];
      for (const event of events) {
        const row = document.createElement('article');
        row.className = 'bg-surface-container-low rounded-lg p-space-sm';
        const action = document.createElement('p');
        action.className = 'font-label-sm text-label-sm text-on-surface';
        action.textContent = String(event.action || 'Account activity').replaceAll('_', ' ');
        const detail = document.createElement('p');
        detail.className = 'font-body-sm text-body-sm text-on-surface-variant';
        detail.textContent = [event.target_type, event.created_at].filter(Boolean).join(' · ') || 'Time unavailable';
        row.append(action, detail);
        activityHistoryList.append(row);
      }
      activityHistoryCursor = result.next_cursor ? String(result.next_cursor) : null;
      activityHistoryMore.hidden = result.has_more !== true;
      activityHistoryStatus.textContent = events.length
        ? 'Only actions recorded under your account in this family are shown.'
        : (append || activityHistoryList.childElementCount ? 'No older activity is available.' : 'No family activity has been recorded for your account.');
    } catch (error) {
      activityHistoryStatus.textContent = `Activity history is unavailable: ${error.message}`;
      activityHistoryStatus.setAttribute('role', 'alert');
    } finally {
      activityHistoryMore.disabled = false;
    }
  }
  activityHistoryMore.addEventListener('click', () => loadActivityHistory(true));
  let signedInEmail = '';
  let permissionRequestId = 0;
  let summaryRequestId = 0;
  function setText(id, value) { const element = byId(id); if (element) element.textContent = value; }
  function initials(name) { const parts = name.split(/\s+/).filter(Boolean); return parts.slice(0, 2).map((part) => Array.from(part)[0].toUpperCase()).join('') || '?'; }
  function profileName(member) {
    const legalName = [member.first_name, member.middle_name, member.last_name]
      .filter((part) => typeof part === 'string' && part.trim())
      .map((part) => part.trim())
      .join(' ');
    return member.preferred_name ? `${member.preferred_name} (${legalName})` : legalName;
  }
  function renderFamily(family) {
    selectedFamily = family;
    const members = byId('familyMembers');
    if (members) members.replaceChildren();
    if (!family) {
      setText('familyStatTitle', 'Active family profiles'); setText('familyCount', 'Unavailable'); setText('familyStatDescription', 'No authorized active family profile is available.');
      setText('familyMembersHeading', 'Family members'); setText('familyMembersCount', 'Unavailable');
      if (members) { const empty = document.createElement('p'); empty.className = 'font-body-sm text-body-sm text-on-surface-variant'; empty.textContent = 'Family profiles are unavailable.'; members.append(empty); }
      setText('pendingCount', 'Unavailable'); setText('pendingLabel', 'Unavailable'); setText('pendingDescription', 'No authorized profile is available to check requests.');
      setText('permissionStatus', 'Permission status unavailable'); setText('permissionDescription', 'No authorized active family profile is available.'); setText('permissionScope', 'Owner-scoped requests unavailable');
      loadPermissions(null); return;
    }
    const familyName = display(family.family_name, 'Active family');
    const activeMembers = Array.isArray(family.members) ? family.members.filter(isActive) : [];
    setText('familyStatTitle', familyName); setText('familyCount', String(activeMembers.length)); setText('familyStatDescription', 'Active profiles in this family.');
    setText('familyMembersHeading', familyName + ' profiles'); setText('familyMembersCount', activeMembers.length + ' active');
    if (members) {
      if (!activeMembers.length) { const empty = document.createElement('p'); empty.className = 'font-body-sm text-body-sm text-on-surface-variant'; empty.textContent = 'No active family profiles are available.'; members.append(empty); }
      for (const member of activeMembers) {
        const mine = Number(member.id) === Number(family.member_id);
        const card = document.createElement('div'); card.dataset.familyMemberCard = 'true'; card.className = 'bg-surface-container-lowest p-space-sm rounded-lg flex items-center justify-between shadow-sm';
        const details = document.createElement('div'); details.className = 'flex items-center gap-space-sm min-w-0';
        const icon = document.createElement('span'); icon.className = 'w-10 h-10 rounded-full bg-surface-container-high text-on-surface-variant flex items-center justify-center shrink-0 material-symbols-outlined'; icon.textContent = 'person_outline';
        const text = document.createElement('div'); text.className = 'min-w-0';
        const name = document.createElement('p'); name.className = 'font-label-md text-label-md text-on-surface truncate font-semibold';
        const fullName = [member.first_name, member.middle_name, member.last_name].filter((part) => typeof part === 'string' && part.trim()).map((part) => part.trim()).join(' ');
        name.textContent = fullName || 'Family member';
        const status = document.createElement('p'); status.className = 'font-body-sm text-body-sm text-on-surface-variant'; status.textContent = mine ? 'Your active family profile' : 'Active family profile';
        text.append(name, status); details.append(icon, text); card.append(details);
        const badge = document.createElement('span'); badge.className = 'px-2 py-0.5 rounded-full bg-secondary-container text-on-secondary-container font-label-sm text-label-sm'; badge.textContent = mine ? 'You' : 'Active'; card.append(badge); members.append(card);
      }
    }
    applyMemberSearch();
    const name = profileName(family) || signedInEmail || 'Family member';
    setText('welcomeName', name); setText('sidebarName', name); setText('headerName', name); setText('sidebarAvatar', initials(name)); setText('headerFamily', familyName + ' - Family member');
    setText('permissionStatus', 'Loading permission requests'); setText('permissionDescription', 'Checking requests owned by your profile in ' + familyName + '.'); setText('permissionScope', 'Loading owner-scoped requests');
    loadPermissions(family);
    loadMemberSummary(family);
  }
  function memberStatCard(labelText) {
    const label = Array.from(document.querySelectorAll('main span')).find((node) => node.textContent.trim() === labelText);
    return label ? label.closest('.rounded-xl') : null;
  }
  function formatBytes(bytes) {
    let size = Math.max(0, Number(bytes) || 0); const units = ['B', 'KB', 'MB', 'GB', 'TB']; let index = 0;
    while (size >= 1024 && index < units.length - 1) { size /= 1024; index++; }
    return size.toFixed(index ? 1 : 0) + ' ' + units[index];
  }
  async function loadMemberSummary(family) {
    const requestId = ++summaryRequestId;
    if (!family) return;
    try {
      const result = await apiRequest('family/member_dashboard.php?family_id=' + encodeURIComponent(family.id));
      if (requestId !== summaryRequestId || selectedFamily !== family) return;
      const summary = result.summary || {};
      const docs = memberStatCard('My Documents'); const mediaCard = memberStatCard('My Media');
      for (const [card, amount, noun, detail] of [
        [docs, summary.document_count, 'documents', 'Private documents stored on your profile.'],
        [mediaCard, Number(summary.photo_count || 0) + Number(summary.video_count || 0), 'photos and videos', 'Private photos and videos stored on your profile.']
      ]) {
        const value = card?.querySelector('.font-headline-xl'); if (value) value.textContent = String(Number(amount) || 0);
        const suffix = card?.querySelector('.font-headline-xl')?.parentElement?.querySelector('.font-label-sm'); if (suffix) suffix.textContent = noun;
        const description = card?.querySelector('p.font-body-sm'); if (description) description.textContent = detail;
      }
      const storageHeading = Array.from(document.querySelectorAll('main h3')).find((node) => node.textContent.trim() === 'Storage Distribution');
      const storageCard = storageHeading?.closest('.rounded-xl');
      const documentBytes = (result.media || []).filter((item) => item.media_type === 'document').reduce((sum, item) => sum + Number(item.bytes || 0), 0);
      const photoBytes = (result.media || []).filter((item) => item.media_type === 'photo').reduce((sum, item) => sum + Number(item.bytes || 0), 0);
      const videoBytes = (result.media || []).filter((item) => item.media_type === 'video').reduce((sum, item) => sum + Number(item.bytes || 0), 0);
      const totalBytes = Number(summary.total_media_bytes || 0);
      const storageTitle = storageCard?.querySelector(':scope > div:first-child > span'); if (storageTitle) storageTitle.textContent = formatBytes(totalBytes) + ' stored · capacity not configured';
      const progress = storageCard?.querySelector(':scope > div:nth-of-type(2)');
      if (progress) {
        progress.replaceChildren();
        for (const [bytes, color, title] of [[documentBytes, 'bg-primary', 'Documents'], [photoBytes, 'bg-secondary', 'Photos'], [videoBytes, 'bg-tertiary-fixed-dim', 'Videos']]) {
          const segment = document.createElement('div'); segment.className = color + ' h-full'; segment.style.width = totalBytes ? (bytes / totalBytes * 100) + '%' : '0%'; segment.title = title + ': ' + formatBytes(bytes); progress.append(segment);
        }
      }
      if (storageCard) {
        const categories = [...storageCard.querySelectorAll('.grid.grid-cols-3 > div')];
        [formatBytes(documentBytes), formatBytes(photoBytes + videoBytes), String(Number(summary.relationship_count || 0))].forEach((value, index) => {
          const output = categories[index]?.querySelector('p.font-data-mono'); if (output) output.textContent = value;
        });
      }
      const securityLabel = Array.from(document.querySelectorAll('main span')).find((node) => node.textContent.trim() === 'Security status');
      const securityCard = securityLabel?.closest('.rounded-xl');
      if (securityCard) {
        const badge = [...securityCard.querySelectorAll('span')].find((node) => node.textContent.trim() === 'Not available');
        if (badge) badge.textContent = summary.mfa_enabled ? 'MFA enabled' : 'MFA not enabled';
        const heading = [...securityCard.querySelectorAll('p')].find((node) => node.textContent.includes('Security details unavailable'));
        if (heading) heading.textContent = summary.mfa_enabled ? 'Multi-factor authentication is enabled' : 'Multi-factor authentication is not enabled';
        const detail = [...securityCard.querySelectorAll('p')].find((node) => node.textContent.includes('does not report MFA'));
        if (detail) detail.textContent = summary.email_verified ? 'Email verified · account protected by the active session policy.' : 'Email verification is incomplete · review sign-in security.';
        const labels = [...securityCard.querySelectorAll('span')];
        const lastLabel = labels.find((node) => node.textContent.trim() === 'Last vault access:');
        const lastRow = lastLabel?.closest('div.flex'); if (lastLabel) lastLabel.textContent = 'Last sign-in:';
        const lastValue = lastRow?.querySelector('span.font-semibold'); if (lastValue) lastValue.textContent = summary.last_login_at || 'Not recorded';
        const locationLabel = labels.find((node) => node.textContent.trim() === 'Access location:'); if (locationLabel) locationLabel.textContent = 'Email verification:';
        const locationRow = locationLabel?.closest('div.flex'); const locationValue = locationRow?.querySelector('span:last-child'); if (locationValue) locationValue.textContent = summary.email_verified ? 'Verified' : 'Not verified';
      }
      const activityHeading = [...document.querySelectorAll('main h2')].find((node) => node.textContent.trim() === 'Recent Personal & Vault Activity');
      const activityCard = activityHeading?.closest('.rounded-xl');
      if (activityCard) {
        const intro = [...activityCard.querySelectorAll('p')].find((node) => node.textContent.includes('Activity history unavailable'));
        if (intro) intro.textContent = 'Recent actions performed by your account in this family.';
        const status = activityCard.querySelector('[role="status"]');
        const events = Array.isArray(result.activity) ? result.activity : [];
        if (status) status.textContent = events.length ? events.length + ' recent account event(s).' : 'No recent account activity was recorded.';
        let list = activityCard.querySelector('[data-member-activity]');
        if (!list) { list = document.createElement('div'); list.dataset.memberActivity = 'true'; list.className = 'mt-space-sm space-y-space-xs'; status?.after(list); }
        list.replaceChildren();
        for (const event of events) {
          const item = document.createElement('div'); item.className = 'bg-surface-container-low rounded-lg p-space-sm';
          const action = document.createElement('p'); action.className = 'font-label-sm text-label-sm text-on-surface'; action.textContent = String(event.action || 'Account activity').replaceAll('_', ' ');
          const time = document.createElement('p'); time.className = 'font-body-sm text-body-sm text-on-surface-variant'; time.textContent = (event.target_type ? String(event.target_type) + ' · ' : '') + String(event.created_at || 'Time unavailable');
          item.append(action, time); list.append(item);
        }
        const activityButtons = [...activityCard.querySelectorAll('button')];
        const refreshActivity = activityButtons[0];
        const fullHistory = activityButtons[1];
        if (refreshActivity && !refreshActivity.dataset.activityBound) {
          refreshActivity.disabled = false;
          refreshActivity.title = 'Refresh recent family activity';
          refreshActivity.dataset.activityBound = 'true';
          refreshActivity.addEventListener('click', () => {
            if (selectedFamily) loadMemberSummary(selectedFamily);
          });
        }
        if (fullHistory && !fullHistory.dataset.activityBound) {
          fullHistory.disabled = false;
          fullHistory.title = 'View paginated activity recorded under your account';
          const label = fullHistory.querySelector('span:not(.material-symbols-outlined)');
          if (label) label.textContent = 'View full activity history';
          fullHistory.dataset.activityBound = 'true';
          fullHistory.addEventListener('click', () => {
            activityDialog.showModal();
            loadActivityHistory(false);
          });
        }
      }
    } catch (error) {
      if (requestId !== summaryRequestId || selectedFamily !== family) return;
      const docs = memberStatCard('My Documents'); const mediaCard = memberStatCard('My Media');
      for (const card of [docs, mediaCard]) { const value = card?.querySelector('.font-headline-xl'); if (value) value.textContent = 'Unavailable'; const desc = card?.querySelector('p.font-body-sm'); if (desc) desc.textContent = error.message || 'Summary data could not be loaded.'; }
    }
  }
  async function loadPermissions(family) {
    const requestId = ++permissionRequestId;
    if (!family) return;
    setText('pendingCount', '...'); setText('pendingLabel', 'Loading'); setText('pendingDescription', 'Checking your profile-specific requests.');
    try {
      const result = await apiRequest('permissions/list.php?family_id=' + encodeURIComponent(family.id));
      if (requestId !== permissionRequestId || selectedFamily !== family) return;
      const records = Array.isArray(result.permissions) ? result.permissions : [];
      const pending = records.filter((record) => Number(record.family_id) === Number(family.id)
        && Number(record.owner_member_id) === Number(family.member_id)
        && (record.is_owner === true || record.is_owner === 1 || record.is_owner === '1' || record.is_owner === 'true')
        && (record.can_decide === true || record.can_decide === 1 || record.can_decide === '1' || record.can_decide === 'true')
        && String(record.status || '').toLowerCase() === 'pending');
      setText('pendingCount', String(pending.length)); setText('pendingLabel', pending.length ? 'Requires your review' : 'No pending decisions');
      setText('pendingDescription', 'Only requests you own and are authorized to decide are counted.');
      setText('permissionStatus', pending.length ? 'Action may be required' : 'No pending decisions');
      setText('permissionDescription', pending.length ? pending.length + ' pending request(s) for your own profile can be reviewed in Access Permissions.' : 'No pending requests requiring your decision were returned for your own family profile.');
      setText('permissionScope', 'Limited to your profile and role');
    } catch (error) {
      if (requestId !== permissionRequestId || selectedFamily !== family) return;
      setText('pendingCount', 'Unavailable'); setText('pendingLabel', 'Could not load'); setText('pendingDescription', 'Permission data is unavailable; this is not a zero count.');
      setText('permissionStatus', 'Permission data unavailable'); setText('permissionDescription', error.message || 'Permission requests could not be loaded.'); setText('permissionScope', 'No decision status available');
    }
  }
  async function start() {
    try {
      const [auth, familyResult] = await Promise.all([apiRequest('auth/me.php'), apiRequest('family/my_family.php')]);
      signedInEmail = display(auth.user && auth.user.email, 'Email unavailable'); setText('accountEmail', signedInEmail);
      const authFamilies = Array.isArray(auth.families) ? auth.families : [];
      const familyRecords = Array.isArray(familyResult.families) ? familyResult.families : [];
      const authorizedIds = new Set(authFamilies.filter((family) => family.status === 'active' && family.role === 'member' && family.authorization_conflict !== true).map((family) => String(family.id)));
      const activeFamilies = familyRecords.filter((family) => family.status === 'active' && family.role === 'member' && authorizedIds.has(String(family.id)));
      const selectorWrap = byId('familySelectorWrap'); const selector = byId('familySelector');
      if (selectorWrap && selector && activeFamilies.length > 1) {
        selectorWrap.hidden = false; selectorWrap.classList.remove('hidden');
        for (const family of activeFamilies) { const option = document.createElement('option'); option.value = String(family.id); option.textContent = display(family.family_name, 'Family'); selector.append(option); }
        selector.addEventListener('change', () => renderFamily(activeFamilies.find((family) => String(family.id) === selector.value) || null));
      }
      const shownName = (activeFamilies.length && profileName(activeFamilies[0])) || signedInEmail || 'Family member';
      setText('welcomeName', shownName); setText('sidebarName', shownName); setText('headerName', shownName); setText('sidebarAvatar', initials(shownName));
      setText('sidebarAccountStatus', 'Account: ' + display(auth.user && auth.user.status, 'status unavailable'));
      if (!activeFamilies.length) { setText('headerFamily', 'No active member family'); renderFamily(null); return; }
      renderFamily(activeFamilies[0]);
    } catch (error) {
      const message = error.message || 'Authenticated profile data could not be loaded.';
      setText('welcomeName', 'Profile unavailable'); setText('sidebarName', 'Profile unavailable'); setText('headerName', 'Profile unavailable'); setText('sidebarAccountStatus', 'Account status unavailable'); setText('accountEmail', 'Unavailable'); setText('headerFamily', 'Family data unavailable');
      renderFamily(null); setText('permissionStatus', 'Profile data unavailable'); setText('permissionDescription', message); setText('permissionScope', 'No profile-scoped status available');
    }
  }
  start();
}());
</script></body></html>
