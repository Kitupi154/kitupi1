<?php
declare(strict_types=1);

require_once __DIR__ . '/../zip_extracted/src/bootstrap.php';

$path = parse_url($_SERVER['REQUEST_URI'] ?? '', PHP_URL_PATH);
$page = is_string($path) ? basename(rawurldecode($path)) : '';
$allowedPages = [
    'my-profile.html',
    'my-family.html',
    'family-tree.html',
    'documents-and-records.html',
    'photos-and-videos.html',
    'access-permissions.html',
    'security-center.html',
];
if (!in_array($page, $allowedPages, true)) {
    http_response_code(404);
    exit;
}

if ($page === 'my-family.html') {
    PageAccess::requireSignedInUser();
    $user = Auth::requireLogin();
    $stmt = $db->prepare(
        "SELECT fm.family_id
         FROM family_members fm
         INNER JOIN family_roles fr
           ON fr.member_id = fm.id
          AND fr.family_id = fm.family_id
          AND fr.role = 'member'
         INNER JOIN families f ON f.id = fm.family_id AND f.status = 'active'
         WHERE fm.user_id = ? AND fm.member_status = 'active'
         LIMIT 1"
    );
    $stmt->execute([(int) $user['id']]);
    if ($stmt->fetchColumn() === false) {
        header('Location: membership-onboarding.php', true, 302);
        exit;
    }
} else {
    PageAccess::requireFamilyDashboardRole('member');
}

header('Content-Type: text/html; charset=utf-8');
require __DIR__ . DIRECTORY_SEPARATOR . $page;
