<?php
declare(strict_types=1);

require_once __DIR__ . '/../zip_extracted/src/bootstrap.php';
PageAccess::requireSignedInUser();
$user = Auth::requireLogin();
if (empty($user['email_verified_at'])) {
    header('Location: ../super%20admin/login.php?verification=required', true, 302);
    exit;
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <meta name="theme-color" content="#f8f9ff">
  <title>Family Membership | KinKeep Vault</title>
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&family=Material+Symbols+Outlined:wght,FILL@100..700,0..1&display=swap" rel="stylesheet">
  <link rel="stylesheet" href="member-pages.css">
</head>
<body>
  <aside class="sidebar">
    <a class="brand" href="membership-onboarding.php">
      <span class="brand-icon material-symbols-outlined">family_restroom</span>
      <span><span class="brand-name">KinKeep Vault</span><span class="brand-caption">Heritage &amp; Lineage</span></span>
    </a>
    <div class="role-box"><span><span class="material-symbols-outlined">account_circle</span>Account</span><span class="role-pill">Onboarding</span></div>
    <nav class="side-nav" aria-label="Account navigation">
      <div class="nav-label">Membership</div>
      <a class="active" aria-current="page" href="membership-onboarding.php"><span class="material-symbols-outlined">how_to_reg</span>Family membership</a>
    </nav>
    <div class="sidebar-footer">
      <div class="user-mini"><span class="avatar-sm" data-member-avatar aria-hidden="true">?</span><span><strong data-member-name>Account</strong><small data-member-status>Verified account</small></span></div>
    </div>
  </aside>
  <div class="workspace">
    <header class="topbar"><div style="display:flex;align-items:center;gap:9px"><button class="icon-button menu-toggle" aria-label="Open navigation"><span class="material-symbols-outlined">menu</span></button><span class="crumb">Account / Family Membership</span></div></header>
    <main class="page-wrap">
      <div class="page-heading"><div><p class="eyebrow">A private space for your family</p><h1>Join your family on KinKeep Vault</h1><p class="subtitle">KinKeep Vault helps families preserve their history, relationships, and important records in one secure place.</p></div></div>
      <section class="card" style="margin-bottom:16px">
        <div class="card-head"><div><h2>How family access works</h2><p>Email verification protects your account; it does not itself grant access to private family information.</p></div><span class="section-icon material-symbols-outlined">verified_user</span></div>
        <div class="grid three">
          <article class="member-card"><div><p class="eyebrow">Step 1</p><h3>Find your family</h3><p class="subtitle">Search only families that have chosen to appear in membership search.</p></div></article>
          <article class="member-card"><div><p class="eyebrow">Step 2</p><h3>Request access</h3><p class="subtitle">Tell the Family Admin how you are related. Request access only to a family you genuinely belong to.</p></div></article>
          <article class="member-card"><div><p class="eyebrow">Step 3</p><h3>Wait for approval</h3><p class="subtitle">A Family Admin must review your request. Family records stay private until your membership is approved.</p></div></article>
        </div>
      </section>
      <section id="membership-status" class="card" style="margin-bottom:16px" aria-live="polite">
        <div class="card-head"><div><h2>Your membership requests</h2><p>Check the latest status of requests submitted from this account.</p></div></div>
        <p id="status-message" class="subtitle" role="status">Loading your membership status…</p>
        <div id="request-list" class="stack"></div>
      </section>
      <section class="card">
        <div class="card-head"><div><h2>Request to join a family</h2><p>Only discoverable families are listed. No member lists, contact details, or family records are shared here.</p></div></div>
        <form id="membership-form" style="display:grid;gap:14px;max-width:680px">
          <label style="display:grid;gap:5px;font-size:12px;font-weight:600">Family<select id="family-select" name="family_id" required disabled style="width:100%;padding:10px;border:1px solid #c3c6ce;border-radius:8px;background:#fff;color:#0b1c30"><option value="">Loading available families…</option></select></label>
          <div class="grid two">
            <label style="display:grid;gap:5px;font-size:12px;font-weight:600">First name<input name="first_name" type="text" maxlength="100" autocomplete="given-name" required style="width:100%;padding:10px;border:1px solid #c3c6ce;border-radius:8px"></label>
            <label style="display:grid;gap:5px;font-size:12px;font-weight:600">Last name<input name="last_name" type="text" maxlength="100" autocomplete="family-name" required style="width:100%;padding:10px;border:1px solid #c3c6ce;border-radius:8px"></label>
          </div>
          <label style="display:grid;gap:5px;font-size:12px;font-weight:600">Your relationship to this family<input name="claimed_relationship" type="text" maxlength="50" placeholder="For example, daughter, cousin, or grandchild" required style="width:100%;padding:10px;border:1px solid #c3c6ce;border-radius:8px"></label>
          <label style="display:grid;gap:5px;font-size:12px;font-weight:600">Message to the Family Admin (optional)<textarea name="reason" maxlength="500" rows="3" style="width:100%;padding:10px;border:1px solid #c3c6ce;border-radius:8px"></textarea></label>
          <button id="submit-request" class="btn primary" type="submit" disabled>Submit membership request</button>
          <p id="form-message" class="subtitle" role="status" aria-live="polite"></p>
        </form>
      </section>
    </main>
  </div>
  <div class="toast" role="status" aria-live="polite"></div>
  <script src="member-pages.js"></script>
  <script src="membership-onboarding.js"></script>
</body>
</html>
