'use strict';

const apiBase = '../zip_extracted/public/api/';
const membershipForm = document.querySelector('#membership-form');
const familySelect = document.querySelector('#family-select');
const submitButton = document.querySelector('#submit-request');
const statusMessage = document.querySelector('#status-message');
const formMessage = document.querySelector('#form-message');
const requestList = document.querySelector('#request-list');
let csrfToken = '';
let requests = [];

async function request(path, options = {}) {
  const response = await fetch(apiBase + path, {
    ...options,
    credentials: 'same-origin',
    headers: { Accept: 'application/json', ...(options.headers || {}) }
  });
  const result = await response.json().catch(() => null);
  if (!response.ok || result?.success !== true) {
    throw new Error(result?.error || `Request failed (HTTP ${response.status}).`);
  }
  return result;
}

function showFormMessage(message, isError = false) {
  formMessage.textContent = message;
  formMessage.setAttribute('role', isError ? 'alert' : 'status');
}

function renderRequests() {
  requestList.replaceChildren();
  for (const membershipRequest of requests) {
    const item = document.createElement('article');
    item.className = 'member-card';
    const details = document.createElement('div');
    const familyName = document.createElement('strong');
    familyName.textContent = membershipRequest.family_name;
    const submitted = document.createElement('p');
    submitted.className = 'subtitle';
    const date = new Date(`${membershipRequest.created_at.replace(' ', 'T')}Z`);
    submitted.textContent = `Submitted ${Number.isNaN(date.getTime()) ? membershipRequest.created_at : date.toLocaleString()}`;
    const status = document.createElement('p');
    status.className = 'subtitle';
    const statusText = {
      pending: 'A Family Admin must review this request. Family information remains private until approval.',
      approved: 'Approved. Your family membership is active.',
      rejected: 'Not approved. You may submit a new request if your circumstances change.',
      cancelled: 'This request was cancelled.'
    }[membershipRequest.status] || 'Status unavailable.';
    status.textContent = statusText;
    details.append(familyName, submitted, status);
    const badge = document.createElement('span');
    badge.className = `pill ${membershipRequest.status === 'pending' ? 'gold' : membershipRequest.status === 'rejected' ? 'red' : 'teal'}`;
    badge.textContent = membershipRequest.status.charAt(0).toUpperCase() + membershipRequest.status.slice(1);
    item.append(details, badge);
    requestList.append(item);
  }
  if (!requests.length) {
    const empty = document.createElement('p');
    empty.className = 'subtitle';
    empty.textContent = 'You have not submitted a family membership request.';
    requestList.append(empty);
  }
}

function updateFamilyOptions(families) {
  const pendingFamilyIds = new Set(
    requests.filter((item) => item.status === 'pending').map((item) => String(item.family_id))
  );
  familySelect.replaceChildren();
  const placeholder = document.createElement('option');
  placeholder.value = '';
  placeholder.textContent = families.length ? 'Select a family' : 'No discoverable families are currently available';
  familySelect.append(placeholder);

  for (const family of families) {
    const option = document.createElement('option');
    option.value = String(family.id);
    option.textContent = family.family_name;
    option.disabled = pendingFamilyIds.has(option.value);
    if (option.disabled) option.textContent += ' — request pending';
    familySelect.append(option);
  }
  familySelect.disabled = families.length === 0;
  submitButton.disabled = families.length === 0;
}

async function loadMembershipData() {
  statusMessage.textContent = 'Loading your membership status…';
  try {
    const [auth, membership, discovery] = await Promise.all([
      request('auth/me.php'),
      request('family/membership_status.php'),
      request('family/available.php')
    ]);
    if (typeof auth.csrf_token !== 'string' || auth.csrf_token.length < 32) {
      throw new Error('Could not obtain a valid security token. Refresh and sign in again.');
    }
    applyMemberIdentity(auth);
    if (auth.user?.email_verified_at == null) {
      throw new Error('Verify your email before requesting family membership.');
    }
    csrfToken = auth.csrf_token;
    requests = Array.isArray(membership.requests) ? membership.requests : [];
    renderRequests();
    if (Number.isSafeInteger(membership.active_member_family_id) && membership.active_member_family_id > 0) {
      window.location.replace(`dashboard.php?family_id=${encodeURIComponent(membership.active_member_family_id)}`);
      return;
    }
    const families = Array.isArray(discovery.families) ? discovery.families : [];
    updateFamilyOptions(families);
    statusMessage.textContent = requests.some((item) => item.status === 'pending')
      ? 'Your pending request is awaiting a Family Admin decision. You can review it above.'
      : 'Your email is verified. Request approval from a family you genuinely belong to.';
    if (!families.length) {
      showFormMessage('No families have enabled membership search yet. Ask a Family Admin for an invitation or to make the family discoverable.');
    }
  } catch (error) {
    familySelect.disabled = true;
    submitButton.disabled = true;
    statusMessage.textContent = error instanceof Error ? error.message : 'Membership information could not be loaded.';
    statusMessage.setAttribute('role', 'alert');
  }
}

membershipForm.addEventListener('submit', async (event) => {
  event.preventDefault();
  if (!csrfToken || !membershipForm.reportValidity()) return;

  const selectedFamily = familySelect.selectedOptions[0];
  if (!selectedFamily?.value) {
    showFormMessage('Choose an available family before submitting.', true);
    return;
  }
  if (!window.confirm(`Submit a membership request to ${selectedFamily.textContent}? The Family Admin will review your request.`)) {
    return;
  }

  submitButton.disabled = true;
  showFormMessage('Submitting your request…');
  try {
    const formData = new FormData(membershipForm);
    const result = await request('family/join_request.php', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'X-CSRF-Token': csrfToken
      },
      body: JSON.stringify({
        family_id: Number(formData.get('family_id')),
        first_name: formData.get('first_name'),
        last_name: formData.get('last_name'),
        claimed_relationship: formData.get('claimed_relationship'),
        reason: formData.get('reason')
      })
    });
    showFormMessage(result.message || 'Your membership request was submitted.');
    await loadMembershipData();
  } catch (error) {
    showFormMessage(error instanceof Error ? error.message : 'Could not submit the membership request.', true);
    submitButton.disabled = familySelect.disabled;
  }
});

loadMembershipData();
