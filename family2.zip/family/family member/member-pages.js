﻿/* FILE ORGANIZATION
 * 1. Sidebar open/close behavior
 * 2. Toast notifications
 * 3. Search/filter helpers
 * 4. Page-specific interactions (where present)
 */

const sidebar = document.querySelector('.sidebar');
const menuToggle = document.querySelector('.menu-toggle');
const toast = document.querySelector('.toast');
let toastTimeout;

async function logoutCurrentUser() {
  try {
    const tokenResponse = await fetch('../zip_extracted/public/index.php', {
      credentials: 'same-origin',
      headers: { Accept: 'application/json' }
    });
    const tokenJson = await tokenResponse.json().catch(() => null);
    if (!tokenResponse.ok || !tokenJson?.success || typeof tokenJson.csrf_token !== 'string' || tokenJson.csrf_token.length < 32) {
      throw new Error('Could not obtain a valid security token.');
    }
    const logoutResponse = await fetch('../zip_extracted/public/api/auth/logout.php', {
      method: 'POST',
      credentials: 'same-origin',
      headers: {
        Accept: 'application/json',
        'X-CSRF-Token': tokenJson.csrf_token,
        'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8'
      },
      body: new URLSearchParams({ csrf_token: tokenJson.csrf_token }).toString()
    });
    const logoutJson = await logoutResponse.json().catch(() => null);
    if (logoutResponse.ok && logoutJson?.success) {
      window.location.href = '../super admin/login.php';
      return;
    }
    throw new Error(logoutJson?.error || 'Logout failed.');
  } catch (error) {
    console.error('Logout failed:', error);
    window.location.href = '../super admin/login.php';
  }
}

function ensureSidebarLogoutButton() {
  if (!sidebar || sidebar.querySelector('.sidebar-logout')) return;
  const footer = sidebar.querySelector('.sidebar-footer');
  const button = document.createElement('button');
  button.type = 'button';
  button.className = 'sidebar-logout';
  button.innerHTML = '<span class="material-symbols-outlined">logout</span>Log out';
  button.addEventListener('click', logoutCurrentUser);
  if (footer) {
    footer.appendChild(button);
  } else {
    sidebar.appendChild(button);
  }
}

ensureSidebarLogoutButton();

menuToggle?.addEventListener('click', () => {
  sidebar?.classList.toggle('open');
});

document.addEventListener('click', (event) => {
  if (sidebar?.classList.contains('open') &&
      !sidebar.contains(event.target) &&
      !event.target.closest('.menu-toggle')) {
    sidebar.classList.remove('open');
  }
});

document.querySelectorAll('[data-toast]').forEach((button) => {
  button.addEventListener('click', () => {
    if (!button.dataset.toast) return;
    if (!toast) return;
    toast.textContent = button.dataset.toast;
    toast.classList.add('visible');
    window.clearTimeout(toastTimeout);
    toastTimeout = window.setTimeout(() => toast.classList.remove('visible'), 2800);
  });
});

document.querySelectorAll('[data-filter]').forEach((input) => {
  const selector = input.dataset.filter;
  input.addEventListener('input', () => {
    document.querySelectorAll(selector).forEach((item) => {
      item.hidden = !item.textContent.toLowerCase().includes(input.value.toLowerCase());
    });
  });
});

function membershipRequestForm() {
    const heading = document.querySelector('.page-heading');
    if (!heading) return;

    const invitationSection = document.createElement('section');
    invitationSection.className = 'card';
    invitationSection.style.cssText = 'margin-bottom:16px';
    invitationSection.hidden = true;
    const invitationTitle = document.createElement('h2');
    invitationTitle.textContent = 'Family Admin invitations';
    const invitationDescription = document.createElement('p');
    invitationDescription.className = 'subtitle';
    invitationDescription.textContent = 'Review invitations addressed to your signed-in account. Accepting grants Family Admin access only for the named family.';
    const invitationList = document.createElement('div');
    invitationList.style.cssText = 'display:grid;gap:12px;margin-top:12px';
    invitationSection.append(invitationTitle, invitationDescription, invitationList);

    const section = document.createElement('section');
    section.className = 'card';
    section.style.marginBottom = '16px';
    const title = document.createElement('h2');
    title.textContent = 'Request to join a family';
    const description = document.createElement('p');
    description.className = 'subtitle';
    description.textContent = 'Submit a membership request for review by an administrator of that family.';
    const form = document.createElement('form');
    form.style.cssText = 'display:grid;gap:12px;max-width:620px';
    const status = document.createElement('p');
    status.className = 'subtitle';
    status.setAttribute('role', 'status');
    status.hidden = true;

    function addField(labelText, control) {
      const label = document.createElement('label');
      label.style.cssText = 'display:grid;gap:5px;font-size:12px;font-weight:600';
      label.append(document.createTextNode(labelText), control);
      form.append(label);
    }

    function styleControl(control) {
      control.style.cssText = 'width:100%;box-sizing:border-box;padding:9px 10px;border:1px solid #c3c6ce;border-radius:8px;background:#fff;color:#0b1c30';
    }

    const familySelect = document.createElement('select');
    familySelect.required = true;
    styleControl(familySelect);
    addField('Family', familySelect);

    const firstName = document.createElement('input');
    firstName.type = 'text';
    firstName.name = 'first_name';
    firstName.maxLength = 100;
    firstName.required = true;
    styleControl(firstName);
    addField('First name', firstName);

    const lastName = document.createElement('input');
    lastName.type = 'text';
    lastName.name = 'last_name';
    lastName.maxLength = 100;
    lastName.required = true;
    styleControl(lastName);
    addField('Last name', lastName);

    const relationship = document.createElement('input');
    relationship.type = 'text';
    relationship.name = 'claimed_relationship';
    relationship.maxLength = 50;
    relationship.required = true;
    styleControl(relationship);
    addField('Claimed relationship', relationship);

    const reason = document.createElement('textarea');
    reason.name = 'reason';
    reason.maxLength = 500;
    reason.rows = 3;
    styleControl(reason);
    addField('Reason or additional context (optional)', reason);

    const submit = document.createElement('button');
    submit.type = 'submit';
    submit.className = 'btn primary';
    submit.textContent = 'Submit membership request';
    form.append(submit, status);
    section.append(title, description, form);
    heading.after(invitationSection, section);

    const apiBase = '../zip_extracted/public/api/';
    let csrfToken;
    async function request(path, options = {}) {
      const response = await fetch(apiBase + path, {
        ...options,
        credentials: 'same-origin',
        headers: { Accept: 'application/json', ...(options.headers || {}) }
      });
      let result;
      try {
        result = await response.json();
      } catch {
        throw new Error(`The server returned an invalid response (HTTP ${response.status}).`);
      }
      if (!response.ok || !result.success) {
        throw new Error(result.error || `Request failed (HTTP ${response.status}).`);
      }
      return result;
    }

    (async () => {
      try {
        const auth = await request('auth/me.php');
        if (typeof auth.csrf_token !== 'string' || auth.csrf_token.length < 32) {
          throw new Error('Could not obtain a valid security token. Refresh and sign in again.');
        }
        applyMemberIdentity(auth);
        csrfToken = auth.csrf_token;
        try {
          await loadInvitations();
        } catch (error) {
          invitationSection.hidden = false;
          invitationDescription.textContent = `Family Admin invitations are unavailable: ${error.message}`;
        }
        const result = await request('family/available.php');
        familySelect.replaceChildren();
        for (const family of result.families) {
          const option = document.createElement('option');
          option.value = String(family.id);
          option.textContent = family.family_name;
          familySelect.append(option);
        }
        if (!result.families.length) {
          const option = document.createElement('option');
          option.value = '';
          option.textContent = 'No active families available';
          familySelect.append(option);
          familySelect.disabled = true;
          submit.disabled = true;
          status.textContent = 'There are currently no active families to request.';
          status.hidden = false;
        }
      } catch (error) {
        familySelect.disabled = true;
        submit.disabled = true;
        status.textContent = error.message;
        status.hidden = false;
      }
    })();

    async function loadInvitations() {
      const result = await request('family/admin_invitations.php');
      invitationList.replaceChildren();
      invitationSection.hidden = result.invitations.length === 0;
      for (const invitation of result.invitations) {
        const item = document.createElement('article');
        item.style.cssText = 'display:grid;gap:8px;padding:12px;border:1px solid #dce4ef;border-radius:9px';
        const familyName = document.createElement('strong');
        familyName.textContent = invitation.family_name;
        const details = document.createElement('p');
        details.className = 'subtitle';
        details.textContent = `Invited by ${invitation.invited_by_email || 'a Super Admin'} Â· Expires ${invitation.expires_at}. Enter your name only if you do not already have a profile in this family.`;
        const acceptanceForm = document.createElement('form');
        acceptanceForm.style.cssText = 'display:grid;gap:8px;max-width:620px';
        const names = document.createElement('div');
        names.style.cssText = 'display:grid;grid-template-columns:repeat(auto-fit,minmax(180px,1fr));gap:8px';
        const firstInput = document.createElement('input');
        firstInput.type = 'text';
        firstInput.name = 'first_name';
        firstInput.maxLength = 100;
        firstInput.required = false;
        firstInput.placeholder = 'First name';
        styleControl(firstInput);
        const lastInput = document.createElement('input');
        lastInput.type = 'text';
        lastInput.name = 'last_name';
        lastInput.maxLength = 100;
        lastInput.required = false;
        lastInput.placeholder = 'Last name';
        styleControl(lastInput);
        names.append(firstInput, lastInput);
        const accept = document.createElement('button');
        accept.type = 'submit';
        accept.className = 'btn primary';
        accept.textContent = 'Accept Family Admin invitation';
        const resultMessage = document.createElement('p');
        resultMessage.className = 'subtitle';
        resultMessage.setAttribute('role', 'status');
        acceptanceForm.append(names, accept, resultMessage);
        acceptanceForm.addEventListener('submit', async (event) => {
          event.preventDefault();
          if (!window.confirm(`Accept this invitation and become a Family Admin for ${invitation.family_name}?`)) return;
          accept.disabled = true;
          try {
            const accepted = await request('family/admin_invitations.php', {
              method: 'POST',
              headers: {
                'Content-Type': 'application/json',
                'X-CSRF-Token': csrfToken
              },
              body: JSON.stringify({
                invitation_id: Number(invitation.id),
                first_name: firstInput.value.trim(),
                last_name: lastInput.value.trim()
              })
            });
            resultMessage.textContent = accepted.message;
            acceptanceForm.replaceChildren(resultMessage);
            item.remove();
            invitationSection.hidden = invitationList.children.length === 0;
          } catch (error) {
            resultMessage.textContent = error.message;
            accept.disabled = false;
          }
        });
        item.append(familyName, details, acceptanceForm);
        invitationList.append(item);
      }
    }

    form.addEventListener('submit', async (event) => {
      event.preventDefault();
      if (!csrfToken || !familySelect.value) return;
      submit.disabled = true;
      status.hidden = true;
      try {
        const result = await request('family/join_request.php', {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            'X-CSRF-Token': csrfToken
          },
          body: JSON.stringify({
            family_id: Number(familySelect.value),
            first_name: firstName.value.trim(),
            last_name: lastName.value.trim(),
            claimed_relationship: relationship.value.trim(),
            reason: reason.value.trim()
          })
        });
        status.textContent = result.message;
        form.reset();
        status.hidden = false;
      } catch (error) {
        status.textContent = error.message;
        status.hidden = false;
      } finally {
        submit.disabled = false;
      }
    });
  }

if (location.pathname.endsWith('/my-family.html')) {
  membershipRequestForm();
}

const MEMBER_API_BASE = '../zip_extracted/public/api/';

async function memberApiRequest(path, options = {}) {
  const response = await fetch(MEMBER_API_BASE + path, {
    ...options,
    credentials: 'same-origin',
    headers: { Accept: 'application/json', ...(options.headers || {}) }
  });
  let result;
  try {
    result = await response.json();
  } catch {
    throw new Error(`The server returned an invalid response (HTTP ${response.status}).`);
  }
  if (!response.ok || !result.success) {
    throw new Error(result.error || `Request failed (HTTP ${response.status}).`);
  }
  return result;
}

function applyMemberIdentity(auth) {
  const email = auth?.user?.email;
  if (typeof auth?.csrf_token !== 'string' || auth.csrf_token.length < 32
      || typeof email !== 'string' || !email.trim()) {
    return;
  }
  const account = email.trim();
  document.querySelectorAll('[data-member-name]').forEach((element) => {
    element.textContent = account;
  });
  document.querySelectorAll('[data-member-status], [data-member-auth-state]').forEach((element) => {
    element.textContent = 'Signed in';
  });
  document.querySelectorAll('[data-member-avatar]').forEach((element) => {
    element.textContent = account[0].toUpperCase();
  });
}

async function loadMemberIdentity() {
  try {
    const auth = await memberApiRequest('auth/me.php');
    applyMemberIdentity(auth);
  } catch {
    // Keep the neutral HTML placeholder when authentication is unavailable.
  }
}

async function getMemberContext() {
  const auth = await memberApiRequest('auth/me.php');
  if (typeof auth.csrf_token !== 'string' || auth.csrf_token.length < 32) {
    throw new Error('Could not obtain a valid security token. Refresh and sign in again.');
  }
  applyMemberIdentity(auth);
  const familyResult = await memberApiRequest('family/my_family.php');
  return {
    auth,
    csrfToken: auth.csrf_token,
    families: familyResult.families.filter((family) => family.status === 'active')
  };
}

function disableUnbackedMemberAction(button, reason) {
  if (!button) return;
  button.removeAttribute('data-toast');
  button.disabled = false;
  button.disabled = true;
  button.title = reason;
}

function setMemberStatus(container, text, isError = false) {
  container.textContent = text;
  container.setAttribute('role', isError ? 'alert' : 'status');
  container.setAttribute('aria-live', 'polite');
}

function memberProfilePage() {
  const headingActions = document.querySelector('.page-heading .heading-actions');
  const fields = [...document.querySelectorAll('.field-grid .field')];
  if (!headingActions || !fields.length) return;
  const editButton = [...headingActions.querySelectorAll('button')]
    .find((button) => button.textContent.includes('Edit profile'));
  const status = document.createElement('p');
  status.className = 'subtitle';
  status.setAttribute('role', 'status');
  status.setAttribute('aria-live', 'polite');
  headingActions.prepend(status);

  const familyLabel = document.createElement('label');
  familyLabel.className = 'search';
  familyLabel.append(document.createTextNode('Family '));
  const familySelect = document.createElement('select');
  familySelect.setAttribute('aria-label', 'Profile family');
  familySelect.className = 'btn';
  familyLabel.append(familySelect);
  headingActions.prepend(familyLabel);

  const profileDialog = document.createElement('dialog');
  profileDialog.className = 'card member-dialog';
  profileDialog.tabIndex = -1;
  const dialogTitle = document.createElement('h2');
  dialogTitle.textContent = 'Edit personal profile';
  dialogTitle.id = 'profile-dialog-title';
  profileDialog.setAttribute('aria-labelledby', dialogTitle.id);
  const dialogStatus = document.createElement('p');
  dialogStatus.className = 'subtitle';
  dialogStatus.setAttribute('role', 'status');
  const form = document.createElement('form');
  form.style.cssText = 'display:grid;gap:12px';
  const editorFields = document.createElement('div');
  editorFields.className = 'field-grid';
  const controls = new Map();
  for (const [name, labelText, maxLength, type] of [
    ['first_name', 'First name', 100, 'text'],
    ['middle_name', 'Middle name', 100, 'text'],
    ['preferred_name', 'Preferred name', 100, 'text'],
    ['last_name', 'Last name', 100, 'text'],
    ['preferred_contact_method', 'Preferred contact method', 12, 'select'],
    ['email', 'Email address', 190, 'email'],
    ['phone', 'Phone number', 30, 'tel'],
    ['bio', 'Bio', 5000, 'textarea']
  ]) {
    const wrapper = document.createElement('label');
    wrapper.className = 'field';
    wrapper.append(document.createTextNode(labelText));
    const control = type === 'textarea'
      ? document.createElement('textarea')
      : type === 'select'
        ? document.createElement('select')
        : document.createElement('input');
    control.name = name;
    if (type !== 'textarea' && type !== 'select') control.type = type;
    if (type !== 'select') control.maxLength = maxLength;
    if (type === 'textarea') control.rows = 3;
    if (type === 'select') {
      for (const [value, optionLabel] of [
        ['', 'Choose a preference'],
        ['email', 'Email'],
        ['phone', 'Phone'],
        ['either', 'Email or phone'],
        ['none', 'No preference']
      ]) {
        const option = document.createElement('option');
        option.value = value;
        option.textContent = optionLabel;
        control.append(option);
      }
    }
    if (name === 'first_name' || name === 'last_name') control.required = true;
    control.className = 'field-value';
    wrapper.append(control);
    editorFields.append(wrapper);
    controls.set(name, control);
  }
  form.append(editorFields);
  const actions = document.createElement('div');
  actions.className = 'admin-row-actions';
  const save = document.createElement('button');
  save.type = 'submit';
  save.className = 'btn primary';
  save.textContent = 'Save profile';
  const cancel = document.createElement('button');
  cancel.type = 'button';
  cancel.className = 'btn';
  cancel.textContent = 'Cancel';
  actions.append(save, cancel);
  form.append(actions, dialogStatus);
  profileDialog.append(dialogTitle, form);
  document.body.append(profileDialog);

  let context;
  let profile;
  const summaryCard = [...document.querySelectorAll('.card')]
    .find((card) => card.querySelector('.avatar') && card.querySelector('h2'));
  const profileName = summaryCard?.querySelector('h2');
  const summaryValues = summaryCard ? [...summaryCard.querySelectorAll('strong')] : [];
  const identityCard = [...document.querySelectorAll('.card')]
    .find((card) => card.querySelector('h2')?.textContent.trim() === 'Identity verification');
  const identityStatus = document.createElement('p');
  identityStatus.className = 'subtitle';
  identityStatus.setAttribute('role', 'status');
  identityStatus.setAttribute('aria-live', 'polite');
  const identityRecords = document.createElement('div');
  identityRecords.className = 'stack';
  const identityForm = document.createElement('form');
  identityForm.style.cssText = 'display:grid;gap:12px;margin-top:14px';
  identityForm.autocomplete = 'off';
  const identityType = document.createElement('input');
  identityType.type = 'text';
  identityType.name = 'document_type';
  identityType.maxLength = 50;
  identityType.required = true;
  identityType.autocomplete = 'off';
  identityType.setAttribute('aria-label', 'Identity document type');
  identityType.placeholder = 'e.g. National ID or passport';
  const identityNumber = document.createElement('input');
  identityNumber.type = 'password';
  identityNumber.name = 'document_number';
  identityNumber.maxLength = 100;
  identityNumber.required = true;
  identityNumber.autocomplete = 'new-password';
  identityNumber.setAttribute('aria-label', 'Identity document number');
  identityNumber.placeholder = 'Enter document number for submission';
  const identitySubmit = document.createElement('button');
  identitySubmit.type = 'submit';
  identitySubmit.className = 'btn primary';
  identitySubmit.textContent = 'Submit identity for review';
  const identityHelp = document.createElement('p');
  identityHelp.className = 'subtitle';
  identityHelp.textContent = 'The document number is sent only for submission and is never shown in your review history.';
  function identityField(labelText, control) {
    const label = document.createElement('label');
    label.style.cssText = 'display:grid;gap:5px;font-size:12px;font-weight:600';
    label.append(document.createTextNode(labelText), control);
    return label;
  }
  identityForm.append(
    identityField('Document type', identityType),
    identityField('Document number', identityNumber),
    identitySubmit,
    identityHelp
  );
  identityForm.hidden = true;
  identitySubmit.disabled = true;
  if (identityCard) {
    identityCard.querySelectorAll('.security-row, [data-profile-note]').forEach((element) => element.remove());
    identityCard.append(identityStatus, identityRecords, identityForm);
  }
  for (const field of fields) {
    const value = field.querySelector('.field-value');
    if (value) value.textContent = 'â€”';
  }
  if (profileName) profileName.textContent = 'Loading profile...';
  if (summaryValues.length) summaryValues.forEach((value) => { value.textContent = 'â€”'; });
  const initialAvatar = summaryCard?.querySelector('.avatar');
  if (initialAvatar) initialAvatar.textContent = '?';
  const initialSummarySubtitle = summaryCard?.querySelector('.subtitle');
  if (initialSummarySubtitle) initialSummarySubtitle.textContent = 'Profile details unavailable until authentication.';
  const initialSummaryPills = summaryCard ? [...summaryCard.querySelectorAll('.pill')] : [];
  if (initialSummaryPills[0]) {
    initialSummaryPills[0].textContent = 'Identity status unavailable';
    initialSummaryPills[0].className = 'pill blue';
  }
  if (initialSummaryPills[1]) {
    initialSummaryPills[1].textContent = 'Profile unavailable';
    initialSummaryPills[1].className = 'pill blue';
  }
  const initialBanner = document.querySelector('.banner');
  if (initialBanner) {
    const bannerTitle = initialBanner.querySelector('h2');
    const bannerDescription = initialBanner.querySelector('p');
    const bannerPill = initialBanner.querySelector('.pill');
    if (bannerTitle) bannerTitle.textContent = 'Family membership status';
    if (bannerDescription) bannerDescription.textContent = 'Membership and identity details are unavailable until your profile is loaded.';
    if (bannerPill) {
      bannerPill.textContent = 'Unavailable';
      bannerPill.className = 'pill blue';
    }
  }

  function displayProfile(member, family) {
    const values = new Map([
      ['First name', member.first_name],
      ['Middle name', member.middle_name],
      ['Last name', member.last_name],
      ['Preferred name', member.preferred_name || 'Not set'],
      ['Date of birth', member.date_of_birth],
      ['Gender', member.gender],
      ['Family role', family.role === 'admin'
        ? 'Family Admin'
        : family.role === 'viewer'
          ? 'Family Viewer'
          : 'Family Member'],
      ['Home region', member.home_region],
      ['Email address', member.email || context.auth.user.email],
      ['Phone number', member.phone],
      ['Preferred contact', ({ email: 'Email', phone: 'Phone', either: 'Email or phone', none: 'No preference' })[member.preferred_contact_method] || 'Not set'],
      ['Visibility', member.profile_visibility === 'private' ? 'Private by default' : 'Family members only']
    ]);
    for (const field of fields) {
      const labelElement = field.querySelector('label');
      const label = labelElement?.textContent.trim();
      const value = field.querySelector('.field-value');
      if (label === 'Visibility' && labelElement) labelElement.textContent = 'Family visibility default';
      if (value) value.textContent = values.get(label) || 'â€”';
    }
    if (profileName) {
      profileName.textContent = member.preferred_name
        || `${member.first_name || ''} ${member.middle_name || ''} ${member.last_name || ''}`.trim();
    }
    const avatar = summaryCard?.querySelector('.avatar');
    if (avatar) avatar.textContent = `${member.first_name?.[0] || ''}${member.last_name?.[0] || ''}`.toUpperCase();
    const summarySubtitle = summaryCard?.querySelector('.subtitle');
    if (summarySubtitle) summarySubtitle.textContent = `Family member Â· ${family.family_name}`;
    if (summaryValues[0]) summaryValues[0].textContent = String(member.id);
    if (summaryValues[1]) summaryValues[1].textContent = member.created_at || 'â€”';
    if (summaryValues[2]) summaryValues[2].textContent = member.updated_at || 'â€”';
    const summaryPills = summaryCard ? [...summaryCard.querySelectorAll('.pill')] : [];
    if (summaryPills[0]) {
      summaryPills[0].textContent = 'Identity status unavailable';
      summaryPills[0].className = 'pill blue';
    }
    if (summaryPills[1]) {
      summaryPills[1].textContent = 'Profile loaded';
      summaryPills[1].className = 'pill blue';
    }
    const banner = document.querySelector('.banner');
    if (banner) {
      const title = banner.querySelector('h2');
      const description = banner.querySelector('p');
      const pill = banner.querySelector('.pill');
      if (title) title.textContent = 'Family membership status';
      if (description) description.textContent = `Membership status: ${member.member_status || 'unknown'}. Identity verification status is not available through the profile API.`;
      if (pill) {
        pill.textContent = member.member_status || 'unknown';
        pill.className = `pill ${member.member_status === 'active' ? 'teal' : 'blue'}`;
      }
    }
  }

  function renderIdentityStatuses(verifications) {
    identityRecords.replaceChildren();
    if (!verifications.length) {
      const empty = document.createElement('p');
      empty.className = 'empty-state';
      empty.textContent = 'No identity submissions are recorded for this profile.';
      identityRecords.append(empty);
      return;
    }
    for (const verification of verifications) {
      const row = document.createElement('article');
      row.className = 'member-card';
      const details = document.createElement('div');
      details.className = 'permission-detail';
      const type = document.createElement('strong');
      type.textContent = typeof verification.document_type === 'string'
        ? verification.document_type
        : 'Identity document';
      const state = document.createElement('p');
      state.textContent = `Status: ${typeof verification.status === 'string' ? verification.status : 'unknown'}`;
      details.append(type, state);
      if (typeof verification.rejection_reason === 'string' && verification.rejection_reason) {
        const rejection = document.createElement('p');
        rejection.textContent = `Reason: ${verification.rejection_reason}`;
        details.append(rejection);
      }
      const dates = document.createElement('small');
      dates.textContent = `Submitted: ${verification.submitted_at || 'Unavailable'} Â· Reviewed: ${verification.reviewed_at || 'Not reviewed'}`;
      details.append(dates);
      row.append(details);
      identityRecords.append(row);
    }
  }

  async function loadIdentityStatus(family) {
    if (!identityCard || !family || Number(family.member_id) !== Number(profile?.id)) return;
    identitySubmit.disabled = true;
    identityForm.hidden = family.role === 'viewer';
    setMemberStatus(identityStatus, 'Loading identity verification status...');
    identityRecords.replaceChildren();
    try {
      const result = await memberApiRequest(
        `identity/status.php?member_id=${encodeURIComponent(family.member_id)}`
      );
      if (String(family.id) !== familySelect.value || Number(profile?.id) !== Number(family.member_id)) return;
      const verifications = Array.isArray(result.verifications)
        ? result.verifications.map((record) => ({
          document_type: record.document_type,
          status: record.status,
          rejection_reason: record.rejection_reason,
          submitted_at: record.submitted_at,
          reviewed_at: record.reviewed_at
        }))
        : [];
      renderIdentityStatuses(verifications);
      const hasPending = verifications.some((record) => record.status === 'pending');
      identitySubmit.disabled = family.role === 'viewer' || hasPending;
      const summaryPill = summaryCard?.querySelector('.pill');
      if (summaryPill) {
        summaryPill.textContent = verifications[0]?.status
          ? `Identity ${verifications[0].status}`
          : 'Identity not submitted';
        summaryPill.className = `pill ${verifications[0]?.status === 'verified' ? 'teal' : 'blue'}`;
      }
      setMemberStatus(identityStatus, hasPending
        ? 'A submission is pending authorized review.'
        : 'Identity status loaded for your own profile.');
    } catch (error) {
      setMemberStatus(identityStatus, error.message, true);
      identitySubmit.disabled = true;
      const summaryPill = summaryCard?.querySelector('.pill');
      if (summaryPill) {
        summaryPill.textContent = 'Identity status unavailable';
        summaryPill.className = 'pill blue';
      }
    }
  }

  identityForm.addEventListener('submit', async (event) => {
    event.preventDefault();
    const family = context?.families.find((item) => String(item.id) === familySelect.value);
    if (!profile || !family || !context || Number(profile.id) !== Number(family.member_id)) return;
    const documentType = identityType.value.trim();
    const documentNumber = identityNumber.value;
    if (!documentType || !documentNumber.trim()) {
      setMemberStatus(identityStatus, 'Enter a document type and number.', true);
      return;
    }
    identitySubmit.disabled = true;
    setMemberStatus(identityStatus, 'Submitting identity for review...');
    try {
      const result = await memberApiRequest('identity/submit.php', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'X-CSRF-Token': context.csrfToken
        },
        body: JSON.stringify({
          member_id: Number(profile.id),
          document_type: documentType,
          document_number: documentNumber
        })
      });
      identityNumber.value = '';
      identityType.value = '';
      setMemberStatus(identityStatus, result.message || 'Identity submitted for review.');
      await loadIdentityStatus(family);
    } catch (error) {
      setMemberStatus(identityStatus, error.message, true);
      identitySubmit.disabled = false;
    } finally {
      identityNumber.value = '';
    }
  });

  async function loadProfile() {
    const family = context?.families.find((item) => String(item.id) === familySelect.value);
    if (!family) return;
    editButton && (editButton.disabled = true);
    setMemberStatus(status, 'Loading your profile...');
    try {
      const result = await memberApiRequest(
        `members/profile.php?member_id=${encodeURIComponent(family.member_id)}`
      );
      if (String(family.id) !== familySelect.value) return;
      if (String(result.member.family_id) !== String(family.id)) {
        throw new Error('The profile does not belong to the selected family.');
      }
      profile = result.member;
      displayProfile(profile, family);
      await loadIdentityStatus(family);
      setMemberStatus(status, 'Profile loaded.');
    } catch (error) {
      setMemberStatus(status, error.message, true);
      setMemberStatus(identityStatus, error.message, true);
      identityForm.hidden = true;
      identitySubmit.disabled = true;
    } finally {
      if (editButton) editButton.disabled = !profile;
    }
  }

  editButton?.removeAttribute('data-toast');
  editButton?.addEventListener('click', () => {
    if (!profile) return;
    dialogStatus.textContent = '';
    for (const [name, control] of controls) {
      control.value = name === 'email'
        ? profile.email || context.auth.user.email || ''
        : profile[name] || '';
    }
    profileDialog.showModal();
  });
  cancel.addEventListener('click', () => profileDialog.close());
  familySelect.addEventListener('change', () => {
    profile = null;
    identityNumber.value = '';
    identityType.value = '';
    identityForm.hidden = true;
    identitySubmit.disabled = true;
    identityRecords.replaceChildren();
    setMemberStatus(identityStatus, 'Loading identity verification status...');
    if (editButton) editButton.disabled = true;
    loadProfile();
  });
  form.addEventListener('submit', async (event) => {
    event.preventDefault();
    if (!profile || !context) return;
    save.disabled = true;
    save.textContent = 'Saving...';
    try {
      const body = Object.fromEntries(new FormData(form).entries());
      body.member_id = String(profile.id);
      await memberApiRequest('members/update.php', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'X-CSRF-Token': context.csrfToken
        },
        body: JSON.stringify(body)
      });
      profile = { ...profile, ...body };
      displayProfile(profile, context.families.find((item) => String(item.id) === familySelect.value));
      setMemberStatus(status, 'Profile updated successfully.');
      profileDialog.close();
    } catch (error) {
      setMemberStatus(dialogStatus, error.message, true);
    } finally {
      save.disabled = false;
      save.textContent = 'Save profile';
    }
  });

  (async () => {
    if (editButton) editButton.disabled = true;
    try {
      context = await getMemberContext();
      familySelect.replaceChildren();
      for (const family of context.families) {
        const option = document.createElement('option');
        option.value = String(family.id);
        option.textContent = family.family_name;
        familySelect.append(option);
      }
      if (!context.families.length) throw new Error('No active family profile is linked to this account.');
      familyLabel.hidden = context.families.length < 2;
      await loadProfile();
    } catch (error) {
      setMemberStatus(status, error.message, true);
      setMemberStatus(identityStatus, error.message, true);
      identityForm.hidden = true;
      identitySubmit.disabled = true;
      if (editButton) editButton.disabled = true;
    }
  })();
}

function memberFamilyDirectoryPage() {
  const body = document.querySelector('.table-wrap tbody');
  if (!body) return;
  const relativeButton = [...document.querySelectorAll('.page-heading button')]
    .find((button) => button.textContent.includes('Suggest a relative'));
  const immediateCard = [...document.querySelectorAll('.page-wrap > .card')]
    .find((card) => card.querySelector('h2')?.textContent.trim() === 'My immediate family');
  const immediateGrid = immediateCard?.querySelector('.grid.two');
  const immediateStatus = document.createElement('p');
  immediateStatus.className = 'subtitle';
  immediateStatus.setAttribute('role', 'status');
  immediateStatus.setAttribute('aria-live', 'polite');
  const immediateList = document.createElement('div');
  immediateList.className = 'stack';
  if (immediateGrid) {
    immediateGrid.replaceWith(immediateStatus, immediateList);
  }
  const stats = [...document.querySelectorAll('.stat-card strong')];
  const statLabels = [...document.querySelectorAll('.stat-card span:last-child')];
  if (statLabels[0]) statLabels[0].textContent = 'Active family profiles';
  if (statLabels[1]) statLabels[1].textContent = 'Approved relationships';
  if (statLabels[2]) statLabels[2].textContent = 'Your approved links';
  if (statLabels[3]) statLabels[3].textContent = 'Active families';
  const immediateTitle = immediateCard?.querySelector('h2');
  if (immediateTitle) immediateTitle.textContent = 'Approved relationships for your profile';
  const immediateDescription = immediateCard?.querySelector('.card-head p');
  if (immediateDescription) immediateDescription.textContent = 'Only relationships approved in the family records are shown.';
  const immediatePill = immediateCard?.querySelector('.card-head .pill');
  if (immediatePill) {
    immediatePill.textContent = 'Loading';
    immediatePill.className = 'pill blue';
  }
  relativeButton?.removeAttribute('data-toast');
  relativeButton?.addEventListener('click', () => {
    window.location.href = 'family-tree.html#suggest-relationship';
  });
  body.replaceChildren();
  const initialRow = document.createElement('tr');
  const initialCell = document.createElement('td');
  initialCell.colSpan = 5;
  initialCell.textContent = 'Loading family directory...';
  initialRow.append(initialCell);
  body.append(initialRow);
  const search = document.querySelector('input[aria-label="Search family members"]');
  const message = document.createElement('p');
  message.className = 'subtitle';
  message.setAttribute('role', 'status');
  document.querySelector('.table-wrap')?.before(message);
  const profileDialog = document.createElement('dialog');
  profileDialog.setAttribute('aria-labelledby', 'member-profile-title');
  const profileTitle = document.createElement('h2');
  profileTitle.id = 'member-profile-title';
  const profileDetails = document.createElement('dl');
  const profileStatus = document.createElement('p');
  profileStatus.setAttribute('role', 'status');
  const closeProfile = document.createElement('button');
  closeProfile.type = 'button';
  closeProfile.className = 'btn';
  closeProfile.textContent = 'Close';
  closeProfile.addEventListener('click', () => profileDialog.close());
  profileDialog.append(profileTitle, profileDetails, profileStatus, closeProfile);
  document.body.append(profileDialog);

  function render(context) {
    body.replaceChildren();
    const allMembers = context.families.flatMap((family) =>
      family.members.map((member) => ({ ...member, family_name: family.family_name, family_id: family.id }))
    );
    const uniqueMembers = new Set(allMembers
      .filter((member) => member.member_status === 'active')
      .map((member) => `${member.family_id}:${member.id}`));
    if (stats[0]) stats[0].textContent = String(uniqueMembers.size);
    if (stats[3]) stats[3].textContent = String(context.families.length);
    const term = search?.value.trim().toLowerCase() || '';
    const visible = allMembers.filter((member) =>
      `${member.first_name} ${member.middle_name || ''} ${member.preferred_name || ''} ${member.last_name} ${member.family_name}`
        .toLowerCase().includes(term)
    );
    if (!visible.length) {
      const row = document.createElement('tr');
      const cell = document.createElement('td');
      cell.colSpan = 5;
      cell.textContent = allMembers.length ? 'No family members match this search.' : 'No family members are available.';
      row.append(cell);
      body.append(row);
      return;
    }
    for (const member of visible) {
      const row = document.createElement('tr');
      row.className = 'family-member-row';
      const nameCell = document.createElement('td');
      const person = document.createElement('div');
      person.className = 'person-row';
      const avatar = document.createElement('span');
      avatar.className = 'avatar-sm';
      avatar.textContent = `${member.first_name?.[0] || ''}${member.last_name?.[0] || ''}`.toUpperCase();
      const details = document.createElement('div');
      const name = document.createElement('strong');
      const legalName = `${member.first_name || ''} ${member.middle_name ? `${member.middle_name} ` : ''}${member.last_name || ''}`.trim();
      name.textContent = member.preferred_name ? `${member.preferred_name} (${legalName})` : legalName;
      const family = document.createElement('small');
      family.textContent = member.family_name;
      details.append(name, family);
      person.append(avatar, details);
      nameCell.append(person);
      row.append(nameCell);
      const relationshipCell = document.createElement('td');
      relationshipCell.className = 'family-relationship';
      relationshipCell.dataset.familyId = String(member.family_id);
      relationshipCell.dataset.memberId = String(member.id);
      relationshipCell.textContent = 'Not recorded';
      row.append(relationshipCell);
      const locationCell = document.createElement('td');
      locationCell.textContent = 'Not provided';
      row.append(locationCell);
      for (const value of ['â€”', 'â€”']) {
        const cell = document.createElement('td');
        cell.textContent = value;
        row.append(cell);
      }
      const statusCell = document.createElement('td');
      const pill = document.createElement('span');
      pill.className = `pill ${member.member_status === 'active' ? 'teal' : 'blue'}`;
      pill.textContent = member.member_status || 'unknown';
      statusCell.append(pill);
      row.append(statusCell);
      const actionCell = document.createElement('td');
      const view = document.createElement('button');
      view.type = 'button';
      view.className = 'btn small';
      view.textContent = 'View';
      view.addEventListener('click', async () => {
        view.disabled = true;
        profileTitle.textContent = name.textContent;
        profileDetails.replaceChildren();
        profileStatus.textContent = 'Loading profile…';
        if (!profileDialog.open) profileDialog.showModal();
        try {
          const result = await memberApiRequest(
            `members/profile.php?member_id=${encodeURIComponent(member.id)}`
          );
          const profile = result.member || {};
          const fields = [
            ['Family', profile.family_name], ['Home region', profile.home_region], ['Gender', profile.gender],
            ['Membership status', profile.member_status], ['Date of birth', profile.date_of_birth],
            ['Email', profile.email], ['Phone', profile.phone], ['About', profile.bio]
          ];
          for (const [label, value] of fields) {
            if (value === null || value === undefined || String(value).trim() === '') continue;
            const term = document.createElement('dt');
            term.textContent = label;
            const description = document.createElement('dd');
            description.textContent = String(value);
            profileDetails.append(term, description);
          }
          profileStatus.textContent = profileDetails.childElementCount
            ? 'Information shown according to the profile owner’s access settings.'
            : 'No additional profile information is available to you.';
        } catch (error) {
          profileStatus.textContent = error.message;
        } finally {
          view.disabled = false;
        }
      });
      actionCell.append(view);
      row.append(actionCell);
      body.append(row);
    }
  }

  search?.addEventListener('input', () => {
    if (directoryContext) render(directoryContext);
  });
  let directoryContext;
  getMemberContext().then((context) => {
    directoryContext = context;
    render(context);
    message.textContent = `Directory loaded for ${context.families.length} active family assignment${context.families.length === 1 ? '' : 's'}.`;
    return loadFamilyRelationships(context);
  }).catch((error) => {
    const row = document.createElement('tr');
    const cell = document.createElement('td');
    cell.colSpan = 5;
    cell.textContent = error.message;
    row.append(cell);
    body.replaceChildren(row);
    setMemberStatus(message, error.message, true);
    stats.forEach((value) => { value.textContent = 'â€”'; });
    setMemberStatus(immediateStatus, error.message, true);
  });

  async function loadFamilyRelationships(context) {
    setMemberStatus(immediateStatus, 'Loading approved family relationships...');
    immediateList.replaceChildren();
    const results = await Promise.all(context.families.map(async (family) => {
      try {
        const result = await memberApiRequest(
          `relationships/list.php?family_id=${encodeURIComponent(family.id)}`
        );
        const approved = (Array.isArray(result.relationships) ? result.relationships : [])
          .filter((relationship) =>
            Number(relationship.family_id) === Number(family.id)
            && relationship.status === 'approved'
          );
        return { family, approved };
      } catch (error) {
        return { family, error };
      }
    }));
    const failed = results.filter((result) => result.error);
    const approved = results.flatMap(({ family, approved: relationships = [] }) =>
      relationships.map((relationship) => ({ ...relationship, family }))
    );
    const direct = approved.filter((relationship) =>
      Number(relationship.person_id) === Number(relationship.family.member_id)
      || Number(relationship.related_person_id) === Number(relationship.family.member_id)
    );
    const relationshipByMember = new Map();
    for (const relationship of direct) {
      const isPerson = Number(relationship.person_id) === Number(relationship.family.member_id);
      const otherId = isPerson ? relationship.related_person_id : relationship.person_id;
      relationshipByMember.set(`${relationship.family.id}:${otherId}`, relationship.relationship_type || 'Related');
    }
    body.querySelectorAll('.family-relationship').forEach((cell) => {
      const familyId = cell.dataset.familyId;
      const memberId = cell.dataset.memberId;
      const family = context.families.find((item) => String(item.id) === familyId);
      cell.textContent = family && Number(family.member_id) === Number(memberId)
        ? 'You'
        : (relationshipByMember.get(`${familyId}:${memberId}`) || 'Not recorded');
    });
    if (failed.length) {
      if (stats[1]) stats[1].textContent = 'â€”';
      if (stats[2]) stats[2].textContent = 'â€”';
      if (immediatePill) immediatePill.textContent = 'Unavailable';
      setMemberStatus(immediateStatus, 'Approved relationship data is unavailable for one or more families.', true);
    } else {
      if (stats[1]) stats[1].textContent = String(approved.length);
      if (stats[2]) stats[2].textContent = String(direct.length);
      if (immediatePill) immediatePill.textContent = `${direct.length} approved`;
      setMemberStatus(immediateStatus, 'Showing only relationships approved by the family records.');
    }
    const memberByFamilyAndId = new Map();
    for (const family of context.families) {
      for (const member of family.members) {
        memberByFamilyAndId.set(`${family.id}:${member.id}`, member);
      }
    }
    if (!direct.length) {
      const empty = document.createElement('p');
      empty.className = 'empty-state';
      empty.textContent = failed.length
        ? 'No approved relationships can be displayed until the family relationship service is available.'
        : 'No approved relationships are recorded for your active family profiles.';
      immediateList.append(empty);
      return;
    }
    for (const relationship of direct) {
      const isPerson = Number(relationship.person_id) === Number(relationship.family.member_id);
      const otherId = isPerson ? relationship.related_person_id : relationship.person_id;
      const other = memberByFamilyAndId.get(`${relationship.family.id}:${otherId}`);
      const row = document.createElement('article');
      row.className = 'member-card';
      const details = document.createElement('div');
      details.className = 'relationship-detail';
      const name = document.createElement('strong');
      name.textContent = other
        ? `${other.first_name || ''} ${other.middle_name ? `${other.middle_name} ` : ''}${other.last_name || ''}`.trim()
        : 'Family member';
      const type = document.createElement('small');
      type.textContent = `${relationship.relationship_type || 'Relationship'} Â· ${relationship.family.family_name}`;
      details.append(name, type);
      const approvedPill = document.createElement('span');
      approvedPill.className = 'pill teal';
      approvedPill.textContent = 'Approved';
      row.append(details, approvedPill);
      immediateList.append(row);
    }
  }
}

function memberRelationshipPage() {
  const addButton = [...document.querySelectorAll('.page-heading button')]
    .find((button) => button.textContent.includes('Suggest relationship'));
  if (!addButton) return;
  const staticTree = [...document.querySelectorAll('.tree-level, .tree-connector, .tree-branch')];
  staticTree.forEach((element) => element.remove());
  const staticTreeCard = document.querySelector('.page-wrap > .card');
  let context;
  const familyLabel = document.createElement('label');
  familyLabel.className = 'search';
  familyLabel.append(document.createTextNode('Family '));
  const treeFamilySelect = document.createElement('select');
  treeFamilySelect.className = 'btn';
  treeFamilySelect.setAttribute('aria-label', 'Family relationships');
  familyLabel.append(treeFamilySelect);
  document.querySelector('.page-heading .heading-actions')?.prepend(familyLabel);

  const treeStatus = document.createElement('p');
  treeStatus.className = 'subtitle';
  treeStatus.setAttribute('role', 'status');
  treeStatus.setAttribute('aria-live', 'polite');
  const relationshipsList = document.createElement('div');
  relationshipsList.className = 'stack relationships-list';
  if (staticTreeCard) {
    const treeTitle = staticTreeCard.querySelector('h2');
    const treeDescription = staticTreeCard.querySelector('.card-head p');
    if (treeTitle) treeTitle.textContent = 'Family relationships';
    if (treeDescription) treeDescription.textContent = 'Relationships recorded for your selected family.';
    staticTreeCard.querySelectorAll('.eyebrow').forEach((element) => element.remove());
    staticTreeCard.append(treeStatus, relationshipsList);
  }
  const statValues = [...document.querySelectorAll('.stat-card strong')];
  statValues.forEach((value) => { value.textContent = 'â€”'; });
  const statLabels = [...document.querySelectorAll('.stat-card span:last-child')];
  if (statLabels[0]) statLabels[0].textContent = 'Relationships';
  if (statLabels[1]) statLabels[1].textContent = 'API-approved links';
  if (statLabels[2]) statLabels[2].textContent = 'Pending proposals';
  if (statLabels[3]) statLabels[3].textContent = 'Parent/child generations';
  if (statLabels[3]) statLabels[3].title = 'Inferred from approved directional parent and child relationships.';
  const exportButton = [...document.querySelectorAll('.page-heading button')]
    .find((button) => button.textContent.includes('Export tree'));
  let exportRows = [];
  let selectedExportFamily = null;
  if (exportButton) {
    exportButton.removeAttribute('data-toast');
    exportButton.disabled = true;
    exportButton.title = 'Export the approved and visible relationships for the selected family.';
    exportButton.addEventListener('click', () => {
      if (!selectedExportFamily || !exportRows.length) return;
      const escape = (value) => {
        const text = String(value ?? '');
        const safe = /^[\t\r\n ]*[=+\-@]/.test(text) ? `'${text}` : text;
        return `"${safe.replaceAll('"', '""')}"`;
      };
      const rows = [
        ['family', 'person', 'relationship', 'related_person', 'status', 'recorded_at'],
        ...exportRows.map((item) => [
          selectedExportFamily.family_name,
          `${item.person_first_name || ''} ${item.person_last_name || ''}`.trim(),
          item.relationship_type,
          `${item.related_first_name || ''} ${item.related_last_name || ''}`.trim(),
          item.status,
          item.created_at
        ])
      ];
      const blob = new Blob(['\uFEFF', rows.map((row) => row.map(escape).join(',')).join('\r\n')], { type: 'text/csv;charset=utf-8' });
      const url = URL.createObjectURL(blob); const link = document.createElement('a'); link.href = url;
      const slug = String(selectedExportFamily.family_name || 'family').toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/^-|-$/g, '') || 'family';
      link.download = `${slug}-relationships.csv`; link.click(); window.setTimeout(() => URL.revokeObjectURL(url), 1000);
    });
  }

  function renderRelationships(family, relationships) {
    relationshipsList.replaceChildren();
    const visible = relationships.filter((relationship) =>
      Number(relationship.family_id) === Number(family.id)
      && (family.role === 'admin'
        ? ['approved', 'pending'].includes(relationship.status)
        : relationship.status === 'approved')
    );
    selectedExportFamily = family;
    exportRows = visible.filter((relationship) => relationship.status === 'approved');
    if (exportButton) exportButton.disabled = !exportRows.length;
    const approvedCount = visible.filter((relationship) => relationship.status === 'approved').length;
    const pendingCount = visible.filter((relationship) => relationship.status === 'pending').length;
    if (statValues[0]) statValues[0].textContent = String(visible.length);
    if (statValues[1]) statValues[1].textContent = String(approvedCount);
    if (statValues[2]) statValues[2].textContent = String(pendingCount);
    if (statValues[3]) statValues[3].textContent = 'â€”';
    if (!visible.length) {
      if (statValues[3]) statValues[3].textContent = '0';
      const empty = document.createElement('p');
      empty.className = 'empty-state';
      empty.textContent = 'No API-approved relationships are recorded for this family.';
      relationshipsList.append(empty);
      setMemberStatus(treeStatus, 'Relationship list loaded.');
      return;
    }
    for (const relationship of visible) {
      const item = document.createElement('article');
      item.className = 'member-card relationship-row';
      const detail = document.createElement('div');
      detail.className = 'relationship-detail';
      const names = document.createElement('strong');
      names.textContent = `${relationship.person_first_name || 'Family member'} ${relationship.person_last_name || ''} Â· ${relationship.related_first_name || 'Family member'} ${relationship.related_last_name || ''}`.trim();
      const type = document.createElement('small');
      type.textContent = `${relationship.relationship_type || 'Relationship'} Â· ${relationship.created_at || 'Date unavailable'}`;
      detail.append(names, type);
      const status = document.createElement('span');
      status.className = `pill ${relationship.status === 'approved' ? 'teal' : 'gold'}`;
      status.textContent = relationship.status || 'unknown';
      item.append(detail, status);
      relationshipsList.append(item);
    }
    const parents = new Map();
    const indegree = new Map();
    const addEdge = (parentId, childId) => {
      const parent = String(parentId);
      const child = String(childId);
      if (!parents.has(parent)) parents.set(parent, new Set());
      if (parents.get(parent).has(child)) return;
      parents.get(parent).add(child);
      indegree.set(parent, indegree.get(parent) || 0);
      indegree.set(child, (indegree.get(child) || 0) + 1);
    };
    for (const relationship of visible) {
      if (relationship.status !== 'approved') continue;
      if (relationship.relationship_type === 'parent') addEdge(relationship.person_id, relationship.related_person_id);
      if (relationship.relationship_type === 'child') addEdge(relationship.related_person_id, relationship.person_id);
    }
    let generationCount = 0;
    let circularLinks = false;
    if (indegree.size) {
      const levels = new Map([...indegree.keys()].map((memberId) => [memberId, 1]));
      const queue = [...indegree.entries()].filter(([, value]) => value === 0).map(([memberId]) => memberId);
      let processed = 0;
      while (queue.length) {
        const parentId = queue.shift();
        processed++;
        generationCount = Math.max(generationCount, levels.get(parentId) || 1);
        for (const childId of parents.get(parentId) || []) {
          levels.set(childId, Math.max(levels.get(childId) || 1, (levels.get(parentId) || 1) + 1));
          indegree.set(childId, indegree.get(childId) - 1);
          if (indegree.get(childId) === 0) queue.push(childId);
        }
      }
      circularLinks = processed !== indegree.size;
    }
    if (statValues[3]) statValues[3].textContent = circularLinks ? 'Review' : String(generationCount);
    setMemberStatus(treeStatus, circularLinks
      ? `Showing ${visible.length} relationship records. Circular parent/child links prevent a reliable generation count.`
      : `Showing ${visible.length} relationship records. Generation depth uses approved parent/child links only.`);
  }

  async function loadRelationships() {
    const family = context?.families.find((item) => String(item.id) === treeFamilySelect.value);
    if (!family) return;
    statValues.forEach((value) => { value.textContent = 'â€”'; });
    relationshipsList.replaceChildren();
    const loading = document.createElement('p');
    loading.className = 'empty-state';
    loading.textContent = 'Loading family relationships...';
    relationshipsList.append(loading);
    setMemberStatus(treeStatus, 'Loading relationship records...');
    try {
      const result = await memberApiRequest(
        `relationships/list.php?family_id=${encodeURIComponent(family.id)}`
      );
      if (String(family.id) !== treeFamilySelect.value) return;
      renderRelationships(family, Array.isArray(result.relationships) ? result.relationships : []);
    } catch (error) {
      relationshipsList.replaceChildren();
      exportRows = [];
      selectedExportFamily = family;
      if (exportButton) exportButton.disabled = true;
      statValues.forEach((value) => { value.textContent = 'â€”'; });
      setMemberStatus(treeStatus, error.message, true);
    }
  }
  treeFamilySelect.addEventListener('change', loadRelationships);

  const suggestion = document.createElement('dialog');
  suggestion.className = 'card';
  suggestion.classList.add('member-dialog');
  suggestion.tabIndex = -1;
  const title = document.createElement('h2');
  title.textContent = 'Suggest a relationship';
  title.id = 'relationship-dialog-title';
  suggestion.setAttribute('aria-labelledby', title.id);
  const status = document.createElement('p');
  status.className = 'subtitle';
  status.setAttribute('role', 'status');
  const form = document.createElement('form');
  form.style.cssText = 'display:grid;gap:12px';
  const familySelect = document.createElement('select');
  familySelect.className = 'btn';
  const personSelect = document.createElement('select');
  personSelect.className = 'btn';
  const relatedSelect = document.createElement('select');
  relatedSelect.className = 'btn';
  const typeSelect = document.createElement('select');
  typeSelect.className = 'btn';
  familySelect.setAttribute('aria-label', 'Family');
  personSelect.setAttribute('aria-label', 'Person');
  relatedSelect.setAttribute('aria-label', 'Related person');
  typeSelect.setAttribute('aria-label', 'Relationship type');
  for (const [value, label] of [
    ['parent', 'Parent'],
    ['child', 'Child'],
    ['spouse', 'Spouse'],
    ['guardian', 'Guardian']
  ]) {
    const option = document.createElement('option');
    option.value = value;
    option.textContent = label;
    typeSelect.append(option);
  }
  const addField = (name, control) => {
    const label = document.createElement('label');
    label.style.cssText = 'display:grid;gap:5px;font-size:12px;font-weight:600';
    label.append(document.createTextNode(name), control);
    form.append(label);
  };
  addField('Family', familySelect);
  addField('Person', personSelect);
  addField('Related person', relatedSelect);
  addField('Relationship type', typeSelect);
  const actions = document.createElement('div');
  actions.className = 'admin-row-actions';
  const submit = document.createElement('button');
  submit.type = 'submit';
  submit.className = 'btn primary';
  submit.textContent = 'Submit proposal';
  const close = document.createElement('button');
  close.type = 'button';
  close.className = 'btn';
  close.textContent = 'Close';
  actions.append(submit, close);
  form.append(actions, status);
  suggestion.append(title, form);
  document.body.append(suggestion);
  let currentFamily;

  function populateMembers() {
    currentFamily = context.families.find((family) => String(family.id) === familySelect.value);
    const members = (currentFamily?.members || []).filter((member) => member.member_status === 'active');
    for (const select of [personSelect, relatedSelect]) {
      select.replaceChildren();
      for (const member of members) {
        const option = document.createElement('option');
        option.value = String(member.id);
        option.textContent = `${member.first_name} ${member.last_name}`;
        if (select === personSelect && Number(member.id) === Number(currentFamily?.member_id)) option.selected = true;
        select.append(option);
      }
    }
    submit.disabled = members.length < 2;
  }
  familySelect.addEventListener('change', populateMembers);
  addButton.removeAttribute('data-toast');
  addButton.addEventListener('click', async () => {
    addButton.disabled = true;
    status.textContent = 'Loading active family members...';
    try {
      context = context || await getMemberContext();
      familySelect.replaceChildren();
      for (const family of context.families) {
        const option = document.createElement('option');
        option.value = String(family.id);
        option.textContent = family.family_name;
        familySelect.append(option);
      }
      if (!context.families.length) throw new Error('No active family membership is available.');
      populateMembers();
      status.textContent = '';
      suggestion.showModal();
    } catch (error) {
      setMemberStatus(status, error.message, true);
    } finally {
      addButton.disabled = false;
    }
  });
  close.addEventListener('click', () => suggestion.close());
  form.addEventListener('submit', async (event) => {
    event.preventDefault();
    if (!currentFamily || personSelect.value === relatedSelect.value) {
      setMemberStatus(status, 'Select two different active family members.', true);
      return;
    }
    submit.disabled = true;
    submit.textContent = 'Submitting...';
    try {
      const result = await memberApiRequest('relationships/create.php', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'X-CSRF-Token': context.csrfToken
        },
        body: JSON.stringify({
          family_id: Number(currentFamily.id),
          person_id: Number(personSelect.value),
          related_person_id: Number(relatedSelect.value),
          relationship_type: typeSelect.value
        })
      });
      status.textContent = result.message || 'Relationship proposal submitted.';
      suggestion.close();
    } catch (error) {
      setMemberStatus(status, error.message, true);
    } finally {
      submit.disabled = false;
      submit.textContent = 'Submit proposal';
    }
  });

  (async () => {
    setMemberStatus(treeStatus, 'Loading family relationships...');
    try {
      context = await getMemberContext();
      treeFamilySelect.replaceChildren();
      for (const family of context.families) {
        const option = document.createElement('option');
        option.value = String(family.id);
        option.textContent = family.family_name;
        treeFamilySelect.append(option);
      }
      familyLabel.hidden = context.families.length < 2;
      if (!context.families.length) throw new Error('No active family membership is available.');
      await loadRelationships();
    } catch (error) {
      familyLabel.hidden = true;
      relationshipsList.replaceChildren();
      setMemberStatus(treeStatus, error.message, true);
    }
  })();
  if (location.hash === '#suggest-relationship') {
    addButton.click();
  }
}

function memberPermissionPage() {
  const requestButton = [...document.querySelectorAll('.page-heading button')]
    .find((button) => button.textContent.includes('Request access'));
  if (!requestButton) return;
  const cards = [...document.querySelectorAll('.grid.two > .card')];
  const requestCard = cards[0];
  const grantCard = cards[1];
  const permissionGrid = document.querySelector('.grid.two');
  const statValues = [...document.querySelectorAll('.stat-card strong')];
  statValues.forEach((value) => { value.textContent = 'â€”'; });
  const statLabels = [...document.querySelectorAll('.stat-card span:last-child')];
  if (statLabels[1]) statLabels[1].textContent = 'Approved permissions';
  if (statLabels[2]) statLabels[2].textContent = 'Sent & past requests';
  const grantsDescription = grantCard?.querySelector('.card-head p');
  if (grantsDescription) grantsDescription.textContent = 'Approved permissions recorded for your information.';
  requestCard?.querySelectorAll('.stack, article').forEach((item) => item.remove());
  grantCard?.querySelectorAll('.security-row').forEach((item) => item.remove());
  requestButton.removeAttribute('data-toast');
  requestButton.disabled = true;
  const pageStatus = document.createElement('p');
  pageStatus.className = 'subtitle';
  pageStatus.setAttribute('role', 'status');
  pageStatus.setAttribute('aria-live', 'polite');
  requestCard?.append(pageStatus);
  const pendingList = document.createElement('div');
  pendingList.className = 'stack';
  requestCard?.append(pendingList);
  const grantsStatus = document.createElement('p');
  grantsStatus.className = 'subtitle';
  grantsStatus.setAttribute('role', 'status');
  grantsStatus.setAttribute('aria-live', 'polite');
  grantCard?.append(grantsStatus);
  const grantsList = document.createElement('div');
  grantsList.className = 'stack';
  grantCard?.append(grantsList);
  const historyCard = document.createElement('section');
  historyCard.className = 'card permission-history';
  const historyTitle = document.createElement('h2');
  historyTitle.textContent = 'Requests I sent and past decisions';
  const historyStatus = document.createElement('p');
  historyStatus.className = 'subtitle';
  historyStatus.setAttribute('role', 'status');
  const historyList = document.createElement('div');
  historyList.className = 'stack';
  historyCard.append(historyTitle, historyStatus, historyList);
  permissionGrid?.after(historyCard);
  const pendingPill = requestCard?.querySelector('.pill.gold');
  const grantsPill = grantCard?.querySelector('.pill.teal');
  if (pendingPill) pendingPill.textContent = 'Loading...';
  if (grantsPill) grantsPill.textContent = 'Loading...';

  const dialog = document.createElement('dialog');
  dialog.className = 'card member-dialog';
  dialog.tabIndex = -1;
  const title = document.createElement('h2');
  title.textContent = 'Request access to family information';
  title.id = 'permission-request-dialog-title';
  dialog.setAttribute('aria-labelledby', title.id);
  const status = document.createElement('p');
  status.className = 'subtitle';
  status.setAttribute('role', 'status');
  const form = document.createElement('form');
  form.style.cssText = 'display:grid;gap:12px';
  const familySelect = document.createElement('select');
  const ownerSelect = document.createElement('select');
  const resourceSelect = document.createElement('select');
  familySelect.className = ownerSelect.className = resourceSelect.className = 'btn';
  for (const [control, label] of [
    [familySelect, 'Family'],
    [ownerSelect, 'Information owner'],
    [resourceSelect, 'Requested information']
  ]) control.setAttribute('aria-label', label);
  for (const [value, label] of [
    ['profile', 'Profile'],
    ['document', 'Document'],
    ['photo', 'Photo'],
    ['video', 'Video']
  ]) {
    const option = document.createElement('option');
    option.value = value;
    option.textContent = label;
    resourceSelect.append(option);
  }
  const purpose = document.createElement('textarea');
  purpose.maxLength = 500;
  purpose.rows = 3;
  purpose.required = true;
  purpose.placeholder = 'Explain why access is needed';
  const field = (labelText, control) => {
    const label = document.createElement('label');
    label.style.cssText = 'display:grid;gap:5px;font-size:12px;font-weight:600';
    label.append(document.createTextNode(labelText), control);
    form.append(label);
  };
  field('Family', familySelect);
  field('Information owner', ownerSelect);
  field('Requested information', resourceSelect);
  field('Purpose', purpose);
  const actions = document.createElement('div');
  actions.className = 'admin-row-actions';
  const submit = document.createElement('button');
  submit.type = 'submit';
  submit.className = 'btn primary';
  submit.textContent = 'Submit request';
  const close = document.createElement('button');
  close.type = 'button';
  close.className = 'btn';
  close.textContent = 'Close';
  actions.append(submit, close);
  form.append(actions, status);
  dialog.append(title, form);
  document.body.append(dialog);
  let context;
  let family;
  let allPermissions = [];
  const allowedRoles = new Set(['admin', 'member']);
  const canDecide = (ownerFamily) => allowedRoles.has(ownerFamily?.role);
  const apiFlag = (value) => value === true || value === 1 || value === '1' || value === 'true';

  function permissionScope(record) {
    const type = record.resource_type || 'resource';
    if (record.resource_id === null || record.resource_id === undefined) {
      return `Category-wide grant for ${type} resources; not limited to one item.`;
    }
    return `Limited to specific ${type} item #${record.resource_id}.`;
  }

  function permissionItem(record) {
    const item = document.createElement('article');
    item.className = 'member-card permission-entry';
    const details = document.createElement('div');
    details.className = 'permission-detail';
    const resource = document.createElement('strong');
    resource.textContent = record.resource_type || 'Information request';
    const participants = document.createElement('p');
    const ownerName = `${record.owner_first_name || 'Family member'} ${record.owner_last_name || ''}`.trim();
    const requesterName = `${record.requester_first_name || 'Family member'} ${record.requester_last_name || ''}`.trim();
    participants.textContent = `Owner: ${ownerName} Â· Requester: ${requesterName}`;
    const purpose = document.createElement('p');
    purpose.textContent = record.purpose ? `Purpose: ${record.purpose}` : 'No purpose provided.';
    const scope = document.createElement('p');
    scope.textContent = permissionScope(record);
    const metadata = document.createElement('small');
    metadata.textContent = `${record._isOwner ? 'Received' : 'Sent'} Â· ${record.ownerFamily.family_name} Â· ${record.status || 'unknown'} Â· ${record.created_at || 'Date unavailable'}${record.expires_at ? ` Â· Expires ${record.expires_at}` : ''}`;
    details.append(resource, participants, purpose, scope, metadata);
    item.append(details);

    const actions = document.createElement('div');
    actions.className = 'admin-row-actions permission-actions';
    const available = record._isOwner
      && apiFlag(record.can_decide)
      && Number(record.owner_member_id) === Number(record.ownerFamily.member_id);
    const decisions = record.status === 'pending'
      ? [['approved', 'Approve', 'btn small teal'], ['rejected', 'Reject', 'btn small']]
      : record.status === 'approved'
        ? [['revoked', 'Revoke', 'btn small danger']]
        : [];
    for (const [decision, label, className] of decisions) {
      if (!available) continue;
      const button = document.createElement('button');
      button.type = 'button';
      button.className = className;
      button.textContent = label;
      button.addEventListener('click', async () => {
        if (decision === 'approved' || decision === 'revoked') {
          const action = decision === 'approved' ? 'Approve' : 'Revoke';
          const confirmation = `${action} this ${record.resource_type || 'resource'} permission?\n\nScope: ${permissionScope(record)}\n\n${decision === 'approved' ? 'This will grant access according to the scope above.' : 'This will revoke the approved access.'}`;
          if (!window.confirm(confirmation)) return;
        }
        button.disabled = true;
        setMemberStatus(pageStatus, 'Saving permission decision...');
        try {
          const result = await memberApiRequest('permissions/decision.php', {
            method: 'POST',
            headers: {
              'Content-Type': 'application/json',
              'X-CSRF-Token': context.csrfToken
            },
            body: JSON.stringify({
              permission_id: Number(record.id),
              decision
            })
          });
          setMemberStatus(pageStatus, result.message || 'Permission decision recorded.');
          await loadPermissions();
        } catch (error) {
          setMemberStatus(pageStatus, error.message, true);
          button.disabled = false;
        }
      });
      actions.append(button);
    }
    if (record._isOwner && decisions.length && !available) {
      const restriction = document.createElement('small');
      restriction.textContent = 'Your role cannot decide this permission request.';
      actions.append(restriction);
    } else if (!decisions.length) {
      const state = document.createElement('span');
      state.className = 'pill blue';
      state.textContent = record.status || 'unknown';
      actions.append(state);
    }
    if (actions.childNodes.length) item.append(actions);
    return item;
  }

  function renderPermissions() {
    pendingList.replaceChildren();
    grantsList.replaceChildren();
    historyList.replaceChildren();
    const pending = allPermissions.filter((record) => record._isOwner && record.status === 'pending');
    const approved = allPermissions.filter((record) => record._isOwner && record.status === 'approved');
    const history = allPermissions.filter((record) =>
      !record._isOwner || ['rejected', 'revoked'].includes(record.status)
    );
    if (statValues[0]) statValues[0].textContent = String(pending.length);
    if (statValues[1]) statValues[1].textContent = String(approved.length);
    if (statValues[2]) statValues[2].textContent = String(history.length);
    if (pendingPill) pendingPill.textContent = `${pending.length} pending`;
    if (grantsPill) grantsPill.textContent = `${approved.length} approved`;
    for (const record of pending) pendingList.append(permissionItem(record));
    for (const record of approved) grantsList.append(permissionItem(record));
    for (const record of history) historyList.append(permissionItem(record));
    if (!pending.length) {
      const empty = document.createElement('p');
      empty.className = 'empty-state';
      empty.textContent = 'No pending requests for your information.';
      pendingList.append(empty);
    }
    if (!approved.length) {
      const empty = document.createElement('p');
      empty.className = 'empty-state';
      empty.textContent = 'You have no approved permissions.';
      grantsList.append(empty);
    }
    if (!history.length) {
      const empty = document.createElement('p');
      empty.className = 'empty-state';
      empty.textContent = 'No sent requests or past permission decisions.';
      historyList.append(empty);
    }
  }

  async function loadPermissions() {
    if (!context) return;
    setMemberStatus(pageStatus, 'Loading your permission history...');
    setMemberStatus(grantsStatus, 'Loading your approved permissions...');
    setMemberStatus(historyStatus, 'Loading sent requests and past decisions...');
    try {
      const resultSets = await Promise.all(context.families.map(async (ownerFamily) => {
        const result = await memberApiRequest(
          `permissions/list.php?family_id=${encodeURIComponent(ownerFamily.id)}`
        );
        return (Array.isArray(result.permissions) ? result.permissions : [])
          .filter((record) =>
            Number(record.family_id) === Number(ownerFamily.id)
            && (
              Number(record.owner_member_id) === Number(ownerFamily.member_id)
              || Number(record.requester_member_id) === Number(ownerFamily.member_id)
            )
          )
          .map((record) => ({
            ...record,
            ownerFamily,
            _isOwner: apiFlag(record.is_owner)
              && Number(record.owner_member_id) === Number(ownerFamily.member_id)
          }));
      }));
      allPermissions = resultSets.flat();
      renderPermissions();
      setMemberStatus(pageStatus, 'Permission history loaded for your own sent and received requests.');
      setMemberStatus(grantsStatus, 'Only approved requests owned by your signed-in family profiles are shown.');
      setMemberStatus(historyStatus, 'Sent requests and decisions on your own requests are shown.');
    } catch (error) {
      allPermissions = [];
      pendingList.replaceChildren();
      grantsList.replaceChildren();
      historyList.replaceChildren();
      setMemberStatus(pageStatus, error.message, true);
      setMemberStatus(grantsStatus, error.message, true);
      setMemberStatus(historyStatus, error.message, true);
    }
  }

  function populateOwners() {
    family = context.families.find((item) => String(item.id) === familySelect.value);
    ownerSelect.replaceChildren();
    for (const member of (family?.members || []).filter((item) =>
      item.member_status === 'active'
      && apiFlag(item.permission_owner_eligible)
      && Number(item.id) !== Number(family?.member_id)
    )) {
      const option = document.createElement('option');
      option.value = String(member.id);
      option.textContent = `${member.preferred_name || member.first_name} ${member.last_name}`.trim() || 'Family member';
      ownerSelect.append(option);
    }
    submit.disabled = !ownerSelect.options.length;
    if (!ownerSelect.options.length) {
      status.textContent = 'No other active family profile can currently receive a permission request.';
    } else {
      status.textContent = '';
    }
  }
  familySelect.addEventListener('change', populateOwners);
  requestButton.addEventListener('click', async () => {
    requestButton.disabled = true;
    status.textContent = 'Loading family members...';
    try {
    context = context || await getMemberContext();
      familySelect.replaceChildren();
    for (const item of context.families.filter(canDecide)) {
        const option = document.createElement('option');
        option.value = String(item.id);
        option.textContent = item.family_name;
        familySelect.append(option);
      }
      if (!context.families.length) throw new Error('No active family membership is available.');
      populateOwners();
      dialog.showModal();
    } catch (error) {
      setMemberStatus(status, error.message, true);
    } finally {
      requestButton.disabled = false;
    }
  });
  close.addEventListener('click', () => dialog.close());
  form.addEventListener('submit', async (event) => {
    event.preventDefault();
    if (!family || !ownerSelect.value || !purpose.value.trim()) {
      setMemberStatus(status, 'Choose an owner and provide a purpose.', true);
      return;
    }
    submit.disabled = true;
    submit.textContent = 'Submitting...';
    try {
      const result = await memberApiRequest('permissions/request.php', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'X-CSRF-Token': context.csrfToken
        },
        body: JSON.stringify({
          family_id: Number(family.id),
          owner_member_id: Number(ownerSelect.value),
          resource_type: resourceSelect.value,
          purpose: purpose.value.trim()
        })
      });
      status.textContent = result.message || 'Permission request submitted.';
      pageStatus.textContent = result.message || 'Permission request submitted.';
      form.reset();
      populateOwners();
      await loadPermissions();
    } catch (error) {
      setMemberStatus(status, error.message, true);
    } finally {
      submit.disabled = false;
      submit.textContent = 'Submit request';
    }
  });

  (async () => {
    try {
      context = await getMemberContext();
      const requestFamilies = context.families.filter(canDecide);
      requestButton.hidden = requestFamilies.length === 0;
      requestButton.disabled = requestFamilies.length === 0;
      if (!context.families.length) {
        throw new Error('No active family profile is linked to this account.');
      }
      await loadPermissions();
    } catch (error) {
      setMemberStatus(pageStatus, error.message, true);
      setMemberStatus(grantsStatus, error.message, true);
      setMemberStatus(historyStatus, error.message, true);
    }
  })();
}

function memberMediaPage(isPhotoPage) {
  const heading = document.querySelector('.page-heading');
  const uploadButton = [...document.querySelectorAll('.page-heading button')]
    .find((button) => button.textContent.includes(isPhotoPage ? 'Add media' : 'Upload document'));
  const mediaSection = [...document.querySelectorAll('.card')]
    .find((card) => card.querySelector(isPhotoPage ? '.media-tile' : '.document-row'));
  const mediaGrid = isPhotoPage
    ? mediaSection?.querySelector('.grid.three')
    : mediaSection?.querySelector('tbody');
  if (!heading || !uploadButton || !mediaSection || !mediaGrid) return;
  if (!isPhotoPage) {
    const typeHeader = mediaGrid.closest('table')?.querySelector('thead th:nth-child(2)');
    if (typeHeader) typeHeader.textContent = 'Type';
  }

  const pageStatus = document.createElement('p');
  pageStatus.className = 'subtitle';
  pageStatus.setAttribute('role', 'status');
  pageStatus.setAttribute('aria-live', 'polite');
  heading.after(pageStatus);
  const familyLabel = document.createElement('label');
  familyLabel.className = 'search';
  familyLabel.append(document.createTextNode('Profile '));
  const familySelect = document.createElement('select');
  familySelect.className = 'btn';
  familySelect.setAttribute('aria-label', 'Media family profile');
  familyLabel.append(familySelect);
  heading.querySelector('.heading-actions')?.append(familyLabel);
  const memberLabel = document.createElement('label');
  memberLabel.className = 'search';
  memberLabel.append(document.createTextNode('Member '));
  const memberSelect = document.createElement('select');
  memberSelect.className = 'btn';
  memberSelect.setAttribute('aria-label', 'Family member media');
  memberLabel.append(memberSelect);
  heading.querySelector('.heading-actions')?.append(memberLabel);

  const fileInput = document.createElement('input');
  fileInput.type = 'file';
  fileInput.hidden = true;
  fileInput.accept = isPhotoPage
    ? 'image/jpeg,image/png,image/webp,video/mp4,video/webm'
    : 'application/pdf';
  document.body.append(fileInput);
  const previewDialog = document.createElement('dialog');
  previewDialog.className = 'card member-dialog media-preview-dialog';
  previewDialog.tabIndex = -1;
  const previewTitle = document.createElement('h2');
  previewTitle.id = 'media-preview-title';
  previewDialog.setAttribute('aria-labelledby', previewTitle.id);
  const previewStatus = document.createElement('p');
  previewStatus.className = 'subtitle';
  previewStatus.setAttribute('role', 'status');
  const previewContent = document.createElement('div');
  previewContent.className = 'media-preview-content';
  const previewClose = document.createElement('button');
  previewClose.type = 'button';
  previewClose.className = 'btn';
  previewClose.textContent = 'Close preview';
  previewDialog.append(previewTitle, previewStatus, previewContent, previewClose);
  document.body.append(previewDialog);
  let previewUrl;
  function closePreview() {
    previewDialog.close();
  }
  previewClose.addEventListener('click', closePreview);
  previewDialog.addEventListener('close', () => {
    if (previewUrl) URL.revokeObjectURL(previewUrl);
    previewUrl = undefined;
    previewContent.replaceChildren();
  });
  async function openMediaPreview(item, button) {
    button.disabled = true;
    const originalText = button.textContent;
    button.textContent = 'Loading...';
    try {
      const response = await fetch(
        `${MEMBER_API_BASE}media/download.php?media_id=${encodeURIComponent(item.id)}`,
        {
          credentials: 'same-origin',
          headers: { Accept: 'application/pdf, image/jpeg, image/png, image/webp, video/mp4, video/webm, audio/mpeg, audio/mp4, audio/ogg, audio/wav, audio/webm' }
        }
      );
      if (!response.ok) {
        let message = `Could not open this media (HTTP ${response.status}).`;
        try {
          const result = await response.json();
          if (typeof result.error === 'string') message = result.error;
        } catch {}
        throw new Error(message);
      }
      const blob = await response.blob();
      const mime = (response.headers.get('Content-Type') || item.mime_type || '')
        .split(';')[0].trim().toLowerCase();
      if (!['image/jpeg', 'image/png', 'image/webp', 'application/pdf', 'video/mp4', 'video/webm', 'audio/mpeg', 'audio/mp4', 'audio/ogg', 'audio/wav', 'audio/webm'].includes(mime)) {
        throw new Error('This media type cannot be previewed.');
      }
      if (previewUrl) URL.revokeObjectURL(previewUrl);
      previewUrl = URL.createObjectURL(blob);
      previewTitle.textContent = item.original_name || 'Private media preview';
      previewStatus.textContent = '';
      previewContent.replaceChildren();
      let preview;
      if (mime.startsWith('image/')) {
        preview = document.createElement('img');
        preview.alt = item.original_name || 'Private media preview';
      } else if (mime.startsWith('video/')) {
        preview = document.createElement('video');
        preview.controls = true;
        preview.preload = 'metadata';
      } else if (mime.startsWith('audio/')) {
        preview = document.createElement('audio');
        preview.controls = true;
        preview.preload = 'metadata';
      } else {
        preview = document.createElement('iframe');
        preview.title = item.original_name || 'PDF preview';
        preview.className = 'media-pdf-preview';
      }
      preview.src = previewUrl;
      preview.classList.add('media-preview-object');
      previewContent.append(preview);
      previewDialog.showModal();
      previewDialog.focus();
    } catch (error) {
      setMemberStatus(pageStatus, error.message, true);
    } finally {
      button.disabled = false;
      button.textContent = originalText;
    }
  }
  uploadButton.removeAttribute('data-toast');
  const search = document.querySelector(
    isPhotoPage ? 'input[aria-label="Search media"]' : 'input[aria-label="Search documents"]'
  );
  if (!isPhotoPage && search) search.addEventListener('input', render);

  const typeButtons = isPhotoPage
    ? [...mediaSection.querySelectorAll('.toolbar button')]
    : [];
  let typeFilter = 'all';
  for (const button of typeButtons) {
    button.removeAttribute('data-toast');
    button.setAttribute('aria-pressed', String(button.textContent.trim().toLowerCase() === 'all media'));
    button.classList.toggle('selected', button.textContent.trim().toLowerCase() === 'all media');
    button.addEventListener('click', () => {
      typeFilter = button.textContent.trim().toLowerCase().replace(' media', '');
      typeButtons.forEach((tab) => {
        const selected = tab === button;
        tab.classList.toggle('selected', selected);
        tab.setAttribute('aria-pressed', String(selected));
      });
      render();
    });
  }

  const stats = [...document.querySelectorAll('.stat-card strong')];
  stats.forEach((value) => { value.textContent = 'â€”'; });
  const statLabels = [...document.querySelectorAll('.stat-card span:last-child')];
  if (isPhotoPage) {
    if (statLabels[2]) statLabels[2].textContent = 'Family-visible media';
    if (statLabels[3]) statLabels[3].textContent = 'Visible media size';
  } else {
    if (statLabels[0]) statLabels[0].textContent = 'Documents available';
    if (statLabels[1]) statLabels[1].textContent = 'Family-visible documents';
    if (statLabels[2]) statLabels[2].textContent = 'Private documents';
    if (statLabels[3]) statLabels[3].textContent = 'Visible document size';
  }
  if (!isPhotoPage) {
    const storageCard = [...document.querySelectorAll('.card')]
      .find((card) => card.querySelector('.progress'));
    const progress = storageCard?.querySelector('.progress span');
    if (progress) progress.style.width = '0';
    storageCard?.querySelectorAll('span').forEach((label) => {
      if (/used|of 10 GB/i.test(label.textContent)) label.textContent = 'Storage usage unavailable';
    });
  }
  const mediaMessage = document.createElement('p');
  mediaMessage.className = isPhotoPage ? 'subtitle' : '';
  mediaMessage.setAttribute('role', 'status');
  mediaSection.prepend(mediaMessage);
  let context;
  let media = [];
  let selectedFamily;
  let selectedMember;
  mediaGrid.replaceChildren();
  const initialLoading = isPhotoPage ? document.createElement('p') : document.createElement('tr');
  if (isPhotoPage) {
    initialLoading.className = 'subtitle';
    initialLoading.textContent = 'Loading available family media...';
  } else {
    const cell = document.createElement('td');
    cell.colSpan = 6;
    cell.textContent = 'Loading available family documents...';
    initialLoading.append(cell);
  }
  mediaGrid.append(initialLoading);

  function updateStats() {
    const pageItems = isPhotoPage
      ? media.filter((item) => ['photo', 'video', 'audio'].includes(item.media_type))
      : media.filter((item) => item.media_type === 'document');
    const photos = pageItems.filter((item) => item.media_type === 'photo').length;
    const videos = pageItems.filter((item) => item.media_type === 'video').length;
    const documents = pageItems.length;
    const familyVisible = pageItems.filter((item) => item.visibility === 'family').length;
    const privateItems = pageItems.filter((item) => item.visibility === 'private').length;
    const bytes = pageItems.reduce((sum, item) => sum + Number(item.file_size || 0), 0);
    if (isPhotoPage) {
      if (stats[0]) stats[0].textContent = String(photos);
      if (stats[1]) stats[1].textContent = String(videos);
      if (stats[2]) stats[2].textContent = String(familyVisible);
      if (stats[3]) stats[3].textContent = formatBytes(bytes);
    } else {
      if (stats[0]) stats[0].textContent = String(documents);
      if (stats[1]) stats[1].textContent = String(familyVisible);
      if (stats[2]) stats[2].textContent = String(privateItems);
      if (stats[3]) stats[3].textContent = formatBytes(bytes);
    }
  }

  function formatBytes(bytes) {
    if (!bytes) return '0 B';
    const units = ['B', 'KB', 'MB', 'GB'];
    let size = bytes;
    let index = 0;
    while (size >= 1024 && index < units.length - 1) {
      size /= 1024;
      index += 1;
    }
    return `${size.toFixed(index ? 1 : 0)} ${units[index]}`;
  }

  async function changeMediaVisibility(item, button) {
    const family = selectedFamily;
    if (!context || !family || !selectedMember
        || Number(selectedMember.id) !== Number(family.member_id)) return;
    const visibility = item.visibility === 'family' ? 'private' : 'family';
    const actionText = visibility === 'family'
      ? `Share “${item.original_name || 'this file'}” with all active members of ${family.family_name}?`
      : `Make “${item.original_name || 'this file'}” private to your profile? Existing approved individual permissions remain in effect.`;
    if (!window.confirm(actionText)) return;
    button.disabled = true;
    try {
      const result = await memberApiRequest('media/visibility.php', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'X-CSRF-Token': context.csrfToken
        },
        body: JSON.stringify({ media_id: Number(item.id), visibility })
      });
      item.visibility = result.visibility;
      mediaMessage.textContent = visibility === 'family'
        ? 'Media is now visible to active members of this family.'
        : 'Media is private to your profile; existing individual permissions remain active.';
      render();
    } catch (error) {
      setMemberStatus(mediaMessage, error.message, true);
      button.disabled = false;
    }
  }

  function mediaVisibilityButton(item) {
    const isOwner = selectedFamily && selectedMember
      && Number(selectedMember.id) === Number(selectedFamily.member_id);
    if (!isOwner) return null;
    const button = document.createElement('button');
    button.type = 'button';
    button.className = 'btn small';
    const makePrivate = item.visibility === 'family';
    button.textContent = makePrivate ? 'Make private' : 'Share with family';
    button.setAttribute('aria-label', `${button.textContent}: ${item.original_name || 'media file'}`);
    button.addEventListener('click', () => changeMediaVisibility(item, button));
    return button;
  }

  function render() {
    mediaGrid.replaceChildren();
    const term = search?.value.trim().toLowerCase() || '';
    const pageItems = isPhotoPage
      ? media.filter((item) => ['photo', 'video', 'audio'].includes(item.media_type))
      : media.filter((item) => item.media_type === 'document');
    const visible = pageItems.filter((item) => {
      const typeMatch = !isPhotoPage || typeFilter === 'all' || item.media_type === typeFilter.replace(/s$/, '');
      return typeMatch && `${item.original_name} ${item.media_type} ${item.visibility}`.toLowerCase().includes(term);
    });
    if (!visible.length) {
      const empty = isPhotoPage ? document.createElement('p') : document.createElement('tr');
      if (isPhotoPage) {
        empty.className = 'subtitle';
        empty.textContent = pageItems.length ? 'No media matches this filter.' : 'No media is available in this section.';
      } else {
        const cell = document.createElement('td');
        cell.colSpan = 6;
        cell.textContent = pageItems.length ? 'No documents match this search.' : 'No documents are available to this account.';
        empty.append(cell);
      }
      mediaGrid.append(empty);
      return;
    }
    for (const item of visible) {
      if (isPhotoPage) {
        const tile = document.createElement('article');
        tile.className = 'media-tile';
        const thumb = document.createElement('div');
        thumb.className = 'media-thumb';
        const icon = document.createElement('span');
        icon.className = 'material-symbols-outlined';
        icon.textContent = item.media_type === 'video' ? 'videocam' : item.media_type === 'audio' ? 'graphic_eq' : 'photo_camera';
        thumb.append(icon);
        const name = document.createElement('h3');
        name.textContent = item.original_name || 'Private media';
        const details = document.createElement('p');
        details.textContent = `${item.media_type} Â· ${formatBytes(Number(item.file_size || 0))} Â· ${item.created_at || 'Date unavailable'}`;
        const visibility = document.createElement('span');
        visibility.className = `pill ${item.visibility === 'family' ? 'teal' : 'blue'}`;
        visibility.textContent = item.visibility || 'private';
        const visibilityButton = mediaVisibilityButton(item);
        const preview = document.createElement('button');
        preview.type = 'button';
        preview.className = 'btn small media-open';
        preview.textContent = 'Preview';
        preview.setAttribute('aria-label', `Preview ${item.original_name || 'private media'}`);
        preview.addEventListener('click', () => openMediaPreview(item, preview));
        tile.append(thumb, name, details, visibility);
        if (visibilityButton) tile.append(visibilityButton);
        tile.append(preview);
        mediaGrid.append(tile);
      } else {
        const row = document.createElement('tr');
        row.className = 'document-row';
        const fileCell = document.createElement('td');
        const info = document.createElement('div');
        info.className = 'doc-info';
        const icon = document.createElement('span');
        icon.className = 'document-icon material-symbols-outlined';
        icon.textContent = 'description';
        const text = document.createElement('span');
        const name = document.createElement('strong');
        name.textContent = item.original_name || 'Private document';
        const meta = document.createElement('small');
        meta.textContent = `${item.mime_type || 'File'} Â· ${formatBytes(Number(item.file_size || 0))}`;
        text.append(name, meta);
        info.append(icon, text);
        fileCell.append(info);
        row.append(fileCell);
        for (const value of [
          item.media_type || 'â€”',
          item.created_at || 'â€”',
          item.visibility || 'private',
          'Stored'
        ]) {
          const cell = document.createElement('td');
          cell.textContent = value;
          row.append(cell);
        }
        const actionCell = document.createElement('td');
        const visibilityButton = mediaVisibilityButton(item);
        if (visibilityButton) actionCell.append(visibilityButton);
        const preview = document.createElement('button');
        preview.type = 'button';
        preview.className = 'btn small';
        preview.textContent = 'View';
        preview.setAttribute('aria-label', `Preview ${item.original_name || 'private document'}`);
        preview.addEventListener('click', () => openMediaPreview(item, preview));
        actionCell.append(preview);
        row.append(actionCell);
        mediaGrid.append(row);
      }
    }
  }

  async function loadMedia() {
    selectedFamily = context.families.find((family) => String(family.id) === familySelect.value);
    const requestedFamily = selectedFamily;
    const requestedMember = requestedFamily?.members?.find((member) =>
      String(member.id) === memberSelect.value && member.member_status === 'active'
    );
    if (!requestedFamily || !requestedMember) {
      selectedMember = undefined;
      uploadButton.disabled = true;
      media = [];
      updateStats();
      render();
      setMemberStatus(mediaMessage, 'No media is shared with this account.');
      return;
    }
    selectedMember = requestedMember;
    const isOwnProfile = Number(requestedMember.id) === Number(requestedFamily.member_id);
    uploadButton.disabled = !isOwnProfile;
    uploadButton.title = isOwnProfile ? '' : 'Uploads are available only for your own family profile.';
    mediaGrid.replaceChildren();
    const loading = isPhotoPage ? document.createElement('p') : document.createElement('tr');
    if (isPhotoPage) {
      loading.className = 'subtitle';
      loading.textContent = 'Loading available family media...';
    } else {
      const cell = document.createElement('td');
      cell.colSpan = 6;
      cell.textContent = 'Loading available family documents...';
      loading.append(cell);
    }
    mediaGrid.append(loading);
    try {
      const result = await memberApiRequest(
        `media/list.php?member_id=${encodeURIComponent(requestedMember.id)}`
      );
      if (String(requestedFamily.id) !== familySelect.value
          || String(requestedMember.id) !== memberSelect.value) return;
      media = Array.isArray(result.media) ? result.media : [];
      updateStats();
      mediaMessage.textContent = `Showing media available to ${requestedMember.first_name} ${requestedMember.last_name} in ${requestedFamily.family_name}.`;
      render();
    } catch (error) {
      if (String(requestedFamily.id) !== familySelect.value
          || String(requestedMember.id) !== memberSelect.value) return;
      media = [];
      updateStats();
      mediaMessage.textContent = error.message;
      setMemberStatus(mediaMessage, error.message, true);
      mediaGrid.replaceChildren();
      if (isPhotoPage) {
        const errorMessage = document.createElement('p');
        errorMessage.className = 'subtitle';
        errorMessage.textContent = error.message;
        mediaGrid.append(errorMessage);
      } else {
        const row = document.createElement('tr');
        const cell = document.createElement('td');
        cell.colSpan = 6;
        cell.textContent = error.message;
        row.append(cell);
        mediaGrid.append(row);
      }
    }
  }

  function populateMemberSelect() {
    selectedFamily = context.families.find((family) => String(family.id) === familySelect.value);
    const members = (selectedFamily?.members || [])
      .filter((member) => member.member_status === 'active');
    memberSelect.replaceChildren();
    for (const member of members) {
      const option = document.createElement('option');
      option.value = String(member.id);
      option.textContent = `${member.first_name || ''} ${member.last_name || ''}`.trim() || 'Family member';
      memberSelect.append(option);
    }
    if (selectedFamily && members.some((member) =>
      String(member.id) === String(selectedFamily.member_id)
    )) {
      memberSelect.value = String(selectedFamily.member_id);
    }
    memberLabel.hidden = members.length < 2;
    if (!members.length) selectedMember = undefined;
  }

  familySelect.addEventListener('change', () => {
    populateMemberSelect();
    loadMedia();
  });
  memberSelect.addEventListener('change', loadMedia);
  uploadButton.addEventListener('click', () => fileInput.click());
  fileInput.addEventListener('change', async () => {
    const file = fileInput.files?.[0];
    if (!file || !selectedFamily || !selectedMember || !context
        || Number(selectedMember.id) !== Number(selectedFamily.member_id)) return;
    uploadButton.disabled = true;
    const originalText = uploadButton.textContent.trim();
    uploadButton.textContent = 'Uploading...';
    try {
      const body = new FormData();
      body.append('member_id', String(selectedFamily.member_id));
      body.append('file', file);
      const result = await memberApiRequest('media/upload.php', {
        method: 'POST',
        headers: { 'X-CSRF-Token': context.csrfToken },
        body
      });
      pageStatus.textContent = `Upload saved as ${result.media_type || 'media'}.`;
      fileInput.value = '';
      await loadMedia();
    } catch (error) {
      setMemberStatus(pageStatus, error.message, true);
    } finally {
      uploadButton.disabled = false;
      uploadButton.textContent = originalText;
    }
  });
  (async () => {
    uploadButton.disabled = true;
    try {
      context = await getMemberContext();
      familySelect.replaceChildren();
      for (const family of context.families) {
        const option = document.createElement('option');
        option.value = String(family.id);
        option.textContent = family.family_name;
        familySelect.append(option);
      }
      if (!context.families.length) throw new Error('No active family profile is linked to this account.');
      familyLabel.hidden = context.families.length < 2;
      populateMemberSelect();
      await loadMedia();
    } catch (error) {
      setMemberStatus(pageStatus, error.message, true);
      mediaGrid.replaceChildren();
      uploadButton.disabled = true;
    }
  })();
}

function memberSecurityPage() {
  const passwordChangeButton = [...document.querySelectorAll('.page-wrap button[data-toast]')]
    .find((button) => button.textContent.trim() === 'Change');
  if (passwordChangeButton) {
    passwordChangeButton.removeAttribute('data-toast');
    const dialog = document.createElement('dialog');
    dialog.className = 'member-dialog';
    dialog.setAttribute('aria-labelledby', 'passwordChangeTitle');
    const form = document.createElement('form');
    form.style.cssText = 'display:grid;gap:12px;min-width:0';
    const title = document.createElement('h2');
    title.id = 'passwordChangeTitle';
    title.textContent = 'Change password';
    const guidance = document.createElement('p');
    guidance.className = 'subtitle';
    guidance.textContent = 'Enter your current password, then choose a strong password you have not used before.';
    const status = document.createElement('p');
    status.className = 'subtitle';
    status.setAttribute('role', 'status');
    status.setAttribute('aria-live', 'polite');
    status.hidden = true;
    const fields = [
      ['Current password', 'current_password', 'current-password'],
      ['New password', 'new_password', 'new-password'],
      ['Confirm new password', 'confirm_password', 'new-password']
    ].map(([labelText, name, autocomplete]) => {
      const label = document.createElement('label');
      label.className = 'field';
      label.style.cssText = 'display:grid;gap:5px;color:var(--muted);font-size:11px;font-weight:600';
      label.append(document.createTextNode(labelText));
      const input = document.createElement('input');
      input.type = 'password';
      input.className = 'field-value';
      input.name = name;
      input.autocomplete = autocomplete;
      input.required = true;
      input.maxLength = 1024;
      if (name === 'new_password') input.minLength = 12;
      label.append(input);
      form.append(label);
      return input;
    });
    const actions = document.createElement('div');
    actions.className = 'heading-actions';
    const cancel = document.createElement('button');
    cancel.type = 'button';
    cancel.className = 'btn';
    cancel.textContent = 'Cancel';
    cancel.addEventListener('click', () => dialog.close());
    const submit = document.createElement('button');
    submit.type = 'submit';
    submit.className = 'btn primary';
    submit.textContent = 'Update password';
    actions.append(cancel, submit);
    form.prepend(title, guidance);
    form.append(status, actions);
    dialog.append(form);
    document.body.append(dialog);
    passwordChangeButton.addEventListener('click', () => {
      status.hidden = true;
      form.reset();
      dialog.showModal();
      fields[0].focus();
    });
    form.addEventListener('submit', async (event) => {
      event.preventDefault();
      status.hidden = false;
      status.removeAttribute('role');
      status.textContent = 'Updating passwordâ€¦';
      submit.disabled = true;
      try {
        const [currentPassword, newPassword, confirmation] = fields.map((field) => field.value);
        if (newPassword !== confirmation) {
          throw new Error('New password confirmation does not match.');
        }
        const auth = await memberApiRequest('auth/me.php');
        if (typeof auth.csrf_token !== 'string' || auth.csrf_token.length < 32) {
          throw new Error('A valid security token is unavailable. Refresh and try again.');
        }
        const result = await memberApiRequest('password/change.php', {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            'X-CSRF-Token': auth.csrf_token
          },
          body: JSON.stringify({
            current_password: currentPassword,
            new_password: newPassword,
            confirm_password: confirmation
          })
        });
        fields.forEach((field) => { field.value = ''; });
        status.setAttribute('role', 'status');
        status.textContent = result.message || 'Password changed successfully.';
      } catch (error) {
        status.setAttribute('role', 'alert');
        status.textContent = error instanceof Error ? error.message : 'Could not change password.';
      } finally {
        submit.disabled = false;
      }
    });
  }
  document.querySelectorAll('.page-wrap button[data-toast]').forEach((button) => {
    const label = button.textContent.trim();
    if (label.startsWith('View all activity')) {
      button.removeAttribute('data-toast');
      button.title = 'Open paginated successful sign-in history';
      const dialog = document.createElement('dialog');
      dialog.className = 'member-dialog';
      dialog.setAttribute('aria-labelledby', 'signInHistoryTitle');
      const title = document.createElement('h2');
      title.id = 'signInHistoryTitle';
      title.textContent = 'Successful sign-in history';
      const status = document.createElement('p');
      status.className = 'subtitle';
      status.setAttribute('role', 'status');
      status.setAttribute('aria-live', 'polite');
      const list = document.createElement('div');
      list.className = 'stack';
      const actions = document.createElement('div');
      actions.className = 'heading-actions';
      const more = document.createElement('button');
      more.type = 'button';
      more.className = 'btn';
      more.textContent = 'Load older sign-ins';
      more.hidden = true;
      const close = document.createElement('button');
      close.type = 'button';
      close.className = 'btn primary';
      close.textContent = 'Close';
      actions.append(more, close);
      dialog.append(title, status, list, actions);
      document.body.append(dialog);
      let cursor = null;
      let requestSequence = 0;
      async function loadHistory(append = false) {
        const sequence = ++requestSequence;
        if (!append) {
          cursor = null;
          list.replaceChildren();
        }
        status.textContent = 'Loading successful sign-ins...';
        status.setAttribute('role', 'status');
        more.disabled = true;
        try {
          const params = new URLSearchParams({ limit: '25' });
          if (append && cursor) params.set('before_id', cursor);
          const result = await memberApiRequest(`auth/activity.php?${params.toString()}`);
          if (sequence !== requestSequence) return;
          const entries = Array.isArray(result.sign_ins) ? result.sign_ins : [];
          for (const entry of entries) {
            const row = document.createElement('div');
            row.className = 'security-row';
            const details = document.createElement('span');
            const heading = document.createElement('strong');
            heading.textContent = 'Successful sign-in';
            const time = document.createElement('p');
            const parsed = new Date(String(entry.created_at || '').replace(' ', 'T'));
            time.textContent = Number.isNaN(parsed.getTime())
              ? String(entry.created_at || 'Time unavailable')
              : new Intl.DateTimeFormat(undefined, { dateStyle: 'medium', timeStyle: 'short' }).format(parsed);
            details.append(heading, time);
            row.append(details);
            list.append(row);
          }
          cursor = result.next_cursor ? String(result.next_cursor) : null;
          more.hidden = result.has_more !== true;
          status.textContent = entries.length
            ? 'Only sign-in timestamps are retained; device and location details are not collected.'
            : (list.childElementCount ? 'No older sign-ins are available.' : 'No successful sign-ins are recorded.');
        } catch (error) {
          if (sequence !== requestSequence) return;
          status.textContent = `Sign-in history is unavailable: ${error.message}`;
          status.setAttribute('role', 'alert');
        } finally {
          more.disabled = false;
        }
      }
      more.addEventListener('click', () => loadHistory(true));
      close.addEventListener('click', () => dialog.close());
      button.addEventListener('click', () => {
        dialog.showModal();
        loadHistory(false);
      });
      return;
    }
    if (label === 'Sign out' || label === 'Logout' || label === 'Log out') {
      button.removeAttribute('data-toast');
      button.addEventListener('click', async () => {
        button.disabled = true;
        let resultMessage;
        let errorStatus = button.parentElement?.querySelector('[data-logout-status]');
        if (!errorStatus) {
          errorStatus = document.createElement('p');
          errorStatus.className = 'subtitle';
          errorStatus.dataset.logoutStatus = 'true';
          errorStatus.setAttribute('role', 'status');
          errorStatus.setAttribute('aria-live', 'polite');
          button.parentElement?.append(errorStatus);
        }
        setMemberStatus(errorStatus, 'Signing out...');
        try {
          const auth = await memberApiRequest('auth/me.php');
          if (typeof auth.csrf_token !== 'string' || auth.csrf_token.length < 32) {
            throw new Error('A valid security token is unavailable. Refresh and try signing out again.');
          }
          const result = await memberApiRequest('auth/logout.php', {
            method: 'POST',
            headers: {
              'Content-Type': 'application/json',
              'X-CSRF-Token': auth.csrf_token
            },
            body: JSON.stringify({})
          });
          resultMessage = result.message;
          if (resultMessage !== 'Logged out') {
            throw new Error('The server did not confirm sign-out. Please try again.');
          }
          window.location.assign('../super%20admin/login.php');
        } catch (error) {
          setMemberStatus(errorStatus, `${error.message} Your session remains on this page.`, true);
          button.disabled = false;
        }
      });
      return;
    }
  });
  const activitySection = [...document.querySelectorAll('.card')]
    .find((card) => card.querySelector('h2')?.textContent.trim() === 'Recent sign-in activity');
  if (activitySection) {
    const activityHeader = activitySection.querySelector('.card-head') || activitySection;
    const revokeButton = document.createElement('button');
    revokeButton.type = 'button';
    revokeButton.className = 'btn small danger';
    revokeButton.textContent = 'Sign out other sessions';
    revokeButton.title = 'End all other active sessions while keeping this session signed in';
    activityHeader.append(revokeButton);
    const revokeStatus = document.createElement('p');
    revokeStatus.className = 'subtitle';
    revokeStatus.dataset.sessionRevokeStatus = 'true';
    revokeStatus.setAttribute('role', 'status');
    revokeStatus.setAttribute('aria-live', 'polite');
    activitySection.append(revokeStatus);
    revokeButton.addEventListener('click', async () => {
      if (!window.confirm('Sign out all other active sessions? This current session will remain signed in.')) return;
      revokeButton.disabled = true;
      revokeStatus.setAttribute('role', 'status');
      revokeStatus.textContent = 'Signing out other sessions...';
      try {
        const auth = await memberApiRequest('auth/me.php');
        if (typeof auth.csrf_token !== 'string' || auth.csrf_token.length < 32) {
          throw new Error('A valid security token is unavailable. Refresh and try again.');
        }
        const result = await memberApiRequest('auth/revoke_other_sessions.php', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json', 'X-CSRF-Token': auth.csrf_token },
          body: JSON.stringify({})
        });
        revokeStatus.textContent = result.message || 'Other sessions were signed out.';
      } catch (error) {
        revokeStatus.textContent = `Could not sign out other sessions: ${error.message}`;
        revokeStatus.setAttribute('role', 'alert');
      } finally {
        revokeButton.disabled = false;
      }
    });
  }
  const pageBanner = document.querySelector('.page-wrap > .banner');
  const bannerHeading = pageBanner?.querySelector('h2');
  const bannerDescription = pageBanner?.querySelector('p');
  if (bannerHeading) bannerHeading.textContent = 'Account security overview';
  if (bannerDescription) bannerDescription.textContent = 'Review sign-in security, manage authenticator verification, change your password, and sign out other sessions.';
  const bannerPill = pageBanner?.querySelector('.pill');
  if (bannerPill) bannerPill.textContent = 'Core controls available';
  if (activitySection) {
    activitySection.querySelectorAll('.security-row').forEach((row) => row.remove());
    let status = activitySection.querySelector('[data-signin-history-status]');
    if (!status) {
      status = document.createElement('p');
      status.className = 'subtitle';
      status.dataset.signinHistoryStatus = 'true';
      status.setAttribute('role', 'status');
      activitySection.append(status);
    }
    status.textContent = 'Loading recent successful sign-ins...';
    memberApiRequest('auth/activity.php').then((result) => {
      const events = Array.isArray(result.sign_ins) ? result.sign_ins : [];
      activitySection.querySelectorAll('.security-row').forEach((row) => row.remove());
      if (!events.length) {
        status.textContent = 'No successful sign-ins are available in the audit history yet.';
        return;
      }
      status.textContent = 'Only sign-in time is recorded; device and location details are not collected.';
      for (const event of events) {
        const row = document.createElement('div');
        row.className = 'security-row';
        const details = document.createElement('span');
        const heading = document.createElement('strong');
        heading.textContent = 'Successful sign-in';
        const time = document.createElement('p');
        const parsed = new Date(String(event.created_at || '').replace(' ', 'T'));
        time.textContent = Number.isNaN(parsed.getTime())
          ? String(event.created_at || 'Time unavailable')
          : new Intl.DateTimeFormat(undefined, { dateStyle: 'medium', timeStyle: 'short' }).format(parsed);
        details.append(heading, time);
        row.append(details);
        activitySection.insertBefore(row, status);
      }
    }).catch((error) => {
      status.textContent = `Sign-in history is unavailable: ${error.message}`;
      status.setAttribute('role', 'alert');
    });
  }
  const checklist = [...document.querySelectorAll('.card')]
    .find((card) => card.querySelector('h2')?.textContent.trim() === 'Security checklist');
  let mfaRow;
  let mfaDescription;
  let mfaBadge;
  let mfaControl;
  let mfaEnabled = false;
  const mfaDialog = document.createElement('dialog');
  mfaDialog.className = 'member-dialog';
  mfaDialog.setAttribute('aria-labelledby', 'mfaDialogTitle');
  const mfaForm = document.createElement('form');
  mfaForm.style.cssText = 'display:grid;gap:12px;min-width:min(420px,80vw)';
  const mfaTitle = document.createElement('h2');
  mfaTitle.id = 'mfaDialogTitle';
  const mfaGuidance = document.createElement('p');
  mfaGuidance.className = 'subtitle';
  const mfaPasswordLabel = document.createElement('label');
  mfaPasswordLabel.className = 'field';
  mfaPasswordLabel.append(document.createTextNode('Current password'));
  const mfaPassword = document.createElement('input');
  mfaPassword.type = 'password';
  mfaPassword.className = 'field-value';
  mfaPassword.autocomplete = 'current-password';
  mfaPassword.required = true;
  mfaPassword.maxLength = 1024;
  mfaPasswordLabel.append(mfaPassword);
  const mfaSecretPanel = document.createElement('div');
  mfaSecretPanel.hidden = true;
  const mfaSecretLabel = document.createElement('p');
  mfaSecretLabel.textContent = 'Add this private setup key to your authenticator app:';
  const mfaSecret = document.createElement('code');
  mfaSecret.style.cssText = 'display:block;overflow-wrap:anywhere;padding:10px;background:var(--surface);border-radius:8px';
  mfaSecretPanel.append(mfaSecretLabel, mfaSecret);
  const mfaCodeLabel = document.createElement('label');
  mfaCodeLabel.className = 'field';
  mfaCodeLabel.append(document.createTextNode('Six-digit authenticator code'));
  const mfaCode = document.createElement('input');
  mfaCode.type = 'text';
  mfaCode.className = 'field-value';
  mfaCode.inputMode = 'numeric';
  mfaCode.autocomplete = 'one-time-code';
  mfaCode.pattern = '[0-9]{6}';
  mfaCode.maxLength = 6;
  mfaCode.required = true;
  mfaCodeLabel.append(mfaCode);
  mfaCodeLabel.hidden = true;
  const mfaStatus = document.createElement('p');
  mfaStatus.className = 'subtitle';
  mfaStatus.setAttribute('role', 'status');
  mfaStatus.setAttribute('aria-live', 'polite');
  const mfaActions = document.createElement('div');
  mfaActions.className = 'heading-actions';
  const mfaCancel = document.createElement('button');
  mfaCancel.type = 'button';
  mfaCancel.className = 'btn';
  mfaCancel.textContent = 'Cancel';
  const mfaSubmit = document.createElement('button');
  mfaSubmit.type = 'submit';
  mfaSubmit.className = 'btn primary';
  mfaActions.append(mfaCancel, mfaSubmit);
  mfaForm.append(mfaTitle, mfaGuidance, mfaPasswordLabel, mfaSecretPanel,
    mfaCodeLabel, mfaStatus, mfaActions);
  mfaDialog.append(mfaForm);
  document.body.append(mfaDialog);
  mfaDialog.addEventListener('close', () => {
    mfaSecret.textContent = '';
    mfaPassword.value = '';
    mfaCode.value = '';
  });
  mfaCancel.addEventListener('click', () => mfaDialog.close());

  async function openMfaDialog(disableMfa) {
    mfaForm.reset();
    mfaSecret.textContent = '';
    mfaSecretPanel.hidden = true;
    mfaCodeLabel.hidden = disableMfa;
    mfaPasswordLabel.hidden = false;
    mfaPassword.required = true;
    mfaStatus.textContent = '';
    mfaStatus.setAttribute('role', 'status');
    mfaTitle.textContent = disableMfa ? 'Disable authenticator verification' : 'Set up authenticator verification';
    mfaGuidance.textContent = disableMfa
      ? 'Confirm your current password and a current authenticator code to disable this sign-in protection.'
      : 'Confirm your current password, then add the setup key to an authenticator app and verify its code.';
    mfaSubmit.textContent = disableMfa ? 'Disable multi-factor authentication' : 'Continue setup';
    mfaDialog.dataset.mode = disableMfa ? 'disable' : 'setup';
    mfaDialog.dataset.pending = 'false';
    mfaDialog.showModal();
    mfaPassword.focus();
  }

  async function updateMfaStatus(enabled) {
    mfaEnabled = Boolean(enabled);
    if (!checklist) return;
    if (!mfaRow) {
      mfaRow = document.createElement('div');
      mfaRow.className = 'security-row';
      const details = document.createElement('span');
      const heading = document.createElement('strong');
      heading.textContent = 'Multi-factor authentication';
      mfaDescription = document.createElement('p');
      details.append(heading, mfaDescription);
      mfaBadge = document.createElement('span');
      mfaBadge.className = 'pill';
      mfaControl = document.createElement('button');
      mfaControl.type = 'button';
      mfaControl.className = 'btn small';
      mfaControl.addEventListener('click', () => openMfaDialog(mfaEnabled));
      mfaRow.append(details, mfaBadge, mfaControl);
      checklist.append(mfaRow);
    }
    mfaDescription.textContent = mfaEnabled
      ? 'Authenticator app verification is required at sign-in.'
      : 'Add an authenticator app as a second sign-in step.';
    mfaBadge.textContent = mfaEnabled ? 'Enabled' : 'Not enabled';
    mfaBadge.className = `pill ${mfaEnabled ? 'teal' : 'blue'}`;
    mfaControl.textContent = mfaEnabled ? 'Disable' : 'Set up';
  }

  mfaForm.addEventListener('submit', async (event) => {
    event.preventDefault();
    mfaSubmit.disabled = true;
    mfaStatus.textContent = 'Updating authenticator settings...';
    mfaStatus.setAttribute('role', 'status');
    try {
      const auth = await memberApiRequest('auth/me.php');
      if (typeof auth.csrf_token !== 'string' || auth.csrf_token.length < 32) {
        throw new Error('A valid security token is unavailable. Refresh and try again.');
      }
      const mode = mfaDialog.dataset.mode;
      const pending = mfaDialog.dataset.pending === 'true';
      let result;
      if (mode === 'disable') {
        result = await memberApiRequest('auth/mfa/disable.php', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json', 'X-CSRF-Token': auth.csrf_token },
          body: JSON.stringify({ current_password: mfaPassword.value, code: mfaCode.value.trim() })
        });
      } else if (!pending) {
        result = await memberApiRequest('auth/mfa/setup.php', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json', 'X-CSRF-Token': auth.csrf_token },
          body: JSON.stringify({ current_password: mfaPassword.value })
        });
        mfaSecret.textContent = result.secret;
        mfaPassword.value = '';
        mfaPasswordLabel.hidden = true;
        mfaPassword.required = false;
        mfaSecretPanel.hidden = false;
        mfaCodeLabel.hidden = false;
        mfaDialog.dataset.pending = 'true';
        mfaSubmit.textContent = 'Confirm setup';
        mfaStatus.textContent = 'Enter the current code from your authenticator app to finish setup.';
        mfaSubmit.disabled = false;
        mfaCode.focus();
        return;
      } else {
        result = await memberApiRequest('auth/mfa/confirm.php', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json', 'X-CSRF-Token': auth.csrf_token },
          body: JSON.stringify({ code: mfaCode.value.trim() })
        });
      }
      mfaSecret.textContent = '';
      mfaPassword.value = '';
      mfaCode.value = '';
      const refreshed = await memberApiRequest('auth/me.php');
      await updateMfaStatus(refreshed.user?.mfa_enabled === true);
      mfaStatus.textContent = result.message || 'Authenticator settings updated.';
      mfaDialog.close();
    } catch (error) {
      mfaStatus.textContent = error.message;
      mfaStatus.setAttribute('role', 'alert');
      mfaCode.value = '';
    } finally {
      mfaSubmit.disabled = false;
    }
  });

  if (checklist) {
    checklist.querySelectorAll('.security-row').forEach((row) => row.remove());
    const status = document.createElement('p');
    status.className = 'subtitle';
    status.setAttribute('role', 'status');
    status.textContent = 'Loading account security settings...';
    checklist.append(status);
    memberApiRequest('auth/me.php').then((auth) => {
      status.remove();
      const addSecurityRow = (headingText, descriptionText, badgeText) => {
        const row = document.createElement('div');
        row.className = 'security-row';
        const details = document.createElement('span');
        const heading = document.createElement('strong');
        heading.textContent = headingText;
        const description = document.createElement('p');
        description.textContent = descriptionText;
        details.append(heading, description);
        const badge = document.createElement('span');
        badge.className = 'pill';
        badge.textContent = badgeText;
        row.append(details, badge);
        checklist.append(row);
      };
      const user = auth.user || {};
      addSecurityRow(
        'Email address verification',
        user.email_verified_at ? 'The account email is verified.' : 'Verify the account email to protect account recovery.',
        user.email_verified_at ? 'Verified' : 'Needs attention'
      );
      addSecurityRow(
        'Password policy',
        'Password changes require your current password and a 12-character minimum with mixed character types.',
        'Enforced on change'
      );
      updateMfaStatus(user.mfa_enabled === true);
    }).catch((error) => {
      status.textContent = `Account security settings are unavailable: ${error.message}`;
      status.setAttribute('role', 'alert');
    });
  }
  const preferences = [...document.querySelectorAll('.card')]
    .find((card) => card.querySelector('h2')?.textContent.trim() === 'Privacy controls');
  if (preferences) {
    preferences.querySelectorAll('.security-row').forEach((row) => row.remove());
    const note = document.createElement('p');
    note.className = 'subtitle';
    note.textContent = 'Your visibility and active grants are shown in Access Permissions. Identity documents remain private and are never displayed here.';
    preferences.append(note);
  }
}

if (location.pathname.endsWith('/my-profile.html')) {
  memberProfilePage();
}
if (location.pathname.endsWith('/my-family.html')) {
  memberFamilyDirectoryPage();
}
if (location.pathname.endsWith('/family-tree.html')) {
  memberRelationshipPage();
}
if (location.pathname.endsWith('/access-permissions.html')) {
  memberPermissionPage();
}
if (location.pathname.endsWith('/photos-and-videos.html')) {
  memberMediaPage(true);
}
if (location.pathname.endsWith('/documents-and-records.html')) {
  memberMediaPage(false);
}
if (location.pathname.endsWith('/security-center.html')) {
  memberSecurityPage();
}

function initializeMemberNotifications() {
  const button = document.querySelector('.top-actions button[aria-label="Notifications"]');
  if (!button) return;
  button.removeAttribute('data-toast');
  button.title = 'Open family action items';

  const badge = document.createElement('span');
  badge.hidden = true;
  badge.style.cssText = 'position:absolute;top:-3px;right:-3px;min-width:16px;padding:1px 4px;border-radius:999px;background:#b42318;color:#fff;font-size:10px;line-height:14px;text-align:center';
  button.style.position = 'relative';
  button.append(badge);

  const dialog = document.createElement('dialog');
  dialog.className = 'member-dialog';
  dialog.setAttribute('aria-labelledby', 'member-notification-title');
  const heading = document.createElement('h2');
  heading.id = 'member-notification-title';
  heading.textContent = 'Family action items';
  const familySelect = document.createElement('select');
  familySelect.className = 'field-value';
  familySelect.setAttribute('aria-label', 'Notification family');
  const status = document.createElement('p');
  status.className = 'subtitle';
  status.setAttribute('role', 'status');
  const list = document.createElement('div');
  list.className = 'stack';
  const close = document.createElement('button');
  close.type = 'button';
  close.className = 'btn';
  close.textContent = 'Close';
  close.addEventListener('click', () => dialog.close());
  dialog.append(heading, familySelect, status, list, close);
  document.body.append(dialog);

  async function loadItems() {
    const familyId = familySelect.value;
    list.replaceChildren();
    badge.hidden = true;
    status.setAttribute('role', 'status');
    status.textContent = 'Loading family action items...';
    if (!familyId) {
      status.textContent = 'No active family is available for this account.';
      return;
    }
    try {
      const result = await memberApiRequest(`family/notifications.php?family_id=${encodeURIComponent(familyId)}`);
      const total = Number(result.total) || 0;
      badge.textContent = total > 99 ? '99+' : String(total);
      badge.hidden = total === 0;
      button.setAttribute('aria-label', total ? `Notifications, ${total} family action items` : 'Notifications, no family action items');
      if (!result.items?.length) {
        status.textContent = 'No access requests are waiting for your decision.';
        return;
      }
      status.textContent = `${total} item${total === 1 ? '' : 's'} need your review.`;
      for (const item of result.items) {
        if (item.url !== 'access-permissions.html') continue;
        const link = document.createElement('a');
        link.className = 'btn';
        link.href = item.url;
        link.textContent = `${item.title} (${Number(item.count) || 0})`;
        link.style.cssText = 'display:block;margin:6px 0;text-decoration:none';
        list.append(link);
      }
    } catch (error) {
      status.textContent = `Family action items are unavailable: ${error.message}`;
      status.setAttribute('role', 'alert');
    }
  }

  familySelect.addEventListener('change', loadItems);
  button.addEventListener('click', async () => {
    if (!familySelect.options.length) {
      status.textContent = 'Loading your authorized families...';
      dialog.showModal();
      try {
        const result = await memberApiRequest('family/my_family.php');
        for (const family of result.families || []) {
          if (!['admin', 'member', 'viewer'].includes(family.role)) continue;
          const option = document.createElement('option');
          option.value = String(family.id);
          option.textContent = family.family_name;
          familySelect.append(option);
        }
      } catch (error) {
        status.textContent = `Family list is unavailable: ${error.message}`;
        status.setAttribute('role', 'alert');
        return;
      }
    } else {
      dialog.showModal();
    }
    await loadItems();
  });
}

initializeMemberNotifications();
loadMemberIdentity();
