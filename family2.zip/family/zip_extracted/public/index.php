<?php
declare(strict_types=1);
require_once __DIR__ . '/../src/bootstrap.php';

header('Cache-Control: no-store');
JsonResponse::ok([
    'app' => $config['app_name'],
    'status' => 'online',
    'csrf_token' => Security::csrfToken(),
]);
