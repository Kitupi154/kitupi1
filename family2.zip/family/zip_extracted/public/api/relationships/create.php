<?php
declare(strict_types=1);

require_once __DIR__ . '/../../../src/bootstrap.php';

if (($_SERVER['REQUEST_METHOD'] ?? '') !== 'POST') {
    header('Allow: POST');
    JsonResponse::error('Method not allowed', 405);
}

Security::requireCsrf();
$data = JsonResponse::input();
$familyId = filter_var($data['family_id'] ?? null, FILTER_VALIDATE_INT);
$personId = filter_var($data['person_id'] ?? null, FILTER_VALIDATE_INT);
$relatedId = filter_var($data['related_person_id'] ?? null, FILTER_VALIDATE_INT);
$type = $data['relationship_type'] ?? '';

if ($familyId === false || $familyId < 1
    || $personId === false || $personId < 1
    || $relatedId === false || $relatedId < 1) {
    JsonResponse::error('Invalid family or member ID', 422);
}
if (!is_string($type) || !in_array($type, ['parent', 'child', 'spouse', 'guardian'], true)) {
    JsonResponse::error('Invalid relationship type', 422);
}
if ($personId === $relatedId) {
    JsonResponse::error('Two different members are required', 422);
}

try {
    $db->beginTransaction();
    $familyStmt = $db->prepare(
        "SELECT id FROM families WHERE id = ? AND status = 'active' FOR UPDATE"
    );
    $familyStmt->execute([$familyId]);
    if (!$familyStmt->fetch()) {
        $db->rollBack();
        JsonResponse::error('Active family not found', 404);
    }

    $member = Auth::requireFamilyMember((int) $familyId);
    if (($member['role'] ?? null) !== 'admin'
        && (int) $member['id'] !== (int) $personId
        && (int) $member['id'] !== (int) $relatedId) {
        $db->rollBack();
        JsonResponse::error('You can only propose a relationship involving your own profile', 403);
    }

    $stmt = $db->prepare(
        "SELECT COUNT(*) FROM family_members
         WHERE id IN (?, ?) AND family_id = ? AND member_status = 'active'"
    );
    $stmt->execute([$personId, $relatedId, $familyId]);
    if ((int) $stmt->fetchColumn() !== 2) {
        $db->rollBack();
        JsonResponse::error('Both people must be active members of this family', 422);
    }

    $stmt = $db->prepare(
        "SELECT id FROM family_relationships
         WHERE family_id = ? AND status IN ('pending', 'approved')
           AND ((person_id = ? AND related_person_id = ?)
             OR (person_id = ? AND related_person_id = ?))
           AND relationship_type = ?
         LIMIT 1 FOR UPDATE"
    );
    $stmt->execute([$familyId, $personId, $relatedId, $relatedId, $personId, $type]);
    if ($stmt->fetch()) {
        $db->rollBack();
        JsonResponse::error('This relationship already exists or is pending', 409);
    }

    $stmt = $db->prepare(
        "INSERT INTO family_relationships
         (family_id, person_id, related_person_id, relationship_type, created_by_member_id)
         VALUES (?, ?, ?, ?, ?)"
    );
    $stmt->execute([$familyId, $personId, $relatedId, $type, (int) $member['id']]);
    $relationshipId = (int) $db->lastInsertId();
    Audit::log(
        'relationship_created',
        (int) $familyId,
        'family_relationship',
        $relationshipId,
        ['type' => $type]
    );
    $db->commit();
    JsonResponse::ok(['message' => 'Relationship submitted for approval'], 201);
} catch (Throwable $e) {
    if ($db->inTransaction()) {
        $db->rollBack();
    }
    error_log('Relationship proposal failed: ' . $e->getMessage());
    JsonResponse::error('Could not submit relationship proposal', 500);
}
