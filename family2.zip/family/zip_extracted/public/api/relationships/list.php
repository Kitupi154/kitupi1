<?php
declare(strict_types=1);

require_once __DIR__ . '/../../../src/bootstrap.php';

if (($_SERVER['REQUEST_METHOD'] ?? '') !== 'GET') {
    header('Allow: GET');
    JsonResponse::error('Method not allowed', 405);
}

Auth::requireLogin();
$familyId = filter_var($_GET['family_id'] ?? null, FILTER_VALIDATE_INT);
if ($familyId === false || $familyId < 1) {
    JsonResponse::error('Invalid family ID', 422);
}

$actor = Auth::requireFamilyViewer((int) $familyId);
$sql = "SELECT relationship.id, relationship.family_id, relationship.person_id,
               relationship.related_person_id, relationship.relationship_type,
               relationship.status, relationship.created_at, relationship.approved_at,
               person.first_name AS person_first_name,
               person.last_name AS person_last_name,
               related.first_name AS related_first_name,
               related.last_name AS related_last_name
        FROM family_relationships relationship
        INNER JOIN family_members person
          ON person.id = relationship.person_id
         AND person.family_id = relationship.family_id
         AND person.member_status = 'active'
        INNER JOIN family_members related
          ON related.id = relationship.related_person_id
         AND related.family_id = relationship.family_id
         AND related.member_status = 'active'
        WHERE relationship.family_id = ?
          AND relationship.status IN ('approved', 'pending')";
if (($actor['role'] ?? null) !== 'admin') {
    $sql .= " AND relationship.status = 'approved'";
}
$sql .= ' ORDER BY relationship.created_at DESC, relationship.id DESC';

$stmt = $db->prepare($sql);
$stmt->execute([(int) $familyId]);
JsonResponse::ok(['relationships' => $stmt->fetchAll()]);
