<?php
declare(strict_types=1);

require_once __DIR__ . '/../../../src/bootstrap.php';

if (($_SERVER['REQUEST_METHOD'] ?? '') !== 'POST') {
    header('Allow: POST');
    JsonResponse::error('Method not allowed', 405);
}

Security::requireCsrf();
$data = JsonResponse::input();
$familyId = filter_var($data['family_id'] ?? null, FILTER_VALIDATE_INT);
$relationshipId = filter_var($data['relationship_id'] ?? null, FILTER_VALIDATE_INT);
$decision = $data['decision'] ?? '';
if ($familyId === false || $familyId < 1
    || $relationshipId === false || $relationshipId < 1) {
    JsonResponse::error('Invalid family or relationship ID', 422);
}
if (!is_string($decision) || !in_array($decision, ['approved', 'rejected'], true)) {
    JsonResponse::error('Invalid relationship decision', 422);
}

try {
    $db->beginTransaction();
    $familyStmt = $db->prepare(
        "SELECT id FROM families WHERE id = ? AND status = 'active' FOR UPDATE"
    );
    $familyStmt->execute([$familyId]);
    if (!$familyStmt->fetch()) {
        $db->rollBack();
        JsonResponse::error('Active family not found', 404);
    }

    $admin = Auth::requireFamilyAdmin((int) $familyId);
    $relationshipStmt = $db->prepare(
        "SELECT relationship.id, relationship.person_id, relationship.related_person_id,
                relationship.created_by_member_id,
                person.member_status AS person_status,
                related.member_status AS related_status
         FROM family_relationships relationship
         INNER JOIN family_members person
           ON person.id = relationship.person_id
          AND person.family_id = relationship.family_id
         INNER JOIN family_members related
           ON related.id = relationship.related_person_id
          AND related.family_id = relationship.family_id
         WHERE relationship.id = ? AND relationship.family_id = ?
           AND relationship.status = 'pending'
         FOR UPDATE"
    );
    $relationshipStmt->execute([$relationshipId, $familyId]);
    $relationship = $relationshipStmt->fetch();
    if (!$relationship) {
        $db->rollBack();
        JsonResponse::error('Pending relationship proposal not found', 409);
    }
    if ((int) $relationship['created_by_member_id'] === (int) $admin['id']) {
        $db->rollBack();
        JsonResponse::error('You cannot decide your own relationship proposal', 403);
    }
    if ($relationship['person_status'] !== 'active'
        || $relationship['related_status'] !== 'active') {
        $db->rollBack();
        JsonResponse::error('Both people must remain active members of this family', 409);
    }

    $update = $db->prepare(
        "UPDATE family_relationships
         SET status = ?,
             approved_by_member_id = CASE WHEN ? = 'approved' THEN ? ELSE NULL END,
             approved_at = CASE WHEN ? = 'approved' THEN NOW() ELSE NULL END
         WHERE id = ? AND family_id = ? AND status = 'pending'"
    );
    $update->execute([
        $decision,
        $decision,
        (int) $admin['id'],
        $decision,
        $relationshipId,
        $familyId,
    ]);
    if ($update->rowCount() !== 1) {
        $db->rollBack();
        JsonResponse::error('Relationship proposal has already changed', 409);
    }

    Audit::log(
        'relationship_' . $decision,
        (int) $familyId,
        'family_relationship',
        (int) $relationshipId
    );
    $db->commit();
    JsonResponse::ok(['message' => 'Relationship decision recorded']);
} catch (Throwable $e) {
    if ($db->inTransaction()) {
        $db->rollBack();
    }
    error_log('Relationship decision failed: ' . $e->getMessage());
    JsonResponse::error('Could not record relationship decision', 500);
}
