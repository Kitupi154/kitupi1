<?php
declare(strict_types=1);

require_once __DIR__ . '/../../../src/bootstrap.php';

if ($_SERVER['REQUEST_METHOD'] !== 'GET') {
    JsonResponse::error('GET required', 405);
}

// Only an authenticated Super Admin may view global statistics.
Auth::requireSuperAdmin();

try {
    $stmt = $db->query("
        SELECT
            (SELECT COUNT(*) FROM families) AS total_families,
            (SELECT COUNT(*) FROM families WHERE status = 'active') AS active_families,
            (SELECT COUNT(*) FROM users WHERE status <> 'deleted') AS total_user_accounts,
            (SELECT COUNT(*) FROM users WHERE status = 'active') AS active_user_accounts,
            (SELECT COUNT(*) FROM family_members WHERE member_status <> 'removed') AS total_family_members,
            (SELECT COUNT(*) FROM family_members
                WHERE member_status = 'active') AS active_family_members,
            (SELECT COALESCE(SUM(file_size), 0) FROM media) AS tracked_media_bytes
    ");

    $stats = $stmt->fetch();
    $activity = $db->query(
        "SELECT al.action, al.target_type, al.created_at, al.actor_user_id,
                u.is_admin AS actor_is_admin, f.family_name
         FROM audit_logs al
         LEFT JOIN families f ON f.id = al.family_id
         LEFT JOIN users u ON u.id = al.actor_user_id
         ORDER BY al.created_at DESC, al.id DESC
         LIMIT 5"
    )->fetchAll();

    JsonResponse::ok([
        'statistics' => [
            'total_families' => (int) $stats['total_families'],
            'active_families' => (int) $stats['active_families'],
            'total_user_accounts' => (int) $stats['total_user_accounts'],
            'active_user_accounts' => (int) $stats['active_user_accounts'],
            'total_family_members' => (int) $stats['total_family_members'],
            'active_family_members' => (int) $stats['active_family_members'],
            'tracked_media_bytes' => (int) $stats['tracked_media_bytes'],
        ],
        'recent_activity' => $activity,
    ]);
} catch (Throwable $e) {
    error_log('Admin overview statistics failed: ' . $e->getMessage());
    JsonResponse::error('Could not load dashboard statistics', 500);
}
