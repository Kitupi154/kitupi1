<?php
declare(strict_types=1);

require_once __DIR__ . '/../../../src/bootstrap.php';

if (($_SERVER['REQUEST_METHOD'] ?? '') !== 'GET') {
    header('Allow: GET');
    JsonResponse::error('Method not allowed', 405);
}

$user = Auth::requireLogin();
$memberId = filter_var($_GET['member_id'] ?? null, FILTER_VALIDATE_INT);
if ($memberId === false || $memberId < 1) {
    JsonResponse::error('Invalid member ID', 422);
}

$memberStmt = $db->prepare(
    "SELECT id, family_id, user_id
     FROM family_members
     WHERE id = ? AND member_status = 'active'
     LIMIT 1"
);
$memberStmt->execute([$memberId]);
$member = $memberStmt->fetch();
if (!$member) {
    JsonResponse::error('Member not found', 404);
}
if ((int) $member['user_id'] !== (int) $user['id']) {
    JsonResponse::error('You can only view your own identity status', 403);
}

Auth::requireFamilyViewer((int) $member['family_id']);
$stmt = $db->prepare(
    "SELECT id, document_type, status, rejection_reason, submitted_at, reviewed_at
     FROM identity_verifications
     WHERE user_id = ? AND member_id = ?
     ORDER BY submitted_at DESC, id DESC
     LIMIT 20"
);
$stmt->execute([(int) $user['id'], (int) $member['id']]);

JsonResponse::ok(['verifications' => $stmt->fetchAll()]);
