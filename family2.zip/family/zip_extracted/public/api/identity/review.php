<?php
declare(strict_types=1);

require_once __DIR__ . '/../../../src/bootstrap.php';

if (($_SERVER['REQUEST_METHOD'] ?? '') !== 'POST') {
    header('Allow: POST');
    JsonResponse::error('Method not allowed', 405);
}

Security::requireCsrf();
$user = Auth::requireSuperAdmin();
$data = JsonResponse::input();
$verificationId = filter_var($data['verification_id'] ?? null, FILTER_VALIDATE_INT);
$decision = $data['decision'] ?? '';
$reasonValue = $data['rejection_reason'] ?? '';

if ($verificationId === false || $verificationId < 1) {
    JsonResponse::error('Invalid verification ID', 422);
}
if (!is_string($decision) || !in_array($decision, ['verified', 'rejected'], true)) {
    JsonResponse::error('Invalid decision', 422);
}
if (!is_string($reasonValue)) {
    JsonResponse::error('Invalid rejection reason', 422);
}
$reason = Security::cleanString($reasonValue, 500);
if ($decision === 'rejected' && $reason === '') {
    JsonResponse::error('A rejection reason is required', 422);
}

try {
    $db->beginTransaction();
    $stmt = $db->prepare(
        'SELECT verification.id, verification.status, member.family_id
         FROM identity_verifications verification
         INNER JOIN family_members member ON member.id = verification.member_id
         WHERE verification.id = ?
         LIMIT 1 FOR UPDATE'
    );
    $stmt->execute([(int) $verificationId]);
    $verification = $stmt->fetch();
    if (!$verification) {
        $db->rollBack();
        JsonResponse::error('Verification not found', 404);
    }
    if ($verification['status'] !== 'pending') {
        $db->rollBack();
        JsonResponse::error('Only a pending identity submission can be reviewed', 409);
    }

    $update = $db->prepare(
        "UPDATE identity_verifications
         SET status = ?, reviewer_user_id = ?, rejection_reason = ?, reviewed_at = NOW()
         WHERE id = ? AND status = 'pending'"
    );
    $update->execute([
        $decision,
        (int) $user['id'],
        $decision === 'rejected' ? $reason : null,
        (int) $verificationId,
    ]);
    if ($update->rowCount() !== 1) {
        $db->rollBack();
        JsonResponse::error('Identity submission has already changed', 409);
    }

    Audit::log(
        'identity_' . $decision,
        (int) $verification['family_id'],
        'identity_verification',
        (int) $verificationId
    );
    $db->commit();
    JsonResponse::ok(['message' => 'Identity decision recorded']);
} catch (Throwable $e) {
    if ($db->inTransaction()) {
        $db->rollBack();
    }
    error_log('Identity review failed: ' . $e->getMessage());
    JsonResponse::error('Could not record identity decision', 500);
}
