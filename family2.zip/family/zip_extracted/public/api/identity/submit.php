<?php
declare(strict_types=1);

require_once __DIR__ . '/../../../src/bootstrap.php';

if (($_SERVER['REQUEST_METHOD'] ?? '') !== 'POST') {
    header('Allow: POST');
    JsonResponse::error('Method not allowed', 405);
}

Security::requireCsrf();
$user = Auth::requireLogin();
$data = JsonResponse::input();
$memberId = filter_var($data['member_id'] ?? null, FILTER_VALIDATE_INT);
$typeValue = $data['document_type'] ?? '';
$numberValue = $data['document_number'] ?? '';
if ($memberId === false || $memberId < 1
    || !is_string($typeValue) || !is_string($numberValue)) {
    JsonResponse::error('Invalid identity submission details', 422);
}

$type = Security::cleanString($typeValue, 50);
$number = Security::cleanString($numberValue, 100);
if ($type === '' || $number === '') {
    JsonResponse::error('Document type and number are required', 422);
}

try {
    $db->beginTransaction();
    $stmt = $db->prepare(
        "SELECT id, family_id FROM family_members
         WHERE id = ? AND user_id = ? AND member_status = 'active'
         LIMIT 1 FOR UPDATE"
    );
    $stmt->execute([(int) $memberId, (int) $user['id']]);
    $member = $stmt->fetch();
    if (!$member) {
        $db->rollBack();
        JsonResponse::error('You can only submit identity for your own active profile', 403);
    }

    Auth::requireFamilyMember((int) $member['family_id']);
    $pendingStmt = $db->prepare(
        "SELECT id FROM identity_verifications
         WHERE user_id = ? AND member_id = ? AND status = 'pending'
         LIMIT 1 FOR UPDATE"
    );
    $pendingStmt->execute([(int) $user['id'], (int) $memberId]);
    if ($pendingStmt->fetch()) {
        $db->rollBack();
        JsonResponse::error('An identity verification is already pending', 409);
    }

    $encKey = hash_hkdf('sha256', (string) $config['app_key'], 32, 'kinkeep-identity-v1');
    $nonce = random_bytes(12);
    $tag = '';
    $cipher = openssl_encrypt(
        $number,
        'aes-256-gcm',
        $encKey,
        OPENSSL_RAW_DATA,
        $nonce,
        $tag,
        'kinkeep-identity-v1',
        16
    );
    if ($cipher === false || strlen($tag) !== 16) {
        $db->rollBack();
        JsonResponse::error('Could not securely process identity submission', 500);
    }
    $encrypted = 'v2:' . base64_encode($nonce . $tag . $cipher);
    $hash = hash_hmac('sha256', $number, $config['app_key']);

    $insert = $db->prepare(
        "INSERT INTO identity_verifications
         (user_id, member_id, document_type, document_number_encrypted, document_number_hash)
         VALUES (?, ?, ?, ?, ?)"
    );
    $insert->execute([(int) $user['id'], (int) $memberId, $type, $encrypted, $hash]);
    $verificationId = (int) $db->lastInsertId();
    Audit::log(
        'identity_submitted',
        (int) $member['family_id'],
        'identity_verification',
        $verificationId
    );
    $db->commit();
    JsonResponse::ok(['message' => 'Identity verification submitted for authorized review'], 201);
} catch (Throwable $e) {
    if ($db->inTransaction()) {
        $db->rollBack();
    }
    error_log('Identity submission failed: ' . $e->getMessage());
    JsonResponse::error('Could not submit identity verification', 500);
}
