<?php
declare(strict_types=1);

require_once __DIR__ . '/../../../src/bootstrap.php';

if (($_SERVER['REQUEST_METHOD'] ?? '') !== 'GET') {
    header('Allow: GET');
    JsonResponse::error('Method not allowed', 405);
}

Auth::requireLogin();
$familyId = filter_var($_GET['family_id'] ?? null, FILTER_VALIDATE_INT);
if ($familyId === false || $familyId < 1) {
    JsonResponse::error('Invalid family ID', 422);
}
Auth::requireFamilyAdmin((int) $familyId);
$stmt = $db->prepare(
    "SELECT verification.id, verification.member_id, verification.document_type,
            verification.status, verification.submitted_at, verification.reviewed_at,
            member.first_name, member.last_name
     FROM identity_verifications verification
     INNER JOIN family_members member ON member.id = verification.member_id
       AND member.family_id = ? AND member.member_status = 'active'
     INNER JOIN families family ON family.id = member.family_id AND family.status = 'active'
     ORDER BY verification.submitted_at DESC, verification.id DESC
     LIMIT 200"
);
$stmt->execute([(int) $familyId]);
$items = $stmt->fetchAll();
JsonResponse::ok(['verifications' => $items]);
