<?php
require_once __DIR__ . '/../../../src/bootstrap.php';
if ($_SERVER['REQUEST_METHOD'] !== 'POST') JsonResponse::error('POST required',405);
Security::requireCsrf();
$user = Auth::requireLogin();
Audit::log('logout', null, 'user', (int)$user['id']);
Auth::logout();
JsonResponse::ok(['message'=>'Logged out']);
