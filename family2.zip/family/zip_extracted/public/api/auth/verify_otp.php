<?php
declare(strict_types=1);

require_once __DIR__ . '/../../../src/bootstrap.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    JsonResponse::error('POST required', 405);
}

Security::requireCsrf();

// OTP verification must support pending accounts.
// Do not use requireLogin() here because it requires status='active'.
if (empty($_SESSION['user_id'])) {
    JsonResponse::error('Authentication required', 401);
}

$userId = (int) $_SESSION['user_id'];

$data = JsonResponse::input();
$code = preg_replace('/\D/', '', (string) ($data['code'] ?? ''));

if (strlen($code) !== 6) {
    JsonResponse::error('Invalid or expired code', 422);
}

try {
    $db->beginTransaction();

    // Serialize verification with resends so an invalidated challenge cannot
    // be accepted while a replacement code is being issued.
    $stmt = $db->prepare(
        "SELECT id, status
         FROM users
         WHERE id = ?
         LIMIT 1
         FOR UPDATE"
    );
    $stmt->execute([$userId]);
    $user = $stmt->fetch();

    if (!$user || !in_array($user['status'], ['pending', 'active'], true)) {
        $db->rollBack();
        Auth::logout();
        JsonResponse::error('Account cannot be verified', 403);
    }

    $stmt = $db->prepare(
        "SELECT *
         FROM otp_challenges
         WHERE user_id = ?
           AND channel = 'email'
           AND consumed_at IS NULL
           AND expires_at > NOW()
         ORDER BY id DESC
         LIMIT 1"
    );
    $stmt->execute([$userId]);
    $otp = $stmt->fetch();

    if (
        $otp &&
        (int) $otp['attempts'] >= (int) $config['otp']['max_attempts']
    ) {
        $db->prepare(
            "UPDATE otp_challenges
             SET consumed_at = NOW()
             WHERE id = ? AND consumed_at IS NULL"
        )->execute([$otp['id']]);

        Audit::log('otp_locked', null, 'user', $userId);
        $db->commit();

        JsonResponse::error(
            'Too many attempts. Request a new code.',
            429
        );
    }

    if (!$otp || !password_verify($code, $otp['code_hash'])) {
        if ($otp) {
            $db->prepare(
                "UPDATE otp_challenges
                 SET attempts = attempts + 1
                 WHERE id = ? AND consumed_at IS NULL"
            )->execute([$otp['id']]);
        }

        Audit::log('otp_failed', null, 'user', $userId);
        $db->commit();
        JsonResponse::error('Invalid or expired code', 422);
    }

    $consumeStmt = $db->prepare(
        "UPDATE otp_challenges
         SET consumed_at = NOW()
         WHERE id = ?
           AND consumed_at IS NULL
           AND expires_at > NOW()"
    );
    $consumeStmt->execute([$otp['id']]);

    if ($consumeStmt->rowCount() !== 1) {
        $db->rollBack();
        JsonResponse::error('Invalid or expired code', 422);
    }

    if ($user['status'] === 'pending') {
        $db->prepare(
            "UPDATE users
             SET status = 'active',
                 email_verified_at = NOW()
             WHERE id = ? AND status = 'pending'"
        )->execute([$userId]);
    }

    $db->commit();
} catch (Throwable $e) {
    if ($db->inTransaction()) {
        $db->rollBack();
    }

    JsonResponse::error('Verification failed. Please try again.', 500);
}

Audit::log('otp_verified', null, 'user', $userId);

$invitationHash = $_SESSION['pending_family_invitation_hash'] ?? null;
if (is_string($invitationHash)) {
    try {
        $invitation = FamilyInvitation::acceptForUser($userId, $invitationHash);
        unset($_SESSION['pending_family_invitation_hash']);
        JsonResponse::ok([
            'message' => $invitation['message'],
            'email_verified' => true,
            'invitation_accepted' => true,
            'family_id' => $invitation['family_id'],
            'family_name' => $invitation['family_name'],
            'role' => $invitation['role'],
        ]);
    } catch (FamilyInvitationException $e) {
        JsonResponse::ok([
            'message' => 'Your email has been verified, but your family invitation could not be accepted.',
            'email_verified' => true,
            'invitation_accepted' => false,
            'invitation_error' => $e->getMessage(),
        ]);
    } catch (Throwable $e) {
        error_log('Verified account invitation acceptance failed (' . get_class($e) . ')');
        JsonResponse::ok([
            'message' => 'Your email has been verified, but your family invitation could not be accepted. Return to the invitation and try again.',
            'email_verified' => true,
            'invitation_accepted' => false,
            'invitation_error' => 'Invitation acceptance could not be completed. Return to the invitation and try again.',
        ]);
    }
}

$membershipStmt = $db->prepare(
    "SELECT fm.family_id
     FROM family_members fm
     INNER JOIN families f ON f.id = fm.family_id AND f.status = 'active'
     INNER JOIN family_roles fr ON fr.member_id = fm.id
                               AND fr.family_id = fm.family_id
                               AND fr.role IN ('admin', 'member')
     WHERE fm.user_id = ? AND fm.member_status = 'active'
     LIMIT 1"
);
$membershipStmt->execute([$userId]);
$hasActiveFamilyMembership = $membershipStmt->fetchColumn() !== false;

JsonResponse::ok([
    'message' => 'Account verified',
    'email_verified' => true,
    'membership_onboarding' => !$hasActiveFamilyMembership,
]);
