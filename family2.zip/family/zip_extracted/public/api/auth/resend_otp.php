<?php
declare(strict_types=1);

require_once __DIR__ . '/../../../src/bootstrap.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    JsonResponse::error('POST required', 405);
}

Security::requireCsrf();

if (empty($_SESSION['user_id'])) {
    JsonResponse::error('Authentication required', 401);
}

$userId = (int) $_SESSION['user_id'];
if ($userId <= 0) {
    JsonResponse::error('Authentication required', 401);
}

try {
    $db->beginTransaction();

    $stmt = $db->prepare(
        "SELECT id, email, status
         FROM users
         WHERE id = ?
         LIMIT 1
         FOR UPDATE"
    );
    $stmt->execute([$userId]);
    $user = $stmt->fetch();

    if (!$user) {
        $db->rollBack();
        Auth::logout();
        JsonResponse::error('Authentication required', 401);
    }

    if ($user['status'] !== 'pending') {
        $db->rollBack();
        if ($user['status'] === 'active') {
            JsonResponse::error('This account is already verified.', 409);
        }
        JsonResponse::error('This account cannot request a verification code.', 403);
    }

    $stmt = $db->prepare(
        "SELECT COUNT(*) AS resend_count,
                MAX(resends.created_at) AS latest_resend,
                SUM(resends.created_at > DATE_SUB(NOW(), INTERVAL 60 SECOND)) AS is_cooling_down,
                GREATEST(1, 60 - TIMESTAMPDIFF(SECOND, MAX(resends.created_at), NOW())) AS cooldown_seconds,
                GREATEST(1, 3600 - TIMESTAMPDIFF(SECOND, MIN(resends.created_at), NOW())) AS hourly_retry_seconds
         FROM otp_challenges AS resends
         WHERE resends.user_id = ?
           AND resends.channel = 'email'
           AND resends.created_at > DATE_SUB(NOW(), INTERVAL 1 HOUR)
           AND resends.id > (
               SELECT MIN(initial.id)
               FROM otp_challenges AS initial
               WHERE initial.user_id = resends.user_id
                 AND initial.channel = 'email'
           )"
    );
    $stmt->execute([$userId]);
    $limits = $stmt->fetch();
    $resendCount = (int) $limits['resend_count'];

    if ($resendCount > 0 && (int) $limits['is_cooling_down'] > 0) {
        $retryAfter = (int) $limits['cooldown_seconds'];
        $db->rollBack();
        JsonResponse::error(
            'Please wait before requesting another verification code.',
            429,
            ['retry_after_seconds' => $retryAfter]
        );
    }

    if ($resendCount >= 5) {
        $retryAfter = (int) $limits['hourly_retry_seconds'];
        $db->rollBack();
        JsonResponse::error(
            'You have reached the limit of five code requests in one hour. Please try again later.',
            429,
            ['retry_after_seconds' => $retryAfter]
        );
    }

    $code = (string) random_int(100000, 999999);
    $codeHash = password_hash($code, PASSWORD_DEFAULT);
    if ($codeHash === false) {
        throw new RuntimeException('Could not hash verification code.');
    }

    $db->prepare(
        "UPDATE otp_challenges
         SET consumed_at = NOW()
         WHERE user_id = ?
           AND channel = 'email'
           AND consumed_at IS NULL"
    )->execute([$userId]);

    $ttlSeconds = max(1, (int) ($config['otp']['ttl_seconds'] ?? 600));
    $expires = date('Y-m-d H:i:s', time() + $ttlSeconds);
    $stmt = $db->prepare(
        "INSERT INTO otp_challenges
            (user_id, channel, destination, code_hash, expires_at)
         VALUES (?, 'email', ?, ?, ?)"
    );
    $stmt->execute([$userId, $user['email'], $codeHash, $expires]);
    $challengeId = (int) $db->lastInsertId();

    Audit::log('otp_resend_requested', null, 'user', $userId);
    $db->commit();
} catch (Throwable $e) {
    if ($db->inTransaction()) {
        $db->rollBack();
    }
    JsonResponse::error('Could not prepare a verification code. Please try again later.', 500);
}

$sent = false;
try {
    $sent = Mailer::sendOtp((string) $user['email'], $code);
} catch (Throwable $e) {
    $sent = false;
}

if (!$sent) {
    $cleanupSucceeded = false;
    try {
        $db->beginTransaction();
        $db->prepare(
            "UPDATE otp_challenges
             SET consumed_at = NOW()
             WHERE id = ?
               AND user_id = ?
               AND consumed_at IS NULL"
        )->execute([$challengeId, $userId]);
        Audit::log('otp_resend_send_failed', null, 'user', $userId);
        $db->commit();
        $cleanupSucceeded = true;
    } catch (Throwable $e) {
        if ($db->inTransaction()) {
            $db->rollBack();
        }
    }

    if (!$cleanupSucceeded) {
        JsonResponse::error(
            'Code delivery failed and the challenge could not be safely updated. Contact the site administrator.',
            500
        );
    }

    JsonResponse::error(
        'Could not send the verification code. Please wait before trying again or contact the site administrator.',
        500
    );
}

$mailMode = $config['mail']['mode'] ?? 'log';
if ($mailMode === 'log') {
    JsonResponse::ok([
        'message' => 'The verification code was recorded in the development mail log; it was not delivered to a real inbox.',
        'delivery_mode' => 'log',
    ]);
}

JsonResponse::ok([
    'message' => 'A new verification code was sent to the email address on file.',
    'delivery_mode' => 'mail',
]);
