<?php
declare(strict_types=1);

require_once __DIR__ . '/../../../src/bootstrap.php';

if (($_SERVER['REQUEST_METHOD'] ?? '') !== 'GET') {
    header('Allow: GET');
    JsonResponse::error('Method not allowed', 405);
}

$user = Auth::requireLogin();
$limitValue = filter_var($_GET['limit'] ?? '25', FILTER_VALIDATE_INT);
$beforeValue = isset($_GET['before_id'])
    ? filter_var($_GET['before_id'], FILTER_VALIDATE_INT)
    : null;
if ($limitValue === false || $limitValue < 1
    || $beforeValue === false || ($beforeValue !== null && $beforeValue < 1)) {
    JsonResponse::error('Invalid sign-in history request', 422);
}
$limit = min((int) $limitValue, 50);
try {
    $sql = "SELECT id, action, created_at
         FROM audit_logs
         WHERE actor_user_id = ? AND action = 'login_success'
         ";
    $params = [(int) $user['id']];
    if ($beforeValue !== null) {
        $sql .= ' AND id < ?';
        $params[] = (int) $beforeValue;
    }
    $sql .= ' ORDER BY id DESC LIMIT ' . ($limit + 1);
    $stmt = $db->prepare($sql);
    $stmt->execute($params);
    $signIns = $stmt->fetchAll();
    $hasMore = count($signIns) > $limit;
    if ($hasMore) {
        array_pop($signIns);
    }
    JsonResponse::ok([
        'sign_ins' => $signIns,
        'has_more' => $hasMore,
        'next_cursor' => $hasMore && $signIns ? (int) end($signIns)['id'] : null,
        'page_size' => $limit,
    ]);
} catch (Throwable $e) {
    error_log('Account sign-in history query failed: ' . $e->getMessage());
    JsonResponse::error('Could not load sign-in history', 500);
}
