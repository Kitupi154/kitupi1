<?php
declare(strict_types=1);

require_once __DIR__ . '/../../../src/bootstrap.php';
require_once __DIR__ . '/../../../src/Mfa.php';

if (($_SERVER['REQUEST_METHOD'] ?? '') !== 'POST') {
    header('Allow: POST');
    JsonResponse::error('Method not allowed', 405);
}
Security::requireCsrf();

$challenge = $_SESSION['mfa_challenge'] ?? null;
if (!is_array($challenge)
    || !isset($challenge['user_id'], $challenge['attempt_id'], $challenge['identifier_hash'], $challenge['ip_hash'], $challenge['expires_at'], $challenge['attempts'])
    || (int) $challenge['expires_at'] < time()
    || !hash_equals((string) $challenge['ip_hash'], Security::hashClient(Security::clientIp(), $config['app_key']))) {
    unset($_SESSION['mfa_challenge']);
    JsonResponse::error('Sign-in verification expired. Enter your password again.', 401);
}
$data = JsonResponse::input();
$code = $data['code'] ?? null;
if (!is_string($code) || !preg_match('/^[0-9]{6}$/D', trim($code))) {
    JsonResponse::error('Enter the six-digit authenticator code', 422);
}

$attemptLimit = $db->prepare(
    'SELECT COUNT(*) FROM login_attempts
     WHERE (identifier_hash = ? OR ip_hash = ?)
       AND success = 0 AND created_at > DATE_SUB(NOW(), INTERVAL 15 MINUTE)'
);
$attemptLimit->execute([(string) $challenge['identifier_hash'], (string) $challenge['ip_hash']]);
if ((int) $attemptLimit->fetchColumn() >= 10) {
    unset($_SESSION['mfa_challenge']);
    JsonResponse::error('Too many attempts. Sign in again later.', 429);
}

try {
    $db->beginTransaction();
    $userStmt = $db->prepare(
        "SELECT id, status, locked_until, mfa_enabled
         FROM users WHERE id = ? LIMIT 1 FOR UPDATE"
    );
    $userStmt->execute([(int) $challenge['user_id']]);
    $user = $userStmt->fetch();
    if (!$user || $user['status'] !== 'active'
        || ($user['locked_until'] && strtotime($user['locked_until']) > time())
        || (int) $user['mfa_enabled'] !== 1) {
        $db->rollBack();
        unset($_SESSION['mfa_challenge']);
        JsonResponse::error('Sign-in verification is no longer available. Enter your credentials again.', 401);
    }

    $mfaStmt = $db->prepare(
        'SELECT secret_encrypted, last_used_step
         FROM user_mfa WHERE user_id = ? AND confirmed_at IS NOT NULL
         LIMIT 1 FOR UPDATE'
    );
    $mfaStmt->execute([(int) $user['id']]);
    $mfa = $mfaStmt->fetch();
    if (!$mfa || !is_string($mfa['secret_encrypted'])) {
        $db->rollBack();
        unset($_SESSION['mfa_challenge']);
        JsonResponse::error('Multi-factor sign-in is unavailable. Contact support.', 503);
    }

    $secret = Mfa::decryptSecret($mfa['secret_encrypted'], (string) $config['app_key']);
    $step = Mfa::verifyCode($secret, trim($code), (int) $mfa['last_used_step']);
    if ($step === null) {
        Audit::log('mfa_login_failed', null, 'user', (int) $user['id']);
        $db->commit();
        $_SESSION['mfa_challenge']['attempts'] = (int) $challenge['attempts'] + 1;
        if ($_SESSION['mfa_challenge']['attempts'] >= 5) {
            unset($_SESSION['mfa_challenge']);
            JsonResponse::error('Authenticator verification failed. Enter your password and try again.', 401);
        }
        JsonResponse::error('Authenticator code is invalid or was already used', 422);
    }

    $db->prepare('UPDATE user_mfa SET last_used_step = ? WHERE user_id = ?')
        ->execute([$step, (int) $user['id']]);
    $db->prepare(
        'UPDATE users SET failed_login_count = 0, locked_until = NULL, last_login_at = NOW() WHERE id = ?'
    )->execute([(int) $user['id']]);
    $markAttempt = $db->prepare(
        'UPDATE login_attempts SET success = 1
         WHERE id = ? AND identifier_hash = ? AND ip_hash = ? AND success = 0'
    );
    $markAttempt->execute([
        (int) $challenge['attempt_id'],
        (string) $challenge['identifier_hash'],
        (string) $challenge['ip_hash'],
    ]);
    if ($markAttempt->rowCount() !== 1) {
        throw new RuntimeException('Sign-in attempt expired or already completed');
    }
    $db->commit();
    unset($_SESSION['mfa_challenge']);
    Auth::login((int) $user['id']);
    Audit::log('login_success', null, 'user', (int) $user['id']);
    JsonResponse::ok(['message' => 'Login successful']);
} catch (Throwable $e) {
    if ($db->inTransaction()) {
        $db->rollBack();
    }
    error_log('Multi-factor sign-in verification failed: ' . $e->getMessage());
    JsonResponse::error('Could not complete sign-in verification', 500);
}
