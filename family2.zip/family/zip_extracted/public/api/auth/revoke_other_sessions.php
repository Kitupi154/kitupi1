<?php
declare(strict_types=1);

require_once __DIR__ . '/../../../src/bootstrap.php';

if (($_SERVER['REQUEST_METHOD'] ?? '') !== 'POST') {
    header('Allow: POST');
    JsonResponse::error('Method not allowed', 405);
}

Security::requireCsrf();
$user = Auth::requireLogin();
$currentHash = Security::hashClient(session_id(), (string) $config['app_key']);

try {
    $db->beginTransaction();
    $stmt = $db->prepare(
        'UPDATE user_sessions
         SET revoked_at = NOW()
         WHERE user_id = ? AND session_hash <> ? AND revoked_at IS NULL'
    );
    $stmt->execute([(int) $user['id'], $currentHash]);
    $revoked = $stmt->rowCount();
    Audit::log('other_sessions_revoked', null, 'user', (int) $user['id']);
    $db->commit();
    JsonResponse::ok([
        'message' => $revoked > 0
            ? 'Other active sessions were signed out.'
            : 'There were no other active sessions to sign out.',
        'revoked_count' => $revoked,
    ]);
} catch (Throwable $e) {
    if ($db->inTransaction()) {
        $db->rollBack();
    }
    error_log('Other session revocation failed: ' . $e->getMessage());
    JsonResponse::error('Could not sign out other sessions', 500);
}
