<?php
require_once __DIR__ . '/../../../src/bootstrap.php';
$user = Auth::requireLogin();
$stmt = $db->prepare(
    "SELECT f.id, f.family_name, f.status,
            CASE WHEN COUNT(fm.id) = 1 THEN MIN(fr.role) ELSE NULL END AS role,
            COUNT(fm.id) AS membership_count
     FROM families f
     INNER JOIN family_members fm
         ON fm.family_id = f.id
        AND fm.user_id = ?
        AND fm.member_status = 'active'
     LEFT JOIN family_roles fr
         ON fr.family_id = f.id
        AND fr.member_id = fm.id
     WHERE f.status = 'active'
     GROUP BY f.id, f.family_name, f.status
     ORDER BY f.family_name, f.id"
);
$stmt->execute([(int) $user['id']]);
$families = array_map(
    static fn(array $family): array => [
        'id' => (int) $family['id'],
        'family_name' => $family['family_name'],
        'status' => $family['status'],
        'role' => $family['role'],
        'authorization_conflict' => (int) $family['membership_count'] !== 1
            || $family['role'] === null,
    ],
    $stmt->fetchAll()
);

JsonResponse::ok(['user' => [
    'id' => (int)$user['id'],
    'email' => $user['email'],
    'phone' => $user['phone'],
    'status' => $user['status'],
    'is_admin' => (bool)($user['is_admin'] ?? false),
    'mfa_enabled' => (bool)($user['mfa_enabled'] ?? false),
    'email_verified_at' => $user['email_verified_at'],
    'last_login_at' => $user['last_login_at'],
], 'families' => $families, 'csrf_token' => Security::csrfToken()]);
