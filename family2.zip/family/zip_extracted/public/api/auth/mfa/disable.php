<?php
declare(strict_types=1);

require_once __DIR__ . '/../../../../src/bootstrap.php';
require_once __DIR__ . '/../../../../src/Mfa.php';

if (($_SERVER['REQUEST_METHOD'] ?? '') !== 'POST') {
    header('Allow: POST');
    JsonResponse::error('Method not allowed', 405);
}

Security::requireCsrf();
$user = Auth::requireLogin();
$data = JsonResponse::input();
$password = $data['current_password'] ?? null;
$code = $data['code'] ?? null;
if (!is_string($password) || strlen($password) > 1024 || !is_string($code)
    || !Security::verifyPassword($password, (string) $user['password_hash'])) {
    JsonResponse::error('Current password or authenticator code is incorrect', 403);
}

try {
    $db->beginTransaction();
    $stmt = $db->prepare(
        'SELECT secret_encrypted, last_used_step
         FROM user_mfa WHERE user_id = ? AND confirmed_at IS NOT NULL
         LIMIT 1 FOR UPDATE'
    );
    $stmt->execute([(int) $user['id']]);
    $mfa = $stmt->fetch();
    if (!$mfa || !is_string($mfa['secret_encrypted'])) {
        $db->rollBack();
        JsonResponse::error('Multi-factor authentication is not enabled', 409);
    }
    $secret = Mfa::decryptSecret($mfa['secret_encrypted'], (string) $config['app_key']);
    $step = Mfa::verifyCode($secret, trim($code), (int) $mfa['last_used_step']);
    if ($step === null) {
        $db->rollBack();
        JsonResponse::error('Current password or authenticator code is incorrect', 403);
    }

    $db->prepare('DELETE FROM user_mfa WHERE user_id = ?')->execute([(int) $user['id']]);
    $disable = $db->prepare('UPDATE users SET mfa_enabled = 0 WHERE id = ? AND mfa_enabled = 1');
    $disable->execute([(int) $user['id']]);
    if ($disable->rowCount() !== 1) {
        throw new RuntimeException('Could not disable multi-factor authentication');
    }
    Audit::log('mfa_disabled', null, 'user', (int) $user['id']);
    $db->commit();
    JsonResponse::ok(['message' => 'Multi-factor authentication is disabled']);
} catch (Throwable $e) {
    if ($db->inTransaction()) {
        $db->rollBack();
    }
    error_log('Multi-factor disable failed: ' . $e->getMessage());
    JsonResponse::error('Could not disable multi-factor authentication', 500);
}
