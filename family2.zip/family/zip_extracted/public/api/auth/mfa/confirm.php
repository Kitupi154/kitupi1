<?php
declare(strict_types=1);

require_once __DIR__ . '/../../../../src/bootstrap.php';
require_once __DIR__ . '/../../../../src/Mfa.php';

if (($_SERVER['REQUEST_METHOD'] ?? '') !== 'POST') {
    header('Allow: POST');
    JsonResponse::error('Method not allowed', 405);
}

Security::requireCsrf();
$user = Auth::requireLogin();
$data = JsonResponse::input();
$code = $data['code'] ?? null;
if (!is_string($code)) {
    JsonResponse::error('Enter the current six-digit authenticator code', 422);
}

try {
    $db->beginTransaction();
    $stmt = $db->prepare(
        'SELECT pending_secret_encrypted,
                (pending_expires_at IS NOT NULL AND pending_expires_at > NOW()) AS pending_is_valid
         FROM user_mfa WHERE user_id = ? AND confirmed_at IS NULL
         LIMIT 1 FOR UPDATE'
    );
    $stmt->execute([(int) $user['id']]);
    $pending = $stmt->fetchColumn();
    if (!is_array($pending) || !is_string($pending['pending_secret_encrypted'])
        || $pending['pending_secret_encrypted'] === '' || (int) $pending['pending_is_valid'] !== 1) {
        $db->rollBack();
        JsonResponse::error('Multi-factor setup expired. Start setup again.', 410);
    }
    $secret = Mfa::decryptSecret($pending['pending_secret_encrypted'], (string) $config['app_key']);
    $step = Mfa::verifyCode($secret, trim($code));
    if ($step === null) {
        $db->rollBack();
        JsonResponse::error('Authenticator code is invalid or expired', 422);
    }

    $activate = $db->prepare(
        'UPDATE user_mfa
         SET secret_encrypted = pending_secret_encrypted,
             pending_secret_encrypted = NULL,
             pending_expires_at = NULL,
             confirmed_at = NOW(), last_used_step = ?
         WHERE user_id = ? AND confirmed_at IS NULL'
    );
    $activate->execute([$step, (int) $user['id']]);
    if ($activate->rowCount() !== 1) {
        throw new RuntimeException('Could not enable multi-factor authentication');
    }
    $enableUser = $db->prepare("UPDATE users SET mfa_enabled = 1 WHERE id = ? AND status = 'active'");
    $enableUser->execute([(int) $user['id']]);
    if ($enableUser->rowCount() !== 1) {
        throw new RuntimeException('Could not enable multi-factor authentication');
    }
    Audit::log('mfa_enabled', null, 'user', (int) $user['id']);
    $db->commit();
    JsonResponse::ok(['message' => 'Multi-factor authentication is enabled']);
} catch (Throwable $e) {
    if ($db->inTransaction()) {
        $db->rollBack();
    }
    error_log('Multi-factor confirmation failed: ' . $e->getMessage());
    JsonResponse::error('Could not confirm multi-factor setup', 500);
}
