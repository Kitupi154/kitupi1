<?php
declare(strict_types=1);

require_once __DIR__ . '/../../../../src/bootstrap.php';
require_once __DIR__ . '/../../../../src/Mfa.php';

if (($_SERVER['REQUEST_METHOD'] ?? '') !== 'POST') {
    header('Allow: POST');
    JsonResponse::error('Method not allowed', 405);
}

Security::requireCsrf();
$user = Auth::requireLogin();
$data = JsonResponse::input();
$password = $data['current_password'] ?? null;
if (!is_string($password) || strlen($password) > 1024
    || !Security::verifyPassword($password, (string) $user['password_hash'])) {
    JsonResponse::error('Current password is incorrect', 403);
}
if ((int) ($user['mfa_enabled'] ?? 0) === 1) {
    JsonResponse::error('Multi-factor authentication is already enabled', 409);
}

try {
    $secret = Mfa::generateSecret();
    $encrypted = Mfa::encryptSecret($secret, (string) $config['app_key']);
    $stmt = $db->prepare(
        'INSERT INTO user_mfa (user_id, secret_encrypted, pending_secret_encrypted, pending_expires_at, confirmed_at, last_used_step)
         VALUES (?, NULL, ?, DATE_ADD(NOW(), INTERVAL 10 MINUTE), NULL, 0)
         ON DUPLICATE KEY UPDATE secret_encrypted = NULL,
             pending_secret_encrypted = VALUES(pending_secret_encrypted),
             pending_expires_at = DATE_ADD(NOW(), INTERVAL 10 MINUTE),
             confirmed_at = NULL, last_used_step = 0'
    );
    $stmt->execute([(int) $user['id'], $encrypted]);
    JsonResponse::ok([
        'secret' => $secret,
        'otpauth_uri' => Mfa::otpauthUri((string) $user['email'], $secret),
    ]);
} catch (Throwable $e) {
    error_log('Multi-factor setup failed: ' . $e->getMessage());
    JsonResponse::error('Could not start multi-factor setup', 500);
}
