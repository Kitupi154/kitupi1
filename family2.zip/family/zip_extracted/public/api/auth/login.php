<?php
declare(strict_types=1);

require_once __DIR__ . '/../../../src/bootstrap.php';

if (($_SERVER['REQUEST_METHOD'] ?? '') !== 'POST') {
    header('Allow: POST');
    JsonResponse::error('Method not allowed', 405);
}
Security::requireCsrf();

$data = JsonResponse::input();
$identifierValue = $data['identifier'] ?? '';
$password = $data['password'] ?? '';
$invitationToken = $data['invitation_token'] ?? null;
$superAdminOnly = ($data['super_admin_only'] ?? false) === true;
if (!is_string($identifierValue) || !is_string($password)
    || ($invitationToken !== null && !is_string($invitationToken))
    || strlen($identifierValue) > 760 || strlen($password) > 1024) {
    JsonResponse::error('Invalid credentials', 422);
}
$identifier = Security::cleanString($identifierValue, 190);
if ($identifier === '' || $password === '') {
    JsonResponse::error('Credentials required', 422);
}

$identifierHash = Security::hashClient(mb_strtolower($identifier), $config['app_key']);
$ipHash = Security::hashClient(Security::clientIp(), $config['app_key']);
$attempts = $db->prepare(
    'SELECT COUNT(*) FROM login_attempts
     WHERE (identifier_hash = ? OR ip_hash = ?)
       AND success = 0 AND created_at > DATE_SUB(NOW(), INTERVAL 15 MINUTE)'
);
$attempts->execute([$identifierHash, $ipHash]);
if ((int) $attempts->fetchColumn() >= 10) {
    JsonResponse::error('Too many attempts. Try again later.', 429);
}

$stmt = $db->prepare('SELECT * FROM users WHERE email = ? OR phone = ? LIMIT 1');
$stmt->execute([$identifier, $identifier]);
$user = $stmt->fetch();
$locked = $user && $user['locked_until'] && strtotime($user['locked_until']) > time();
$passwordOk = $user && !$locked
    && Security::verifyPassword($password, (string) $user['password_hash']);
$invitationHash = null;
if ($passwordOk && is_string($invitationToken)
    && preg_match('/\A[a-f0-9]{64}\z/i', $invitationToken)) {
    try {
        $invitationHash = FamilyInvitation::registrationTokenHash(
            $invitationToken,
            (string) $user['email']
        );
    } catch (FamilyInvitationException $e) {
        $invitationHash = null;
    }
}
$pendingInvitationLogin = $user
    && $passwordOk
    && $user['status'] === 'pending'
    && $invitationHash !== null;
$credentialsOk = $passwordOk
    && ($user['status'] === 'active' || $pendingInvitationLogin);
$authorized = $credentialsOk
    && (!$superAdminOnly || (int) ($user['is_admin'] ?? 0) === 1);
$mfaRequired = $authorized && (int) ($user['mfa_enabled'] ?? 0) === 1;

if ($mfaRequired) {
    $mfaReady = $db->prepare(
        'SELECT user_id FROM user_mfa
         WHERE user_id = ? AND secret_encrypted IS NOT NULL AND confirmed_at IS NOT NULL
         LIMIT 1'
    );
    $mfaReady->execute([(int) $user['id']]);
    if (!$mfaReady->fetchColumn()) {
        $db->prepare(
            'INSERT INTO login_attempts (identifier_hash, ip_hash, success) VALUES (?, ?, 0)'
        )->execute([$identifierHash, $ipHash]);
        error_log('MFA is enabled without an active encrypted secret for an account');
        JsonResponse::error('Multi-factor sign-in is unavailable for this account. Contact support.', 503);
    }
}

$attempt = $db->prepare(
    'INSERT INTO login_attempts (identifier_hash, ip_hash, success) VALUES (?, ?, ?)'
);
$attempt->execute([$identifierHash, $ipHash, $authorized && !$mfaRequired ? 1 : 0]);
$attemptId = (int) $db->lastInsertId();

if (!$authorized) {
    if ($user && !$locked && !$credentialsOk) {
        $failures = (int) $user['failed_login_count'] + 1;
        if ($failures >= 10) {
            $db->prepare(
                'UPDATE users SET failed_login_count = 0,
                    locked_until = DATE_ADD(NOW(), INTERVAL 15 MINUTE) WHERE id = ?'
            )->execute([(int) $user['id']]);
            Audit::log('account_locked', null, 'user', (int) $user['id']);
        } else {
            $db->prepare('UPDATE users SET failed_login_count = ? WHERE id = ?')
                ->execute([$failures, (int) $user['id']]);
        }
    }
    Audit::log('login_failed', null, 'user', $user ? (int) $user['id'] : null);
    JsonResponse::error('Invalid credentials', 401);
}

if ($mfaRequired) {
    unset($_SESSION['user_id'], $_SESSION['login_time']);
    session_regenerate_id(true);
    $_SESSION['mfa_challenge'] = [
        'user_id' => (int) $user['id'],
        'attempt_id' => $attemptId,
        'identifier_hash' => $identifierHash,
        'ip_hash' => $ipHash,
        'expires_at' => time() + 300,
        'attempts' => 0,
    ];
    JsonResponse::ok(['message' => 'Authenticator code required', 'mfa_required' => true]);
}

Auth::login((int) $user['id']);
if ($invitationHash !== null) {
    $_SESSION['pending_family_invitation_hash'] = $invitationHash;
}
$db->prepare(
    'UPDATE users SET failed_login_count = 0, locked_until = NULL, last_login_at = NOW() WHERE id = ?'
)->execute([(int) $user['id']]);
Audit::log('login_success', null, 'user', (int) $user['id']);
if ($pendingInvitationLogin) {
    JsonResponse::ok([
        'message' => 'Sign-in successful. Verify your email to complete the family invitation.',
        'verification_required' => true,
    ]);
}
JsonResponse::ok(['message' => 'Login successful']);
