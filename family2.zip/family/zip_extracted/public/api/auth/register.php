<?php
require_once __DIR__ . '/../../../src/bootstrap.php';
if ($_SERVER['REQUEST_METHOD'] !== 'POST') JsonResponse::error('POST required',405);
Security::requireCsrf();

$data = JsonResponse::input();
$email = filter_var($data['email'] ?? '', FILTER_VALIDATE_EMAIL);
$phone = Security::cleanString($data['phone'] ?? '', 30);
$password = (string)($data['password'] ?? '');
$invitationToken = $data['invitation_token'] ?? null;

if (!$email || !$phone || !Security::validatePassword($password)) {
    JsonResponse::error('Valid email, phone and strong password are required',422);
}

$invitationHash = null;
if ($invitationToken !== null) {
    if (!is_string($invitationToken)) {
        JsonResponse::error('Invalid invitation details', 422);
    }
    try {
        $invitationHash = FamilyInvitation::registrationTokenHash($invitationToken, (string) $email);
    } catch (FamilyInvitationException $e) {
        JsonResponse::error($e->getMessage(), $e->statusCode());
    }
}

$stmt = $db->prepare("SELECT id FROM users WHERE email=? OR phone=? LIMIT 1");
$stmt->execute([$email,$phone]);
if ($stmt->fetch()) JsonResponse::error('Account already exists',409);

$hash = Security::passwordHash($password);
$stmt = $db->prepare("INSERT INTO users(email,phone,password_hash,status) VALUES(?,?,?,'pending')");
$stmt->execute([$email,$phone,$hash]);
$userId = (int)$db->lastInsertId();

// Single active challenge per user/channel: invalidate previous ones.
$db->prepare("UPDATE otp_challenges SET consumed_at=NOW() WHERE user_id=? AND channel='email' AND consumed_at IS NULL")
   ->execute([$userId]);

$code = (string)random_int(100000,999999);
$codeHash = password_hash($code, PASSWORD_DEFAULT);
$expires = date('Y-m-d H:i:s', time()+$config['otp']['ttl_seconds']);
$stmt = $db->prepare("INSERT INTO otp_challenges(user_id,channel,destination,code_hash,expires_at) VALUES(?,?,?,?,?)");
$stmt->execute([$userId,'email',$email,$codeHash,$expires]);

if (!Mailer::sendOtp($email, $code)) {
    Audit::log('otp_send_failed', null, 'user', $userId);
    JsonResponse::error('Could not send verification code. Try again later.',500);
}

Auth::login($userId);
if ($invitationHash !== null) {
    $_SESSION['pending_family_invitation_hash'] = $invitationHash;
} else {
    unset($_SESSION['pending_family_invitation_hash']);
}
Audit::log('account_registered', null, 'user', $userId);

JsonResponse::ok([
    'message'=>'Registration created. Check your email for the verification code.',
    'user_id'=>$userId,
],201);
