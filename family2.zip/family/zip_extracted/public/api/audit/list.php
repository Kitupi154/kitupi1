<?php
declare(strict_types=1);

require_once __DIR__ . '/../../../src/bootstrap.php';

if (($_SERVER['REQUEST_METHOD'] ?? '') !== 'GET') {
    header('Allow: GET');
    JsonResponse::error('Method not allowed', 405);
}

$familyId = filter_var($_GET['family_id'] ?? null, FILTER_VALIDATE_INT);
$limitValue = filter_var($_GET['limit'] ?? '50', FILTER_VALIDATE_INT);
$beforeValue = isset($_GET['before_id'])
    ? filter_var($_GET['before_id'], FILTER_VALIDATE_INT)
    : null;
$daysValue = filter_var($_GET['days'] ?? '30', FILTER_VALIDATE_INT);
$category = $_GET['category'] ?? 'All activity';
$searchValue = $_GET['q'] ?? '';

if ($familyId === false || $familyId < 1) {
    JsonResponse::error('Invalid family ID', 422);
}
if ($limitValue === false || $limitValue < 1) {
    JsonResponse::error('Invalid page size', 422);
}
if ($beforeValue === false || ($beforeValue !== null && $beforeValue < 1)) {
    JsonResponse::error('Invalid audit cursor', 422);
}
if ($daysValue === false || !in_array((int) $daysValue, [0, 7, 30, 90], true)) {
    JsonResponse::error('Invalid audit date range', 422);
}
if (!is_string($category) || !in_array($category, ['All activity', 'Membership', 'Identity', 'Permissions', 'Vault'], true)) {
    JsonResponse::error('Invalid audit category', 422);
}
if (!is_string($searchValue)) {
    JsonResponse::error('Invalid audit search', 422);
}
$search = trim($searchValue);
if (strlen($search) > 100) {
    JsonResponse::error('Audit search is too long', 422);
}

Auth::requireFamilyAdmin((int) $familyId);
$limit = min((int) $limitValue, 100);
$sql = 'SELECT id, actor_user_id, action, target_type, target_id, created_at
        FROM audit_logs
        WHERE family_id = ?';
$params = [(int) $familyId];
if ((int) $daysValue > 0) {
    $sql .= ' AND created_at >= DATE_SUB(NOW(), INTERVAL ' . (int) $daysValue . ' DAY)';
}
if ($category !== 'All activity') {
    $categoryPatterns = match ($category) {
        'Membership' => ['%family%', '%membership%', '%member%', '%invitation%'],
        'Identity' => ['%identity%'],
        'Permissions' => ['%permission%'],
        'Vault' => ['%media%', '%vault%'],
    };
    $sql .= ' AND (' . implode(' OR ', array_fill(0, count($categoryPatterns), 'action LIKE ?')) . ')';
    array_push($params, ...$categoryPatterns);
}
if ($search !== '') {
    $sql .= ' AND (action LIKE ? OR target_type LIKE ? OR CAST(target_id AS CHAR) LIKE ? OR CAST(actor_user_id AS CHAR) LIKE ?)';
    $pattern = '%' . $search . '%';
    array_push($params, $pattern, $pattern, $pattern, $pattern);
}
if ($beforeValue !== null) {
    $sql .= ' AND id < ?';
    $params[] = (int) $beforeValue;
}
$sql .= ' ORDER BY id DESC LIMIT ' . ($limit + 1);

try {
    $stmt = $db->prepare($sql);
    $stmt->execute($params);
    $logs = $stmt->fetchAll();
    $hasMore = count($logs) > $limit;
    if ($hasMore) {
        array_pop($logs);
    }

    JsonResponse::ok([
        'logs' => $logs,
        'has_more' => $hasMore,
        'next_cursor' => $hasMore && $logs ? (int) end($logs)['id'] : null,
        'page_size' => $limit,
    ]);
} catch (Throwable $e) {
    error_log('Family audit log query failed: ' . $e->getMessage());
    JsonResponse::error('Could not load family audit events', 500);
}
