<?php
declare(strict_types=1);

require_once __DIR__ . '/../../../src/bootstrap.php';

if (($_SERVER['REQUEST_METHOD'] ?? '') !== 'POST') {
    header('Allow: POST');
    JsonResponse::error('Method not allowed', 405);
}

Security::requireCsrf();
$user = Auth::requireLogin();
$data = JsonResponse::input();
$mediaId = filter_var($data['media_id'] ?? null, FILTER_VALIDATE_INT);
$visibility = $data['visibility'] ?? '';
if ($mediaId === false || $mediaId < 1
    || !is_string($visibility) || !in_array($visibility, ['private', 'family'], true)) {
    JsonResponse::error('Invalid media visibility request', 422);
}

try {
    $db->beginTransaction();
    $stmt = $db->prepare(
        "SELECT media.id, media.member_id, media.visibility, member.family_id,
                member.user_id, member.member_status, family.status AS family_status
         FROM media
         INNER JOIN family_members member ON member.id = media.member_id
         INNER JOIN families family ON family.id = member.family_id
         WHERE media.id = ?
         LIMIT 1 FOR UPDATE"
    );
    $stmt->execute([(int) $mediaId]);
    $media = $stmt->fetch();
    if (!$media || $media['member_status'] !== 'active' || $media['family_status'] !== 'active') {
        $db->rollBack();
        JsonResponse::error('Media is unavailable', 404);
    }
    $member = Auth::requireFamilyMember((int) $media['family_id']);
    if ((int) $media['user_id'] !== (int) $user['id']
        || (int) $member['id'] !== (int) $media['member_id']) {
        $db->rollBack();
        JsonResponse::error('Only the active profile owner can change media visibility', 403);
    }

    if ($media['visibility'] !== $visibility) {
        $update = $db->prepare('UPDATE media SET visibility = ? WHERE id = ? AND member_id = ?');
        $update->execute([$visibility, (int) $mediaId, (int) $media['member_id']]);
        if ($update->rowCount() !== 1) {
            $db->rollBack();
            JsonResponse::error('Media visibility has already changed', 409);
        }
        Audit::log('media_visibility_changed', (int) $media['family_id'], 'media', (int) $mediaId, [
            'visibility' => $visibility,
        ]);
    }
    $db->commit();
    JsonResponse::ok(['visibility' => $visibility]);
} catch (Throwable $e) {
    if ($db->inTransaction()) {
        $db->rollBack();
    }
    error_log('Media visibility update failed: ' . $e->getMessage());
    JsonResponse::error('Could not update media visibility', 500);
}
