<?php
declare(strict_types=1);

require_once __DIR__ . '/../../../src/bootstrap.php';

if (($_SERVER['REQUEST_METHOD'] ?? '') !== 'POST') {
    header('Allow: POST');
    JsonResponse::error('Method not allowed', 405);
}
Security::requireCsrf();
$user = Auth::requireLogin();
$memberId = filter_var($_POST['member_id'] ?? null, FILTER_VALIDATE_INT);
if ($memberId === false || $memberId < 1) JsonResponse::error('Invalid member ID', 422);
$memberStmt = $db->prepare(
    "SELECT id, family_id, user_id, member_status FROM family_members WHERE id = ? LIMIT 1"
);
$memberStmt->execute([(int) $memberId]); $member = $memberStmt->fetch();
if (!$member || $member['member_status'] !== 'active') JsonResponse::error('Member not found', 404);
$requester = Auth::requireFamilyMember((int) $member['family_id']);
if ((int) $member['user_id'] !== (int) $user['id'] || (int) $requester['id'] !== (int) $member['id']) {
    JsonResponse::error('Members may upload files only to their own active profile', 403);
}

$file = $_FILES['file'] ?? null;
if (!is_array($file) || ($file['error'] ?? UPLOAD_ERR_NO_FILE) !== UPLOAD_ERR_OK
    || !is_uploaded_file((string) ($file['tmp_name'] ?? '')) || (int) ($file['size'] ?? 0) < 1) {
    JsonResponse::error('Choose a valid file to upload', 422);
}
$allowed = [
    'image/jpeg' => ['photo', 'jpg', 5 * 1024 * 1024],
    'image/png' => ['photo', 'png', 5 * 1024 * 1024],
    'image/webp' => ['photo', 'webp', 5 * 1024 * 1024],
    'application/pdf' => ['document', 'pdf', 10 * 1024 * 1024],
    'video/mp4' => ['video', 'mp4', 100 * 1024 * 1024],
    'video/webm' => ['video', 'webm', 100 * 1024 * 1024],
];
$mime = (new finfo(FILEINFO_MIME_TYPE))->file((string) $file['tmp_name']);
if (!is_string($mime) || !isset($allowed[$mime])) JsonResponse::error('File type not allowed', 415);
[$mediaType, $extension, $maxBytes] = $allowed[$mime];
if ((int) $file['size'] > $maxBytes) JsonResponse::error('File too large', 413);
$originalName = basename(str_replace('\\', '/', (string) ($file['name'] ?? 'file')));
$originalName = preg_replace('/[\x00-\x1F\x7F]/u', '', $originalName) ?: 'file';
$originalName = mb_substr($originalName, 0, 255);
$root = realpath((string) ($config['upload']['private_root'] ?? ''));
if ($root === false || !is_dir($root)) JsonResponse::error('Private storage is unavailable', 503);
$familyDir = $root . DIRECTORY_SEPARATOR . 'family_' . (int) $member['family_id'];
if (!is_dir($familyDir) && !mkdir($familyDir, 0700, true)) JsonResponse::error('Storage unavailable', 500);
$resolvedFamilyDir = realpath($familyDir);
if ($resolvedFamilyDir === false || stripos($resolvedFamilyDir, rtrim($root, DIRECTORY_SEPARATOR) . DIRECTORY_SEPARATOR) !== 0) {
    JsonResponse::error('Storage unavailable', 500);
}
$storedName = bin2hex(random_bytes(24)) . '.' . $extension;
$destination = $resolvedFamilyDir . DIRECTORY_SEPARATOR . $storedName;
if (!move_uploaded_file((string) $file['tmp_name'], $destination)) JsonResponse::error('Could not store file', 500);
$sha = hash_file('sha256', $destination);
if (!is_string($sha)) { @unlink($destination); JsonResponse::error('Could not verify uploaded file', 500); }

try {
    $db->beginTransaction();
    $insert = $db->prepare(
        "INSERT INTO media (member_id, media_type, original_name, stored_name, mime_type,
                            file_size, sha256, storage_path, visibility)
         VALUES (?, ?, ?, ?, ?, ?, ?, ?, 'private')"
    );
    $insert->execute([(int) $member['id'], $mediaType, $originalName, $storedName, $mime,
        (int) $file['size'], $sha, $destination]);
    $mediaId = (int) $db->lastInsertId();
    Audit::log('media_uploaded', (int) $member['family_id'], 'media', $mediaId, ['media_type' => $mediaType]);
    $db->commit();
    JsonResponse::ok(['media_id' => $mediaId, 'media_type' => $mediaType], 201);
} catch (Throwable $e) {
    if ($db->inTransaction()) $db->rollBack();
    @unlink($destination);
    error_log('Media upload failed: ' . $e->getMessage());
    JsonResponse::error('Could not complete file upload', 500);
}
