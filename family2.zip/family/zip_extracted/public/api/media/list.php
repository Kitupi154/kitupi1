<?php
declare(strict_types=1);

require_once __DIR__ . '/../../../src/bootstrap.php';

if (($_SERVER['REQUEST_METHOD'] ?? '') !== 'GET') {
    header('Allow: GET');
    JsonResponse::error('Method not allowed', 405);
}

$user = Auth::requireLogin();
$memberId = filter_var($_GET['member_id'] ?? null, FILTER_VALIDATE_INT);
if ($memberId === false || $memberId < 1) {
    JsonResponse::error('Invalid member ID', 422);
}

$memberStmt = $db->prepare(
    "SELECT id, family_id, user_id
     FROM family_members
     WHERE id = ? AND member_status = 'active'
     LIMIT 1"
);
$memberStmt->execute([$memberId]);
$member = $memberStmt->fetch();
if (!$member) {
    JsonResponse::error('Member not found', 404);
}

$requester = Auth::requireFamilyViewer((int) $member['family_id']);
$isOwner = (int) $member['user_id'] === (int) $user['id'];
$stmt = $db->prepare(
    "SELECT media.id, media.media_type, media.original_name, media.mime_type,
            media.file_size, media.visibility, media.created_at
     FROM media
     WHERE media.member_id = ?
       AND (
           ? = 1
           OR media.visibility = 'family'
           OR (
               media.visibility IN ('private', 'permissioned')
               AND EXISTS (
                   SELECT 1
                   FROM permissions permission
                   INNER JOIN family_roles owner_role
                     ON owner_role.member_id = permission.owner_member_id
                    AND owner_role.family_id = permission.family_id
                   INNER JOIN family_members owner
                     ON owner.id = permission.owner_member_id
                    AND owner.family_id = permission.family_id
                    AND owner.member_status = 'active'
                    AND owner.user_id IS NOT NULL
                   INNER JOIN users owner_account
                     ON owner_account.id = owner.user_id
                    AND owner_account.status = 'active'
                   INNER JOIN family_members requester_member
                     ON requester_member.id = permission.requester_member_id
                    AND requester_member.family_id = permission.family_id
                    AND requester_member.member_status = 'active'
                   INNER JOIN families family
                     ON family.id = permission.family_id
                    AND family.status = 'active'
                   WHERE permission.family_id = ?
                     AND permission.owner_member_id = media.member_id
                     AND permission.requester_member_id = ?
                     AND permission.resource_type = CASE media.media_type
                         WHEN 'photo' THEN 'photo'
                         WHEN 'video' THEN 'video'
                         WHEN 'document' THEN 'document'
                         ELSE ''
                     END
                     AND (permission.resource_id IS NULL OR permission.resource_id = media.id)
                     AND permission.status = 'approved'
                     AND (permission.expires_at IS NULL OR permission.expires_at > NOW())
                     AND owner_role.role IN ('admin', 'member')
               )
           )
       )
     ORDER BY media.created_at DESC, media.id DESC"
);
$stmt->execute([
    (int) $member['id'],
    $isOwner ? 1 : 0,
    (int) $member['family_id'],
    (int) $requester['id'],
]);

JsonResponse::ok(['media' => $stmt->fetchAll()]);
