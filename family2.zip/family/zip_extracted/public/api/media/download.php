<?php
declare(strict_types=1);

require_once __DIR__ . '/../../../src/bootstrap.php';

if (($_SERVER['REQUEST_METHOD'] ?? '') !== 'GET') {
    header('Allow: GET');
    JsonResponse::error('Method not allowed', 405);
}

$user = Auth::requireLogin();
$mediaId = filter_var($_GET['media_id'] ?? null, FILTER_VALIDATE_INT);
if ($mediaId === false || $mediaId < 1) {
    JsonResponse::error('Invalid media ID', 422);
}

$stmt = $db->prepare(
    "SELECT media.id, media.storage_path, media.media_type, media.mime_type, media.original_name,
            media.visibility, family_member.id AS member_id,
            family_member.family_id, family_member.user_id,
            family_member.member_status
     FROM media
     INNER JOIN family_members family_member ON family_member.id = media.member_id
     WHERE media.id = ?"
);
$stmt->execute([$mediaId]);
$media = $stmt->fetch();
if (!$media) {
    JsonResponse::error('Media not found', 404);
}

$requester = Auth::requireFamilyViewer((int) $media['family_id']);
$isOwner = (int) $media['user_id'] === (int) $user['id'];
$canAccess = $isOwner || $media['visibility'] === 'family';
if (!$canAccess) {
    $permissionStmt = $db->prepare(
        "SELECT permission.id
         FROM permissions permission
         INNER JOIN family_roles owner_role
           ON owner_role.member_id = permission.owner_member_id
          AND owner_role.family_id = permission.family_id
         INNER JOIN family_members owner
           ON owner.id = permission.owner_member_id
          AND owner.family_id = permission.family_id
          AND owner.member_status = 'active'
          AND owner.user_id IS NOT NULL
         INNER JOIN users owner_account
           ON owner_account.id = owner.user_id
          AND owner_account.status = 'active'
         INNER JOIN family_members requester_member
           ON requester_member.id = permission.requester_member_id
          AND requester_member.family_id = permission.family_id
          AND requester_member.member_status = 'active'
         INNER JOIN families family
           ON family.id = permission.family_id AND family.status = 'active'
         WHERE permission.family_id = ?
           AND permission.owner_member_id = ?
           AND permission.requester_member_id = ?
           AND permission.resource_type = ?
           AND (permission.resource_id IS NULL OR permission.resource_id = ?)
           AND permission.status = 'approved'
           AND (permission.expires_at IS NULL OR permission.expires_at > NOW())
           AND owner_role.role IN ('admin', 'member')
         LIMIT 1"
    );
    $permissionStmt->execute([
        (int) $media['family_id'],
        (int) $media['member_id'],
        (int) $requester['id'],
        (string) $media['media_type'],
        (int) $media['id'],
    ]);
    $canAccess = (bool) $permissionStmt->fetch();
}
if ($media['member_status'] !== 'active') {
    JsonResponse::error('Media is unavailable', 404);
}
if (!$canAccess) {
    JsonResponse::error('Not authorized to view this media', 403);
}

$allowedTypes = [
    'image/jpeg',
    'image/png',
    'image/webp',
    'application/pdf',
    'video/mp4',
    'video/webm',
    'audio/mpeg',
    'audio/mp4',
    'audio/ogg',
    'audio/wav',
    'audio/webm',
];
if (!in_array($media['mime_type'], $allowedTypes, true)) {
    JsonResponse::error('This media type cannot be previewed', 415);
}

$privateRoot = realpath($config['upload']['private_root']);
$storedPath = realpath($media['storage_path']);
if ($privateRoot === false || $storedPath === false
    || !is_file($storedPath)
    || stripos($storedPath, rtrim($privateRoot, DIRECTORY_SEPARATOR) . DIRECTORY_SEPARATOR) !== 0) {
    JsonResponse::error('Media is unavailable', 404);
}

$filename = basename((string) $media['original_name']);
header('Content-Type: ' . $media['mime_type']);
header('Content-Disposition: inline; filename*=UTF-8\'\'' . rawurlencode($filename));
header('Content-Length: ' . (string) filesize($storedPath));
header('Cache-Control: private, no-store');
header('X-Content-Type-Options: nosniff');
readfile($storedPath);
exit;
