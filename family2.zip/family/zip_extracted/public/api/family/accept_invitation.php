<?php
declare(strict_types=1);

require_once __DIR__ . '/../../../src/bootstrap.php';

if (($_SERVER['REQUEST_METHOD'] ?? '') === 'GET') {
    $token = $_GET['token'] ?? '';
    if (!is_string($token) || !preg_match('/\A[a-f0-9]{64}\z/i', $token)) {
        JsonResponse::error('Invalid invitation details', 422);
    }

    $tokenHash = hash('sha256', strtolower($token));
    try {
        $stmt = $db->prepare(
            "SELECT fi.id, fi.family_id, fi.member_id, fi.invitee_email, fi.invited_role,
                    fi.status, fi.expires_at, f.family_name, f.status AS family_status,
                    fm.first_name, fm.last_name, fm.user_id AS member_user_id,
                    fm.member_status
             FROM family_invitations fi
             INNER JOIN families f ON f.id = fi.family_id
             LEFT JOIN family_members fm ON fm.id = fi.member_id
             WHERE fi.token_hash = ?
             LIMIT 1"
        );
        $stmt->execute([$tokenHash]);
        $invitation = $stmt->fetch();
        if (!$invitation) {
            JsonResponse::error('Invitation link is invalid or no longer available', 404);
        }

        if ($invitation['status'] !== 'pending') {
            JsonResponse::error('Invitation has already been used or revoked', 409);
        }

        if ($invitation['family_status'] !== 'active') {
            JsonResponse::error('This family is not accepting invitations', 409);
        }

        if ((string) $invitation['expires_at'] <= date('Y-m-d H:i:s')) {
            $db->prepare(
                "UPDATE family_invitations SET status = 'expired'
                 WHERE id = ? AND status = 'pending'"
            )->execute([(int) $invitation['id']]);
            JsonResponse::error('Invitation has expired', 410);
        }
        if ($invitation['invited_role'] !== 'member'
            || (int) ($invitation['member_id'] ?? 0) < 1) {
            JsonResponse::error('This invitation is not for an unclaimed family member profile', 409);
        }
        if ($invitation['member_status'] !== 'unclaimed'
            || $invitation['member_user_id'] !== null) {
            JsonResponse::error('This invitation targets a profile that is no longer available to claim', 409);
        }

        $email = strtolower((string) $invitation['invitee_email']);
        $existing = $db->prepare('SELECT id FROM users WHERE LOWER(email) = ? LIMIT 1');
        $existing->execute([$email]);
        $accountExists = $existing->fetchColumn() !== false;

        JsonResponse::ok([
            'invitee_email' => $email,
            'family_name' => $invitation['family_name'],
            'family_id' => (int) $invitation['family_id'],
            'member_id' => $invitation['member_id'] !== null ? (int) $invitation['member_id'] : null,
            'member_full_name' => trim(((string) ($invitation['first_name'] ?? '')) . ' ' . ((string) ($invitation['last_name'] ?? ''))) ?: null,
            'requires_account_creation' => !$accountExists,
            'account_exists' => $accountExists,
        ]);
    } catch (Throwable $e) {
        error_log('Invitation lookup failed (' . get_class($e) . ')');
        JsonResponse::error('Could not load invitation details', 500);
    }
}

if (($_SERVER['REQUEST_METHOD'] ?? '') !== 'POST') {
    header('Allow: POST, GET');
    JsonResponse::error('Method not allowed', 405);
}

$data = JsonResponse::input();
$action = strtolower((string) ($data['action'] ?? 'accept'));

if ($action === 'claim_account') {
    Security::requireCsrf();
    if (!empty($_SESSION['user_id'])) {
        JsonResponse::error('Sign out before creating an invitation account in this browser.', 409);
    }

    $token = $data['token'] ?? null;
    $phone = Security::cleanString($data['phone'] ?? '', 30);
    $password = (string) ($data['password'] ?? '');
    $passwordConfirm = (string) ($data['password_confirm'] ?? '');
    if (!is_string($token) || !preg_match('/\A[a-f0-9]{64}\z/i', $token)
        || $phone === ''
        || !Security::validatePassword($password)
        || $password !== $passwordConfirm) {
        JsonResponse::error('Provide a valid invitation, phone number, and matching password.', 422);
    }

    $tokenHash = hash('sha256', strtolower($token));

    try {
        $db->beginTransaction();
        $lookup = $db->prepare(
            "SELECT fi.id, fi.family_id, fi.member_id, fi.invitee_email, fi.invited_role, fi.status, fi.expires_at,
                    f.family_name
             FROM family_invitations fi
             INNER JOIN families f ON f.id = fi.family_id
             WHERE fi.token_hash = ?
             LIMIT 1
             FOR UPDATE"
        );
        $lookup->execute([$tokenHash]);
        $invitation = $lookup->fetch();
        if (!$invitation) {
            $db->rollBack();
            JsonResponse::error('Invitation link is invalid or no longer available', 404);
        }
        if ($invitation['status'] !== 'pending') {
            $db->rollBack();
            JsonResponse::error('Invitation has already been used or revoked', 409);
        }
        if ($invitation['invited_role'] !== 'member') {
            $db->rollBack();
            JsonResponse::error('Only Family Member invitations can create an invitation account', 403);
        }
        if ((string) $invitation['expires_at'] <= date('Y-m-d H:i:s')) {
            $db->prepare(
                "UPDATE family_invitations SET status = 'expired'
                 WHERE id = ? AND status = 'pending'"
            )->execute([(int) $invitation['id']]);
            $db->commit();
            JsonResponse::error('Invitation has expired', 410);
        }

        $email = strtolower((string) $invitation['invitee_email']);
        $existing = $db->prepare('SELECT id, status, email_verified_at FROM users WHERE LOWER(email) = ? LIMIT 1 FOR UPDATE');
        $existing->execute([$email]);
        $account = $existing->fetch();
        if ($account) {
            $db->rollBack();
            JsonResponse::error('An account already exists for this invitation email. Sign in and verify it before accepting the invitation.', 409);
        }

        $memberId = $invitation['member_id'] !== null ? (int) $invitation['member_id'] : 0;
        if ($memberId <= 0) {
            $db->rollBack();
            JsonResponse::error('This invitation is not linked to an existing family member profile.', 409);
        }
        $memberStmt = $db->prepare(
            "SELECT id, family_id, user_id, member_status, first_name, last_name
             FROM family_members
             WHERE id = ? AND family_id = ? AND member_status = 'unclaimed'
             FOR UPDATE"
        );
        $memberStmt->execute([$memberId, (int) $invitation['family_id']]);
        $member = $memberStmt->fetch();
        if (!$member || (int) ($member['user_id'] ?? 0) !== 0) {
            $db->rollBack();
            JsonResponse::error('This invitation targets a member profile that is not currently available to claim.', 409);
        }

        $userId = null;
        $hash = Security::passwordHash($password);
        $userInsert = $db->prepare(
            "INSERT INTO users (email, phone, password_hash, status)
             VALUES (?, ?, ?, 'pending')"
        );
        $userInsert->execute([$email, $phone, $hash]);
        $userId = (int) $db->lastInsertId();

        $db->prepare(
            "UPDATE otp_challenges
             SET consumed_at = NOW()
             WHERE user_id = ? AND channel = 'email' AND consumed_at IS NULL"
        )->execute([$userId]);

        $code = (string) random_int(100000, 999999);
        $codeHash = password_hash($code, PASSWORD_DEFAULT);
        if ($codeHash === false) {
            $db->rollBack();
            JsonResponse::error('Could not create the verification code for this invitation.', 500);
        }

        $expires = date('Y-m-d H:i:s', time() + (int) ($config['otp']['ttl_seconds'] ?? 600));
        $otpInsert = $db->prepare(
            "INSERT INTO otp_challenges (user_id, channel, destination, code_hash, expires_at)
             VALUES (?, 'email', ?, ?, ?)"
        );
        $otpInsert->execute([$userId, $email, $codeHash, $expires]);

        $sent = false;
        try {
            $sent = Mailer::sendOtp($email, $code);
        } catch (Throwable $e) {
            $sent = false;
        }

        if (!$sent) {
            $db->rollBack();
            JsonResponse::error('The verification code could not be saved to the local development mail file. Please try again.', 500);
        }

        $db->prepare(
            "UPDATE family_invitations
             SET invited_user_id = ?
             WHERE id = ? AND invited_user_id IS NULL"
        )->execute([$userId, (int) $invitation['id']]);

        Auth::login($userId);
        Audit::log('invitation_account_created', (int) $invitation['family_id'], 'family_invitation', (int) $invitation['id'], ['member_id' => $invitation['member_id'] ?? null]);
        $db->commit();
        $_SESSION['pending_family_invitation_hash'] = $tokenHash;

        JsonResponse::ok([
            'message' => 'Account created. Verify your email to complete the invitation claim.',
            'redirect' => 'verify-email',
            'invitee_email' => $email,
        ]);
    } catch (Throwable $e) {
        if ($db->inTransaction()) {
            $db->rollBack();
        }
        error_log('Invitation account creation failed (' . get_class($e) . ')');
        JsonResponse::error('Could not create the invitation account', 500);
    }
}

$user = Auth::requireLogin();
Security::requireCsrf();
if ($user['email_verified_at'] === null) {
    JsonResponse::error('Verify your email before accepting a family invitation', 403);
}

$data = JsonResponse::input();
$token = $data['token'] ?? null;
if (!is_string($token) || !preg_match('/\A[a-f0-9]{64}\z/i', $token)) {
    JsonResponse::error('Invalid invitation details', 422);
}

try {
    $result = FamilyInvitation::acceptForUser(
        (int) $user['id'],
        hash('sha256', strtolower($token))
    );
    unset($_SESSION['pending_family_invitation_hash']);
    JsonResponse::ok($result);
} catch (FamilyInvitationException $e) {
    JsonResponse::error($e->getMessage(), $e->statusCode());
} catch (Throwable $e) {
    error_log('Family invitation acceptance failed (' . get_class($e) . ')');
    JsonResponse::error('Could not accept this family invitation', 500);
}
