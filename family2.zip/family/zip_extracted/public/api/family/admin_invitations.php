<?php
declare(strict_types=1);

require_once __DIR__ . '/../../../src/bootstrap.php';

$method = $_SERVER['REQUEST_METHOD'] ?? '';
if ($method !== 'GET' && $method !== 'POST') {
    header('Allow: GET, POST');
    JsonResponse::error('Method not allowed', 405);
}

$user = Auth::requireLogin();

if ($method === 'GET') {
    $stmt = $db->prepare(
        "SELECT invitation.id, invitation.family_id, family.family_name,
                invitation.created_at, invitation.expires_at,
                inviter.email AS invited_by_email
         FROM family_admin_invitations invitation
         INNER JOIN families family ON family.id = invitation.family_id
         LEFT JOIN users inviter ON inviter.id = invitation.invited_by_user_id
         WHERE invitation.invited_user_id = ?
           AND invitation.status = 'pending'
           AND invitation.expires_at > NOW()
           AND family.status = 'active'
         ORDER BY invitation.created_at DESC, invitation.id DESC"
    );
    $stmt->execute([(int) $user['id']]);
    JsonResponse::ok(['invitations' => $stmt->fetchAll()]);
}

Security::requireCsrf();
$data = JsonResponse::input();
$user = Auth::requireLogin();
if ($user['email_verified_at'] === null) {
    JsonResponse::error('Verify your email before accepting a Family Admin invitation', 403);
}
$invitationId = filter_var($data['invitation_id'] ?? null, FILTER_VALIDATE_INT);
$firstValue = $data['first_name'] ?? '';
$lastValue = $data['last_name'] ?? '';
if ($invitationId === false || $invitationId < 1
    || !is_string($firstValue) || !is_string($lastValue)) {
    JsonResponse::error('Invalid invitation details', 422);
}

$firstName = Security::cleanString($firstValue, 100);
$lastName = Security::cleanString($lastValue, 100);

try {
    $db->beginTransaction();

    $lookup = $db->prepare(
        "SELECT family_id FROM family_admin_invitations
         WHERE id = ? AND invited_user_id = ?"
    );
    $lookup->execute([$invitationId, (int) $user['id']]);
    $familyId = $lookup->fetchColumn();
    if (!$familyId) {
        $db->rollBack();
        JsonResponse::error('Invitation not found', 404);
    }
    $familyId = (int) $familyId;

    $familyStmt = $db->prepare(
        "SELECT id, status FROM families WHERE id = ? FOR UPDATE"
    );
    $familyStmt->execute([$familyId]);
    $family = $familyStmt->fetch();
    if (!$family || $family['status'] !== 'active') {
        $db->rollBack();
        JsonResponse::error('Invitation family is not active', 409);
    }

    $invitationStmt = $db->prepare(
        "SELECT id, status, expires_at, (expires_at <= NOW()) AS is_expired
         FROM family_admin_invitations
         WHERE id = ? AND family_id = ? AND invited_user_id = ?
         FOR UPDATE"
    );
    $invitationStmt->execute([$invitationId, $familyId, (int) $user['id']]);
    $invitation = $invitationStmt->fetch();
    if (!$invitation || $invitation['status'] !== 'pending') {
        $db->rollBack();
        JsonResponse::error('Invitation is no longer pending or has already been used', 409);
    }

    if ((int) $invitation['is_expired'] === 1) {
        $db->prepare(
            "UPDATE family_admin_invitations SET status = 'expired'
             WHERE id = ? AND status = 'pending'"
        )->execute([$invitationId]);
        Audit::log(
            'family_admin_invitation_expired',
            $familyId,
            'family_admin_invitation',
            (int) $invitationId
        );
        $db->commit();
        JsonResponse::error('Invitation has expired', 410);
    }

    $memberStmt = $db->prepare(
        "SELECT id, member_status FROM family_members
         WHERE family_id = ? AND user_id = ?
         ORDER BY id ASC FOR UPDATE"
    );
    $memberStmt->execute([$familyId, (int) $user['id']]);
    $members = $memberStmt->fetchAll();
    if (count($members) > 1) {
        $db->rollBack();
        JsonResponse::error('Multiple family profiles are linked to this account; contact support', 409);
    }
    $member = $members[0] ?? null;
    if ($member && in_array($member['member_status'], ['removed', 'suspended'], true)) {
        $db->rollBack();
        JsonResponse::error('This family profile is not eligible for activation', 409);
    }
    if (!$member && ($firstName === '' || $lastName === '')) {
        $db->rollBack();
        JsonResponse::error('First and last name are required to accept this invitation', 422);
    }

    if ($member) {
        $memberId = (int) $member['id'];
        if ($member['member_status'] !== 'active') {
            $db->prepare(
                "UPDATE family_members SET member_status = 'active'
                 WHERE id = ? AND family_id = ?"
            )->execute([$memberId, $familyId]);
        }
    } else {
        $insertMember = $db->prepare(
            "INSERT INTO family_members
             (family_id, user_id, first_name, last_name, member_status)
             VALUES (?, ?, ?, ?, 'active')"
        );
        $insertMember->execute([$familyId, (int) $user['id'], $firstName, $lastName]);
        $memberId = (int) $db->lastInsertId();
    }

    $pendingRequestsStmt = $db->prepare(
        "SELECT id FROM membership_requests
         WHERE family_id = ? AND applicant_member_id = ? AND status = 'pending'
         FOR UPDATE"
    );
    $pendingRequestsStmt->execute([$familyId, $memberId]);
    foreach ($pendingRequestsStmt->fetchAll() as $pendingRequest) {
        $db->prepare(
            "UPDATE membership_requests
             SET status = 'cancelled', reviewed_by_member_id = ?, reviewed_at = NOW()
             WHERE id = ? AND status = 'pending'"
        )->execute([$memberId, (int) $pendingRequest['id']]);
        Audit::log(
            'membership_request_cancelled_by_admin_invitation',
            $familyId,
            'membership_request',
            (int) $pendingRequest['id'],
            ['invitation_id' => (int) $invitationId]
        );
    }

    $db->prepare(
        "INSERT INTO family_roles (family_id, member_id, role)
         VALUES (?, ?, 'admin')
         ON DUPLICATE KEY UPDATE role = 'admin'"
    )->execute([$familyId, $memberId]);

    $db->prepare(
        "UPDATE family_admin_invitations
         SET status = 'accepted', accepted_at = NOW()
         WHERE id = ? AND status = 'pending'"
    )->execute([$invitationId]);
    Audit::log(
        'family_admin_invitation_accepted',
        $familyId,
        'family_admin_invitation',
        (int) $invitationId,
        ['member_id' => $memberId]
    );
    $db->commit();

    JsonResponse::ok([
        'message' => 'Invitation accepted. You are now a Family Admin for this family.',
        'family_id' => $familyId,
    ]);
} catch (Throwable $e) {
    if ($db->inTransaction()) {
        $db->rollBack();
    }
    error_log('Family administrator invitation acceptance failed: ' . $e->getMessage());
    JsonResponse::error('Could not accept family administrator invitation', 500);
}
