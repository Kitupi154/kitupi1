<?php
declare(strict_types=1);

require_once __DIR__ . '/../../../src/bootstrap.php';

if (($_SERVER['REQUEST_METHOD'] ?? '') !== 'POST') {
    header('Allow: POST');
    JsonResponse::error('Method not allowed', 405);
}

Security::requireCsrf();
$user = Auth::requireSuperAdmin();
$data = JsonResponse::input();
$nameValue = $data['family_name'] ?? '';
$firstValue = $data['first_name'] ?? '';
$lastValue = $data['last_name'] ?? '';
if (!is_string($nameValue) || !is_string($firstValue) || !is_string($lastValue)) {
    JsonResponse::error('Invalid family or member name', 422);
}
$name = Security::cleanString($nameValue, 190);
$first = Security::cleanString($firstValue, 100);
$last = Security::cleanString($lastValue, 100);
if ($name === '' || $first === '' || $last === '') {
    JsonResponse::error('Family and member names are required', 422);
}

try {
    $db->beginTransaction();
    $stmt = $db->prepare('INSERT INTO families (family_name, created_by_user_id) VALUES (?, ?)');
    $stmt->execute([$name, (int) $user['id']]);
    $familyId = (int) $db->lastInsertId();

    $stmt = $db->prepare(
        "INSERT INTO family_members (family_id, user_id, first_name, last_name, member_status)
         VALUES (?, ?, ?, ?, 'active')"
    );
    $stmt->execute([$familyId, (int) $user['id'], $first, $last]);
    $memberId = (int) $db->lastInsertId();

    $stmt = $db->prepare(
        "INSERT INTO family_roles (family_id, member_id, role) VALUES (?, ?, 'admin')"
    );
    $stmt->execute([$familyId, $memberId]);

    Audit::log('family_created', $familyId, 'family', $familyId);
    $db->commit();
    JsonResponse::ok(['family_id' => $familyId, 'member_id' => $memberId], 201);
} catch (Throwable $e) {
    if ($db->inTransaction()) {
        $db->rollBack();
    }
    error_log('Family creation failed: ' . $e->getMessage());
    JsonResponse::error('Could not create family', 500);
}
