<?php
declare(strict_types=1);

require_once __DIR__ . '/../../../src/bootstrap.php';

$method = $_SERVER['REQUEST_METHOD'] ?? '';
if ($method !== 'GET' && $method !== 'POST') {
    header('Allow: GET, POST');
    JsonResponse::error('Method not allowed', 405);
}

if ($method === 'GET') {
    $familyId = filter_var($_GET['family_id'] ?? null, FILTER_VALIDATE_INT);
    if ($familyId === false || $familyId < 1) {
        JsonResponse::error('Invalid family ID', 422);
    }
    $actor = Auth::requireFamilyAdmin((int) $familyId);

    try {
        $adminsStmt = $db->prepare(
            "SELECT member.id AS member_id, member.first_name, member.middle_name,
                    member.last_name, member.created_at,
                    CASE WHEN member.user_id = ? THEN 1 ELSE 0 END AS is_current
             FROM family_roles role
             INNER JOIN family_members member
               ON member.id = role.member_id AND member.family_id = role.family_id
             INNER JOIN users account
               ON account.id = member.user_id AND account.status = 'active'
             INNER JOIN families family
               ON family.id = role.family_id AND family.status = 'active'
             WHERE role.family_id = ? AND role.role = 'admin'
               AND member.member_status = 'active'
             ORDER BY is_current DESC, member.first_name, member.last_name, member.id"
        );
        $adminsStmt->execute([(int) $actor['user_id'], (int) $familyId]);

        $invitationsStmt = $db->prepare(
            "SELECT invitation.id, account.email, invitation.created_at, invitation.expires_at
             FROM family_admin_invitations invitation
             INNER JOIN users account ON account.id = invitation.invited_user_id
             WHERE invitation.family_id = ? AND invitation.status = 'pending'
               AND invitation.expires_at > NOW()
             ORDER BY invitation.created_at DESC, invitation.id DESC"
        );
        $invitationsStmt->execute([(int) $familyId]);

        JsonResponse::ok([
            'administrators' => $adminsStmt->fetchAll(),
            'pending_invitations' => $invitationsStmt->fetchAll(),
        ]);
    } catch (Throwable $e) {
        error_log('Family administrator list query failed: ' . $e->getMessage());
        JsonResponse::error('Could not load family administrators', 500);
    }
}

Security::requireCsrf();
$data = JsonResponse::input();
$familyId = filter_var($data['family_id'] ?? null, FILTER_VALIDATE_INT);
$action = $data['action'] ?? 'invite';
if (!is_string($action) || !in_array($action, ['invite', 'revoke'], true)) {
    JsonResponse::error('Invalid administrator invitation action', 422);
}
if ($action === 'revoke') {
    $invitationId = filter_var($data['invitation_id'] ?? null, FILTER_VALIDATE_INT);
    if ($familyId === false || $familyId < 1 || $invitationId === false || $invitationId < 1) {
        JsonResponse::error('Invalid family or invitation ID', 422);
    }
    try {
        $db->beginTransaction();
        $familyStmt = $db->prepare("SELECT id FROM families WHERE id = ? AND status = 'active' FOR UPDATE");
        $familyStmt->execute([(int) $familyId]);
        if (!$familyStmt->fetch()) {
            $db->rollBack();
            JsonResponse::error('Active family not found', 404);
        }
        Auth::requireFamilyAdmin((int) $familyId);
        $invitationStmt = $db->prepare(
            "SELECT id FROM family_admin_invitations
             WHERE id = ? AND family_id = ? AND status = 'pending' AND expires_at > NOW()
             FOR UPDATE"
        );
        $invitationStmt->execute([(int) $invitationId, (int) $familyId]);
        if (!$invitationStmt->fetch()) {
            $db->rollBack();
            JsonResponse::error('Pending invitation not found', 404);
        }
        $db->prepare(
            "UPDATE family_admin_invitations SET status = 'revoked'
             WHERE id = ? AND family_id = ? AND status = 'pending'"
        )->execute([(int) $invitationId, (int) $familyId]);
        Audit::log('family_admin_invitation_revoked', (int) $familyId,
            'family_admin_invitation', (int) $invitationId);
        $db->commit();
        JsonResponse::ok(['message' => 'Family Admin invitation revoked']);
    } catch (Throwable $e) {
        if ($db->inTransaction()) {
            $db->rollBack();
        }
        error_log('Family administrator invitation revocation failed: ' . $e->getMessage());
        JsonResponse::error('Could not revoke Family Admin invitation', 500);
    }
}

$emailValue = $data['email'] ?? null;
if ($familyId === false || $familyId < 1 || !is_string($emailValue)
    || strlen($emailValue) > 190 || filter_var(trim($emailValue), FILTER_VALIDATE_EMAIL) === false) {
    JsonResponse::error('Enter a valid family and account email', 422);
}
$email = mb_strtolower(trim($emailValue));

try {
    $db->beginTransaction();
    $familyStmt = $db->prepare("SELECT id FROM families WHERE id = ? AND status = 'active' FOR UPDATE");
    $familyStmt->execute([(int) $familyId]);
    if (!$familyStmt->fetch()) {
        $db->rollBack();
        JsonResponse::error('Active family not found', 404);
    }

    $actor = Auth::requireFamilyAdmin((int) $familyId);
    $accountStmt = $db->prepare(
        "SELECT id, email FROM users
         WHERE email = ? AND status = 'active' AND email_verified_at IS NOT NULL
         LIMIT 1 FOR UPDATE"
    );
    $accountStmt->execute([$email]);
    $account = $accountStmt->fetch();
    if (!$account) {
        $db->rollBack();
        JsonResponse::error('No active account with a verified matching email was found', 404);
    }
    if ((int) $account['id'] === (int) $actor['user_id']) {
        $db->rollBack();
        JsonResponse::error('You already administer this family', 409);
    }

    $memberStmt = $db->prepare(
        "SELECT id, member_status FROM family_members
         WHERE family_id = ? AND user_id = ? ORDER BY id FOR UPDATE"
    );
    $memberStmt->execute([(int) $familyId, (int) $account['id']]);
    $members = $memberStmt->fetchAll();
    if (count($members) > 1 || ($members && in_array($members[0]['member_status'], ['removed', 'suspended'], true))) {
        $db->rollBack();
        JsonResponse::error('This account has a family profile that cannot be safely promoted', 409);
    }

    $roleStmt = $db->prepare(
        "SELECT role FROM family_roles WHERE family_id = ? AND member_id = ? FOR UPDATE"
    );
    if ($members) {
        $roleStmt->execute([(int) $familyId, (int) $members[0]['id']]);
        if ($roleStmt->fetchColumn() === 'admin' && $members[0]['member_status'] === 'active') {
            $db->rollBack();
            JsonResponse::error('This account is already a Family Admin', 409);
        }
    }

    $expiredStmt = $db->prepare(
        "SELECT id FROM family_admin_invitations
         WHERE family_id = ? AND invited_user_id = ? AND status = 'pending'
           AND expires_at <= NOW() FOR UPDATE"
    );
    $expiredStmt->execute([(int) $familyId, (int) $account['id']]);
    foreach ($expiredStmt->fetchAll() as $expired) {
        $db->prepare(
            "UPDATE family_admin_invitations SET status = 'expired'
             WHERE id = ? AND status = 'pending'"
        )->execute([(int) $expired['id']]);
        Audit::log('family_admin_invitation_expired', (int) $familyId,
            'family_admin_invitation', (int) $expired['id']);
    }

    $pendingStmt = $db->prepare(
        "SELECT id FROM family_admin_invitations
         WHERE family_id = ? AND invited_user_id = ? AND status = 'pending'
           AND expires_at > NOW() LIMIT 1 FOR UPDATE"
    );
    $pendingStmt->execute([(int) $familyId, (int) $account['id']]);
    if ($pendingStmt->fetch()) {
        $db->rollBack();
        JsonResponse::error('A pending Family Admin invitation already exists for this account', 409);
    }

    $insert = $db->prepare(
        "INSERT INTO family_admin_invitations
         (family_id, invited_user_id, invited_by_user_id, expires_at)
         VALUES (?, ?, ?, DATE_ADD(NOW(), INTERVAL 7 DAY))"
    );
    $insert->execute([(int) $familyId, (int) $account['id'], (int) $actor['user_id']]);
    $invitationId = (int) $db->lastInsertId();
    Audit::log('family_admin_invitation_created', (int) $familyId,
        'family_admin_invitation', $invitationId,
        ['invited_user_id' => (int) $account['id']]);
    $db->commit();

    JsonResponse::ok([
        'message' => 'Invitation created. The recipient can accept it after signing in.',
        'expires_in_days' => 7,
    ], 201);
} catch (Throwable $e) {
    if ($db->inTransaction()) {
        $db->rollBack();
    }
    error_log('Family administrator invitation creation failed: ' . $e->getMessage());
    JsonResponse::error('Could not create Family Admin invitation', 500);
}
