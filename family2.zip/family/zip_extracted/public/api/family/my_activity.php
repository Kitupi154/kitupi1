<?php
declare(strict_types=1);

require_once __DIR__ . '/../../../src/bootstrap.php';

if (($_SERVER['REQUEST_METHOD'] ?? '') !== 'GET') {
    header('Allow: GET');
    JsonResponse::error('Method not allowed', 405);
}

$familyId = filter_var($_GET['family_id'] ?? null, FILTER_VALIDATE_INT);
$limitValue = filter_var($_GET['limit'] ?? '25', FILTER_VALIDATE_INT);
$beforeValue = isset($_GET['before_id'])
    ? filter_var($_GET['before_id'], FILTER_VALIDATE_INT)
    : null;
if ($familyId === false || $familyId < 1
    || $limitValue === false || $limitValue < 1
    || $beforeValue === false || ($beforeValue !== null && $beforeValue < 1)) {
    JsonResponse::error('Invalid activity request', 422);
}

$user = Auth::requireLogin();
$member = Auth::requireFamilyMember((int) $familyId);
if ((int) ($member['user_id'] ?? 0) !== (int) $user['id']) {
    JsonResponse::error('Activity is available only for your own family account', 403);
}

$limit = min((int) $limitValue, 50);
$sql = 'SELECT id, action, target_type, created_at
        FROM audit_logs
        WHERE family_id = ? AND actor_user_id = ?';
$params = [(int) $familyId, (int) $user['id']];
if ($beforeValue !== null) {
    $sql .= ' AND id < ?';
    $params[] = (int) $beforeValue;
}
$sql .= ' ORDER BY id DESC LIMIT ' . ($limit + 1);

try {
    $stmt = $db->prepare($sql);
    $stmt->execute($params);
    $events = $stmt->fetchAll();
    $hasMore = count($events) > $limit;
    if ($hasMore) {
        array_pop($events);
    }
    JsonResponse::ok([
        'events' => $events,
        'has_more' => $hasMore,
        'next_cursor' => $hasMore && $events ? (int) end($events)['id'] : null,
        'page_size' => $limit,
    ]);
} catch (Throwable $e) {
    error_log('Member family activity query failed: ' . $e->getMessage());
    JsonResponse::error('Could not load family activity', 500);
}
