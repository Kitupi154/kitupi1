<?php
declare(strict_types=1);

require_once __DIR__ . '/../../../src/bootstrap.php';

if (($_SERVER['REQUEST_METHOD'] ?? '') !== 'GET') {
    header('Allow: GET');
    JsonResponse::error('Method not allowed', 405);
}

$user = Auth::requireLogin();

$stmt = $db->prepare(
    "SELECT f.id, f.family_name, f.status,
            fm.id AS member_id, fm.first_name, fm.middle_name, fm.last_name,
            fr.role
     FROM families f
     INNER JOIN family_members fm
       ON fm.family_id = f.id AND fm.user_id = ?
     INNER JOIN family_roles fr
       ON fr.family_id = f.id AND fr.member_id = fm.id
     WHERE fm.member_status = 'active'
       AND f.status = 'active'
     ORDER BY f.id"
);
$stmt->execute([(int) $user['id']]);
$families = $stmt->fetchAll();

foreach ($families as &$family) {
    $members = $db->prepare(
        "SELECT member.id, member.first_name, member.middle_name, member.preferred_name,
                member.last_name, member.member_status,
                CASE WHEN EXISTS (
                    SELECT 1
                    FROM family_roles eligible_role
                    INNER JOIN users eligible_account
                      ON eligible_account.id = member.user_id
                     AND eligible_account.status = 'active'
                    WHERE eligible_role.family_id = member.family_id
                      AND eligible_role.member_id = member.id
                      AND eligible_role.role IN ('admin', 'member')
                ) THEN 1 ELSE 0 END AS permission_owner_eligible
         FROM family_members member
         WHERE member.family_id = ?
           AND member.member_status = 'active'
         ORDER BY member.first_name, member.last_name, member.id"
    );
    $members->execute([(int) $family['id']]);
    $family['members'] = $members->fetchAll();
}
unset($family);

JsonResponse::ok(['families' => $families]);
