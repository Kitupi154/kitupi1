<?php
declare(strict_types=1);

require_once __DIR__ . '/../../../src/bootstrap.php';

if (($_SERVER['REQUEST_METHOD'] ?? '') !== 'GET') {
    header('Allow: GET');
    JsonResponse::error('Method not allowed', 405);
}

$familyId = filter_var($_GET['family_id'] ?? null, FILTER_VALIDATE_INT);
if ($familyId === false || $familyId < 1) {
    JsonResponse::error('Invalid family ID', 422);
}

$member = Auth::requireFamilyViewer((int) $familyId);
$role = (string) ($member['role'] ?? '');
$items = [];

try {
    if ($role === 'admin') {
        $membership = $db->prepare(
            "SELECT COUNT(*) FROM membership_requests
             WHERE family_id = ? AND status = 'pending'"
        );
        $membership->execute([(int) $familyId]);
        $count = (int) $membership->fetchColumn();
        if ($count > 0) {
            $items[] = [
                'title' => 'Membership requests awaiting review',
                'count' => $count,
                'url' => 'enrollment-requests.html',
            ];
        }

        $relationships = $db->prepare(
            "SELECT COUNT(*) FROM family_relationships
             WHERE family_id = ? AND status = 'pending'"
        );
        $relationships->execute([(int) $familyId]);
        $count = (int) $relationships->fetchColumn();
        if ($count > 0) {
            $items[] = [
                'title' => 'Relationship proposals awaiting review',
                'count' => $count,
                'url' => 'relationships-and-kin.html',
            ];
        }
    } elseif ($role === 'member') {
        $permissions = $db->prepare(
            "SELECT COUNT(*) FROM permissions
             WHERE family_id = ? AND owner_member_id = ? AND status = 'pending'
               AND (expires_at IS NULL OR expires_at > NOW())"
        );
        $permissions->execute([(int) $familyId, (int) $member['id']]);
        $count = (int) $permissions->fetchColumn();
        if ($count > 0) {
            $items[] = [
                'title' => 'Access requests awaiting your decision',
                'count' => $count,
                'url' => 'access-permissions.html',
            ];
        }
    }

    JsonResponse::ok([
        'family_id' => (int) $familyId,
        'role' => $role,
        'items' => $items,
        'total' => array_sum(array_column($items, 'count')),
    ]);
} catch (Throwable $e) {
    error_log('Family notification summary failed: ' . $e->getMessage());
    JsonResponse::error('Could not load family notifications', 500);
}
