<?php
declare(strict_types=1);

require_once __DIR__ . '/../../../src/bootstrap.php';
require_once __DIR__ . '/../../../src/FamilyArchive.php';

$method = $_SERVER['REQUEST_METHOD'] ?? '';
if (!in_array($method, ['GET', 'POST'], true)) {
    header('Allow: GET, POST');
    JsonResponse::error('Method not allowed', 405);
}

if ($method === 'GET') {
    $familyId = filter_var($_GET['family_id'] ?? null, FILTER_VALIDATE_INT);
    if ($familyId === false || $familyId < 1) JsonResponse::error('Invalid family ID', 422);
    Auth::requireFamilyAdmin((int) $familyId);
    $stmt = $db->prepare(
        "SELECT media.media_type, COUNT(*) AS file_count, COALESCE(SUM(media.file_size), 0) AS bytes
         FROM media INNER JOIN family_members member ON member.id = media.member_id
           AND member.family_id = ? AND member.member_status = 'active'
         WHERE media.visibility = 'family'
         GROUP BY media.media_type"
    );
    $stmt->execute([(int) $familyId]);
    $inventory = $stmt->fetchAll();
    $summary = $db->prepare(
        "SELECT
           (SELECT COUNT(*) FROM family_members WHERE family_id = ? AND member_status = 'active') AS member_count,
           (SELECT COUNT(*) FROM family_relationships WHERE family_id = ? AND status = 'approved') AS relationship_count,
           (SELECT COALESCE(SUM(media.file_size), 0) FROM media INNER JOIN family_members m ON m.id = media.member_id
             WHERE m.family_id = ? AND m.member_status = 'active' AND media.visibility = 'family') AS shared_media_bytes,
           (SELECT COUNT(*) FROM media INNER JOIN family_members m ON m.id = media.member_id
             WHERE m.family_id = ? AND m.member_status = 'active' AND media.visibility = 'family') AS shared_media_count"
    );
    $summary->execute([(int) $familyId, (int) $familyId, (int) $familyId, (int) $familyId]);
    JsonResponse::ok(['inventory' => $inventory, 'summary' => $summary->fetch()]);
}

Security::requireCsrf();
$user = Auth::requireLogin();
$familyId = filter_var($_POST['family_id'] ?? null, FILTER_VALIDATE_INT);
$action = $_POST['action'] ?? '';
if ($familyId === false || $familyId < 1 || !in_array($action, ['export', 'restore'], true)) {
    JsonResponse::error('Invalid vault request', 422);
}
Auth::requireFamilyAdmin((int) $familyId);
if (!class_exists(PharData::class) || !extension_loaded('openssl')) JsonResponse::error('Encrypted archive support is unavailable on this server', 503);
$archiveKey = hash_hkdf('sha256', (string) $config['app_key'], 32, 'kinkeep-family-archive-v1');

$privateRoot = realpath($config['upload']['private_root'] ?? '');
if ($privateRoot === false || !is_dir($privateRoot)) JsonResponse::error('Private storage is unavailable', 503);

if ($action === 'export') {
    $familyStmt = $db->prepare("SELECT id, family_name, created_at FROM families WHERE id = ? AND status = 'active'");
    $familyStmt->execute([(int) $familyId]); $family = $familyStmt->fetch();
    if (!$family) JsonResponse::error('Active family not found', 404);
    $membersStmt = $db->prepare(
        "SELECT id, first_name, middle_name, last_name, gender, member_status, created_at
         FROM family_members WHERE family_id = ? AND member_status IN ('active', 'unclaimed') ORDER BY id"
    );
    $membersStmt->execute([(int) $familyId]); $members = $membersStmt->fetchAll();
    $memberIds = array_map(static fn(array $row): int => (int) $row['id'], $members);
    $relationships = [];
    if ($memberIds) {
        $rel = $db->prepare(
            "SELECT person_id, related_person_id, relationship_type, status
             FROM family_relationships WHERE family_id = ? AND status = 'approved' ORDER BY id"
        );
        $rel->execute([(int) $familyId]); $relationships = $rel->fetchAll();
    }
    $mediaStmt = $db->prepare(
        "SELECT media.id, media.member_id, media.media_type, media.original_name, media.mime_type,
                media.file_size, media.sha256, media.storage_path
         FROM media INNER JOIN family_members member ON member.id = media.member_id
           AND member.family_id = ? AND member.member_status = 'active'
         WHERE media.visibility = 'family'
         ORDER BY media.id"
    );
    $mediaStmt->execute([(int) $familyId]); $mediaRows = $mediaStmt->fetchAll();
    $manifest = ['format' => 'kinkeep-family-export', 'version' => 1, 'created_at' => gmdate('c'),
        'family' => ['id' => (int) $family['id'], 'name' => $family['family_name'], 'created_at' => $family['created_at']],
        'members' => $members, 'relationships' => $relationships, 'media' => []];
    $tmpBase = tempnam(sys_get_temp_dir(), 'kkvault_');
    $encBase = tempnam(sys_get_temp_dir(), 'kkvault_enc_');
    if ($tmpBase === false || $encBase === false) { if (is_string($tmpBase)) @unlink($tmpBase); if (is_string($encBase)) @unlink($encBase); JsonResponse::error('Could not prepare a temporary archive', 500); }
    @unlink($tmpBase); $tmpTar = $tmpBase . '.tar'; @unlink($encBase); $encryptedPath = $encBase . '.kkv';
    try {
        $archive = new PharData($tmpTar);
        $includedBytes = 0; $fileNumber = 0;
        foreach ($mediaRows as $media) {
            $path = realpath((string) $media['storage_path']);
            if ($path === false || !is_file($path)
                || stripos($path, rtrim($privateRoot, DIRECTORY_SEPARATOR) . DIRECTORY_SEPARATOR) !== 0
                || filesize($path) !== (int) $media['file_size'] || !hash_equals((string) $media['sha256'], hash_file('sha256', $path))) continue;
            if ($includedBytes + (int) $media['file_size'] > 524288000) throw new RuntimeException('Family-visible media exceeds the 500 MB archive limit');
            $fileNumber++; $archiveName = sprintf('media/%06d.bin', $fileNumber);
            $archive->addFile($path, $archiveName);
            $includedBytes += (int) $media['file_size'];
            $manifest['media'][] = ['member_id' => (int) $media['member_id'], 'media_type' => $media['media_type'],
                'original_name' => basename((string) $media['original_name']), 'mime_type' => $media['mime_type'],
                'file_size' => (int) $media['file_size'], 'sha256' => $media['sha256'], 'archive_path' => $archiveName];
        }
        $archive->addFromString('manifest.json', json_encode($manifest, JSON_UNESCAPED_SLASHES | JSON_THROW_ON_ERROR));
        unset($archive);
        if (!is_file($tmpTar)) throw new RuntimeException('Could not finalize family archive');
        FamilyArchive::encryptTar($tmpTar, $encryptedPath, $archiveKey);
        @unlink($tmpTar);
        Audit::log('family_export_created', (int) $familyId, 'family', (int) $familyId, ['media_files' => count($manifest['media']), 'media_bytes' => $includedBytes]);
        header('Content-Type: application/octet-stream');
        header('Content-Disposition: attachment; filename="kinkeep-family-' . (int) $familyId . '-' . gmdate('Ymd-His') . '.kkv"');
        header('Content-Length: ' . (string) filesize($encryptedPath)); header('Cache-Control: private, no-store');
        readfile($encryptedPath); @unlink($encryptedPath); exit;
    } catch (Throwable $e) {
        unset($archive); @unlink($tmpTar); @unlink($encryptedPath);
        error_log('Family archive export failed: ' . $e->getMessage());
        JsonResponse::error('Could not create family archive', 500);
    }
}

$upload = $_FILES['archive'] ?? null;
if (!is_array($upload) || ($upload['error'] ?? UPLOAD_ERR_NO_FILE) !== UPLOAD_ERR_OK
    || !is_uploaded_file((string) ($upload['tmp_name'] ?? ''))
    || (int) ($upload['size'] ?? 0) < 1 || (int) $upload['size'] > 540000000) {
    JsonResponse::error('Choose a valid encrypted archive within the 500 MB uncompressed limit', 422);
}
$archiveBase = tempnam(sys_get_temp_dir(), 'kkrestore_');
if ($archiveBase === false) JsonResponse::error('Could not prepare the restore archive', 500);
@unlink($archiveBase); $restoreArchivePath = $archiveBase . '.tar';
try { FamilyArchive::decryptTar((string) $upload['tmp_name'], $restoreArchivePath, $archiveKey); }
catch (Throwable) { @unlink($restoreArchivePath); JsonResponse::error('Encrypted archive is invalid or was created with a different server key', 422); }
try {
    $archive = new PharData($restoreArchivePath);
    if (!isset($archive['manifest.json']) || $archive['manifest.json']->getSize() < 2 || $archive['manifest.json']->getSize() > 16777216) throw new RuntimeException('Archive manifest is missing or too large');
    $manifestRaw = $archive['manifest.json']->getContent();
} catch (Throwable $e) {
    unset($archive); @unlink($restoreArchivePath);
    JsonResponse::error('Archive could not be opened', 422);
}
try { $manifest = is_string($manifestRaw) ? json_decode($manifestRaw, true, 32, JSON_THROW_ON_ERROR) : null; }
catch (Throwable) { $manifest = null; }
if (!is_array($manifest) || ($manifest['format'] ?? '') !== 'kinkeep-family-export'
    || ($manifest['version'] ?? null) !== 1 || (int) ($manifest['family']['id'] ?? 0) !== (int) $familyId
    || !is_array($manifest['members'] ?? null) || !is_array($manifest['relationships'] ?? null)
    || !is_array($manifest['media'] ?? null) || count($manifest['members']) > 10000
    || count($manifest['relationships']) > 50000 || count($manifest['media']) > 10000) {
    unset($archive); @unlink($restoreArchivePath); JsonResponse::error('Archive format or family does not match this restore target', 422);
}
$familyDir = rtrim($privateRoot, DIRECTORY_SEPARATOR) . DIRECTORY_SEPARATOR . 'family_' . (int) $familyId;
if (!is_dir($familyDir) && !mkdir($familyDir, 0700, true)) { unset($archive); @unlink($restoreArchivePath); JsonResponse::error('Private storage is unavailable', 503); }
$resolvedFamilyDir = realpath($familyDir);
if ($resolvedFamilyDir === false || stripos($resolvedFamilyDir, rtrim($privateRoot, DIRECTORY_SEPARATOR) . DIRECTORY_SEPARATOR) !== 0) {
    unset($archive); @unlink($restoreArchivePath); JsonResponse::error('Private storage is unavailable', 503);
}
$familyDir = $resolvedFamilyDir;
$staged = []; $memberMap = []; $addedMembers = 0; $addedRelations = 0; $addedMedia = 0;
$totalMediaBytes = 0;
try {
    $db->beginTransaction();
    $lock = $db->prepare("SELECT id FROM families WHERE id = ? AND status = 'active' FOR UPDATE");
    $lock->execute([(int) $familyId]); if (!$lock->fetch()) throw new RuntimeException('Active family not found');
    Auth::requireFamilyAdmin((int) $familyId);
    foreach ($manifest['members'] as $row) {
        if (!is_array($row) || !filter_var($row['id'] ?? null, FILTER_VALIDATE_INT)
            || !is_string($row['first_name'] ?? null) || !is_string($row['last_name'] ?? null)
            || !in_array($row['gender'] ?? '', ['male', 'female', 'other', 'unspecified'], true)
            || !in_array($row['member_status'] ?? '', ['active', 'unclaimed'], true)) throw new RuntimeException('Archive contains invalid member metadata');
        $oldId = (int) $row['id'];
        $existing = $db->prepare('SELECT family_id FROM family_members WHERE id = ?'); $existing->execute([$oldId]); $existingFamily = $existing->fetchColumn();
        if ($existingFamily !== false && (int) $existingFamily !== (int) $familyId) throw new RuntimeException('A member identifier conflicts with another family');
        if ($existingFamily === false) {
            $insert = $db->prepare('INSERT INTO family_members (id, family_id, user_id, first_name, middle_name, last_name, gender, member_status) VALUES (?, ?, NULL, ?, ?, ?, ?, ?)');
            $insert->execute([$oldId, (int) $familyId, mb_substr($row['first_name'], 0, 100), isset($row['middle_name']) ? mb_substr((string) $row['middle_name'], 0, 100) : null, mb_substr($row['last_name'], 0, 100), $row['gender'], $row['member_status']]);
            $db->prepare("INSERT INTO family_roles (family_id, member_id, role) VALUES (?, ?, 'member')")->execute([(int) $familyId, $oldId]);
        $addedMembers++;
        }
        $memberMap[$oldId] = $oldId;
    }
    foreach ($manifest['relationships'] as $row) {
        if (!is_array($row) || !in_array($row['relationship_type'] ?? '', ['parent', 'child', 'spouse', 'guardian'], true)) throw new RuntimeException('Archive contains invalid relationship metadata');
        $person = (int) ($row['person_id'] ?? 0); $related = (int) ($row['related_person_id'] ?? 0);
        if (!isset($memberMap[$person], $memberMap[$related])) throw new RuntimeException('Archive relationship references an unknown member');
        $check = $db->prepare("SELECT id FROM family_relationships WHERE family_id = ? AND person_id = ? AND related_person_id = ? AND relationship_type = ? AND status = 'approved' LIMIT 1");
        $check->execute([(int) $familyId, $person, $related, $row['relationship_type']]);
        if (!$check->fetch()) {
            $db->prepare("INSERT INTO family_relationships (family_id, person_id, related_person_id, relationship_type, status, created_by_member_id) VALUES (?, ?, ?, ?, 'approved', ?)")
                ->execute([(int) $familyId, $person, $related, $row['relationship_type'], $person]);
            $addedRelations++;
        }
    }
    foreach ($manifest['media'] as $row) {
        $archivePath = $row['archive_path'] ?? '';
        $memberId = (int) ($row['member_id'] ?? 0); $size = (int) ($row['file_size'] ?? 0);
        if (!is_string($archivePath) || !preg_match('#^media/[0-9]{6}\.bin$#D', $archivePath)
            || !isset($memberMap[$memberId]) || $size < 0 || $size > 104857600
                || !in_array($row['media_type'] ?? '', ['photo', 'video', 'document', 'audio'], true)
            || !is_string($row['mime_type'] ?? null) || !is_string($row['sha256'] ?? null)
            || !preg_match('/^[a-f0-9]{64}$/i', $row['sha256'])) throw new RuntimeException('Archive contains invalid media metadata');
        $totalMediaBytes += $size;
        if ($totalMediaBytes > 524288000) throw new RuntimeException('Archive expands beyond the 500 MB restore limit');
        if (!isset($archive[$archivePath]) || $archive[$archivePath]->getSize() !== $size) throw new RuntimeException('Archive media size does not match its manifest');
        $allowedMime = ['photo' => ['image/jpeg', 'image/png', 'image/webp'], 'video' => ['video/mp4', 'video/webm'], 'document' => ['application/pdf'], 'audio' => ['audio/mpeg', 'audio/mp4', 'audio/ogg', 'audio/wav', 'audio/webm']];
        if (!in_array($row['mime_type'], $allowedMime[$row['media_type']], true)) throw new RuntimeException('Archive contains an unsupported media type');
        $pharUri = 'phar://' . str_replace('\\', '/', $restoreArchivePath) . '/' . $archivePath;
        $stream = fopen($pharUri, 'rb'); if (!is_resource($stream)) throw new RuntimeException('An archive media file is missing');
        $storedName = bin2hex(random_bytes(24)) . '.bin'; $destination = $familyDir . DIRECTORY_SEPARATOR . $storedName;
        $out = fopen($destination, 'xb'); if ($out === false) { fclose($stream); throw new RuntimeException('Could not stage archive media'); }
        $copied = stream_copy_to_stream($stream, $out, $size + 1); fclose($stream); fclose($out);
        $actualHash = hash_file('sha256', $destination);
        if ($copied !== $size || !is_string($actualHash) || !hash_equals(strtolower($row['sha256']), $actualHash)) { @unlink($destination); throw new RuntimeException('Archive media failed integrity validation'); }
        $staged[] = $destination;
        $existing = $db->prepare('SELECT id FROM media WHERE member_id = ? AND sha256 = ? LIMIT 1'); $existing->execute([$memberId, $actualHash]);
        if (!$existing->fetch()) {
            $db->prepare("INSERT INTO media (member_id, media_type, original_name, stored_name, mime_type, file_size, sha256, storage_path, visibility) VALUES (?, ?, ?, ?, ?, ?, ?, ?, 'family')")
                ->execute([$memberId, $row['media_type'], basename((string) ($row['original_name'] ?? 'Family media')), $storedName, $row['mime_type'], $size, $actualHash, $destination]);
            $addedMedia++;
        } else { @unlink($destination); array_pop($staged); }
    }
    unset($archive); @unlink($restoreArchivePath);
    Audit::log('family_export_restored', (int) $familyId, 'family', (int) $familyId, ['members_added' => $addedMembers, 'relationships_added' => $addedRelations, 'media_added' => $addedMedia]);
    $db->commit();
    JsonResponse::ok(['message' => 'Archive merged without replacing existing records', 'members_added' => $addedMembers, 'relationships_added' => $addedRelations, 'media_added' => $addedMedia]);
} catch (Throwable $e) {
    if ($db->inTransaction()) $db->rollBack();
    unset($archive); @unlink($restoreArchivePath); foreach ($staged as $file) @unlink($file);
    error_log('Family archive restore failed: ' . $e->getMessage());
    JsonResponse::error($e instanceof RuntimeException ? $e->getMessage() : 'Could not restore family archive', $e instanceof RuntimeException ? 422 : 500);
}
