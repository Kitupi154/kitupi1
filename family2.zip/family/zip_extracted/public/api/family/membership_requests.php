<?php
declare(strict_types=1);

require_once __DIR__ . '/../../../src/bootstrap.php';

if (($_SERVER['REQUEST_METHOD'] ?? '') !== 'GET') {
    header('Allow: GET');
    JsonResponse::error('Method not allowed', 405);
}

$familyId = filter_var($_GET['family_id'] ?? null, FILTER_VALIDATE_INT);
if ($familyId === false || $familyId < 1) {
    JsonResponse::error('Invalid family ID', 422);
}

Auth::requireFamilyAdmin((int) $familyId);

$familyStmt = $db->prepare("SELECT id FROM families WHERE id = ? AND status = 'active'");
$familyStmt->execute([$familyId]);
if (!$familyStmt->fetch()) {
    JsonResponse::error('Active family not found', 404);
}

$stmt = $db->prepare(
    "SELECT mr.id, mr.family_id, mr.applicant_member_id, mr.target_member_id,
            mr.claimed_relationship, mr.reason, mr.created_at,
            applicant.first_name, applicant.middle_name, applicant.last_name,
            COALESCE(account.email, applicant.email) AS email,
            CONCAT(target.first_name, ' ', target.last_name) AS target_member_name
     FROM membership_requests mr
     INNER JOIN family_members applicant
       ON applicant.id = mr.applicant_member_id
      AND applicant.family_id = mr.family_id
     LEFT JOIN users account ON account.id = applicant.user_id
     LEFT JOIN family_members target
       ON target.id = mr.target_member_id
      AND target.family_id = mr.family_id
     WHERE mr.family_id = ? AND mr.status = 'pending'
     ORDER BY mr.created_at ASC, mr.id ASC"
);
$stmt->execute([$familyId]);

JsonResponse::ok(['requests' => $stmt->fetchAll()]);
