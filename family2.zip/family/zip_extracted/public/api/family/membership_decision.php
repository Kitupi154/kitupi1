<?php
require_once __DIR__ . '/../../../src/bootstrap.php';
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    header('Allow: POST');
    JsonResponse::error('Method not allowed', 405);
}
Security::requireCsrf();
$data = JsonResponse::input();
$familyId = filter_var($data['family_id'] ?? null, FILTER_VALIDATE_INT);
$requestId = filter_var($data['request_id'] ?? null, FILTER_VALIDATE_INT);
$decision = $data['decision'] ?? '';
if ($familyId === false || $familyId < 1 || $requestId === false || $requestId < 1) {
    JsonResponse::error('Invalid family or request ID', 422);
}
if (!is_string($decision) || !in_array($decision, ['approved', 'rejected'], true)) {
    JsonResponse::error('Invalid decision', 422);
}
$admin = Auth::requireFamilyAdmin((int) $familyId);

try {
    $db->beginTransaction();
    $stmt = $db->prepare(
        "SELECT id, family_name FROM families WHERE id = ? AND status = 'active' FOR UPDATE"
    );
    $stmt->execute([$familyId]);
    if (!$stmt->fetch()) {
        $db->rollBack();
        JsonResponse::error('Active family not found', 404);
    }

    $stmt = $db->prepare(
        "SELECT id, applicant_member_id
         FROM membership_requests
         WHERE id = ? AND family_id = ? AND status = 'pending'
         FOR UPDATE"
    );
    $stmt->execute([$requestId, $familyId]);
    $request = $stmt->fetch();
    if (!$request) {
        $db->rollBack();
        JsonResponse::error('Pending membership request not found', 409);
    }

    $stmt = $db->prepare(
        "SELECT id, user_id, member_status
         FROM family_members
         WHERE id = ? AND family_id = ?
         FOR UPDATE"
    );
    $stmt->execute([(int) $request['applicant_member_id'], $familyId]);
    $applicant = $stmt->fetch();
    if (!$applicant) {
        $db->rollBack();
        JsonResponse::error('Applicant profile not found', 409);
    }
    if ((int) $applicant['user_id'] === (int) $admin['user_id']) {
        $db->rollBack();
        JsonResponse::error('You cannot decide your own membership request', 403);
    }

    if ($decision === 'approved' && $applicant['member_status'] !== 'pending') {
        $db->rollBack();
        JsonResponse::error('Applicant is no longer eligible for approval', 409);
    }

    $stmt = $db->prepare(
        "UPDATE membership_requests
         SET status = ?, reviewed_by_member_id = ?, reviewed_at = NOW()
         WHERE id = ? AND family_id = ? AND status = 'pending'"
    );
    $stmt->execute([$decision, (int) $admin['id'], $requestId, $familyId]);
    if ($stmt->rowCount() !== 1) {
        $db->rollBack();
        JsonResponse::error('Pending membership request not found', 409);
    }

    if ($decision === 'approved') {
        $db->prepare(
            "UPDATE family_members SET member_status = 'active'
             WHERE id = ? AND family_id = ? AND member_status = 'pending'"
        )->execute([(int) $applicant['id'], $familyId]);
        $db->prepare(
            "INSERT INTO family_roles (family_id, member_id, role)
             VALUES (?, ?, 'member')
             ON DUPLICATE KEY UPDATE role = 'member'"
        )->execute([$familyId, (int) $applicant['id']]);
    }

    Audit::log('membership_' . $decision, (int) $familyId, 'membership_request', (int) $requestId);
    $db->commit();
    JsonResponse::ok(['message' => 'Decision recorded']);
} catch (Throwable $e) {
    if ($db->inTransaction()) {
        $db->rollBack();
    }
    error_log('Membership decision failed: ' . $e->getMessage());
    JsonResponse::error('Could not process membership decision', 500);
}
