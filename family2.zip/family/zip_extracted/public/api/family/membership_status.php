<?php
declare(strict_types=1);

require_once __DIR__ . '/../../../src/bootstrap.php';

if (($_SERVER['REQUEST_METHOD'] ?? '') !== 'GET') {
    header('Allow: GET');
    JsonResponse::error('Method not allowed', 405);
}

$user = Auth::requireLogin();
if (empty($user['email_verified_at'])) {
    JsonResponse::error('Verify your email before viewing membership status', 403);
}

$stmt = $db->prepare(
    "SELECT mr.id, mr.family_id, f.family_name, mr.status,
            mr.claimed_relationship, mr.created_at, mr.reviewed_at
     FROM membership_requests mr
     INNER JOIN family_members fm
       ON fm.id = mr.applicant_member_id
      AND fm.family_id = mr.family_id
     INNER JOIN families f ON f.id = mr.family_id
     WHERE fm.user_id = ?
     ORDER BY mr.created_at DESC, mr.id DESC"
);
$stmt->execute([(int) $user['id']]);
$requests = array_map(
    static fn(array $request): array => [
        'id' => (int) $request['id'],
        'family_id' => (int) $request['family_id'],
        'family_name' => $request['family_name'],
        'status' => $request['status'],
        'claimed_relationship' => $request['claimed_relationship'],
        'created_at' => $request['created_at'],
        'reviewed_at' => $request['reviewed_at'],
    ],
    $stmt->fetchAll()
);

$stmt = $db->prepare(
    "SELECT fm.family_id
     FROM family_members fm
     INNER JOIN families f ON f.id = fm.family_id AND f.status = 'active'
     INNER JOIN family_roles fr ON fr.member_id = fm.id
                               AND fr.family_id = fm.family_id
                               AND fr.role = 'member'
     WHERE fm.user_id = ? AND fm.member_status = 'active'
     LIMIT 1"
);
$stmt->execute([(int) $user['id']]);
$activeMemberFamilyId = $stmt->fetchColumn();

JsonResponse::ok([
    'requests' => $requests,
    'active_member_family_id' => $activeMemberFamilyId === false
        ? null
        : (int) $activeMemberFamilyId,
    'csrf_token' => Security::csrfToken(),
]);
