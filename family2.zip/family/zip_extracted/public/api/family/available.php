<?php
declare(strict_types=1);

require_once __DIR__ . '/../../../src/bootstrap.php';

if (($_SERVER['REQUEST_METHOD'] ?? '') !== 'GET') {
    header('Allow: GET');
    JsonResponse::error('Method not allowed', 405);
}

$user = Auth::requireLogin();
if (empty($user['email_verified_at'])) {
    JsonResponse::error('Verify your email before searching for a family', 403);
}
$stmt = $db->query(
    "SELECT id, family_name
     FROM families
     WHERE status = 'active'
       AND is_discoverable = 1
     ORDER BY family_name ASC, id ASC"
);

JsonResponse::ok(['families' => $stmt->fetchAll()]);
