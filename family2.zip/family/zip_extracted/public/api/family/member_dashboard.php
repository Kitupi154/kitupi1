<?php
declare(strict_types=1);

require_once __DIR__ . '/../../../src/bootstrap.php';

if (($_SERVER['REQUEST_METHOD'] ?? '') !== 'GET') {
    header('Allow: GET');
    JsonResponse::error('Method not allowed', 405);
}

$user = Auth::requireLogin();
$familyId = filter_var($_GET['family_id'] ?? null, FILTER_VALIDATE_INT);
if ($familyId === false || $familyId < 1) JsonResponse::error('Invalid family ID', 422);
$member = Auth::requireFamilyMember((int) $familyId);
if ((int) $member['user_id'] !== (int) $user['id']) JsonResponse::error('Profile ownership conflict', 403);

try {
    $mediaStmt = $db->prepare(
        "SELECT media_type, COUNT(*) AS file_count, COALESCE(SUM(file_size), 0) AS bytes
         FROM media WHERE member_id = ? GROUP BY media_type"
    );
    $mediaStmt->execute([(int) $member['id']]);
    $media = $mediaStmt->fetchAll();
    $counts = ['document_count' => 0, 'photo_count' => 0, 'video_count' => 0, 'total_media_bytes' => 0];
    foreach ($media as $item) {
        $count = (int) $item['file_count'];
        $counts['total_media_bytes'] += (int) $item['bytes'];
        if ($item['media_type'] === 'document') $counts['document_count'] = $count;
        if ($item['media_type'] === 'photo') $counts['photo_count'] = $count;
        if ($item['media_type'] === 'video') $counts['video_count'] = $count;
    }
    $relationshipStmt = $db->prepare(
        "SELECT COUNT(*) AS total_count,
                SUM(CASE WHEN status = 'approved' THEN 1 ELSE 0 END) AS approved_count,
                SUM(CASE WHEN status = 'pending' THEN 1 ELSE 0 END) AS pending_count
         FROM family_relationships
         WHERE family_id = ? AND (person_id = ? OR related_person_id = ?)"
    );
    $relationshipStmt->execute([(int) $familyId, (int) $member['id'], (int) $member['id']]);
    $relationships = $relationshipStmt->fetch() ?: ['total_count' => 0, 'approved_count' => 0, 'pending_count' => 0];
    $activityStmt = $db->prepare(
        "SELECT action, target_type, created_at
         FROM audit_logs
         WHERE actor_user_id = ? AND family_id = ?
         ORDER BY id DESC LIMIT 8"
    );
    $activityStmt->execute([(int) $user['id'], (int) $familyId]);
    JsonResponse::ok([
        'summary' => $counts + [
            'relationship_count' => (int) $relationships['approved_count'],
            'pending_relationship_count' => (int) $relationships['pending_count'],
            'mfa_enabled' => (bool) $user['mfa_enabled'],
            'email_verified' => $user['email_verified_at'] !== null,
            'last_login_at' => $user['last_login_at'],
        ],
        'media' => $media,
        'activity' => $activityStmt->fetchAll(),
    ]);
} catch (Throwable $e) {
    error_log('Member dashboard summary failed: ' . $e->getMessage());
    JsonResponse::error('Could not load member dashboard summary', 500);
}
