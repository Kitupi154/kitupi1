<?php
require_once __DIR__ . '/../../../src/bootstrap.php';
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    header('Allow: POST');
    JsonResponse::error('Method not allowed', 405);
}
Security::requireCsrf();
$user = Auth::requireLogin();
if (empty($user['email_verified_at'])) {
    JsonResponse::error('Verify your email before requesting family membership', 403);
}
$data = JsonResponse::input();
$familyId = filter_var($data['family_id'] ?? null, FILTER_VALIDATE_INT);
$targetId = null;

if ($familyId === false || $familyId < 1) {
    JsonResponse::error('Invalid family ID', 422);
}
if (array_key_exists('target_member_id', $data) && $data['target_member_id'] !== null && $data['target_member_id'] !== '') {
    $targetId = filter_var($data['target_member_id'], FILTER_VALIDATE_INT);
    if ($targetId === false || $targetId < 1) {
        JsonResponse::error('Invalid target member ID', 422);
    }
}

$relationshipValue = $data['claimed_relationship'] ?? '';
$reasonValue = $data['reason'] ?? '';
$firstValue = $data['first_name'] ?? '';
$lastValue = $data['last_name'] ?? '';
if (!is_string($relationshipValue) || !is_string($reasonValue) || !is_string($firstValue) || !is_string($lastValue)) {
    JsonResponse::error('Invalid membership request fields', 422);
}

$relationship = Security::cleanString($relationshipValue, 50);
$reason = Security::cleanString($reasonValue, 500);
$first = Security::cleanString($firstValue, 100);
$last = Security::cleanString($lastValue, 100);
if ($relationship === '') {
    JsonResponse::error('Claimed relationship is required', 422);
}

$db->beginTransaction();
try {
    $stmt = $db->prepare(
        "SELECT id FROM families
         WHERE id = ? AND status = 'active' AND is_discoverable = 1
         FOR UPDATE"
    );
    $stmt->execute([$familyId]);
    if (!$stmt->fetch()) {
        $db->rollBack();
        JsonResponse::error('Family not found or not available for membership requests', 404);
    }

    $stmt = $db->prepare(
        "SELECT id
         FROM family_invitations
         WHERE family_id = ?
           AND member_id IS NOT NULL
           AND LOWER(invitee_email) = LOWER(?)
           AND status = 'pending'
           AND expires_at > NOW()
         LIMIT 1
         FOR UPDATE"
    );
    $stmt->execute([$familyId, (string) $user['email']]);
    if ($stmt->fetch()) {
        $db->rollBack();
        JsonResponse::error('Accept your pending family invitation instead of requesting membership', 409);
    }

    $stmt = $db->prepare(
        "SELECT member.id
         FROM family_members member
         LEFT JOIN family_invitations invitation
           ON invitation.member_id = member.id
          AND invitation.family_id = member.family_id
         WHERE member.family_id = ?
           AND member.member_status = 'unclaimed'
           AND (LOWER(member.email) = LOWER(?)
                OR LOWER(invitation.invitee_email) = LOWER(?))
         LIMIT 1
         FOR UPDATE"
    );
    $stmt->execute([$familyId, (string) $user['email'], (string) $user['email']]);
    if ($stmt->fetch()) {
        $db->rollBack();
        JsonResponse::error('A family profile already exists for this email. Ask the Family Admin to send or renew its invitation.', 409);
    }

    $stmt = $db->prepare(
        "SELECT id, first_name, last_name, member_status
         FROM family_members
         WHERE user_id = ? AND family_id = ?
         ORDER BY CASE member_status
             WHEN 'active' THEN 0 WHEN 'pending' THEN 1 WHEN 'unclaimed' THEN 2 ELSE 3
         END, id DESC
         LIMIT 1 FOR UPDATE"
    );
    $stmt->execute([(int) $user['id'], $familyId]);
    $member = $stmt->fetch();

    if ($member && $member['member_status'] === 'active') {
        $db->rollBack();
        JsonResponse::error('Already a member', 409);
    }
    if ($member && in_array($member['member_status'], ['suspended', 'removed'], true)) {
        $db->rollBack();
        JsonResponse::error('This family profile is not eligible to rejoin', 409);
    }
    if (!$member && ($first === '' || $last === '')) {
        $db->rollBack();
        JsonResponse::error('First and last name are required to request membership', 422);
    }

    if (!$member) {
        $stmt = $db->prepare(
            "INSERT INTO family_members (family_id, user_id, first_name, last_name, member_status)
             VALUES (?, ?, ?, ?, 'pending')"
        );
        $stmt->execute([$familyId, (int) $user['id'], $first, $last]);
        $memberId = (int) $db->lastInsertId();
    } else {
        $memberId = (int) $member['id'];
    }

    if ($targetId !== null) {
        $stmt = $db->prepare(
            "SELECT id FROM family_members
             WHERE id = ? AND family_id = ? AND member_status = 'active'"
        );
        $stmt->execute([$targetId, $familyId]);
        if (!$stmt->fetch() || $targetId === $memberId) {
            $db->rollBack();
            JsonResponse::error('Target must be another active member of this family', 422);
        }
    }

    $stmt = $db->prepare(
        "SELECT id FROM membership_requests
         WHERE family_id = ? AND status = 'pending'
           AND applicant_member_id IN (
               SELECT id FROM family_members WHERE family_id = ? AND user_id = ?
           )
         LIMIT 1 FOR UPDATE"
    );
    $stmt->execute([$familyId, $familyId, (int) $user['id']]);
    if ($stmt->fetch()) {
        $db->rollBack();
        JsonResponse::error('A membership request is already pending', 409);
    }

    $stmt = $db->prepare(
        "INSERT INTO membership_requests
         (family_id, applicant_member_id, target_member_id, claimed_relationship, reason)
         VALUES (?, ?, ?, ?, ?)"
    );
    $stmt->execute([$familyId, $memberId, $targetId, $relationship, $reason]);
    $requestId = (int) $db->lastInsertId();
    Audit::log('membership_requested', (int) $familyId, 'membership_request', $requestId);
    $db->commit();

    JsonResponse::ok(['message' => 'Membership request submitted'], 201);
} catch (Throwable $e) {
    if ($db->inTransaction()) {
        $db->rollBack();
    }
    error_log('Membership request submission failed: ' . $e->getMessage());
    JsonResponse::error('Could not submit membership request', 500);
}
