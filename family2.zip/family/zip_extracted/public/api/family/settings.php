<?php
declare(strict_types=1);

require_once __DIR__ . '/../../../src/bootstrap.php';

$method = $_SERVER['REQUEST_METHOD'] ?? '';
if (!in_array($method, ['GET', 'POST'], true)) {
    header('Allow: GET, POST');
    JsonResponse::error('Method not allowed', 405);
}

if ($method === 'GET') {
    $familyId = filter_var($_GET['family_id'] ?? null, FILTER_VALIDATE_INT);
    if ($familyId === false || $familyId < 1) {
        JsonResponse::error('Invalid family ID', 422);
    }
    Auth::requireFamilyAdmin((int) $familyId);
    $stmt = $db->prepare(
        "SELECT f.id, f.family_name, f.status, f.created_at,
                f.is_discoverable,
                s.home_region, COALESCE(s.profile_visibility, 'family') AS profile_visibility,
                COALESCE(s.permission_expiry_days, 30) AS permission_expiry_days
         FROM families f LEFT JOIN family_settings s ON s.family_id = f.id
         WHERE f.id = ? AND f.status = 'active' LIMIT 1"
    );
    $stmt->execute([(int) $familyId]);
    $family = $stmt->fetch();
    if (!$family) {
        JsonResponse::error('Active family not found', 404);
    }
    JsonResponse::ok(['family' => $family]);
}

Security::requireCsrf();
$data = JsonResponse::input();
$familyId = filter_var($data['family_id'] ?? null, FILTER_VALIDATE_INT);
$name = $data['family_name'] ?? null;
$region = $data['home_region'] ?? '';
$visibility = $data['profile_visibility'] ?? 'family';
$discoverableValue = $data['is_discoverable'] ?? false;
$isDiscoverable = filter_var($discoverableValue, FILTER_VALIDATE_BOOLEAN, FILTER_NULL_ON_FAILURE);
$validDiscoverableValue = is_bool($discoverableValue)
    || in_array($discoverableValue, [0, 1, '0', '1', 'true', 'false'], true);
$expiry = filter_var($data['permission_expiry_days'] ?? 30, FILTER_VALIDATE_INT);
if ($familyId === false || $familyId < 1 || !is_string($name) || !is_string($region)
    || strlen($name) > 760 || strlen($region) > 760
    || preg_match('/[\x00-\x1F\x7F]/', $name . $region)
    || !in_array($visibility, ['family', 'private'], true)
    || !$validDiscoverableValue
    || $isDiscoverable === null
    || $expiry === false || !in_array($expiry, [7, 30, 90], true)) {
    JsonResponse::error('Invalid family settings', 422);
}
$familyName = trim($name);
$homeRegion = trim($region);
if ($familyName === '' || mb_strlen($familyName) > 190 || mb_strlen($homeRegion) > 190) {
    JsonResponse::error('Family name is required and each text field must be at most 190 characters', 422);
}

try {
    $db->beginTransaction();
    $familyStmt = $db->prepare("SELECT id FROM families WHERE id = ? AND status = 'active' FOR UPDATE");
    $familyStmt->execute([(int) $familyId]);
    if (!$familyStmt->fetch()) {
        $db->rollBack();
        JsonResponse::error('Active family not found', 404);
    }
    Auth::requireFamilyAdmin((int) $familyId);
    $db->prepare("UPDATE families SET family_name = ? WHERE id = ? AND status = 'active'")
        ->execute([$familyName, (int) $familyId]);
    $db->prepare("UPDATE families SET is_discoverable = ? WHERE id = ? AND status = 'active'")
        ->execute([$isDiscoverable ? 1 : 0, (int) $familyId]);
    $db->prepare(
        "INSERT INTO family_settings (family_id, home_region, profile_visibility, permission_expiry_days)
         VALUES (?, ?, ?, ?)
         ON DUPLICATE KEY UPDATE home_region = VALUES(home_region),
             profile_visibility = VALUES(profile_visibility),
             permission_expiry_days = VALUES(permission_expiry_days)"
    )->execute([(int) $familyId, $homeRegion === '' ? null : $homeRegion, $visibility, (int) $expiry]);
    Audit::log('family_settings_updated', (int) $familyId, 'family', (int) $familyId, [
        'profile_visibility' => $visibility,
        'is_discoverable' => $isDiscoverable,
        'permission_expiry_days' => (int) $expiry,
        'home_region_changed' => $homeRegion !== '',
    ]);
    $db->commit();
    JsonResponse::ok(['message' => 'Family settings updated']);
} catch (Throwable $e) {
    if ($db->inTransaction()) {
        $db->rollBack();
    }
    error_log('Family settings update failed: ' . $e->getMessage());
    JsonResponse::error('Could not update family settings', 500);
}
