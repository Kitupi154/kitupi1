<?php
declare(strict_types=1);

require_once __DIR__ . '/../../../src/bootstrap.php';
require_once __DIR__ . '/../../../src/SuperAdminApi.php';

SuperAdminApi::requireMethod('GET');
Auth::requireSuperAdmin();

try {
    $pagination = SuperAdminApi::pagination();
    $search = SuperAdminApi::queryString('q', 100);
    $action = SuperAdminApi::queryString('action', 100);
    $category = SuperAdminApi::queryString('category', 20);
    $from = SuperAdminApi::queryString('from', 10);
    $to = SuperAdminApi::queryString('to', 10);

    if (($from !== '' && !SuperAdminApi::validDate($from))
        || ($to !== '' && !SuperAdminApi::validDate($to))) {
        JsonResponse::error('Dates must use YYYY-MM-DD format', 422);
    }
    if ($from !== '' && $to !== '' && $from > $to) {
        JsonResponse::error('Start date must not be after end date', 422);
    }
    if ($category !== '' && !in_array($category, ['security', 'admin'], true)) {
        JsonResponse::error('Invalid event category', 422);
    }

    $where = [];
    $params = [];
    if ($search !== '') {
        $where[] = "(al.action LIKE ? OR al.target_type LIKE ?
                     OR CAST(al.actor_user_id AS CHAR) LIKE ? OR f.family_name LIKE ?)";
        $pattern = '%' . $search . '%';
        array_push($params, $pattern, $pattern, $pattern, $pattern);
    }
    if ($action !== '') {
        $where[] = 'al.action = ?';
        $params[] = $action;
    }
    if ($category === 'security') {
        $where[] = "al.action IN ('login_failed', 'account_locked', 'login_success',
                       'otp_failed', 'otp_locked', 'otp_verified',
                       'password_reset_completed')";
    } elseif ($category === 'admin') {
        $where[] = '(u.is_admin = 1 OR al.action LIKE ?)';
        $params[] = 'superadmin\\_%';
    }
    if ($from !== '') {
        $where[] = 'al.created_at >= ?';
        $params[] = $from . ' 00:00:00';
    }
    if ($to !== '') {
        $where[] = 'al.created_at < DATE_ADD(?, INTERVAL 1 DAY)';
        $params[] = $to;
    }
    $whereSql = $where ? 'WHERE ' . implode(' AND ', $where) : '';

    $countStmt = $db->prepare(
        "SELECT COUNT(*)
         FROM audit_logs al
         LEFT JOIN users u ON u.id = al.actor_user_id
         LEFT JOIN families f ON f.id = al.family_id
         $whereSql"
    );
    $countStmt->execute($params);
    $total = (int) $countStmt->fetchColumn();

    $stmt = $db->prepare(
        "SELECT al.id, al.action, al.target_type, al.target_id,
                al.actor_user_id, al.created_at, f.family_name
         FROM audit_logs al
         LEFT JOIN users u ON u.id = al.actor_user_id
         LEFT JOIN families f ON f.id = al.family_id
         $whereSql
         ORDER BY al.created_at DESC, al.id DESC
         LIMIT ? OFFSET ?"
    );
    foreach ($params as $index => $value) {
        $stmt->bindValue($index + 1, $value, PDO::PARAM_STR);
    }
    $stmt->bindValue(count($params) + 1, $pagination['per_page'], PDO::PARAM_INT);
    $stmt->bindValue(count($params) + 2, $pagination['offset'], PDO::PARAM_INT);
    $stmt->execute();

    $statistics = $db->query(
        "SELECT
            SUM(CASE WHEN al.created_at >= DATE_FORMAT(NOW(), '%Y-%m-01')
                THEN 1 ELSE 0 END) AS events_this_month,
            SUM(CASE WHEN al.created_at >= DATE_FORMAT(NOW(), '%Y-%m-01')
                AND al.action LIKE 'superadmin\\_%'
                THEN 1 ELSE 0 END) AS superadmin_actions_this_month,
            SUM(CASE WHEN al.created_at >= DATE_FORMAT(NOW(), '%Y-%m-01')
                AND al.action IN ('login_failed', 'account_locked', 'login_success',
                    'otp_failed', 'otp_locked', 'otp_verified',
                    'password_reset_completed')
                THEN 1 ELSE 0 END) AS security_events_this_month
         FROM audit_logs al
         LEFT JOIN users u ON u.id = al.actor_user_id"
    )->fetch();

    JsonResponse::ok([
        'logs' => $stmt->fetchAll(),
        'statistics' => [
            'events_this_month' => (int) ($statistics['events_this_month'] ?? 0),
            'superadmin_actions_this_month' => (int) ($statistics['superadmin_actions_this_month'] ?? 0),
            'security_events_this_month' => (int) ($statistics['security_events_this_month'] ?? 0),
        ],
        'pagination' => [
            'page' => $pagination['page'],
            'per_page' => $pagination['per_page'],
            'total' => $total,
            'pages' => (int) ceil($total / $pagination['per_page']),
        ],
    ]);
} catch (Throwable $e) {
    error_log('Super Admin audit log listing failed: ' . $e->getMessage());
    JsonResponse::error('Could not load audit records', 500);
}
