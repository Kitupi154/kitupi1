<?php
declare(strict_types=1);

require_once __DIR__ . '/../../../src/bootstrap.php';
require_once __DIR__ . '/../../../src/SuperAdminApi.php';

$method = $_SERVER['REQUEST_METHOD'] ?? '';
if ($method !== 'GET' && $method !== 'POST') {
    header('Allow: GET, POST');
    JsonResponse::error('Method not allowed', 405);
}

$admin = Auth::requireSuperAdmin();

if ($method === 'GET') {
    try {
        if (isset($_GET['admin_candidates'])) {
            $familyId = filter_var($_GET['family_id'] ?? null, FILTER_VALIDATE_INT);
            if ($familyId === false || $familyId < 1 || $_GET['admin_candidates'] !== '1') {
                JsonResponse::error('Invalid family administrator lookup', 422);
            }

            $familyStmt = $db->prepare('SELECT id FROM families WHERE id = ?');
            $familyStmt->execute([$familyId]);
            if (!$familyStmt->fetch()) {
                JsonResponse::error('Family not found', 404);
            }

            $candidateStmt = $db->prepare(
                "SELECT fm.id AS member_id, u.id AS user_id, u.email,
                        fm.first_name, fm.last_name, COALESCE(fr.role, 'member') AS role
                 FROM family_members fm
                 INNER JOIN users u ON u.id = fm.user_id AND u.status = 'active'
                 LEFT JOIN family_roles fr
                   ON fr.family_id = fm.family_id AND fr.member_id = fm.id
                 WHERE fm.family_id = ? AND fm.member_status = 'active'
                 ORDER BY fm.last_name ASC, fm.first_name ASC, fm.id ASC"
            );
            $candidateStmt->execute([$familyId]);
            JsonResponse::ok(['candidates' => $candidateStmt->fetchAll()]);
        }

        $pagination = SuperAdminApi::pagination();
        $search = SuperAdminApi::queryString('q', 100);
        $status = SuperAdminApi::queryString('status', 20);
        $sort = SuperAdminApi::queryString('sort', 20);

        if ($status !== '' && !in_array($status, ['active', 'suspended', 'archived'], true)) {
            JsonResponse::error('Invalid family status filter', 422);
        }
        if ($sort !== '' && !in_array($sort, ['created', 'name'], true)) {
            JsonResponse::error('Invalid sort order', 422);
        }

        $where = [];
        $params = [];
        if ($search !== '') {
            $where[] = 'f.family_name LIKE ?';
            $params[] = '%' . $search . '%';
        }
        if ($status !== '') {
            $where[] = 'f.status = ?';
            $params[] = $status;
        }
        $whereSql = $where ? 'WHERE ' . implode(' AND ', $where) : '';
        $orderSql = $sort === 'name' ? 'f.family_name ASC, f.id ASC' : 'f.created_at DESC, f.id DESC';

        $count = $db->prepare("SELECT COUNT(*) FROM families f $whereSql");
        $count->execute($params);
        $total = (int) $count->fetchColumn();

        $stmt = $db->prepare(
            "SELECT f.id, f.family_name, f.status, f.created_at,
                    (SELECT COUNT(*) FROM family_members fm
                     WHERE fm.family_id = f.id AND fm.member_status = 'active') AS active_members,
                    (SELECT CONCAT(fm.first_name, ' ', fm.last_name)
                     FROM family_roles fr
                     INNER JOIN family_members fm
                       ON fm.id = fr.member_id AND fm.family_id = fr.family_id
                     WHERE fr.family_id = f.id AND fr.role = 'admin'
                       AND fm.member_status = 'active'
                     ORDER BY fr.id ASC LIMIT 1) AS family_admin
             FROM families f
             $whereSql
             ORDER BY $orderSql
             LIMIT ? OFFSET ?"
        );
        foreach ($params as $index => $value) {
            $stmt->bindValue($index + 1, $value, PDO::PARAM_STR);
        }
        $stmt->bindValue(count($params) + 1, $pagination['per_page'], PDO::PARAM_INT);
        $stmt->bindValue(count($params) + 2, $pagination['offset'], PDO::PARAM_INT);
        $stmt->execute();

        $counts = $db->query(
            "SELECT status, COUNT(*) AS count FROM families GROUP BY status"
        )->fetchAll();
        $statistics = ['total' => 0, 'active' => 0, 'suspended' => 0, 'archived' => 0];
        foreach ($counts as $row) {
            $statistics['total'] += (int) $row['count'];
            $statistics[$row['status']] = (int) $row['count'];
        }

        JsonResponse::ok([
            'families' => $stmt->fetchAll(),
            'statistics' => $statistics,
            'pagination' => [
                'page' => $pagination['page'],
                'per_page' => $pagination['per_page'],
                'total' => $total,
                'pages' => (int) ceil($total / $pagination['per_page']),
            ],
        ]);
    } catch (Throwable $e) {
        error_log('Super Admin family listing failed: ' . $e->getMessage());
        JsonResponse::error('Could not load family records', 500);
    }
}

Security::requireCsrf();
$data = JsonResponse::input();
$action = $data['action'] ?? '';

if ($action === 'assign_family_admin' || $action === 'remove_family_admin') {
    $familyId = filter_var($data['family_id'] ?? null, FILTER_VALIDATE_INT);
    $memberId = filter_var($data['member_id'] ?? null, FILTER_VALIDATE_INT);
    if ($familyId === false || $familyId < 1 || $memberId === false || $memberId < 1) {
        JsonResponse::error('Invalid family or member ID', 422);
    }

    try {
        $db->beginTransaction();
        $familyStmt = $db->prepare('SELECT id FROM families WHERE id = ? FOR UPDATE');
        $familyStmt->execute([$familyId]);
        if (!$familyStmt->fetch()) {
            $db->rollBack();
            JsonResponse::error('Family not found', 404);
        }

        $memberStmt = $db->prepare(
            "SELECT fm.id, fm.user_id, COALESCE(fr.role, 'member') AS role
             FROM family_members fm
             INNER JOIN users u ON u.id = fm.user_id AND u.status = 'active'
             LEFT JOIN family_roles fr
               ON fr.family_id = fm.family_id AND fr.member_id = fm.id
             WHERE fm.id = ? AND fm.family_id = ? AND fm.member_status = 'active'
             FOR UPDATE"
        );
        $memberStmt->execute([$memberId, $familyId]);
        $member = $memberStmt->fetch();
        if (!$member) {
            $db->rollBack();
            JsonResponse::error('Target must be an active family member with an active account', 422);
        }

        if ($action === 'assign_family_admin') {
            $eligibleAdminCount = $db->prepare(
                "SELECT COUNT(*)
                 FROM family_roles fr
                 INNER JOIN family_members fm
                   ON fm.id = fr.member_id AND fm.family_id = fr.family_id
                 INNER JOIN users u ON u.id = fm.user_id AND u.status = 'active'
                 WHERE fr.family_id = ? AND fr.role = 'admin'
                   AND fm.member_status = 'active'"
            );
            $eligibleAdminCount->execute([$familyId]);
            if ((int) $eligibleAdminCount->fetchColumn() === 0) {
                $db->rollBack();
                JsonResponse::error(
                    'The first Family Admin must accept an invitation before receiving administrator privileges',
                    409
                );
            }

            if ($member['role'] !== 'admin') {
                $stmt = $db->prepare(
                    "INSERT INTO family_roles (family_id, member_id, role)
                     VALUES (?, ?, 'admin')
                     ON DUPLICATE KEY UPDATE role = 'admin'"
                );
                $stmt->execute([$familyId, $memberId]);
                Audit::log(
                    'superadmin_family_admin_assigned',
                    (int) $familyId,
                    'family_member',
                    (int) $memberId,
                    ['user_id' => (int) $member['user_id'], 'previous_role' => $member['role']]
                );
            }
            $db->commit();
            JsonResponse::ok(['message' => 'Family administrator assigned']);
        }

        if ($member['role'] !== 'admin') {
            $db->rollBack();
            JsonResponse::error('Target is not a family administrator', 409);
        }

        $countStmt = $db->prepare(
            "SELECT COUNT(*)
             FROM family_roles fr
             INNER JOIN family_members fm
               ON fm.id = fr.member_id AND fm.family_id = fr.family_id
             INNER JOIN users u ON u.id = fm.user_id AND u.status = 'active'
             WHERE fr.family_id = ? AND fr.role = 'admin'
               AND fm.member_status = 'active' AND fm.id <> ?"
        );
        $countStmt->execute([$familyId, $memberId]);
        if ((int) $countStmt->fetchColumn() < 1) {
            $db->rollBack();
            JsonResponse::error('Assign another family administrator before removing the last one', 409);
        }

        $stmt = $db->prepare(
            "UPDATE family_roles SET role = 'member'
             WHERE family_id = ? AND member_id = ? AND role = 'admin'"
        );
        $stmt->execute([$familyId, $memberId]);
        Audit::log(
            'superadmin_family_admin_removed',
            (int) $familyId,
            'family_member',
            (int) $memberId,
            ['user_id' => (int) $member['user_id'], 'new_role' => 'member']
        );
        $db->commit();
        JsonResponse::ok(['message' => 'Family administrator removed']);
    } catch (Throwable $e) {
        if ($db->inTransaction()) {
            $db->rollBack();
        }
        error_log('Super Admin family administrator change failed: ' . $e->getMessage());
        JsonResponse::error('Could not update family administrator assignment', 500);
    }
}

if ($action === 'create') {
    $name = $data['family_name'] ?? null;
    if (!is_string($name)) {
        JsonResponse::error('Family name is required', 422);
    }
    $name = trim($name);
    if ($name === '' || mb_strlen($name) > 190) {
        JsonResponse::error('Family name must be between 1 and 190 characters', 422);
    }

    try {
        $db->beginTransaction();
        $stmt = $db->prepare(
            "INSERT INTO families (family_name, created_by_user_id) VALUES (?, ?)"
        );
        $stmt->execute([$name, (int) $admin['id']]);
        $familyId = (int) $db->lastInsertId();
        Audit::log(
            'superadmin_family_created',
            $familyId,
            'family',
            $familyId,
            ['family_name' => $name]
        );
        $db->commit();
        JsonResponse::ok(['family_id' => $familyId], 201);
    } catch (Throwable $e) {
        if ($db->inTransaction()) {
            $db->rollBack();
        }
        error_log('Super Admin family creation failed: ' . $e->getMessage());
        JsonResponse::error('Could not create family record', 500);
    }
}

if ($action === 'update') {
    $familyId = filter_var($data['family_id'] ?? null, FILTER_VALIDATE_INT);
    if ($familyId === false || $familyId < 1) {
        JsonResponse::error('Invalid family ID', 422);
    }

    $name = $data['family_name'] ?? null;
    $status = $data['status'] ?? null;
    if ($name !== null && (!is_string($name) || trim($name) === '' || mb_strlen(trim($name)) > 190)) {
        JsonResponse::error('Family name must be between 1 and 190 characters', 422);
    }
    if ($status !== null && (!is_string($status) || !in_array($status, ['active', 'suspended', 'archived'], true))) {
        JsonResponse::error('Invalid family status', 422);
    }
    if ($name === null && $status === null) {
        JsonResponse::error('No family changes provided', 422);
    }

    try {
        $db->beginTransaction();
        $stmt = $db->prepare('SELECT family_name, status FROM families WHERE id = ? FOR UPDATE');
        $stmt->execute([$familyId]);
        $current = $stmt->fetch();
        if (!$current) {
            $db->rollBack();
            JsonResponse::error('Family not found', 404);
        }

        $newName = $name === null ? $current['family_name'] : trim($name);
        $newStatus = $status === null ? $current['status'] : $status;
        $stmt = $db->prepare('UPDATE families SET family_name = ?, status = ? WHERE id = ?');
        $stmt->execute([$newName, $newStatus, $familyId]);

        Audit::log(
            'superadmin_family_updated',
            (int) $familyId,
            'family',
            (int) $familyId,
            [
                'previous_family_name' => $current['family_name'],
                'family_name' => $newName,
                'previous_status' => $current['status'],
                'status' => $newStatus,
            ]
        );
        $db->commit();
        JsonResponse::ok(['message' => 'Family updated']);
    } catch (Throwable $e) {
        if ($db->inTransaction()) {
            $db->rollBack();
        }
        error_log('Super Admin family update failed: ' . $e->getMessage());
        JsonResponse::error('Could not update family record', 500);
    }
}

JsonResponse::error('Invalid family action', 422);
