<?php
declare(strict_types=1);

require_once __DIR__ . '/../../../src/bootstrap.php';

$method = $_SERVER['REQUEST_METHOD'] ?? '';
if ($method !== 'GET' && $method !== 'POST') {
    header('Allow: GET, POST');
    JsonResponse::error('Method not allowed', 405);
}

$admin = Auth::requireSuperAdmin();

if ($method === 'GET') {
    $familyId = filter_var($_GET['family_id'] ?? null, FILTER_VALIDATE_INT);
    if ($familyId === false || $familyId < 1) {
        JsonResponse::error('Invalid family ID', 422);
    }

    $familyStmt = $db->prepare("SELECT id, status FROM families WHERE id = ?");
    $familyStmt->execute([$familyId]);
    $family = $familyStmt->fetch();
    if (!$family) {
        JsonResponse::error('Family not found', 404);
    }

    $adminStmt = $db->prepare(
        "SELECT COUNT(*)
         FROM family_roles fr
         INNER JOIN family_members fm
           ON fm.id = fr.member_id AND fm.family_id = fr.family_id
         INNER JOIN users u ON u.id = fm.user_id AND u.status = 'active'
         WHERE fr.family_id = ? AND fr.role = 'admin'
           AND fm.member_status = 'active'"
    );
    $adminStmt->execute([$familyId]);
    $hasEligibleAdmin = (int) $adminStmt->fetchColumn() > 0;
    if ($family['status'] !== 'active') {
        JsonResponse::ok([
            'family_active' => false,
            'has_eligible_admin' => $hasEligibleAdmin,
            'eligible_users' => [],
        ]);
    }

    $usersStmt = $db->prepare(
        "SELECT u.id, u.email
         FROM users u
         WHERE u.status = 'active'
           AND NOT EXISTS (
               SELECT 1 FROM family_members fm
               WHERE fm.family_id = ? AND fm.user_id = u.id
                 AND fm.member_status IN ('removed', 'suspended')
           )
           AND (
               SELECT COUNT(*) FROM family_members fm
               WHERE fm.family_id = ? AND fm.user_id = u.id
           ) <= 1
           AND NOT EXISTS (
               SELECT 1 FROM family_admin_invitations invitation
               WHERE invitation.family_id = ?
                 AND invitation.invited_user_id = u.id
                 AND invitation.status = 'pending'
                 AND invitation.expires_at > NOW()
           )
         ORDER BY u.email ASC, u.id ASC
         LIMIT 500"
    );
    $usersStmt->execute([$familyId, $familyId, $familyId]);

    JsonResponse::ok([
        'family_active' => true,
        'has_eligible_admin' => $hasEligibleAdmin,
        'eligible_users' => $hasEligibleAdmin ? [] : $usersStmt->fetchAll(),
    ]);
}

Security::requireCsrf();
$data = JsonResponse::input();
$familyId = filter_var($data['family_id'] ?? null, FILTER_VALIDATE_INT);
$userId = filter_var($data['user_id'] ?? null, FILTER_VALIDATE_INT);
if ($familyId === false || $familyId < 1 || $userId === false || $userId < 1) {
    JsonResponse::error('Invalid family or user ID', 422);
}

try {
    $db->beginTransaction();
    $familyStmt = $db->prepare("SELECT id FROM families WHERE id = ? AND status = 'active' FOR UPDATE");
    $familyStmt->execute([$familyId]);
    if (!$familyStmt->fetch()) {
        $db->rollBack();
        JsonResponse::error('Active family not found', 404);
    }

    $adminStmt = $db->prepare(
        "SELECT COUNT(*)
         FROM family_roles fr
         INNER JOIN family_members fm
           ON fm.id = fr.member_id AND fm.family_id = fr.family_id
         INNER JOIN users u ON u.id = fm.user_id AND u.status = 'active'
         WHERE fr.family_id = ? AND fr.role = 'admin'
           AND fm.member_status = 'active'"
    );
    $adminStmt->execute([$familyId]);
    if ((int) $adminStmt->fetchColumn() > 0) {
        $db->rollBack();
        JsonResponse::error('This family already has an eligible administrator', 409);
    }

    $userStmt = $db->prepare(
        "SELECT account.id FROM users account
         WHERE account.id = ? AND account.status = 'active'
           AND NOT EXISTS (
               SELECT 1 FROM family_members fm
               WHERE fm.family_id = ? AND fm.user_id = account.id
                 AND fm.member_status IN ('removed', 'suspended')
           )
           AND (
               SELECT COUNT(*) FROM family_members fm
               WHERE fm.family_id = ? AND fm.user_id = account.id
           )
           <= 1
         FOR UPDATE"
    );
    $userStmt->execute([$userId, $familyId, $familyId]);
    if (!$userStmt->fetch()) {
        $db->rollBack();
        JsonResponse::error('Target must be an active account not already linked to this family', 422);
    }

    $expiredStmt = $db->prepare(
        "SELECT id FROM family_admin_invitations
         WHERE family_id = ? AND invited_user_id = ?
           AND status = 'pending' AND expires_at <= NOW()
         FOR UPDATE"
    );
    $expiredStmt->execute([$familyId, $userId]);
    $expiredInvitations = $expiredStmt->fetchAll();
    foreach ($expiredInvitations as $invitation) {
        $db->prepare(
            "UPDATE family_admin_invitations SET status = 'expired'
             WHERE id = ? AND status = 'pending'"
        )->execute([(int) $invitation['id']]);
        Audit::log(
            'family_admin_invitation_expired',
            (int) $familyId,
            'family_admin_invitation',
            (int) $invitation['id']
        );
    }

    $pendingStmt = $db->prepare(
        "SELECT id FROM family_admin_invitations
         WHERE family_id = ? AND invited_user_id = ? AND status = 'pending'
         LIMIT 1 FOR UPDATE"
    );
    $pendingStmt->execute([$familyId, $userId]);
    if ($pendingStmt->fetch()) {
        $db->rollBack();
        JsonResponse::error('A pending invitation already exists for this account', 409);
    }

    $insert = $db->prepare(
        "INSERT INTO family_admin_invitations
         (family_id, invited_user_id, invited_by_user_id, expires_at)
         VALUES (?, ?, ?, DATE_ADD(NOW(), INTERVAL 7 DAY))"
    );
    $insert->execute([$familyId, $userId, (int) $admin['id']]);
    $invitationId = (int) $db->lastInsertId();
    Audit::log(
        'family_admin_invitation_created',
        (int) $familyId,
        'family_admin_invitation',
        $invitationId,
        ['invited_user_id' => (int) $userId]
    );
    $db->commit();

    JsonResponse::ok([
        'message' => 'Invitation created. It will appear in the recipient account after sign-in.',
        'expires_in_days' => 7,
    ], 201);
} catch (Throwable $e) {
    if ($db->inTransaction()) {
        $db->rollBack();
    }
    error_log('Family administrator invitation creation failed: ' . $e->getMessage());
    JsonResponse::error('Could not create family administrator invitation', 500);
}
