<?php
declare(strict_types=1);

require_once __DIR__ . '/../../../src/bootstrap.php';
require_once __DIR__ . '/../../../src/SuperAdminApi.php';

SuperAdminApi::requireMethod('GET');
Auth::requireSuperAdmin();

try {
    $pagination = SuperAdminApi::pagination();
    $familyPage = filter_var($_GET['family_page'] ?? $pagination['page'], FILTER_VALIDATE_INT);
    if ($familyPage === false || $familyPage < 1 || $familyPage > 1000000) {
        JsonResponse::error('Invalid family administrator page', 422);
    }
    $search = SuperAdminApi::queryString('q', 100);
    $pattern = '%' . $search . '%';

    $globalCountStmt = $db->prepare(
        "SELECT COUNT(*) FROM users
         WHERE is_admin = 1 AND (? = '' OR email LIKE ?)"
    );
    $globalCountStmt->execute([$search, $pattern]);
    $globalCount = (int) $globalCountStmt->fetchColumn();
    $mfaFlagCount = (int) $db->query(
        "SELECT COUNT(*) FROM users WHERE is_admin = 1 AND mfa_enabled = 1"
    )->fetchColumn();

    $globalStmt = $db->prepare(
        "SELECT id, email, status, mfa_enabled, last_login_at, created_at
         FROM users
         WHERE is_admin = 1 AND (? = '' OR email LIKE ?)
         ORDER BY email ASC, id ASC
         LIMIT ? OFFSET ?"
    );
    $globalStmt->bindValue(1, $search, PDO::PARAM_STR);
    $globalStmt->bindValue(2, $pattern, PDO::PARAM_STR);
    $globalStmt->bindValue(3, $pagination['per_page'], PDO::PARAM_INT);
    $globalStmt->bindValue(4, $pagination['offset'], PDO::PARAM_INT);
    $globalStmt->execute();

    $familyStmt = $db->prepare(
        "SELECT u.id AS user_id, u.email, u.status AS account_status,
                u.last_login_at, f.id AS family_id, f.family_name,
                fm.first_name, fm.last_name, fr.role
         FROM family_roles fr
         INNER JOIN family_members fm
           ON fm.id = fr.member_id AND fm.family_id = fr.family_id
         INNER JOIN families f ON f.id = fr.family_id
         LEFT JOIN users u ON u.id = fm.user_id
         WHERE fr.role = 'admin' AND fm.member_status = 'active'
           AND (? = '' OR u.email LIKE ? OR f.family_name LIKE ?
                OR fm.first_name LIKE ? OR fm.last_name LIKE ?)
         ORDER BY f.family_name ASC, fm.last_name ASC, fm.first_name ASC
         LIMIT ? OFFSET ?"
    );
    foreach ([$search, $pattern, $pattern, $pattern, $pattern] as $index => $value) {
        $familyStmt->bindValue($index + 1, $value, PDO::PARAM_STR);
    }
    $familyStmt->bindValue(6, $pagination['per_page'], PDO::PARAM_INT);
    $familyStmt->bindValue(7, ($familyPage - 1) * $pagination['per_page'], PDO::PARAM_INT);
    $familyStmt->execute();

    $familyCountStmt = $db->prepare(
        "SELECT COUNT(*)
         FROM family_roles fr
         INNER JOIN family_members fm
           ON fm.id = fr.member_id AND fm.family_id = fr.family_id
         INNER JOIN families f ON f.id = fr.family_id
         LEFT JOIN users u ON u.id = fm.user_id
         WHERE fr.role = 'admin' AND fm.member_status = 'active'
           AND (? = '' OR u.email LIKE ? OR f.family_name LIKE ?
                OR fm.first_name LIKE ? OR fm.last_name LIKE ?)"
    );
    $familyCountStmt->execute([$search, $pattern, $pattern, $pattern, $pattern]);

    $familyTotal = (int) $familyCountStmt->fetchColumn();

    JsonResponse::ok([
        'platform_administrators' => $globalStmt->fetchAll(),
        'family_administrators' => $familyStmt->fetchAll(),
        'statistics' => [
            'platform_administrators' => $globalCount,
            'family_administrator_assignments' => $familyTotal,
            'mfa_flagged_platform_accounts' => $mfaFlagCount,
        ],
        'pagination' => [
            'page' => $pagination['page'],
            'family_page' => $familyPage,
            'per_page' => $pagination['per_page'],
            'platform_pages' => (int) ceil($globalCount / $pagination['per_page']),
            'family_pages' => (int) ceil($familyTotal / $pagination['per_page']),
        ],
        'mfa_flow_implemented' => false,
    ]);
} catch (Throwable $e) {
    error_log('Super Admin administrator listing failed: ' . $e->getMessage());
    JsonResponse::error('Could not load administrator records', 500);
}
