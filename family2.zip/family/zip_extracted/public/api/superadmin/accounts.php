<?php
declare(strict_types=1);

require_once __DIR__ . '/../../../src/bootstrap.php';
require_once __DIR__ . '/../../../src/SuperAdminApi.php';

$method = $_SERVER['REQUEST_METHOD'] ?? '';
if (!in_array($method, ['GET', 'POST'], true)) {
    header('Allow: GET, POST');
    JsonResponse::error('Method not allowed', 405);
}

Auth::requireSuperAdmin();

if ($method === 'GET') {
    $search = SuperAdminApi::queryString('q', 100);
    if (mb_strlen($search) < 2) {
        JsonResponse::error('Enter at least two characters to search', 422);
    }

    try {
        $pattern = '%' . $search . '%';
        $stmt = $db->prepare(
            "SELECT id, email, phone, status, email_verified_at
             FROM users
             WHERE email LIKE ? OR phone LIKE ?
             ORDER BY email ASC, id ASC
             LIMIT 50"
        );
        $stmt->execute([$pattern, $pattern]);
        $accounts = $stmt->fetchAll();
        if (!$accounts) {
            JsonResponse::ok(['accounts' => []]);
        }

        $ids = array_map(static fn(array $account): int => (int) $account['id'], $accounts);
        $placeholders = implode(',', array_fill(0, count($ids), '?'));
        $membershipStmt = $db->prepare(
            "SELECT fm.user_id, fm.id AS member_id, fm.family_id, f.family_name,
                    fm.member_status, fr.role
             FROM family_members fm
             INNER JOIN families f ON f.id = fm.family_id
             LEFT JOIN family_roles fr
               ON fr.family_id = fm.family_id AND fr.member_id = fm.id
             WHERE fm.user_id IN ($placeholders)
             ORDER BY f.family_name ASC, fm.id ASC"
        );
        $membershipStmt->execute($ids);
        $memberships = [];
        foreach ($membershipStmt->fetchAll() as $membership) {
            $memberships[(int) $membership['user_id']][] = [
                'member_id' => (int) $membership['member_id'],
                'family_id' => (int) $membership['family_id'],
                'family_name' => $membership['family_name'],
                'member_status' => $membership['member_status'],
                'role' => $membership['role'],
            ];
        }

        $results = [];
        foreach ($accounts as $account) {
            $phone = $account['phone'];
            $results[] = [
                'id' => (int) $account['id'],
                'email' => $account['email'],
                'phone' => is_string($phone) && $phone !== ''
                    ? str_repeat('*', max(2, strlen($phone) - 2)) . substr($phone, -2)
                    : null,
                'status' => $account['status'],
                'email_verified' => $account['email_verified_at'] !== null,
                'memberships' => $memberships[(int) $account['id']] ?? [],
            ];
        }

        JsonResponse::ok(['accounts' => $results]);
    } catch (Throwable $e) {
        error_log('Super Admin account search failed (' . get_class($e) . ')');
        JsonResponse::error('Could not search registered users', 500);
    }
}

Security::requireCsrf();
$data = JsonResponse::input();
$action = $data['action'] ?? null;
$userId = filter_var($data['user_id'] ?? null, FILTER_VALIDATE_INT);
$familyId = filter_var($data['family_id'] ?? null, FILTER_VALIDATE_INT);

if (!is_string($action) || !in_array($action, ['assign', 'revoke'], true)) {
    JsonResponse::error('Invalid family access action', 422);
}
if ($userId === false || $userId < 1 || $familyId === false || $familyId < 1) {
    JsonResponse::error('Invalid user or family ID', 422);
}

$role = $data['role'] ?? null;
if ($action === 'assign' && (!is_string($role) || !in_array($role, ['admin', 'member'], true))) {
    JsonResponse::error('Choose Family Admin or Family Member', 422);
}

$firstName = $data['first_name'] ?? '';
$lastName = $data['last_name'] ?? '';
if (!is_string($firstName) || !is_string($lastName)
    || mb_strlen(trim($firstName)) > 100 || mb_strlen(trim($lastName)) > 100
    || preg_match('/[\x00-\x1F\x7F]/', $firstName . $lastName)) {
    JsonResponse::error('Family profile names must be no longer than 100 characters', 422);
}
$firstName = trim($firstName);
$lastName = trim($lastName);

try {
    $db->beginTransaction();

    $familyStmt = $db->prepare(
        'SELECT id, status FROM families WHERE id = ? FOR UPDATE'
    );
    $familyStmt->execute([$familyId]);
    $family = $familyStmt->fetch();
    if (!$family || ($action === 'assign' && $family['status'] !== 'active')) {
        $db->rollBack();
        JsonResponse::error('An active family is required for this change', 404);
    }

    $userStmt = $db->prepare(
        'SELECT id, email, status, email_verified_at FROM users WHERE id = ? FOR UPDATE'
    );
    $userStmt->execute([$userId]);
    $account = $userStmt->fetch();
    if (!$account) {
        $db->rollBack();
        JsonResponse::error('Registered user not found', 404);
    }
    if ($action === 'assign'
        && ($account['status'] !== 'active' || $account['email_verified_at'] === null)) {
        $db->rollBack();
        JsonResponse::error('Only active users with verified email can be assigned', 409);
    }

    $memberStmt = $db->prepare(
        'SELECT id, member_status FROM family_members
         WHERE family_id = ? AND user_id = ? ORDER BY id FOR UPDATE'
    );
    $memberStmt->execute([$familyId, $userId]);
    $memberRows = $memberStmt->fetchAll();
    if (count($memberRows) > 1) {
        $db->rollBack();
        JsonResponse::error('Duplicate family profiles require review before access can change', 409);
    }

    if ($action === 'revoke') {
        if (!$memberRows) {
            $db->rollBack();
            JsonResponse::error('Family assignment not found', 404);
        }

        $memberId = (int) $memberRows[0]['id'];
        $currentRoleStmt = $db->prepare(
            'SELECT role FROM family_roles WHERE family_id = ? AND member_id = ? FOR UPDATE'
        );
        $currentRoleStmt->execute([$familyId, $memberId]);
        $currentRole = $currentRoleStmt->fetchColumn();
        if ($memberRows[0]['member_status'] === 'active' && $currentRole === 'admin') {
            $otherAdminsStmt = $db->prepare(
                "SELECT COUNT(*)
                 FROM family_roles fr
                 INNER JOIN family_members fm
                   ON fm.id = fr.member_id AND fm.family_id = fr.family_id
                 INNER JOIN users u ON u.id = fm.user_id AND u.status = 'active'
                 WHERE fr.family_id = ? AND fr.role = 'admin'
                   AND fm.member_status = 'active' AND fm.id <> ?"
            );
            $otherAdminsStmt->execute([$familyId, $memberId]);
            if ((int) $otherAdminsStmt->fetchColumn() === 0) {
                $db->rollBack();
                JsonResponse::error('Assign another Family Admin before revoking the last one', 409);
            }
        }

        $db->prepare(
            "UPDATE family_members SET member_status = 'removed'
             WHERE id = ? AND member_status <> 'removed'"
        )->execute([$memberId]);
        $db->prepare(
            "UPDATE membership_requests
             SET status = 'cancelled', reviewed_at = NOW()
             WHERE family_id = ? AND applicant_member_id = ? AND status = 'pending'"
        )->execute([$familyId, $memberId]);
        $db->prepare(
            "UPDATE family_admin_invitations SET status = 'revoked'
             WHERE family_id = ? AND invited_user_id = ? AND status = 'pending'"
        )->execute([$familyId, $userId]);
        $db->prepare(
            "UPDATE family_invitations
             SET status = 'revoked', revoked_at = NOW(), token_hash = ?
             WHERE family_id = ? AND invitee_email = ? AND status = 'pending'"
        )->execute([hash('sha256', random_bytes(32)), $familyId, mb_strtolower($account['email'])]);
        Audit::log(
            'superadmin_family_access_revoked',
            (int) $familyId,
            'family_member',
            $memberId,
            ['user_id' => (int) $userId, 'previous_role' => $currentRole ?: 'unassigned']
        );
        $db->commit();
        JsonResponse::ok(['message' => 'Family access revoked']);
    }

    if ($memberRows && in_array($memberRows[0]['member_status'], ['suspended', 'removed'], true)) {
        $db->rollBack();
        JsonResponse::error('Suspended or removed family profiles cannot be reactivated here', 409);
    }

    if ($memberRows) {
        $memberId = (int) $memberRows[0]['id'];
    } else {
        if ($firstName === '' || $lastName === '') {
            $db->rollBack();
            JsonResponse::error('First and last name are required for a new family profile', 422);
        }
        $insertMember = $db->prepare(
            "INSERT INTO family_members (family_id, user_id, first_name, last_name, member_status)
             VALUES (?, ?, ?, ?, 'active')"
        );
        $insertMember->execute([$familyId, $userId, $firstName, $lastName]);
        $memberId = (int) $db->lastInsertId();
    }

    $currentRoleStmt = $db->prepare(
        'SELECT role FROM family_roles WHERE family_id = ? AND member_id = ? FOR UPDATE'
    );
    $currentRoleStmt->execute([$familyId, $memberId]);
    $previousRole = $currentRoleStmt->fetchColumn();
    $previousStatus = $memberRows ? $memberRows[0]['member_status'] : 'new';
    if ($memberRows && $memberRows[0]['member_status'] !== 'active') {
        $db->prepare(
            "UPDATE family_members SET member_status = 'active' WHERE id = ?"
        )->execute([$memberId]);
    }

    if ($previousRole === 'admin' && $role !== 'admin' && $previousStatus === 'active') {
        $otherAdminsStmt = $db->prepare(
            "SELECT COUNT(*)
             FROM family_roles fr
             INNER JOIN family_members fm
               ON fm.id = fr.member_id AND fm.family_id = fr.family_id
             INNER JOIN users u ON u.id = fm.user_id AND u.status = 'active'
             WHERE fr.family_id = ? AND fr.role = 'admin'
               AND fm.member_status = 'active' AND fm.id <> ?"
        );
        $otherAdminsStmt->execute([$familyId, $memberId]);
        if ((int) $otherAdminsStmt->fetchColumn() === 0) {
            $db->rollBack();
            JsonResponse::error('Assign another Family Admin before changing the last one', 409);
        }
    }

    $db->prepare(
        "INSERT INTO family_roles (family_id, member_id, role)
         VALUES (?, ?, ?)
         ON DUPLICATE KEY UPDATE role = VALUES(role)"
    )->execute([$familyId, $memberId, $role]);
    $db->prepare(
        "UPDATE membership_requests
         SET status = 'cancelled', reviewed_at = NOW()
         WHERE family_id = ? AND applicant_member_id = ? AND status = 'pending'"
    )->execute([$familyId, $memberId]);
    $db->prepare(
        "UPDATE family_admin_invitations SET status = 'revoked'
         WHERE family_id = ? AND invited_user_id = ? AND status = 'pending'"
    )->execute([$familyId, $userId]);
    $db->prepare(
        "UPDATE family_invitations
         SET status = 'revoked', revoked_at = NOW(), token_hash = ?
         WHERE family_id = ? AND invitee_email = ? AND status = 'pending'"
    )->execute([hash('sha256', random_bytes(32)), $familyId, mb_strtolower($account['email'])]);

    Audit::log(
        'superadmin_family_role_assigned',
        (int) $familyId,
        'family_member',
        $memberId,
        ['user_id' => (int) $userId, 'previous_role' => $previousRole ?: null, 'new_role' => $role]
    );
    $db->commit();
    JsonResponse::ok(['message' => 'Family role saved', 'member_id' => $memberId]);
} catch (Throwable $e) {
    if ($db->inTransaction()) {
        $db->rollBack();
    }
    error_log('Super Admin family role change failed (' . get_class($e) . ')');
    JsonResponse::error('Could not update family access', 500);
}
