<?php
declare(strict_types=1);

require_once __DIR__ . '/../../../src/bootstrap.php';

// Only authenticated, active Super Admins may access this endpoint.
if ($_SERVER['REQUEST_METHOD'] !== 'GET') {
    header('Allow: GET');
    JsonResponse::error('Method not allowed', 405);
}

$user = Auth::requireSuperAdmin();

// Return only safe information about the current administrator.
JsonResponse::ok([
    'message' => 'Super Admin access verified',
    'admin' => [
        'id' => (int) $user['id'],
        'email' => $user['email'],
        'role' => 'Super Admin',
    ],
    'csrf_token' => Security::csrfToken(),
]);
