<?php
declare(strict_types=1);

require_once __DIR__ . '/../../../src/bootstrap.php';
require_once __DIR__ . '/../../../src/SuperAdminApi.php';

$method = $_SERVER['REQUEST_METHOD'] ?? '';
if (!in_array($method, ['GET', 'POST'], true)) {
    header('Allow: GET, POST');
    JsonResponse::error('Method not allowed', 405);
}

$admin = Auth::requireSuperAdmin();
$deliveryEnabled = ($config['mail']['mode'] ?? 'log') !== 'log';

if ($method === 'GET') {
    try {
        $pagination = SuperAdminApi::pagination();
        $count = (int) $db->query('SELECT COUNT(*) FROM family_invitations')->fetchColumn();
        $stmt = $db->prepare(
            "SELECT invitation.id, invitation.family_id, family.family_name,
                    invitation.invitee_email, invitation.invited_role,
                    CASE WHEN invitation.status = 'pending'
                               AND invitation.expires_at <= NOW()
                         THEN 'expired' ELSE invitation.status END AS status,
                    invitation.created_at, invitation.expires_at,
                    invitation.accepted_at, invitation.revoked_at
             FROM family_invitations invitation
             INNER JOIN families family ON family.id = invitation.family_id
             ORDER BY invitation.created_at DESC, invitation.id DESC
             LIMIT ? OFFSET ?"
        );
        $stmt->bindValue(1, $pagination['per_page'], PDO::PARAM_INT);
        $stmt->bindValue(2, $pagination['offset'], PDO::PARAM_INT);
        $stmt->execute();
        JsonResponse::ok([
            'invitations' => $stmt->fetchAll(),
            'delivery_enabled' => $deliveryEnabled,
            'pagination' => [
                'page' => $pagination['page'],
                'per_page' => $pagination['per_page'],
                'total' => $count,
                'pages' => (int) ceil($count / $pagination['per_page']),
            ],
        ]);
    } catch (Throwable $e) {
        error_log('Super Admin invitation listing failed (' . get_class($e) . ')');
        JsonResponse::error('Could not load family invitations', 500);
    }
}

Security::requireCsrf();
$data = JsonResponse::input();
$action = $data['action'] ?? null;
if (!is_string($action) || !in_array($action, ['create', 'resend', 'revoke'], true)) {
    JsonResponse::error('Invalid invitation action', 422);
}
if (!$deliveryEnabled && in_array($action, ['create', 'resend'], true)) {
    JsonResponse::error(
        'Invitation sending is disabled while mail is in development log mode. No invitation was created or resent.',
        503
    );
}

if ($action === 'create') {
    $familyId = filter_var($data['family_id'] ?? null, FILTER_VALIDATE_INT);
    $email = $data['email'] ?? null;
    $role = $data['role'] ?? null;
    $memberId = filter_var($data['member_id'] ?? null, FILTER_VALIDATE_INT);
    if ($familyId === false || $familyId < 1 || !is_string($email)
        || mb_strlen(trim($email)) > 190 || !filter_var(trim($email), FILTER_VALIDATE_EMAIL)
        || !is_string($role) || !in_array($role, ['admin', 'member'], true)) {
        JsonResponse::error('Enter a valid email, active family, and Family Admin or Family Member role', 422);
    }
    if ($memberId !== false && $memberId !== null && $memberId < 1) {
        JsonResponse::error('Invalid target profile ID', 422);
    }
    $email = mb_strtolower(trim($email));

    try {
        $db->beginTransaction();
        $familyStmt = $db->prepare(
            "SELECT id, status FROM families WHERE id = ? FOR UPDATE"
        );
        $familyStmt->execute([$familyId]);
        $family = $familyStmt->fetch();
        if (!$family || $family['status'] !== 'active') {
            $db->rollBack();
            JsonResponse::error('Active family not found', 404);
        }

        if ($memberId !== false && $memberId !== null) {
            $targetStmt = $db->prepare(
                "SELECT id, user_id, member_status, first_name, last_name
                 FROM family_members
                 WHERE id = ? AND family_id = ?
                 FOR UPDATE"
            );
            $targetStmt->execute([$memberId, $familyId]);
            $target = $targetStmt->fetch();
            if (!$target) {
                $db->rollBack();
                JsonResponse::error('Target member profile does not belong to this family', 404);
            }
            if ((int) ($target['user_id'] ?? 0) !== 0) {
                $db->rollBack();
                JsonResponse::error('This profile is already linked to an account and cannot be invited as an unclaimed member', 409);
            }
            if (($target['member_status'] ?? '') !== 'unclaimed') {
                $db->rollBack();
                JsonResponse::error('Only unclaimed profiles can receive targeted member invitations', 409);
            }
        }

        $db->prepare(
            "UPDATE family_invitations
             SET status = 'expired'
             WHERE family_id = ? AND status = 'pending' AND expires_at <= NOW()"
        )->execute([$familyId]);

        $pendingStmt = $db->prepare(
            "SELECT id, expires_at, (expires_at <= NOW()) AS is_expired
             FROM family_invitations
             WHERE family_id = ? AND pending_email = ? AND status = 'pending'
             FOR UPDATE"
        );
        $pendingStmt->execute([$familyId, $email]);
        $existing = $pendingStmt->fetch();
        if ($existing && (int) $existing['is_expired'] === 1) {
            $db->prepare(
                "UPDATE family_invitations SET status = 'expired'
                 WHERE id = ? AND status = 'pending'"
            )->execute([(int) $existing['id']]);
            Audit::log(
                'family_invitation_expired',
                (int) $familyId,
                'family_invitation',
                (int) $existing['id']
            );
            $existing = null;
        }
        if ($existing) {
            $db->rollBack();
            JsonResponse::error('A pending invitation already exists for this email and family', 409);
        }

        if ($memberId !== false && $memberId !== null) {
            $memberPendingStmt = $db->prepare(
                "SELECT id
                 FROM family_invitations
                 WHERE family_id = ? AND member_id = ? AND status = 'pending'
                 LIMIT 1 FOR UPDATE"
            );
            $memberPendingStmt->execute([$familyId, $memberId]);
            if ($memberPendingStmt->fetch()) {
                $db->rollBack();
                JsonResponse::error('A pending invitation already exists for this unclaimed profile', 409);
            }
        }

        $userStmt = $db->prepare('SELECT id FROM users WHERE LOWER(email) = ? LIMIT 1');
        $userStmt->execute([$email]);
        $invitedUserId = $userStmt->fetchColumn();
        $token = bin2hex(random_bytes(32));
        $tokenHash = hash('sha256', $token);
        $insert = $db->prepare(
            "INSERT INTO family_invitations
             (family_id, member_id, invitee_email, invited_user_id, invited_by_user_id,
              invited_role, token_hash, expires_at)
             VALUES (?, ?, ?, ?, ?, ?, ?, DATE_ADD(NOW(), INTERVAL 7 DAY))"
        );
        $insert->execute([
            $familyId,
            $memberId !== false && $memberId !== null ? (int) $memberId : null,
            $email,
            $invitedUserId === false ? null : (int) $invitedUserId,
            (int) $admin['id'],
            $role,
            $tokenHash,
        ]);
        $invitationId = (int) $db->lastInsertId();
        Audit::log(
            'family_invitation_created',
            (int) $familyId,
            'family_invitation',
            $invitationId,
            ['role' => $role, 'member_id' => $memberId !== false && $memberId !== null ? (int) $memberId : null]
        );
        $db->commit();
    } catch (Throwable $e) {
        if ($db->inTransaction()) {
            $db->rollBack();
        }
        error_log('Super Admin invitation creation failed (' . get_class($e) . ')');
        JsonResponse::error('Could not create the family invitation', 500);
    }

    try {
        $link = invitationLink($config, $token);
        $sent = Mailer::sendInvitation(
            $email,
            $link
        );
    } catch (Throwable $e) {
        $sent = false;
        error_log('Family invitation delivery failed (' . get_class($e) . ')');
    }
    unset($token, $tokenHash, $link);

    if (!$sent) {
        if (invalidateInvitation($db, $invitationId, (int) $familyId)) {
            JsonResponse::error('The invitation email could not be delivered. The invitation was revoked.', 502);
        }
        JsonResponse::error('The invitation email failed and its invitation could not be safely invalidated. Contact the administrator.', 500);
    }

    JsonResponse::ok([
        'message' => 'Invitation email submitted to the configured mail transport',
        'invitation_id' => $invitationId,
    ], 201);
}

$invitationId = filter_var($data['invitation_id'] ?? null, FILTER_VALIDATE_INT);
if ($invitationId === false || $invitationId < 1) {
    JsonResponse::error('Invalid invitation ID', 422);
}

try {
    $db->beginTransaction();
    $lookup = $db->prepare('SELECT family_id FROM family_invitations WHERE id = ?');
    $lookup->execute([$invitationId]);
    $familyId = $lookup->fetchColumn();
    if (!$familyId) {
        $db->rollBack();
        JsonResponse::error('Invitation not found', 404);
    }
    $familyId = (int) $familyId;
    $familyStmt = $db->prepare(
        "SELECT id, status FROM families WHERE id = ? FOR UPDATE"
    );
    $familyStmt->execute([$familyId]);
    $family = $familyStmt->fetch();
    $invitationStmt = $db->prepare(
        "SELECT id, invitee_email, invited_role, token_hash, status, created_at,
                expires_at, (expires_at <= NOW()) AS is_expired
         FROM family_invitations
         WHERE id = ? AND family_id = ?
         FOR UPDATE"
    );
    $invitationStmt->execute([$invitationId, $familyId]);
    $invitation = $invitationStmt->fetch();
    if (!$family || !$invitation) {
        $db->rollBack();
        JsonResponse::error('Invitation not found', 404);
    }
    if ($action === 'resend' && $family['status'] !== 'active') {
        $db->rollBack();
        JsonResponse::error('Invitations can only be resent for an active family', 409);
    }
    $resendingExpired = $action === 'resend' && $invitation['status'] === 'expired';
    if ($invitation['status'] !== 'pending' && !$resendingExpired) {
        $db->rollBack();
        JsonResponse::error('Only pending invitations can be changed', 409);
    }
    if ((int) $invitation['is_expired'] === 1 && !$resendingExpired) {
        $db->prepare(
            "UPDATE family_invitations SET status = 'expired'
             WHERE id = ? AND status = 'pending'"
        )->execute([$invitationId]);
        Audit::log('family_invitation_expired', $familyId, 'family_invitation', (int) $invitationId);
        $db->commit();
        JsonResponse::error('Invitation has expired', 410);
    }

    if ($action === 'revoke') {
        $db->prepare(
            "UPDATE family_invitations
             SET status = 'revoked', revoked_at = NOW(), token_hash = ?
             WHERE id = ? AND status = 'pending'"
        )->execute([hash('sha256', random_bytes(32)), $invitationId]);
        Audit::log('family_invitation_revoked', $familyId, 'family_invitation', (int) $invitationId);
        $db->commit();
        JsonResponse::ok(['message' => 'Invitation revoked']);
    }

    if ($resendingExpired) {
        $duplicateStmt = $db->prepare(
            "SELECT id FROM family_invitations
             WHERE family_id = ? AND pending_email = ? AND status = 'pending'
               AND id <> ? LIMIT 1 FOR UPDATE"
        );
        $duplicateStmt->execute([$familyId, $invitation['invitee_email'], $invitationId]);
        if ($duplicateStmt->fetch()) {
            $db->rollBack();
            JsonResponse::error('A newer pending invitation already exists for this email and family', 409);
        }
    } else {
        $ageStmt = $db->prepare(
            'SELECT GREATEST(0, 60 - TIMESTAMPDIFF(SECOND, created_at, NOW()))
             FROM family_invitations WHERE id = ?'
        );
        $ageStmt->execute([$invitationId]);
        $retryAfter = (int) $ageStmt->fetchColumn();
        if ($retryAfter > 0) {
            $db->rollBack();
            JsonResponse::error('Please wait before resending this invitation', 429, [
                'retry_after_seconds' => $retryAfter,
            ]);
        }
    }

    $oldStatus = $invitation['status'];
    $oldTokenHash = $invitation['token_hash'];
    $oldCreatedAt = $invitation['created_at'];
    $oldExpiresAt = $invitation['expires_at'];
    $token = bin2hex(random_bytes(32));
    $newTokenHash = hash('sha256', $token);
    $db->prepare(
        "UPDATE family_invitations
         SET status = 'pending', revoked_at = NULL, token_hash = ?, created_at = NOW(),
             expires_at = DATE_ADD(NOW(), INTERVAL 7 DAY)
         WHERE id = ? AND status IN ('pending','expired')"
    )->execute([$newTokenHash, $invitationId]);
    Audit::log('family_invitation_resent', $familyId, 'family_invitation', (int) $invitationId);
    $db->commit();
} catch (Throwable $e) {
    if ($db->inTransaction()) {
        $db->rollBack();
    }
    error_log('Super Admin invitation update failed (' . get_class($e) . ')');
    JsonResponse::error('Could not update the family invitation', 500);
}

try {
    $link = invitationLink($config, $token);
    $sent = Mailer::sendInvitation($invitation['invitee_email'], $link);
} catch (Throwable $e) {
    $sent = false;
    error_log('Family invitation resend failed (' . get_class($e) . ')');
}
unset($token, $link);

if (!$sent) {
    $restored = false;
    try {
        $db->beginTransaction();
        $restore = $db->prepare(
            "UPDATE family_invitations
             SET status = ?, token_hash = ?, created_at = ?, expires_at = ?
             WHERE id = ? AND status = 'pending' AND token_hash = ?"
        );
        $restore->execute([
            $oldStatus,
            $oldTokenHash,
            $oldCreatedAt,
            $oldExpiresAt,
            $invitationId,
            $newTokenHash,
        ]);
        $restored = $restore->rowCount() === 1;
        Audit::log('family_invitation_resend_failed', $familyId, 'family_invitation', (int) $invitationId);
        $db->commit();
    } catch (Throwable $e) {
        if ($db->inTransaction()) {
            $db->rollBack();
        }
        error_log('Family invitation resend rollback failed (' . get_class($e) . ')');
    }
    unset($newTokenHash);
    if ($restored) {
        JsonResponse::error('The new invitation email could not be delivered. The previous invitation remains valid if still unexpired.', 502);
    }
    if (invalidateInvitation($db, (int) $invitationId, $familyId)) {
        JsonResponse::error('The new invitation email failed and the invitation was revoked because its previous state could not be restored.', 502);
    }
    JsonResponse::error('The new invitation email failed and its previous state could not be confirmed. Contact the administrator.', 500);
}

unset($newTokenHash);
JsonResponse::ok(['message' => 'Invitation email submitted to the configured mail transport']);

function invitationLink(array $config, string $token): string
{
    $base = parse_url((string) ($config['base_url'] ?? ''));
    if (!is_array($base) || empty($base['scheme']) || empty($base['host'])) {
        throw new RuntimeException('Application base URL is not configured');
    }
    $scriptName = (string) ($_SERVER['SCRIPT_NAME'] ?? '');
    if ($scriptName === '') {
        throw new RuntimeException('Application route is not available');
    }
    $appPath = dirname(dirname(dirname(dirname(dirname($scriptName)))));
    $appPath = $appPath === DIRECTORY_SEPARATOR || $appPath === '.'
        ? ''
        : '/' . trim(str_replace('\\', '/', $appPath), '/');
    $port = isset($base['port']) ? ':' . $base['port'] : '';
    return $base['scheme'] . '://' . $base['host'] . $port
        . $appPath . '/accept-invitation.html#invitation=' . rawurlencode($token);
}

function invalidateInvitation(PDO $db, int $invitationId, int $familyId): bool
{
    try {
        $db->beginTransaction();
        $update = $db->prepare(
            "UPDATE family_invitations
             SET status = 'revoked', revoked_at = NOW(), token_hash = ?
             WHERE id = ? AND status = 'pending'"
        );
        $update->execute([hash('sha256', random_bytes(32)), $invitationId]);
        if ($update->rowCount() !== 1) {
            $status = $db->prepare('SELECT status FROM family_invitations WHERE id = ? FOR UPDATE');
            $status->execute([$invitationId]);
            $currentStatus = $status->fetchColumn();
            $db->rollBack();
            return $currentStatus === 'revoked';
        }
        Audit::log('family_invitation_delivery_failed', $familyId, 'family_invitation', $invitationId);
        $db->commit();
        return true;
    } catch (Throwable $e) {
        if ($db->inTransaction()) {
            $db->rollBack();
        }
        error_log('Failed invitation invalidation failed (' . get_class($e) . ')');
        return false;
    }
}
