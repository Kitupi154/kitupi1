<?php
declare(strict_types=1);

require_once __DIR__ . '/../../../src/bootstrap.php';
require_once __DIR__ . '/../../../src/SuperAdminApi.php';

SuperAdminApi::requireMethod('GET');
Auth::requireSuperAdmin();

try {
    $lockedAccounts = (int) $db->query(
        "SELECT COUNT(*) FROM users
         WHERE status = 'locked' OR (locked_until IS NOT NULL AND locked_until > NOW())"
    )->fetchColumn();
    $failedAttempts = (int) $db->query(
        "SELECT COUNT(*) FROM login_attempts
         WHERE success = 0 AND created_at >= DATE_SUB(NOW(), INTERVAL 24 HOUR)"
    )->fetchColumn();
    $globalAdmins = (int) $db->query(
        "SELECT COUNT(*) FROM users WHERE is_admin = 1 AND status = 'active'"
    )->fetchColumn();
    $mfaFlags = (int) $db->query(
        "SELECT COUNT(*) FROM users WHERE is_admin = 1 AND mfa_enabled = 1"
    )->fetchColumn();
    $storageRoot = realpath((string) ($config['upload']['private_root'] ?? ''));
    $documentRoot = realpath((string) ($_SERVER['DOCUMENT_ROOT'] ?? ''));
    $privateStorageIsOutsideWebRoot = $storageRoot !== false
        && $documentRoot !== false
        && stripos($storageRoot, rtrim($documentRoot, DIRECTORY_SEPARATOR) . DIRECTORY_SEPARATOR) !== 0
        && strcasecmp($storageRoot, $documentRoot) !== 0;

    $eventStmt = $db->query(
        "SELECT al.id, al.action, al.target_type, al.created_at
         FROM audit_logs al
         WHERE al.action IN
           ('login_failed', 'account_locked', 'login_success', 'otp_failed',
            'otp_locked', 'otp_verified', 'password_reset_completed')
         ORDER BY al.created_at DESC, al.id DESC
         LIMIT 10"
    );

    $session = $config['session'];
    JsonResponse::ok([
        'security' => [
            'active_locked_accounts' => $lockedAccounts,
            'failed_login_attempts_24h' => $failedAttempts,
            'active_super_admin_accounts' => $globalAdmins,
            'mfa_flagged_super_admin_accounts' => $mfaFlags,
            'mfa_verification_flow_implemented' => false,
            'login_throttling_enabled' => true,
            'login_throttle_window_minutes' => 15,
            'login_throttle_limit' => 10,
            'session_idle_timeout_seconds' => (int) ($session['idle_timeout_seconds'] ?? 0),
            'secure_cookie_configured' => (bool) ($session['secure'] ?? false),
            'https_request' => isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off',
            'http_only_cookie_configured' => (bool) ($session['httponly'] ?? false),
            'same_site_cookie' => (string) ($session['samesite'] ?? ''),
            'private_storage_outside_web_root' => $privateStorageIsOutsideWebRoot,
            'audit_logging_available' => true,
        ],
        'recent_security_events' => $eventStmt->fetchAll(),
    ]);
} catch (Throwable $e) {
    error_log('Super Admin security summary failed: ' . $e->getMessage());
    JsonResponse::error('Could not load security information', 500);
}
