<?php
require_once __DIR__ . '/../../../src/bootstrap.php';
if ($_SERVER['REQUEST_METHOD'] !== 'POST') JsonResponse::error('POST required',405);
Security::requireCsrf();

$data = JsonResponse::input();
$email = filter_var($data['email'] ?? '', FILTER_VALIDATE_EMAIL);
if (!$email) JsonResponse::error('Valid email required',422);

// Always return the same response to avoid account enumeration.
$stmt = $db->prepare("SELECT id, status FROM users WHERE email=? LIMIT 1");
$stmt->execute([$email]);
$user = $stmt->fetch();

if ($user && $user['status'] !== 'deleted') {
    $db->prepare("UPDATE password_reset_tokens SET consumed_at=NOW() WHERE user_id=? AND consumed_at IS NULL")
       ->execute([$user['id']]);
    $token = Security::randomToken(32);
    $tokenHash = hash('sha256', $token);
    $expires = date('Y-m-d H:i:s', time() + $config['password_reset']['ttl_seconds']);
    $db->prepare("INSERT INTO password_reset_tokens(user_id,token_hash,expires_at) VALUES(?,?,?)")
       ->execute([$user['id'], $tokenHash, $expires]);
    $link = rtrim($config['base_url'], '/') . '/reset-password?token=' . urlencode($token);
    Mailer::sendPasswordReset($email, $link);
    Audit::log('password_reset_requested', null, 'user', (int)$user['id']);
}

JsonResponse::ok(['message' => 'If that email is registered, a reset link has been sent.']);
