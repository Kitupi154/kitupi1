<?php
declare(strict_types=1);

require_once __DIR__ . '/../../../src/bootstrap.php';

if (($_SERVER['REQUEST_METHOD'] ?? '') !== 'POST') {
    header('Allow: POST');
    JsonResponse::error('Method not allowed', 405);
}

Security::requireCsrf();
$user = Auth::requireLogin();
$data = JsonResponse::input();
$currentPassword = $data['current_password'] ?? null;
$newPassword = $data['new_password'] ?? null;
$confirmation = $data['confirm_password'] ?? null;

if (!is_string($currentPassword) || !is_string($newPassword) || !is_string($confirmation)
    || $currentPassword === '' || strlen($currentPassword) > 1024
    || $newPassword === '' || strlen($newPassword) > 1024
    || $confirmation === '' || strlen($confirmation) > 1024) {
    JsonResponse::error('Enter your current password and a valid new password', 422);
}

if (!Security::verifyPassword($currentPassword, (string) $user['password_hash'])) {
    JsonResponse::error('Current password is incorrect', 403);
}
if (!Security::validatePassword($newPassword)) {
    JsonResponse::error('New password must be at least 12 characters and include uppercase, lowercase, a number, and a symbol', 422);
}
if (!hash_equals($newPassword, $confirmation)) {
    JsonResponse::error('New password confirmation does not match', 422);
}
if (hash_equals($currentPassword, $newPassword)) {
    JsonResponse::error('Choose a new password different from your current password', 422);
}

try {
    $db->beginTransaction();
    $update = $db->prepare(
        'UPDATE users SET password_hash = ?, failed_login_count = 0, locked_until = NULL WHERE id = ?'
    );
    $update->execute([Security::passwordHash($newPassword), (int) $user['id']]);
    if ($update->rowCount() !== 1) {
        $db->rollBack();
        JsonResponse::error('Password could not be changed', 409);
    }

    Audit::log('password_changed', null, 'user', (int) $user['id']);
    $db->commit();

    // Rotate the authenticated session identifier after a credential change.
    session_regenerate_id(true);
    $_SESSION['last_activity'] = time();
    $_SESSION['csrf_token'] = bin2hex(random_bytes(32));

    JsonResponse::ok(['message' => 'Password changed successfully']);
} catch (Throwable $e) {
    if ($db->inTransaction()) {
        $db->rollBack();
    }
    error_log('Password change failed: ' . $e->getMessage());
    JsonResponse::error('Could not change password. Please try again.', 500);
}
