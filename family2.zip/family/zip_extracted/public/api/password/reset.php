<?php
require_once __DIR__ . '/../../../src/bootstrap.php';
if ($_SERVER['REQUEST_METHOD'] !== 'POST') JsonResponse::error('POST required',405);
Security::requireCsrf();

$data = JsonResponse::input();
$token = (string)($data['token'] ?? '');
$password = (string)($data['password'] ?? '');

if ($token === '' || !Security::validatePassword($password)) {
    JsonResponse::error('Valid token and strong password are required',422);
}

$tokenHash = hash('sha256', $token);
$stmt = $db->prepare("SELECT * FROM password_reset_tokens WHERE token_hash=? AND consumed_at IS NULL AND expires_at>NOW() LIMIT 1");
$stmt->execute([$tokenHash]);
$reset = $stmt->fetch();
if (!$reset) JsonResponse::error('Invalid or expired reset link',422);

$db->beginTransaction();
$db->prepare("UPDATE password_reset_tokens SET consumed_at=NOW() WHERE id=?")->execute([$reset['id']]);
$db->prepare("UPDATE users SET password_hash=?, failed_login_count=0, locked_until=NULL WHERE id=?")
   ->execute([Security::passwordHash($password), $reset['user_id']]);
$db->commit();

Audit::log('password_reset_completed', null, 'user', (int)$reset['user_id']);
JsonResponse::ok(['message' => 'Password updated. You can now log in.']);
