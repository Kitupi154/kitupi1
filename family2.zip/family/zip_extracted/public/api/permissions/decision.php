<?php
declare(strict_types=1);

require_once __DIR__ . '/../../../src/bootstrap.php';

if (($_SERVER['REQUEST_METHOD'] ?? '') !== 'POST') {
    header('Allow: POST');
    JsonResponse::error('Method not allowed', 405);
}

Security::requireCsrf();
$user = Auth::requireLogin();
$data = JsonResponse::input();
$permissionId = filter_var($data['permission_id'] ?? null, FILTER_VALIDATE_INT);
$decision = $data['decision'] ?? '';

if ($permissionId === false || $permissionId < 1) {
    JsonResponse::error('Invalid permission ID', 422);
}
if (!is_string($decision) || !in_array($decision, ['approved', 'rejected', 'revoked'], true)) {
    JsonResponse::error('Invalid decision', 422);
}

try {
    $db->beginTransaction();
    $stmt = $db->prepare(
        "SELECT p.id, p.family_id, p.owner_member_id, p.requester_member_id,
                p.status, p.expires_at,
                (p.expires_at IS NOT NULL AND p.expires_at <= NOW()) AS is_expired,
                owner_role.role AS owner_role,
                owner.user_id AS owner_user_id,
                owner.family_id AS owner_family_id,
                owner.member_status AS owner_status,
                requester.family_id AS requester_family_id,
                requester.member_status AS requester_status,
                family.status AS family_status
         FROM permissions p
         INNER JOIN family_members owner ON owner.id = p.owner_member_id
         INNER JOIN family_roles owner_role
           ON owner_role.member_id = owner.id AND owner_role.family_id = owner.family_id
         INNER JOIN family_members requester ON requester.id = p.requester_member_id
         INNER JOIN family_roles requester_role
           ON requester_role.member_id = requester.id AND requester_role.family_id = requester.family_id
         INNER JOIN families family ON family.id = p.family_id
         WHERE p.id = ?
         FOR UPDATE"
    );
    $stmt->execute([$permissionId]);
    $permission = $stmt->fetch();
    if (!$permission) {
        $db->rollBack();
        JsonResponse::error('Permission request not found', 404);
    }

    if ((int) $permission['family_id'] !== (int) $permission['owner_family_id']
        || (int) $permission['family_id'] !== (int) $permission['requester_family_id']
        || $permission['family_status'] !== 'active'
        || $permission['owner_status'] !== 'active'
        || $permission['requester_status'] !== 'active') {
        $db->rollBack();
        JsonResponse::error('Permission request is no longer eligible for a decision', 409);
    }

    if ((int) $permission['owner_user_id'] !== (int) $user['id']) {
        $db->rollBack();
        JsonResponse::error('Only the information owner can decide this request', 403);
    }
    if ($permission['owner_role'] === 'viewer') {
        $db->rollBack();
        JsonResponse::error('Viewer roles cannot modify permission requests', 403);
    }

    if (in_array($decision, ['approved', 'rejected'], true)
        && $permission['status'] !== 'pending') {
        $db->rollBack();
        JsonResponse::error('Only a pending permission request can be approved or rejected', 409);
    }
    if ($decision === 'revoked' && $permission['status'] !== 'approved') {
        $db->rollBack();
        JsonResponse::error('Only an approved permission can be revoked', 409);
    }
    if ($decision === 'approved' && (int) $permission['is_expired'] === 1) {
        $db->rollBack();
        JsonResponse::error('An expired permission request cannot be approved', 409);
    }

    $stmt = $db->prepare(
        "UPDATE permissions
         SET status = ?, decided_at = NOW()
         WHERE id = ? AND status = ?"
    );
    $stmt->execute([$decision, $permissionId, $permission['status']]);
    if ($stmt->rowCount() !== 1) {
        $db->rollBack();
        JsonResponse::error('Permission request has already changed', 409);
    }

    Audit::log('permission_' . $decision, (int) $permission['family_id'], 'permission', (int) $permissionId);
    $db->commit();
    JsonResponse::ok(['message' => 'Permission decision recorded']);
} catch (Throwable $e) {
    if ($db->inTransaction()) {
        $db->rollBack();
    }
    error_log('Permission decision failed: ' . $e->getMessage());
    JsonResponse::error('Could not record permission decision', 500);
}
