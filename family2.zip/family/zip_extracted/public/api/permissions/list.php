<?php
declare(strict_types=1);

require_once __DIR__ . '/../../../src/bootstrap.php';

if (($_SERVER['REQUEST_METHOD'] ?? '') !== 'GET') {
    header('Allow: GET');
    JsonResponse::error('Method not allowed', 405);
}

Auth::requireLogin();
$familyId = filter_var($_GET['family_id'] ?? null, FILTER_VALIDATE_INT);
if ($familyId === false || $familyId < 1) {
    JsonResponse::error('Invalid family ID', 422);
}

$owner = Auth::requireFamilyViewer((int) $familyId);
$stmt = $db->prepare(
    "SELECT permission.id, permission.family_id, permission.owner_member_id,
            permission.requester_member_id, permission.resource_type,
            permission.resource_id, permission.purpose, permission.status,
            permission.expires_at, permission.decided_at, permission.created_at,
            owner.first_name AS owner_first_name,
            owner.last_name AS owner_last_name,
            requester.first_name AS requester_first_name,
            requester.last_name AS requester_last_name
     FROM permissions permission
     INNER JOIN family_members owner
       ON owner.id = permission.owner_member_id
      AND owner.family_id = permission.family_id
     INNER JOIN family_members requester
       ON requester.id = permission.requester_member_id
      AND requester.family_id = permission.family_id
     INNER JOIN families family
       ON family.id = permission.family_id AND family.status = 'active'
     WHERE permission.family_id = ?
       AND (permission.owner_member_id = ? OR permission.requester_member_id = ?)
     ORDER BY permission.created_at DESC, permission.id DESC"
);
$stmt->execute([
    (int) $familyId,
    (int) $owner['id'],
    (int) $owner['id'],
]);
$permissions = $stmt->fetchAll();
foreach ($permissions as &$permission) {
    $isOwner = (int) $permission['owner_member_id'] === (int) $owner['id'];
    $permission['is_owner'] = $isOwner;
    $permission['can_decide'] = $isOwner && ($owner['role'] ?? null) !== 'viewer';
}
unset($permission);

JsonResponse::ok(['permissions' => $permissions]);
