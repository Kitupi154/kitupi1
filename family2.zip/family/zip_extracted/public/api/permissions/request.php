<?php
declare(strict_types=1);

require_once __DIR__ . '/../../../src/bootstrap.php';

if (($_SERVER['REQUEST_METHOD'] ?? '') !== 'POST') {
    header('Allow: POST');
    JsonResponse::error('Method not allowed', 405);
}

Security::requireCsrf();
$data = JsonResponse::input();
$familyId = filter_var($data['family_id'] ?? null, FILTER_VALIDATE_INT);
$ownerId = filter_var($data['owner_member_id'] ?? null, FILTER_VALIDATE_INT);
$resourceId = null;
if (array_key_exists('resource_id', $data) && $data['resource_id'] !== null && $data['resource_id'] !== '') {
    $resourceId = filter_var($data['resource_id'], FILTER_VALIDATE_INT);
}
$type = $data['resource_type'] ?? '';
$purpose = Security::cleanString(
    is_string($data['purpose'] ?? null) ? $data['purpose'] : '',
    500
);

$allowedTypes = ['profile', 'document', 'photo', 'video'];
if ($familyId === false || $familyId < 1 || $ownerId === false || $ownerId < 1) {
    JsonResponse::error('Invalid family or owner ID', 422);
}
if ($resourceId === false || !is_string($type) || !in_array($type, $allowedTypes, true)) {
    JsonResponse::error('Invalid resource details', 422);
}
if ($resourceId !== null && !in_array($type, ['document', 'photo', 'video'], true)) {
    JsonResponse::error('A specific resource ID is only supported for media requests', 422);
}

try {
    $db->beginTransaction();
    $familyStmt = $db->prepare(
        "SELECT id FROM families WHERE id = ? AND status = 'active' FOR UPDATE"
    );
    $familyStmt->execute([$familyId]);
    if (!$familyStmt->fetch()) {
        $db->rollBack();
        JsonResponse::error('Active family not found', 404);
    }

    $requester = Auth::requireFamilyMember((int) $familyId);
    if ((int) $ownerId === (int) $requester['id']) {
        $db->rollBack();
        JsonResponse::error('You own this information already', 422);
    }

    $ownerStmt = $db->prepare(
        "SELECT family_member.id, family_member.user_id, family_member.member_status, family_role.role
         FROM family_members family_member
         INNER JOIN family_roles family_role
           ON family_role.member_id = family_member.id
          AND family_role.family_id = family_member.family_id
         INNER JOIN users owner_account
           ON owner_account.id = family_member.user_id
          AND owner_account.status = 'active'
         WHERE family_member.id = ? AND family_member.family_id = ?
           AND family_member.member_status = 'active'
           AND family_member.user_id IS NOT NULL
         FOR UPDATE"
    );
    $ownerStmt->execute([$ownerId, $familyId]);
    $owner = $ownerStmt->fetch();
    if (!$owner || !in_array($owner['role'], ['admin', 'member'], true)) {
        $db->rollBack();
        JsonResponse::error('Owner is not eligible to grant access', 404);
    }

    if ($resourceId !== null) {
        $mediaType = ['document' => 'document', 'photo' => 'photo', 'video' => 'video'][$type];
        $mediaStmt = $db->prepare(
            "SELECT id FROM media WHERE id = ? AND member_id = ? AND media_type = ?"
        );
        $mediaStmt->execute([$resourceId, $ownerId, $mediaType]);
        if (!$mediaStmt->fetch()) {
            $db->rollBack();
            JsonResponse::error('Requested media was not found for this owner', 404);
        }
    }

    $duplicateStmt = $db->prepare(
        "SELECT id FROM permissions
         WHERE family_id = ? AND owner_member_id = ? AND requester_member_id = ?
           AND resource_type = ?
           AND ((resource_id IS NULL AND ? IS NULL) OR resource_id = ?)
           AND status IN ('pending', 'approved')
         LIMIT 1 FOR UPDATE"
    );
    $duplicateStmt->execute([
        $familyId,
        $ownerId,
        (int) $requester['id'],
        $type,
        $resourceId,
        $resourceId,
    ]);
    if ($duplicateStmt->fetch()) {
        $db->rollBack();
        JsonResponse::error('A matching permission request is already pending or approved', 409);
    }

    $settingsStmt = $db->prepare(
        "SELECT COALESCE(permission_expiry_days, 30) AS expiry_days
         FROM family_settings WHERE family_id = ? LIMIT 1"
    );
    $settingsStmt->execute([(int) $familyId]);
    $expiryDays = (int) ($settingsStmt->fetchColumn() ?: 30);
    if (!in_array($expiryDays, [7, 30, 90], true)) {
        $expiryDays = 30;
    }
    $insert = $db->prepare(
        "INSERT INTO permissions
         (family_id, owner_member_id, requester_member_id, resource_type, resource_id, purpose, expires_at)
         VALUES (?, ?, ?, ?, ?, ?, DATE_ADD(NOW(), INTERVAL ? DAY))"
    );
    $insert->execute([
        $familyId,
        $ownerId,
        (int) $requester['id'],
        $type,
        $resourceId,
        $purpose,
        $expiryDays,
    ]);
    $permissionId = (int) $db->lastInsertId();
    Audit::log('permission_requested', (int) $familyId, 'permission', $permissionId);
    $db->commit();
    JsonResponse::ok(['message' => 'Permission request submitted'], 201);
} catch (Throwable $e) {
    if ($db->inTransaction()) {
        $db->rollBack();
    }
    error_log('Permission request failed: ' . $e->getMessage());
    JsonResponse::error('Could not submit permission request', 500);
}
