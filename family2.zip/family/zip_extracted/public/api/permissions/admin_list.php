<?php
declare(strict_types=1);

require_once __DIR__ . '/../../../src/bootstrap.php';

if (($_SERVER['REQUEST_METHOD'] ?? '') !== 'GET') {
    header('Allow: GET');
    JsonResponse::error('Method not allowed', 405);
}

Auth::requireLogin();
$familyId = filter_var($_GET['family_id'] ?? null, FILTER_VALIDATE_INT);
if ($familyId === false || $familyId < 1) {
    JsonResponse::error('Invalid family ID', 422);
}
Auth::requireFamilyAdmin((int) $familyId);
$stmt = $db->prepare(
    "SELECT p.id, p.owner_member_id, p.requester_member_id, p.resource_type,
            p.resource_id, p.purpose, p.status, p.expires_at, p.decided_at, p.created_at,
            owner.first_name AS owner_first_name, owner.last_name AS owner_last_name,
            requester.first_name AS requester_first_name, requester.last_name AS requester_last_name
     FROM permissions p
     INNER JOIN families f ON f.id = p.family_id AND f.status = 'active'
     INNER JOIN family_members owner ON owner.id = p.owner_member_id
       AND owner.family_id = p.family_id AND owner.member_status = 'active'
     INNER JOIN family_members requester ON requester.id = p.requester_member_id
       AND requester.family_id = p.family_id AND requester.member_status = 'active'
     WHERE p.family_id = ?
     ORDER BY p.created_at DESC, p.id DESC
     LIMIT 200"
);
$stmt->execute([(int) $familyId]);
JsonResponse::ok(['permissions' => $stmt->fetchAll()]);
