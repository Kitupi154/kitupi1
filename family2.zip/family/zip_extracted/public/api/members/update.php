<?php
declare(strict_types=1);

require_once __DIR__ . '/../../../src/bootstrap.php';

if (($_SERVER['REQUEST_METHOD'] ?? '') !== 'POST') {
    header('Allow: POST');
    JsonResponse::error('Method not allowed', 405);
}

Security::requireCsrf();
$user = Auth::requireLogin();
$data = JsonResponse::input();
$memberId = filter_var($data['member_id'] ?? null, FILTER_VALIDATE_INT);
if ($memberId === false || $memberId < 1) {
    JsonResponse::error('Invalid member ID', 422);
}

$stmt = $db->prepare(
    'SELECT id, family_id, user_id, first_name, middle_name, preferred_name, last_name,
            bio, phone, preferred_contact_method, email, member_status
     FROM family_members WHERE id = ? LIMIT 1'
);
$stmt->execute([(int) $memberId]);
$member = $stmt->fetch();
if (!$member) {
    JsonResponse::error('Member not found', 404);
}

$actor = Auth::requireFamilyMember((int) $member['family_id']);
$isOwner = (int) $member['user_id'] === (int) $user['id'];
if (!$isOwner && ($actor['role'] ?? null) !== 'admin') {
    JsonResponse::error('Not authorized', 403);
}
if ($isOwner && $member['member_status'] !== 'active') {
    JsonResponse::error('Only an active member profile can be edited', 403);
}

$values = [];
foreach ([
    'first_name' => ['current' => $member['first_name'], 'max' => 100, 'required' => true],
    'middle_name' => ['current' => $member['middle_name'], 'max' => 100, 'required' => false],
    'preferred_name' => ['current' => $member['preferred_name'], 'max' => 100, 'required' => false],
    'last_name' => ['current' => $member['last_name'], 'max' => 100, 'required' => true],
    'bio' => ['current' => $member['bio'], 'max' => 5000, 'required' => false],
    'phone' => ['current' => $member['phone'], 'max' => 30, 'required' => false],
    'preferred_contact_method' => ['current' => $member['preferred_contact_method'], 'max' => 12, 'required' => false],
    'email' => ['current' => $member['email'], 'max' => 190, 'required' => false],
] as $field => $rules) {
    $value = $data[$field] ?? $rules['current'] ?? '';
    if (!is_string($value) || strlen($value) > $rules['max'] * 4) {
        JsonResponse::error('Invalid ' . str_replace('_', ' ', $field), 422);
    }
    $value = trim($value);
    if (mb_strlen($value) > $rules['max']) {
        JsonResponse::error(ucfirst(str_replace('_', ' ', $field)) . ' is too long', 422);
    }
    if ($rules['required'] && $value === '') {
        JsonResponse::error(ucfirst(str_replace('_', ' ', $field)) . ' is required', 422);
    }
    $values[$field] = $value === '' && !$rules['required'] ? null : $value;
}

if ($values['email'] !== null && filter_var($values['email'], FILTER_VALIDATE_EMAIL) === false) {
    JsonResponse::error('Enter a valid contact email address', 422);
}
if ($values['phone'] !== null && !preg_match('/^\+?[0-9() .-]{5,30}$/D', $values['phone'])) {
    JsonResponse::error('Enter a valid contact phone number', 422);
}
if ($values['preferred_contact_method'] !== null
    && !in_array($values['preferred_contact_method'], ['email', 'phone', 'either', 'none'], true)) {
    JsonResponse::error('Select a valid preferred contact method', 422);
}
if (($values['preferred_contact_method'] === 'email' && $values['email'] === null)
    || ($values['preferred_contact_method'] === 'phone' && $values['phone'] === null)
    || ($values['preferred_contact_method'] === 'either'
        && $values['email'] === null && $values['phone'] === null)) {
    JsonResponse::error('Add the contact details needed for your preferred contact method', 422);
}

try {
    $db->beginTransaction();
    $locked = $db->prepare(
        'SELECT user_id, member_status FROM family_members WHERE id = ? AND family_id = ? FOR UPDATE'
    );
    $locked->execute([(int) $memberId, (int) $member['family_id']]);
    $lockedMember = $locked->fetch();
    if (!$lockedMember) {
        $db->rollBack();
        JsonResponse::error('Member profile was changed or removed; reload and try again', 409);
    }
    $lockedIsOwner = (int) ($lockedMember['user_id'] ?? 0) === (int) $user['id'];
    if (!$lockedIsOwner) {
        $admin = Auth::requireFamilyAdmin((int) $member['family_id']);
        $sensitiveFieldsSubmitted = array_intersect(['bio', 'phone', 'email'], array_keys($data)) !== [];
        if ($sensitiveFieldsSubmitted) {
            $grant = $db->prepare(
                "SELECT permission.id
                 FROM permissions permission
                 INNER JOIN family_roles owner_role
                   ON owner_role.member_id = permission.owner_member_id
                  AND owner_role.family_id = permission.family_id
                 INNER JOIN family_members owner
                   ON owner.id = permission.owner_member_id
                  AND owner.family_id = permission.family_id
                  AND owner.member_status = 'active'
                  AND owner.user_id IS NOT NULL
                 INNER JOIN users owner_account
                   ON owner_account.id = owner.user_id AND owner_account.status = 'active'
                 INNER JOIN family_members requester
                   ON requester.id = permission.requester_member_id
                  AND requester.family_id = permission.family_id
                  AND requester.member_status = 'active'
                 INNER JOIN families family
                   ON family.id = permission.family_id AND family.status = 'active'
                 WHERE permission.family_id = ?
                   AND permission.owner_member_id = ?
                   AND permission.requester_member_id = ?
                   AND permission.resource_type = 'profile'
                   AND (permission.resource_id IS NULL OR permission.resource_id = ?)
                   AND permission.status = 'approved'
                   AND (permission.expires_at IS NULL OR permission.expires_at > NOW())
                   AND owner_role.role IN ('admin', 'member')
                 LIMIT 1 FOR UPDATE"
            );
            $grant->execute([
                (int) $member['family_id'],
                (int) $memberId,
                (int) $admin['id'],
                (int) $memberId,
            ]);
            if (!$grant->fetch()) {
                $db->rollBack();
                JsonResponse::error('The profile owner must grant access before personal details can be changed', 403);
            }
        }
    } elseif ($lockedMember['member_status'] !== 'active') {
        $db->rollBack();
        JsonResponse::error('Only an active member profile can be edited', 403);
    }
    if (!$lockedIsOwner && array_key_exists('preferred_contact_method', $data)) {
        $db->rollBack();
        JsonResponse::error('Only the profile owner can change their preferred contact method', 403);
    }

    $update = $db->prepare(
        'UPDATE family_members
         SET first_name = ?, middle_name = ?, preferred_name = ?, last_name = ?,
             bio = ?, phone = ?, preferred_contact_method = ?, email = ?
         WHERE id = ? AND family_id = ?'
    );
    $update->execute([
        $values['first_name'],
        $values['middle_name'],
        $values['preferred_name'],
        $values['last_name'],
        $values['bio'],
        $values['phone'],
        $values['preferred_contact_method'],
        $values['email'],
        (int) $memberId,
        (int) $member['family_id'],
    ]);
    Audit::log('member_updated', (int) $member['family_id'], 'family_member', (int) $memberId);
    $db->commit();
    JsonResponse::ok(['message' => 'Profile updated']);
} catch (Throwable $e) {
    if ($db->inTransaction()) {
        $db->rollBack();
    }
    error_log('Member profile update failed: ' . $e->getMessage());
    JsonResponse::error('Could not update profile', 500);
}
