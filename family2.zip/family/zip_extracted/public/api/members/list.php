<?php
declare(strict_types=1);

require_once __DIR__ . '/../../../src/bootstrap.php';

if (($_SERVER['REQUEST_METHOD'] ?? '') !== 'GET') {
    header('Allow: GET');
    JsonResponse::error('Method not allowed', 405);
}

$familyId = filter_var($_GET['family_id'] ?? null, FILTER_VALIDATE_INT);
if ($familyId === false || $familyId < 1) {
    JsonResponse::error('Invalid family ID', 422);
}
Auth::requireFamilyAdmin((int) $familyId);

$stmt = $db->prepare(
    'SELECT member.id, member.first_name, member.middle_name, member.preferred_name, member.last_name,
            member.member_status, member.created_at, role.role
     FROM family_members member
     LEFT JOIN family_roles role
       ON role.family_id = member.family_id AND role.member_id = member.id
     WHERE member.family_id = ?
     ORDER BY member.first_name, member.last_name, member.id'
);
$stmt->execute([(int) $familyId]);
JsonResponse::ok(['members' => $stmt->fetchAll()]);
