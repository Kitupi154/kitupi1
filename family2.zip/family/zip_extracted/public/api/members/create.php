<?php
declare(strict_types=1);

require_once __DIR__ . '/../../../src/bootstrap.php';

if (($_SERVER['REQUEST_METHOD'] ?? '') !== 'POST') {
    header('Allow: POST');
    JsonResponse::error('Method not allowed', 405);
}

Security::requireCsrf();
$data = JsonResponse::input();
$familyId = filter_var($data['family_id'] ?? null, FILTER_VALIDATE_INT);
if ($familyId === false || $familyId < 1) {
    JsonResponse::error('Invalid family ID', 422);
}
$admin = Auth::requireFamilyAdmin((int) $familyId);

$readString = static function (array $input, string $key, int $max, bool $required = false): ?string {
    $value = $input[$key] ?? '';
    if (!is_string($value) || strlen($value) > $max * 4) {
        JsonResponse::error('Invalid ' . str_replace('_', ' ', $key), 422);
    }
    $value = trim($value);
    if (mb_strlen($value) > $max) {
        JsonResponse::error(ucfirst(str_replace('_', ' ', $key)) . ' is too long', 422);
    }
    if ($required && $value === '') {
        JsonResponse::error(ucfirst(str_replace('_', ' ', $key)) . ' is required', 422);
    }
    return $value === '' ? null : $value;
};

$first = $readString($data, 'first_name', 100, true);
$middle = $readString($data, 'middle_name', 100);
$preferred = $readString($data, 'preferred_name', 100);
$last = $readString($data, 'last_name', 100, true);
$gender = $data['gender'] ?? 'unspecified';
$dobValue = $data['date_of_birth'] ?? '';
$inviteeEmail = $data['invitee_email'] ?? null;
if (!is_string($gender)
    || !in_array($gender, ['male', 'female', 'other', 'unspecified'], true)) {
    JsonResponse::error('Invalid gender', 422);
}
if ($inviteeEmail !== null && !is_string($inviteeEmail)) {
    JsonResponse::error('Invalid invitee email', 422);
}
if ($inviteeEmail !== null) {
    $inviteeEmail = trim(mb_strtolower((string) $inviteeEmail));
    if ($inviteeEmail === '') {
        $inviteeEmail = null;
    } elseif (filter_var($inviteeEmail, FILTER_VALIDATE_EMAIL) === false) {
        JsonResponse::error('Invalid invitee email', 422);
    }
}
if (!is_string($dobValue)) {
    JsonResponse::error('Invalid date of birth', 422);
}
$dob = null;
if ($dobValue !== '') {
    $parsedDob = DateTimeImmutable::createFromFormat('!Y-m-d', $dobValue);
    $dateErrors = DateTimeImmutable::getLastErrors();
    if (!$parsedDob || ($dateErrors !== false
        && ($dateErrors['warning_count'] > 0 || $dateErrors['error_count'] > 0))
        || $parsedDob->format('Y-m-d') !== $dobValue
        || $parsedDob > new DateTimeImmutable('today')) {
        JsonResponse::error('Enter a valid date of birth that is not in the future', 422);
    }
    $dob = $dobValue;
}

try {
    $db->beginTransaction();
    $stmt = $db->prepare(
        "INSERT INTO family_members
         (family_id, first_name, middle_name, preferred_name, last_name, gender, date_of_birth, member_status)
         SELECT id, ?, ?, ?, ?, ?, ?, 'unclaimed'
         FROM families WHERE id = ? AND status = 'active'"
    );
    $stmt->execute([$first, $middle, $preferred, $last, $gender, $dob, (int) $familyId]);
    if ($stmt->rowCount() !== 1) {
        $db->rollBack();
        JsonResponse::error('Active family not found', 404);
    }
    $memberId = (int) $db->lastInsertId();
    Audit::log('member_created', (int) $familyId, 'family_member', $memberId);

    if ($inviteeEmail !== null) {
        $existingUser = $db->prepare('SELECT id FROM users WHERE LOWER(email) = ? LIMIT 1');
        $existingUser->execute([$inviteeEmail]);
        $invitedUserId = $existingUser->fetchColumn();

        $db->prepare(
            "UPDATE family_invitations
             SET status = 'expired'
             WHERE family_id = ? AND status = 'pending' AND expires_at <= NOW()"
        )->execute([(int) $familyId]);

        $similar = $db->prepare(
            "SELECT id FROM family_invitations
             WHERE family_id = ? AND member_id = ? AND status = 'pending'
             LIMIT 1 FOR UPDATE"
        );
        $similar->execute([(int) $familyId, $memberId]);
        if ($similar->fetch()) {
            $db->rollBack();
            JsonResponse::error('A pending invitation already exists for this unclaimed profile', 409);
        }
        $pendingEmailStmt = $db->prepare(
            "SELECT id FROM family_invitations
             WHERE family_id = ? AND pending_email = ? AND status = 'pending'
             LIMIT 1 FOR UPDATE"
        );
        $pendingEmailStmt->execute([(int) $familyId, $inviteeEmail]);
        if ($pendingEmailStmt->fetch()) {
            $db->rollBack();
            JsonResponse::error('A pending invitation already exists for this email and family', 409);
        }
        $token = bin2hex(random_bytes(32));
        $tokenHash = hash('sha256', $token);
        $invitation = $db->prepare(
            "INSERT INTO family_invitations
             (family_id, member_id, invitee_email, invited_user_id, invited_by_user_id, invited_role, token_hash, expires_at)
             VALUES (?, ?, ?, ?, ?, 'member', ?, DATE_ADD(NOW(), INTERVAL 7 DAY))"
        );
        $invitation->execute([
            (int) $familyId,
            $memberId,
            $inviteeEmail,
            $invitedUserId === false ? null : (int) $invitedUserId,
            (int) $admin['user_id'],
            $tokenHash,
        ]);
        $invitationId = (int) $db->lastInsertId();
        Audit::log('family_invitation_created', (int) $familyId, 'family_invitation', $invitationId, ['member_id' => $memberId, 'role' => 'member']);
        $db->commit();

        $link = invitationLink($config, $token);
        $sent = false;
        try {
            $sent = Mailer::sendInvitation($inviteeEmail, $link);
        } catch (Throwable $e) {
            $sent = false;
            error_log('Family member invitation capture failed (' . get_class($e) . ')');
        }
        unset($token, $link);

        if (!$sent) {
            $message = 'The invitation could not be saved to the local development mail file. The member profile remains unclaimed and the invitation stays pending for a retry.';
            Audit::log('family_invitation_capture_failed', (int) $familyId, 'family_invitation', $invitationId, ['member_id' => $memberId]);
            JsonResponse::error($message, 502);
        }

        $localCapture = ($config['mail']['mode'] ?? 'log') === 'log'
            || ($config['mail']['mode'] ?? 'log') === 'test_capture';
        JsonResponse::ok([
            'message' => $localCapture
                ? 'Member profile created successfully. The invitation was saved to the local development mail file for testing.'
                : 'Member profile created successfully. Invitation sent to ' . $inviteeEmail,
            'member_id' => $memberId,
            'invitation_id' => $invitationId,
        ], 201);
    }

    $db->commit();
    JsonResponse::ok([
        'message' => 'Member profile created successfully.',
        'member_id' => $memberId,
    ], 201);
} catch (Throwable $e) {
    if ($db->inTransaction()) {
        $db->rollBack();
    }
    error_log('Family member profile creation failed: ' . $e->getMessage());
    JsonResponse::error('Could not create family member profile', 500);
}

function invitationLink(array $config, string $token): string
{
    $base = parse_url((string) ($config['base_url'] ?? ''));
    if (!is_array($base) || empty($base['scheme']) || empty($base['host'])) {
        throw new RuntimeException('Application base URL is not configured');
    }
    $scriptName = (string) ($_SERVER['SCRIPT_NAME'] ?? '');
    if ($scriptName === '') {
        throw new RuntimeException('Application route is not available');
    }
    $appPath = dirname($scriptName);
    $appPath = dirname($appPath);
    $appPath = dirname($appPath);
    $appPath = dirname($appPath);
    $appPath = dirname($appPath);
    $appPath = $appPath === DIRECTORY_SEPARATOR || $appPath === '.'
        ? ''
        : '/' . trim(str_replace('\\', '/', $appPath), '/');
    $port = isset($base['port']) ? ':' . $base['port'] : '';
    return $base['scheme'] . '://' . $base['host'] . $port
        . $appPath . '/accept-invitation.html#invitation=' . rawurlencode($token);
}
