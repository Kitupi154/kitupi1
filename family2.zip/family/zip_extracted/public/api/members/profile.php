<?php
declare(strict_types=1);

require_once __DIR__ . '/../../../src/bootstrap.php';

if (($_SERVER['REQUEST_METHOD'] ?? '') !== 'GET') {
    header('Allow: GET');
    JsonResponse::error('Method not allowed', 405);
}

$user = Auth::requireLogin();
$memberId = filter_var($_GET['member_id'] ?? null, FILTER_VALIDATE_INT);
if ($memberId === false || $memberId < 1) {
    JsonResponse::error('Invalid member ID', 422);
}

$stmt = $db->prepare(
    "SELECT family_member.*, family.family_name,
            family_setting.home_region,
            COALESCE(family_setting.profile_visibility, 'family') AS profile_visibility
     FROM family_members family_member
     INNER JOIN families family ON family.id = family_member.family_id
     LEFT JOIN family_settings family_setting ON family_setting.family_id = family.id
     WHERE family_member.id = ? LIMIT 1"
);
$stmt->execute([$memberId]);
$member = $stmt->fetch();
if (!$member) {
    JsonResponse::error('Member not found', 404);
}

$actor = Auth::requireFamilyViewer((int) $member['family_id']);
$isOwner = (int) $member['user_id'] === (int) $user['id'];
$familyDefault = $member['profile_visibility'] === 'family';
$hasProfileGrant = false;

if (!$isOwner) {
    $consent = $db->prepare(
        "SELECT permission.id
         FROM permissions permission
         INNER JOIN family_roles owner_role
           ON owner_role.member_id = permission.owner_member_id
          AND owner_role.family_id = permission.family_id
         INNER JOIN family_members owner
           ON owner.id = permission.owner_member_id
          AND owner.family_id = permission.family_id
          AND owner.member_status = 'active'
          AND owner.user_id IS NOT NULL
         INNER JOIN users owner_account
           ON owner_account.id = owner.user_id
          AND owner_account.status = 'active'
         INNER JOIN family_members requester
           ON requester.id = permission.requester_member_id
          AND requester.family_id = permission.family_id
          AND requester.member_status = 'active'
         INNER JOIN families family
           ON family.id = permission.family_id AND family.status = 'active'
         WHERE permission.family_id = ?
           AND permission.owner_member_id = ?
           AND permission.requester_member_id = ?
           AND permission.resource_type = 'profile'
           AND (permission.resource_id IS NULL OR permission.resource_id = ?)
           AND permission.status = 'approved'
           AND (permission.expires_at IS NULL OR permission.expires_at > NOW())
           AND owner_role.role IN ('admin', 'member')
         LIMIT 1"
    );
    $consent->execute([
        (int) $member['family_id'],
        (int) $member['id'],
        (int) $actor['id'],
        (int) $member['id'],
    ]);
    $hasProfileGrant = (bool) $consent->fetch();
    if (!$familyDefault && !$hasProfileGrant) {
        JsonResponse::error('The profile owner has not granted access', 403);
    }
}

$responseMember = $member;
if (!$isOwner && !$hasProfileGrant) {
    $responseMember = array_intersect_key($member, array_flip([
        'id', 'family_id', 'family_name', 'first_name', 'middle_name', 'preferred_name', 'last_name',
        'gender', 'member_status', 'created_at', 'home_region'
    ]));
} else {
    // Return only fields used by profile views. Keep internal ownership,
    // privacy settings, and any future sensitive columns out of JSON.
    $responseMember = array_intersect_key($member, array_flip([
        'id', 'family_id', 'family_name', 'first_name', 'middle_name', 'preferred_name', 'last_name',
        'gender', 'date_of_birth', 'bio', 'phone', 'preferred_contact_method', 'email',
        'member_status', 'created_at', 'home_region'
    ]));
}
$responseMember['profile_detail_access'] = $isOwner || $hasProfileGrant;
if ($isOwner) {
    $responseMember['profile_visibility'] = $member['profile_visibility'];
    $mediaStmt = $db->prepare(
        "SELECT id, media_type, original_name, visibility, created_at
         FROM media WHERE member_id = ? ORDER BY created_at DESC"
    );
    $mediaStmt->execute([(int) $member['id']]);
    $responseMember['media'] = $mediaStmt->fetchAll();
} else {
    $responseMember['media'] = [];
}

JsonResponse::ok(['member' => $responseMember]);
