# Family Information Management System — Secure PHP Backend

This is a security-focused backend foundation for a private family information system.

Stack:
- PHP 8.2+
- MySQL 8 / MariaDB
- PDO with prepared statements
- PHP sessions
- Argon2id password hashing when available
- CSRF protection
- Login throttling
- OTP/email verification workflow
- RBAC
- Family membership approval
- Relationship management
- Permission requests
- Audit logging
- Secure upload validation
- Private file storage pattern

## Important identity-verification limitation

This project does NOT pretend to verify a NIDA identity automatically. A real NIDA verification requires an official, authorized integration. Until that exists, the backend supports a `pending -> verified/rejected` identity-verification workflow for an authorized verifier.

Do not store or expose NIDA numbers casually. For a production deployment, obtain legal/privacy/security review and use only authorized identity data sources.

## Installation

1. Put the project in XAMPP, for example:
   `C:\xampp\htdocs\family_system`

2. Create a MySQL database and import:
   `database/schema.sql`

3. Copy:
   `config/config.example.php`
   to:
   `config/config.php`

4. Set:
   - database credentials
   - application URL
   - secure cookie settings
   - mail/OTP provider settings

5. Create the private storage directory OUTSIDE the public web root if possible:
   `C:\xampp\family_private_storage`

6. Point Apache's public document root to the `public/` directory in production, or use the included public `.htaccess` during local development.

7. Run:
   `php tools/create_admin.php`

8. Delete or protect `tools/create_admin.php` after the first administrator is created.

## API overview

POST /api/auth/register.php
POST /api/auth/verify_otp.php
POST /api/auth/resend_otp.php
POST /api/auth/login.php
POST /api/auth/logout.php
GET  /api/auth/me.php
POST /api/password/forgot.php
POST /api/password/reset.php

GET  /api/family/my_family.php
POST /api/family/create.php
POST /api/family/join_request.php
POST /api/family/membership_decision.php

GET  /api/members/list.php
POST /api/members/create.php
GET  /api/members/profile.php
POST /api/members/update.php

POST /api/relationships/create.php
POST /api/permissions/request.php
POST /api/permissions/decision.php

POST /api/identity/submit.php
POST /api/identity/review.php

POST /api/media/upload.php
GET  /api/media/list.php

GET /api/audit/list.php

### Browser account registration

When the project is served from `C:\xampp\htdocs\family`, ordinary-user registration is available at `../register.html`, followed by email verification at `../verify-email.html`. Public registration creates a pending account without assigning family or administrator roles. Pending users can request a replacement code through `POST /api/auth/resend_otp.php`; requests are limited to one per 60 seconds and five per rolling hour. In `mail.mode = 'log'`, codes are written to the development mail log rather than delivered to an inbox.

## Version 2 changes

- OTP codes are delivered by email (Mailer, `mail.mode` in config); the
  development OTP is no longer returned in API responses.
- OTP challenges lock after `otp.max_attempts` failed tries; only one active
  challenge per user/channel.
- Accounts lock for 15 minutes after 10 consecutive failed logins.
- New password reset flow (`password/forgot.php`, `password/reset.php`).
- New `GET /api/auth/me.php` session endpoint; sessions expire after
  `session.idle_timeout_seconds` of inactivity.
- New `POST /api/relationships/create.php` endpoint.
- Global administrator role (`users.is_admin`, see `database/migration_002.sql`).
  Only global admins can review identity verifications. `tools/create_admin.php`
  now creates a global admin.
- Family admins can no longer approve their own membership requests.
- Permission requests can be decided by the information owner or a family admin.
- Security headers are sent by both `public/.htaccess` and `src/bootstrap.php`.

### Upgrading from version 1

1. Replace the project files with this version.
2. Run `database/migration_002.sql` against your database.
3. Update `config/config.php` with the new `mail`, `password_reset` and
   `session.idle_timeout_seconds` settings (see `config/config.example.php`).
4. Promote your administrator: `UPDATE users SET is_admin=1 WHERE email='...'`
   (or re-run `php tools/create_admin.php` for a new admin).

## Security notes

This is a strong backend foundation, not a certification or guarantee of security. Before public deployment:
- enable HTTPS
- keep PHP/MySQL/Apache patched
- put private files outside web root
- configure real email/SMS OTP delivery
- add MFA/passkeys for privileged users
- add backups and restore testing
- add monitoring and alerting
- run dependency and penetration testing
- obtain legal/privacy review for identity data
- integrate NIDA only through an authorized service/API if applicable
