<?php
declare(strict_types=1);

final class FamilyInvitationException extends RuntimeException
{
    private int $statusCode;

    public function __construct(string $message, int $statusCode)
    {
        parent::__construct($message);
        $this->statusCode = $statusCode;
    }

    public function statusCode(): int
    {
        return $this->statusCode;
    }
}

final class FamilyInvitation
{
    public static function registrationTokenHash(string $token, string $email): string
    {
        if (!preg_match('/\A[a-f0-9]{64}\z/i', $token)) {
            throw new FamilyInvitationException('Invalid invitation details', 422);
        }

        global $db;
        $tokenHash = hash('sha256', strtolower($token));
        $stmt = $db->prepare(
            "SELECT invitation.id, invitation.family_id, invitation.member_id,
                    invitation.invitee_email, invitation.invited_role, invitation.status,
                    (invitation.expires_at <= NOW()) AS is_expired
             FROM family_invitations invitation
             INNER JOIN families family
               ON family.id = invitation.family_id AND family.status = 'active'
             WHERE invitation.token_hash = ?
             LIMIT 1"
        );
        $stmt->execute([$tokenHash]);
        $invitation = $stmt->fetch();

        if (!$invitation) {
            throw new FamilyInvitationException('Invitation link is invalid or no longer available', 404);
        }
        if ($invitation['status'] !== 'pending') {
            throw new FamilyInvitationException('Invitation has already been used or revoked', 409);
        }
        if ((int) $invitation['is_expired'] === 1) {
            $db->prepare(
                "UPDATE family_invitations SET status = 'expired'
                 WHERE id = ? AND status = 'pending'"
            )->execute([(int) $invitation['id']]);
            throw new FamilyInvitationException('Invitation has expired', 410);
        }
        if ((int) ($invitation['member_id'] ?? 0) < 1
            || $invitation['invited_role'] !== 'member') {
            throw new FamilyInvitationException('This invitation is not for an unclaimed family member profile', 409);
        }
        if (strcasecmp((string) $invitation['invitee_email'], $email) !== 0) {
            throw new FamilyInvitationException('Register with the email address this invitation was sent to', 403);
        }

        $memberStmt = $db->prepare(
            "SELECT id
             FROM family_members
             WHERE id = ? AND family_id = ? AND user_id IS NULL
               AND member_status = 'unclaimed'
             LIMIT 1"
        );
        $memberStmt->execute([(int) $invitation['member_id'], (int) $invitation['family_id']]);
        if (!$memberStmt->fetch()) {
            throw new FamilyInvitationException('This invitation targets a profile that is no longer available to claim', 409);
        }

        return $tokenHash;
    }

    public static function acceptForUser(int $userId, string $tokenHash): array
    {
        if ($userId < 1 || !preg_match('/\A[a-f0-9]{64}\z/D', $tokenHash)) {
            throw new FamilyInvitationException('Invalid invitation details', 422);
        }

        global $db;
        try {
            $db->beginTransaction();

            $lookup = $db->prepare(
                'SELECT family_id
                 FROM family_invitations
                 WHERE token_hash = ?
                 LIMIT 1'
            );
            $lookup->execute([$tokenHash]);
            $familyId = $lookup->fetchColumn();
            if ($familyId === false) {
                throw new FamilyInvitationException('Invitation link is invalid or no longer available', 404);
            }
            $familyId = (int) $familyId;

            $familyStmt = $db->prepare(
                'SELECT id, family_name, status
                 FROM families
                 WHERE id = ?
                 LIMIT 1
                 FOR UPDATE'
            );
            $familyStmt->execute([$familyId]);
            $family = $familyStmt->fetch();

            $invitationStmt = $db->prepare(
                'SELECT id, family_id, member_id, invitee_email, invited_user_id,
                        invited_role, status, expires_at, (expires_at <= NOW()) AS is_expired
                 FROM family_invitations
                 WHERE token_hash = ? AND family_id = ?
                 LIMIT 1
                 FOR UPDATE'
            );
            $invitationStmt->execute([$tokenHash, $familyId]);
            $invitation = $invitationStmt->fetch();

            if (!$family || !$invitation) {
                throw new FamilyInvitationException('Invitation link is invalid or no longer available', 404);
            }
            if ($invitation['status'] !== 'pending') {
                throw new FamilyInvitationException('Invitation has already been used or revoked', 409);
            }
            if ((int) $invitation['is_expired'] === 1) {
                $db->prepare(
                    "UPDATE family_invitations SET status = 'expired'
                     WHERE id = ? AND status = 'pending'"
                )->execute([(int) $invitation['id']]);
                Audit::log('family_invitation_expired', $familyId, 'family_invitation', (int) $invitation['id']);
                $db->commit();
                throw new FamilyInvitationException('Invitation has expired', 410);
            }
            if ($family['status'] !== 'active') {
                throw new FamilyInvitationException('This family is not accepting invitations', 409);
            }
            if ($invitation['invited_role'] !== 'member'
                || (int) ($invitation['member_id'] ?? 0) < 1) {
                throw new FamilyInvitationException('This invitation is not for an unclaimed family member profile', 409);
            }

            $accountStmt = $db->prepare(
                'SELECT id, email, status, email_verified_at
                 FROM users
                 WHERE id = ?
                 LIMIT 1
                 FOR UPDATE'
            );
            $accountStmt->execute([$userId]);
            $account = $accountStmt->fetch();
            if (!$account || $account['status'] !== 'active' || $account['email_verified_at'] === null
                || ($invitation['invited_user_id'] !== null
                    && (int) $invitation['invited_user_id'] !== $userId)
                || strcasecmp((string) $invitation['invitee_email'], (string) $account['email']) !== 0) {
                throw new FamilyInvitationException('This invitation is not valid for the signed-in verified account', 403);
            }

            $memberId = (int) $invitation['member_id'];
            $memberStmt = $db->prepare(
                'SELECT id, user_id, member_status
                 FROM family_members
                 WHERE id = ? AND family_id = ?
                 LIMIT 1
                 FOR UPDATE'
            );
            $memberStmt->execute([$memberId, $familyId]);
            $member = $memberStmt->fetch();
            if (!$member) {
                throw new FamilyInvitationException('This invitation targets a profile that no longer belongs to this family', 409);
            }
            if ($member['user_id'] !== null || $member['member_status'] !== 'unclaimed') {
                throw new FamilyInvitationException('This profile has already been claimed or is no longer available', 409);
            }

            $conflictStmt = $db->prepare(
                'SELECT id
                 FROM family_members
                 WHERE family_id = ? AND user_id = ? AND id <> ?
                 LIMIT 1
                 FOR UPDATE'
            );
            $conflictStmt->execute([$familyId, $userId, $memberId]);
            if ($conflictStmt->fetch()) {
                throw new FamilyInvitationException('This account is already linked to another profile in this family', 409);
            }

            $linkStmt = $db->prepare(
                "UPDATE family_members
                 SET user_id = ?, member_status = 'active', updated_at = NOW()
                 WHERE id = ? AND family_id = ? AND user_id IS NULL
                   AND member_status = 'unclaimed'"
            );
            $linkStmt->execute([$userId, $memberId, $familyId]);
            if ($linkStmt->rowCount() !== 1) {
                throw new FamilyInvitationException('The target profile could not be safely linked to the account', 409);
            }

            $db->prepare(
                "INSERT INTO family_roles (family_id, member_id, role)
                 VALUES (?, ?, 'member')
                 ON DUPLICATE KEY UPDATE role = 'member'"
            )->execute([$familyId, $memberId]);

            $acceptedTokenHash = hash('sha256', random_bytes(32));
            $acceptStmt = $db->prepare(
                "UPDATE family_invitations
                 SET status = 'accepted', accepted_at = NOW(), invited_user_id = ?, token_hash = ?
                 WHERE id = ? AND status = 'pending' AND expires_at > NOW()"
            );
            $acceptStmt->execute([$userId, $acceptedTokenHash, (int) $invitation['id']]);
            if ($acceptStmt->rowCount() !== 1) {
                throw new FamilyInvitationException('Invitation has expired or is no longer pending', 409);
            }

            Audit::log(
                'family_invitation_accepted',
                $familyId,
                'family_invitation',
                (int) $invitation['id'],
                ['member_id' => $memberId, 'role' => 'member']
            );
            $db->commit();

            return [
                'message' => 'Your family invitation has been accepted. Your family membership is now active.',
                'family_id' => $familyId,
                'family_name' => $family['family_name'],
                'role' => 'member',
            ];
        } catch (Throwable $e) {
            if ($db->inTransaction()) {
                $db->rollBack();
            }
            throw $e;
        }
    }
}
