<?php
declare(strict_types=1);

final class Mailer {
    /**
     * Send an email. Uses SMTP via mail() by default; in 'log' mode the
     * message is appended to a local log file for development only.
     *
     * 'test_capture' is reserved for isolated local test runs. It does not send
     * externally and stores the message in a dedicated test-only directory.
     */
    public static function send(string $to, string $subject, string $body): bool {
        global $config;
        $mode = $config['mail']['mode'] ?? 'log';

        if ($mode === 'log') {
            $dir = $config['mail']['log_dir'] ?? sys_get_temp_dir();
            if (!is_dir($dir) && !mkdir($dir, 0770, true) && !is_dir($dir)) {
                return false;
            }
            $line = sprintf("[%s] TO:%s SUBJECT:%s\n%s\n---\n", date('c'), $to, $subject, $body);
            return file_put_contents(rtrim($dir, '/\\').DIRECTORY_SEPARATOR.'family_mail.log', $line, FILE_APPEND | LOCK_EX) !== false;
        }

        if ($mode === 'test_capture') {
            $dir = $config['mail']['capture_dir'] ?? ($config['mail']['log_dir'] ?? sys_get_temp_dir());
            if (!is_dir($dir) && !mkdir($dir, 0770, true) && !is_dir($dir)) {
                return false;
            }
            $line = sprintf("[%s] TO:%s SUBJECT:%s\n%s\n---\n", date('c'), $to, $subject, $body);
            return file_put_contents(rtrim($dir, '/\\').DIRECTORY_SEPARATOR.'family_test_capture.log', $line, FILE_APPEND | LOCK_EX) !== false;
        }

        $from = $config['mail']['from'] ?? 'no-reply@localhost';
        $headers = "From: {$from}\r\nContent-Type: text/plain; charset=utf-8\r\n";
        return mail($to, $subject, $body, $headers);
    }

    public static function sendOtp(string $to, string $code): bool {
        $app = $GLOBALS['config']['app_name'] ?? 'Family System';
        return self::send($to, "$app verification code", "Your verification code is: $code\nIt expires in 10 minutes. If you did not request it, ignore this message.");
    }

    public static function sendInvitation(string $to, string $link): bool {
        global $config;
        $app = $config['app_name'] ?? 'Family System';
        $message = "You have been invited to join a family archive. Accept the invitation using this link (valid for seven days):\n$link\nIf you did not expect this invitation, ignore this message.";

        if (($config['mail']['mode'] ?? 'log') === 'log') {
            return self::send($to, "$app family invitation", $message);
        }

        if (($config['mail']['mode'] ?? 'log') === 'test_capture') {
            return self::send($to, "$app family invitation", $message);
        }

        return self::send(
            $to,
            "$app family invitation",
            $message
        );
    }

    public static function sendPasswordReset(string $to, string $link): bool {
        $app = $GLOBALS['config']['app_name'] ?? 'Family System';
        return self::send($to, "$app password reset", "Reset your password using this link (valid 30 minutes):\n$link\nIf you did not request this, ignore this message.");
    }
}
