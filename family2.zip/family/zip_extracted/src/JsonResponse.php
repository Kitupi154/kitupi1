<?php
declare(strict_types=1);

final class JsonResponse {
    public static function ok(array $data = [], int $status = 200): never {
        http_response_code($status);
        header('Content-Type: application/json; charset=utf-8');
        echo json_encode(['success'=>true] + $data, JSON_UNESCAPED_SLASHES);
        exit;
    }

    public static function error(string $message, int $status = 400, array $extra = []): never {
        http_response_code($status);
        header('Content-Type: application/json; charset=utf-8');
        echo json_encode(['success'=>false,'error'=>$message] + $extra, JSON_UNESCAPED_SLASHES);
        exit;
    }

    public static function input(): array {
        $raw = file_get_contents('php://input');
        if (!$raw) return $_POST;
        $json = json_decode($raw, true);
        return is_array($json) ? $json : $_POST;
    }
}
