<?php
declare(strict_types=1);

$configPath = getenv('KINKEEP_CONFIG_PATH');
if (!is_string($configPath) || $configPath === '' || !is_file($configPath)) {
    $configPath = 'C:/xampp/family_private_config/config.php';
}

$config = require $configPath;

date_default_timezone_set($config['timezone']);

// Security headers (also set in public/.htaccess for Apache).
header('X-Content-Type-Options: nosniff');
header('X-Frame-Options: DENY');
header('Referrer-Policy: strict-origin-when-cross-origin');
header('Cache-Control: no-store');

if (session_status() !== PHP_SESSION_ACTIVE) {
    session_name($config['session']['name']);
    session_set_cookie_params([
        'secure' => $config['session']['secure'],
        'httponly' => $config['session']['httponly'],
        'samesite' => $config['session']['samesite'],
        'path' => '/',
    ]);
    session_start();
}

// Session idle timeout: force re-login after inactivity.
$idleLimit = (int)($config['session']['idle_timeout_seconds'] ?? 1800);
if (isset($_SESSION['last_activity']) && (time() - (int)$_SESSION['last_activity']) > $idleLimit) {
    $_SESSION = [];
    if (ini_get('session.use_cookies')) {
        $p = session_get_cookie_params();
        setcookie(session_name(), '', time() - 42000, $p['path'], $p['domain'] ?? '', $p['secure'], $p['httponly']);
    }
    session_destroy();
    session_start();
}
$_SESSION['last_activity'] = time();

require_once __DIR__ . '/Database.php';
require_once __DIR__ . '/Security.php';
require_once __DIR__ . '/Auth.php';
require_once __DIR__ . '/PageAccess.php';
require_once __DIR__ . '/Audit.php';
require_once __DIR__ . '/JsonResponse.php';
require_once __DIR__ . '/Mailer.php';
require_once __DIR__ . '/FamilyInvitation.php';

$db = Database::get($config['db']);
