<?php
declare(strict_types=1);

final class SuperAdminApi
{
    public static function requireMethod(string $method): void
    {
        if (($_SERVER['REQUEST_METHOD'] ?? '') !== $method) {
            header('Allow: ' . $method);
            JsonResponse::error('Method not allowed', 405);
        }
    }

    public static function pagination(): array
    {
        $page = filter_var($_GET['page'] ?? 1, FILTER_VALIDATE_INT);
        $perPage = filter_var($_GET['per_page'] ?? 25, FILTER_VALIDATE_INT);

        if ($page === false || $page < 1 || $page > 1000000 || $perPage === false || $perPage < 1) {
            JsonResponse::error('Invalid pagination values', 422);
        }

        return [
            'page' => $page,
            'per_page' => min($perPage, 100),
            'offset' => ($page - 1) * min($perPage, 100),
        ];
    }

    public static function queryString(string $key, int $maxLength): string
    {
        $value = $_GET[$key] ?? '';
        if (!is_string($value) || strlen($value) > $maxLength) {
            JsonResponse::error('Invalid ' . $key . ' filter', 422);
        }

        return trim($value);
    }

    public static function validDate(string $value): bool
    {
        $date = DateTimeImmutable::createFromFormat('!Y-m-d', $value);
        return $date !== false && $date->format('Y-m-d') === $value;
    }
}
