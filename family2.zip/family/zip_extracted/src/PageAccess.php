<?php
declare(strict_types=1);

final class PageAccess
{
    public static function requireSuperAdminDashboard(): void
    {
        $user = self::authenticatedUser();
        if ((int) ($user['is_admin'] ?? 0) !== 1) {
            http_response_code(403);
            header('Content-Type: text/plain; charset=UTF-8');
            exit('Forbidden');
        }
    }

    public static function requireFamilyDashboardRole(string $role): void
    {
        if (!in_array($role, ['admin', 'member'], true)) {
            self::redirectToSignIn();
        }

        $user = self::authenticatedUser();
        $familyId = filter_input(INPUT_GET, 'family_id', FILTER_VALIDATE_INT);

        if ($familyId !== null && ($familyId === false || $familyId < 1)) {
            self::redirectToSignIn();
        }

        global $db;

        $sql = "SELECT fm.family_id,
                       COUNT(fm.id) AS membership_count,
                       CASE WHEN COUNT(fm.id) = 1 THEN MIN(fr.role) ELSE NULL END AS role
                FROM family_members fm
                LEFT JOIN family_roles fr
                    ON fr.member_id = fm.id
                   AND fr.family_id = fm.family_id
                INNER JOIN families f
                    ON f.id = fm.family_id
                   AND f.status = 'active'
                WHERE fm.user_id = ?
                  AND fm.member_status = 'active'";
        $params = [(int) $user['id']];

        if ($familyId !== null) {
            $sql .= ' AND fm.family_id = ?';
            $params[] = $familyId;
        }

        $sql .= ' GROUP BY fm.family_id ORDER BY fm.family_id';
        $stmt = $db->prepare($sql);
        $stmt->execute($params);
        $memberships = $stmt->fetchAll();

        $hasAuthorizedFamily = false;
        foreach ($memberships as $membership) {
            if ((int) $membership['membership_count'] === 1 && $membership['role'] === $role) {
                $hasAuthorizedFamily = true;
                break;
            }
        }

        if (!$hasAuthorizedFamily) {
            self::redirectToSignIn();
        }
    }

    /**
     * Require an active signed-in account for pages that support family discovery
     * and membership requests before the account has an active family role.
     */
    public static function requireSignedInUser(): void
    {
        self::authenticatedUser();
    }

    private static function authenticatedUser(): array
    {
        $user = Auth::user();
        if (!$user || $user['status'] !== 'active') {
            self::redirectToSignIn();
        }

        return $user;
    }

    private static function redirectToSignIn(): never
    {
        header('Location: ../super%20admin/login.php?access=denied', true, 302);
        exit;
    }
}
