<?php
declare(strict_types=1);

final class Audit {
    public static function log(string $action, ?int $familyId = null, ?string $targetType = null, ?int $targetId = null, array $metadata = []): void {
        global $db, $config;
        $user = Auth::user();
        $ipHash = Security::hashClient(Security::clientIp(), $config['app_key']);
        $uaHash = Security::hashClient($_SERVER['HTTP_USER_AGENT'] ?? '', $config['app_key']);

        $stmt = $db->prepare(
            "INSERT INTO audit_logs
             (actor_user_id,family_id,action,target_type,target_id,ip_hash,user_agent_hash,metadata_json)
             VALUES (?,?,?,?,?,?,?,?)"
        );
        $stmt->execute([
            $user['id'] ?? null,
            $familyId,
            $action,
            $targetType,
            $targetId,
            $ipHash,
            $uaHash,
            $metadata ? json_encode($metadata, JSON_UNESCAPED_SLASHES) : null
        ]);
    }
}
