<?php
declare(strict_types=1);

final class Security {
    public static function csrfToken(): string {
        if (empty($_SESSION['csrf_token'])) {
            $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
        }
        return $_SESSION['csrf_token'];
    }

    public static function requireCsrf(): void {
        $sent = $_SERVER['HTTP_X_CSRF_TOKEN'] ?? ($_POST['csrf_token'] ?? '');
        if (!is_string($sent) || !hash_equals(self::csrfToken(), $sent)) {
            JsonResponse::error('Invalid CSRF token', 403);
        }
    }

    public static function passwordHash(string $password): string {
        $algo = defined('PASSWORD_ARGON2ID') ? PASSWORD_ARGON2ID : PASSWORD_DEFAULT;
        return password_hash($password, $algo);
    }

    public static function verifyPassword(string $password, string $hash): bool {
        return password_verify($password, $hash);
    }

    public static function randomToken(int $bytes = 32): string {
        return bin2hex(random_bytes($bytes));
    }

    public static function hmac(string $value, string $key): string {
        return hash_hmac('sha256', $value, $key);
    }

    public static function clientIp(): string {
        // Do not trust X-Forwarded-For unless a trusted reverse proxy is configured.
        return $_SERVER['REMOTE_ADDR'] ?? '0.0.0.0';
    }

    public static function hashClient(string $value, string $key): string {
        return self::hmac($value, $key);
    }

    public static function validatePassword(string $password): bool {
        return strlen($password) >= 12
            && preg_match('/[A-Z]/', $password)
            && preg_match('/[a-z]/', $password)
            && preg_match('/[0-9]/', $password)
            && preg_match('/[^A-Za-z0-9]/', $password);
    }

    public static function cleanString(?string $v, int $max = 255): string {
        $v = trim((string)$v);
        return mb_substr($v, 0, $max);
    }
}
