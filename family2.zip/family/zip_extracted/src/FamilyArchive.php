<?php
declare(strict_types=1);

/**
 * Streaming, authenticated archive envelope for Family Admin exports.
 * The caller derives a domain-separated key from the private app key.
 */
final class FamilyArchive
{
    private const MAGIC = 'KKVAULT1';
    private const CHUNK_BYTES = 65536;
    private const MAX_PLAINTEXT_BYTES = 524288000;

    public static function encryptTar(string $sourcePath, string $destinationPath, string $key): void
    {
        $input = fopen($sourcePath, 'rb');
        $output = fopen($destinationPath, 'xb');
        if (!is_resource($input) || !is_resource($output)) {
            if (is_resource($input)) fclose($input);
            if (is_resource($output)) fclose($output);
            throw new RuntimeException('Could not prepare encrypted archive');
        }

        $counter = 0;
        try {
            self::writeAll($output, self::MAGIC);
            while (!feof($input)) {
                $plain = fread($input, self::CHUNK_BYTES);
                if ($plain === false) throw new RuntimeException('Could not read family archive');
                if ($plain === '') break;
                $nonce = random_bytes(12);
                $tag = '';
                $cipher = openssl_encrypt(
                    $plain,
                    'aes-256-gcm',
                    $key,
                    OPENSSL_RAW_DATA,
                    $nonce,
                    $tag,
                    self::MAGIC . pack('N', $counter),
                    16
                );
                if (!is_string($cipher) || strlen($tag) !== 16) {
                    throw new RuntimeException('Could not encrypt family archive');
                }
                self::writeAll($output, pack('N', strlen($cipher)) . $nonce . $tag . $cipher);
                $counter++;
            }
            self::writeAll($output, pack('N', 0));
        } finally {
            fclose($input);
            fclose($output);
        }
    }

    public static function decryptTar(string $sourcePath, string $destinationPath, string $key): void
    {
        $input = fopen($sourcePath, 'rb');
        $output = fopen($destinationPath, 'xb');
        if (!is_resource($input) || !is_resource($output)) {
            if (is_resource($input)) fclose($input);
            if (is_resource($output)) fclose($output);
            throw new RuntimeException('Could not prepare archive restore');
        }

        $counter = 0;
        $total = 0;
        try {
            if (self::readExact($input, strlen(self::MAGIC)) !== self::MAGIC) {
                throw new RuntimeException('Archive encryption header is invalid');
            }
            while (true) {
                $lengthRaw = self::readExact($input, 4);
                if ($lengthRaw === null) throw new RuntimeException('Encrypted archive is incomplete');
                $length = unpack('Nlength', $lengthRaw)['length'];
                if ($length === 0) {
                    if (fread($input, 1) !== '') throw new RuntimeException('Encrypted archive has trailing data');
                    break;
                }
                if ($length > self::CHUNK_BYTES) throw new RuntimeException('Encrypted archive record exceeds the allowed size');
                $nonce = self::readExact($input, 12);
                $tag = self::readExact($input, 16);
                $cipher = self::readExact($input, $length);
                if ($nonce === null || $tag === null || $cipher === null) {
                    throw new RuntimeException('Encrypted archive is incomplete');
                }
                $plain = openssl_decrypt(
                    $cipher,
                    'aes-256-gcm',
                    $key,
                    OPENSSL_RAW_DATA,
                    $nonce,
                    $tag,
                    self::MAGIC . pack('N', $counter)
                );
                if (!is_string($plain)) throw new RuntimeException('Archive authentication failed');
                $total += strlen($plain);
                if ($total > self::MAX_PLAINTEXT_BYTES) throw new RuntimeException('Archive exceeds the 500 MB restore limit');
                self::writeAll($output, $plain);
                $counter++;
            }
        } finally {
            fclose($input);
            fclose($output);
        }
    }

    private static function writeAll($stream, string $data): void
    {
        $offset = 0;
        while ($offset < strlen($data)) {
            $written = fwrite($stream, substr($data, $offset));
            if ($written === false || $written === 0) throw new RuntimeException('Could not write archive data');
            $offset += $written;
        }
    }

    private static function readExact($stream, int $length): ?string
    {
        $data = '';
        while (strlen($data) < $length && !feof($stream)) {
            $chunk = fread($stream, $length - strlen($data));
            if ($chunk === false) return null;
            $data .= $chunk;
        }
        return strlen($data) === $length ? $data : null;
    }
}
