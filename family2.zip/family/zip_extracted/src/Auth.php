<?php
declare(strict_types=1);

final class Auth
{
    /**
     * Return the currently authenticated user.
     * Locked, suspended, deleted, or missing accounts are logged out.
     */
    public static function user(): ?array
    {
        if (empty($_SESSION['user_id'])) {
            return null;
        }

        global $db;

        $stmt = $db->prepare(
            "SELECT * FROM users WHERE id = ? LIMIT 1"
        );
        $stmt->execute([(int) $_SESSION['user_id']]);

        $user = $stmt->fetch();

        if (
            !$user ||
            in_array(
                $user['status'],
                ['locked', 'suspended', 'deleted'],
                true
            )
        ) {
            self::logout();
            return null;
        }

        if (!self::sessionIsRegistered((int) $user['id'])) {
            self::logout();
            return null;
        }

        return $user;
    }

    /**
     * Require an authenticated, active account.
     * Pending accounts must complete verification first.
     */
    public static function requireLogin(): array
    {
        $user = self::user();

        if (!$user) {
            JsonResponse::error('Authentication required', 401);
        }

        if ($user['status'] !== 'active') {
            JsonResponse::error(
                'Account verification required',
                403
            );
        }

        return $user;
    }

    /**
     * Establish a session for an existing user.
     * Account status must be checked by the calling authentication flow.
     */
    public static function login(int $userId): void
    {
        session_regenerate_id(true);

        $_SESSION['user_id'] = $userId;
        $_SESSION['login_time'] = time();
        $_SESSION['last_activity'] = time();

        self::registerSession($userId);

        Security::csrfToken();
    }

    private static function sessionHash(): string
    {
        global $config;
        return Security::hashClient(session_id(), (string) $config['app_key']);
    }

    private static function registerSession(int $userId): void
    {
        global $db;
        $hash = self::sessionHash();
        $stmt = $db->prepare(
            'INSERT INTO user_sessions (session_hash, user_id, created_at, last_seen_at)
             VALUES (?, ?, NOW(), NOW())'
        );
        $stmt->execute([$hash, $userId]);
        $_SESSION['_session_touch_at'] = time();
    }

    /** Register legacy sessions once, and reject sessions revoked by the account owner. */
    private static function sessionIsRegistered(int $userId): bool
    {
        global $db;
        $hash = self::sessionHash();
        $stmt = $db->prepare(
            'SELECT user_id, revoked_at FROM user_sessions WHERE session_hash = ? LIMIT 1'
        );
        $stmt->execute([$hash]);
        $session = $stmt->fetch();
        if (!$session) {
            $insert = $db->prepare(
                'INSERT IGNORE INTO user_sessions (session_hash, user_id, created_at, last_seen_at)
                 VALUES (?, ?, NOW(), NOW())'
            );
            $insert->execute([$hash, $userId]);
            $stmt->execute([$hash]);
            $session = $stmt->fetch();
        }
        if (!$session || (int) $session['user_id'] !== $userId || $session['revoked_at'] !== null) {
            return false;
        }

        $lastTouch = (int) ($_SESSION['_session_touch_at'] ?? 0);
        if (time() - $lastTouch >= 300) {
            $touch = $db->prepare(
                'UPDATE user_sessions SET last_seen_at = NOW()
                 WHERE session_hash = ? AND user_id = ? AND revoked_at IS NULL'
            );
            $touch->execute([$hash, $userId]);
            $_SESSION['_session_touch_at'] = time();
        }
        return true;
    }

    /**
     * Destroy the current session and its cookie.
     */
    public static function logout(): void
    {
        if (session_status() === PHP_SESSION_ACTIVE && !empty($_SESSION['user_id'])) {
            try {
                global $db;
                $stmt = $db->prepare(
                    'UPDATE user_sessions SET revoked_at = COALESCE(revoked_at, NOW()), last_seen_at = NOW()
                     WHERE session_hash = ? AND user_id = ?'
                );
                $stmt->execute([self::sessionHash(), (int) $_SESSION['user_id']]);
            } catch (Throwable $e) {
                error_log('Current session revocation failed during logout');
            }
        }
        $_SESSION = [];

        if (ini_get('session.use_cookies')) {
            $params = session_get_cookie_params();

            setcookie(
                session_name(),
                '',
                [
                    'expires' => time() - 42000,
                    'path' => $params['path'] ?: '/',
                    'domain' => $params['domain'] ?? '',
                    'secure' => (bool) $params['secure'],
                    'httponly' => (bool) $params['httponly'],
                    'samesite' => $params['samesite'] ?? 'Lax',
                ]
            );
        }

        if (session_status() === PHP_SESSION_ACTIVE) {
            session_destroy();
        }
    }

    /**
     * Require an active member of the specified family.
     */
    public static function requireFamilyMember(int $familyId): array
    {
        $member = self::familyMembership($familyId, ['admin', 'member']);
        if (!$member) {
            JsonResponse::error(
                'Active Family Member or Family Admin role required',
                403
            );
        }

        return $member;
    }

    /**
     * Require the admin role within the specified family.
     * This does not grant global Super Admin access.
     */
    public static function requireFamilyAdmin(int $familyId): array
    {
        $member = self::familyMembership($familyId, ['admin']);
        if (!$member) {
            JsonResponse::error(
                'Active Family Admin role required for this family',
                403
            );
        }

        return $member;
    }

    /**
     * Require an active family membership for explicitly read-only operations.
     */
    public static function requireFamilyViewer(int $familyId): array
    {
        $member = self::familyMembership($familyId, ['admin', 'member', 'viewer']);
        if (!$member) {
            JsonResponse::error(
                'Active family membership required',
                403
            );
        }

        return $member;
    }

    private static function familyMembership(int $familyId, array $roles): ?array
    {
        if ($familyId <= 0) {
            JsonResponse::error('Invalid family ID', 422);
        }

        $user = self::requireLogin();
        global $db;

        $stmt = $db->prepare(
            "SELECT fm.*, fr.role
             FROM family_members fm
             INNER JOIN family_roles fr
                 ON fr.member_id = fm.id
                AND fr.family_id = fm.family_id
             INNER JOIN families f
                 ON f.id = fm.family_id
                AND f.status = 'active'
             WHERE fm.family_id = ?
               AND fm.user_id = ?
               AND fm.member_status = 'active'
             ORDER BY fm.id"
        );
        $stmt->execute([$familyId, (int) $user['id']]);

        $memberships = $stmt->fetchAll();
        if (count($memberships) !== 1
            || !in_array($memberships[0]['role'] ?? null, $roles, true)) {
            return null;
        }

        return $memberships[0];
    }

    /**
     * Require global Super Admin privileges.
     * This checks the users.is_admin column on the server.
     */
    public static function requireSuperAdmin(): array
    {
        $user = self::requireLogin();

        if ((int) ($user['is_admin'] ?? 0) !== 1) {
            JsonResponse::error(
                'Super Admin permission required',
                403
            );
        }

        return $user;
    }
}
