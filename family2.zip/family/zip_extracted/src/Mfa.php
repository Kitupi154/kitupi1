<?php
declare(strict_types=1);

final class Mfa
{
    private const BASE32 = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ234567';
    private const KEY_INFO = 'kinkeep-user-mfa-v1';
    private const AAD = 'kinkeep-user-mfa-v1';

    public static function generateSecret(): string
    {
        return self::base32Encode(random_bytes(20));
    }

    public static function otpauthUri(string $email, string $secret): string
    {
        $label = rawurlencode('KinKeep Vault:' . $email);
        return 'otpauth://totp/' . $label . '?secret=' . rawurlencode($secret)
            . '&issuer=KinKeep%20Vault&algorithm=SHA1&digits=6&period=30';
    }

    public static function encryptSecret(string $secret, string $appKey): string
    {
        $key = hash_hkdf('sha256', $appKey, 32, self::KEY_INFO);
        $nonce = random_bytes(12);
        $tag = '';
        $cipher = openssl_encrypt(
            $secret,
            'aes-256-gcm',
            $key,
            OPENSSL_RAW_DATA,
            $nonce,
            $tag,
            self::AAD,
            16
        );
        if (!is_string($cipher) || strlen($tag) !== 16) {
            throw new RuntimeException('Could not protect multi-factor secret');
        }
        return 'v1:' . base64_encode($nonce . $tag . $cipher);
    }

    public static function decryptSecret(string $stored, string $appKey): string
    {
        if (!str_starts_with($stored, 'v1:')) {
            throw new RuntimeException('Stored multi-factor secret version is unsupported');
        }
        $packed = base64_decode(substr($stored, 3), true);
        if (!is_string($packed) || strlen($packed) < 29) {
            throw new RuntimeException('Stored multi-factor secret is invalid');
        }
        $nonce = substr($packed, 0, 12);
        $tag = substr($packed, 12, 16);
        $cipher = substr($packed, 28);
        $key = hash_hkdf('sha256', $appKey, 32, self::KEY_INFO);
        $secret = openssl_decrypt(
            $cipher,
            'aes-256-gcm',
            $key,
            OPENSSL_RAW_DATA,
            $nonce,
            $tag,
            self::AAD
        );
        if (!is_string($secret)) {
            throw new RuntimeException('Stored multi-factor secret failed authentication');
        }
        return $secret;
    }

    /** Return the accepted time step, or null when the code is invalid or reused. */
    public static function verifyCode(string $secret, string $code, int $lastUsedStep = 0, ?int $now = null): ?int
    {
        if (!preg_match('/^[0-9]{6}$/D', $code)) {
            return null;
        }
        $rawSecret = self::base32Decode($secret);
        if ($rawSecret === null || $rawSecret === '') {
            return null;
        }
        $currentStep = intdiv($now ?? time(), 30);
        for ($offset = -1; $offset <= 1; $offset++) {
            $step = $currentStep + $offset;
            if ($step <= $lastUsedStep || $step < 0) {
                continue;
            }
            $expected = self::hotp($rawSecret, $step);
            if (hash_equals($expected, $code)) {
                return $step;
            }
        }
        return null;
    }

    private static function hotp(string $secret, int $counter): string
    {
        $high = intdiv($counter, 0x100000000);
        $low = $counter % 0x100000000;
        $hash = hash_hmac('sha1', pack('N2', $high, $low), $secret, true);
        $offset = ord($hash[19]) & 0x0f;
        $binary = ((ord($hash[$offset]) & 0x7f) << 24)
            | ((ord($hash[$offset + 1]) & 0xff) << 16)
            | ((ord($hash[$offset + 2]) & 0xff) << 8)
            | (ord($hash[$offset + 3]) & 0xff);
        return str_pad((string) ($binary % 1000000), 6, '0', STR_PAD_LEFT);
    }

    private static function base32Encode(string $bytes): string
    {
        $output = '';
        $buffer = 0;
        $bits = 0;
        for ($i = 0, $length = strlen($bytes); $i < $length; $i++) {
            $buffer = ($buffer << 8) | ord($bytes[$i]);
            $bits += 8;
            while ($bits >= 5) {
                $bits -= 5;
                $output .= self::BASE32[($buffer >> $bits) & 31];
                $buffer &= (1 << $bits) - 1;
            }
        }
        if ($bits > 0) {
            $output .= self::BASE32[($buffer << (5 - $bits)) & 31];
        }
        return $output;
    }

    private static function base32Decode(string $encoded): ?string
    {
        $encoded = strtoupper(rtrim($encoded, '='));
        if ($encoded === '' || !preg_match('/^[A-Z2-7]+$/D', $encoded)) {
            return null;
        }
        $output = '';
        $buffer = 0;
        $bits = 0;
        for ($i = 0, $length = strlen($encoded); $i < $length; $i++) {
            $value = strpos(self::BASE32, $encoded[$i]);
            if ($value === false) {
                return null;
            }
            $buffer = ($buffer << 5) | $value;
            $bits += 5;
            if ($bits >= 8) {
                $bits -= 8;
                $output .= chr(($buffer >> $bits) & 0xff);
                $buffer &= (1 << $bits) - 1;
            }
        }
        return $bits > 0 && $buffer !== 0 ? null : $output;
    }
}
