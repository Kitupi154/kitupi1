<?php
declare(strict_types=1);

return [
    'app_name' => 'Family Information System',
    'base_url' => 'http://localhost/family_system/public',
    'timezone' => 'Africa/Dar_es_Salaam',

    'db' => [
        'host' => '127.0.0.1',
        'port' => 3306,
        'name' => 'family_system',
        'user' => 'root',
        'pass' => '',
        'charset' => 'utf8mb4',
    ],

    // Generate a long random value: php -r "echo bin2hex(random_bytes(32));"
    'app_key' => 'REPLACE_WITH_A_RANDOM_64_BYTE_SECRET',

    'session' => [
        'name' => 'FAMILYSESSID',
        'secure' => false, // true when HTTPS is enabled
        'httponly' => true,
        'samesite' => 'Lax',
        'idle_timeout_seconds' => 1800, // force re-login after 30 min idle
    ],

    'otp' => [
        'ttl_seconds' => 600,
        'max_attempts' => 5,
    ],

    'password_reset' => [
        'ttl_seconds' => 1800,
    ],

    'mail' => [
        // 'log' writes emails to a local file (development only).
        // 'mail' uses PHP mail()/your server's MTA (configure SMTP in php.ini).
        'mode' => 'log',
        'log_dir' => 'C:/xampp/family_private_storage',
        'from' => 'no-reply@example.com',
    ],

    'upload' => [
        'private_root' => 'C:/xampp/family_private_storage',
        'max_photo_bytes' => 5 * 1024 * 1024,
        'max_document_bytes' => 10 * 1024 * 1024,
        'max_video_bytes' => 100 * 1024 * 1024,
    ],
];
