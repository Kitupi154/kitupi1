-- Migration 009: add a nullable target-member reference to family invitations.
-- This preserves legacy email-only invitations, but ensures only one pending
-- invitation may target a specific unclaimed family_members row at a time.
-- The application expires stale pending rows before duplicate creation checks.
-- This file is not executed automatically and must be approved before use.

ALTER TABLE `family_invitations`
  ADD COLUMN `member_id` BIGINT UNSIGNED NULL AFTER `family_id`,
  ADD COLUMN `pending_member_ref` VARCHAR(64)
    GENERATED ALWAYS AS (
      CASE
        WHEN `status` = 'pending' AND `member_id` IS NOT NULL
          THEN CONCAT(CAST(`family_id` AS CHAR), ':', CAST(`member_id` AS CHAR))
        ELSE NULL
      END
    ) STORED AFTER `member_id`;

ALTER TABLE `family_invitations`
  ADD INDEX `idx_family_invitations_member` (`member_id`, `status`, `expires_at`),
  ADD UNIQUE KEY `uq_pending_member_invitation` (`pending_member_ref`);

ALTER TABLE `family_invitations`
  ADD CONSTRAINT `family_invitations_ibfk_member`
  FOREIGN KEY (`member_id`) REFERENCES `family_members` (`id`) ON DELETE SET NULL;

-- Notes:
-- 1. `member_id` stays nullable so legacy email-only invitations still behave normally.
-- 2. `pending_member_ref` is NULL when the invitation is not pending or when no member_id is present.
--    This keeps the unique constraint compatible with MariaDB 10.4 without using NOW() in a generated column.
-- 3. Stale expired invitations are transitioned to status='expired' by the application before duplicate
--    creation checks, so expiry semantics are enforced in logic rather than in a generated column.
-- 4. The application still performs target-profile ownership, active-family, and account-email checks
--    before any invitation is accepted.
