-- Migration 003: family-scoped first Family Admin invitations.
-- Apply after database/schema.sql and migration_002.sql.
-- This migration is not run automatically.

CREATE TABLE family_admin_invitations (
    id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    family_id BIGINT UNSIGNED NOT NULL,
    invited_user_id BIGINT UNSIGNED NOT NULL,
    invited_by_user_id BIGINT UNSIGNED NULL,
    status ENUM('pending','accepted','revoked','expired') NOT NULL DEFAULT 'pending',
    pending_user_id BIGINT UNSIGNED
        GENERATED ALWAYS AS (
            CASE WHEN status = 'pending' THEN invited_user_id ELSE NULL END
        ) STORED,
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    expires_at DATETIME NOT NULL,
    accepted_at DATETIME NULL,
    UNIQUE KEY uq_pending_family_admin_invitation (family_id, pending_user_id),
    INDEX idx_family_admin_invitation_user (invited_user_id, status, expires_at),
    INDEX idx_family_admin_invitation_family (family_id, status, expires_at),
    FOREIGN KEY (family_id) REFERENCES families(id) ON DELETE CASCADE,
    FOREIGN KEY (invited_user_id) REFERENCES users(id) ON DELETE CASCADE,
    FOREIGN KEY (invited_by_user_id) REFERENCES users(id) ON DELETE SET NULL
) ENGINE=InnoDB;
