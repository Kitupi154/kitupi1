-- Migration 002: global admin role + OTP hardening
-- Apply after database/schema.sql. Additive only; safe for existing installs.

ALTER TABLE users
    ADD COLUMN is_admin TINYINT(1) NOT NULL DEFAULT 0 AFTER mfa_enabled;

-- Promote an existing account to global administrator:
-- UPDATE users SET is_admin = 1 WHERE email = 'you@example.com';
