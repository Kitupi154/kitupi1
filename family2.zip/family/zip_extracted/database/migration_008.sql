-- Migration 008: optional family profile display and contact preferences.
-- Apply once to an existing database that does not already have these columns.
ALTER TABLE family_members
    ADD COLUMN preferred_name VARCHAR(100) DEFAULT NULL AFTER middle_name,
    ADD COLUMN preferred_contact_method ENUM('email', 'phone', 'either', 'none') DEFAULT NULL AFTER phone;
