-- Migration 010: private-by-default family discovery for self-service requests.
-- Apply once to an existing database; this file is not executed automatically.
ALTER TABLE families
    ADD COLUMN is_discoverable TINYINT(1) NOT NULL DEFAULT 0
    AFTER status;
