-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Oct 19, 2026 at 11:28 AM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `family`
--

-- --------------------------------------------------------

--
-- Table structure for table `audit_logs`
--

CREATE TABLE `audit_logs` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `actor_user_id` bigint(20) UNSIGNED DEFAULT NULL,
  `family_id` bigint(20) UNSIGNED DEFAULT NULL,
  `action` varchar(100) NOT NULL,
  `target_type` varchar(100) DEFAULT NULL,
  `target_id` bigint(20) UNSIGNED DEFAULT NULL,
  `ip_hash` char(64) DEFAULT NULL,
  `user_agent_hash` char(64) DEFAULT NULL,
  `metadata_json` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`metadata_json`)),
  `created_at` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `audit_logs`
--

INSERT INTO `audit_logs` (`id`, `actor_user_id`, `family_id`, `action`, `target_type`, `target_id`, `ip_hash`, `user_agent_hash`, `metadata_json`, `created_at`) VALUES
(1, 1, NULL, 'login_success', 'user', 1, '2f0e44b71242630ff46ba5acf8bdbd2ee6c99b0b21e79389503ba5059f86a852', 'a7ea00bdc8f1e36221a99c7c413f613015b29106fee2340372ab3a577b5bca2a', NULL, '2026-10-15 22:23:00'),
(2, 1, NULL, 'login_success', 'user', 1, '2f0e44b71242630ff46ba5acf8bdbd2ee6c99b0b21e79389503ba5059f86a852', 'a7ea00bdc8f1e36221a99c7c413f613015b29106fee2340372ab3a577b5bca2a', NULL, '2026-10-16 12:05:38'),
(3, 1, NULL, 'login_success', 'user', 1, '2f0e44b71242630ff46ba5acf8bdbd2ee6c99b0b21e79389503ba5059f86a852', 'ee52e23671fb67d2e9e704b6d59885a548dd5468debc37d5ece24be66cd5fc10', NULL, '2026-10-16 12:30:39'),
(4, 1, NULL, 'login_success', 'user', 1, '2f0e44b71242630ff46ba5acf8bdbd2ee6c99b0b21e79389503ba5059f86a852', 'ee52e23671fb67d2e9e704b6d59885a548dd5468debc37d5ece24be66cd5fc10', NULL, '2026-10-16 15:19:41'),
(5, 1, NULL, 'login_success', 'user', 1, '2f0e44b71242630ff46ba5acf8bdbd2ee6c99b0b21e79389503ba5059f86a852', 'ee52e23671fb67d2e9e704b6d59885a548dd5468debc37d5ece24be66cd5fc10', NULL, '2026-10-16 16:56:50'),
(6, 1, NULL, 'login_success', 'user', 1, '2f0e44b71242630ff46ba5acf8bdbd2ee6c99b0b21e79389503ba5059f86a852', 'a7ea00bdc8f1e36221a99c7c413f613015b29106fee2340372ab3a577b5bca2a', NULL, '2026-10-16 17:10:03'),
(7, 1, NULL, 'login_success', 'user', 1, '2f0e44b71242630ff46ba5acf8bdbd2ee6c99b0b21e79389503ba5059f86a852', 'ee52e23671fb67d2e9e704b6d59885a548dd5468debc37d5ece24be66cd5fc10', NULL, '2026-10-16 18:20:13'),
(8, 1, NULL, 'login_success', 'user', 1, '2f0e44b71242630ff46ba5acf8bdbd2ee6c99b0b21e79389503ba5059f86a852', 'a7ea00bdc8f1e36221a99c7c413f613015b29106fee2340372ab3a577b5bca2a', NULL, '2026-10-16 20:34:37'),
(9, 1, NULL, 'login_success', 'user', 1, '2f0e44b71242630ff46ba5acf8bdbd2ee6c99b0b21e79389503ba5059f86a852', 'ee52e23671fb67d2e9e704b6d59885a548dd5468debc37d5ece24be66cd5fc10', NULL, '2026-10-16 20:39:50'),
(10, 1, NULL, 'login_success', 'user', 1, '2f0e44b71242630ff46ba5acf8bdbd2ee6c99b0b21e79389503ba5059f86a852', 'a7ea00bdc8f1e36221a99c7c413f613015b29106fee2340372ab3a577b5bca2a', NULL, '2026-10-16 22:02:23'),
(11, 1, NULL, 'login_success', 'user', 1, '2f0e44b71242630ff46ba5acf8bdbd2ee6c99b0b21e79389503ba5059f86a852', 'a7ea00bdc8f1e36221a99c7c413f613015b29106fee2340372ab3a577b5bca2a', NULL, '2026-10-17 09:06:38'),
(12, 1, NULL, 'login_success', 'user', 1, '2f0e44b71242630ff46ba5acf8bdbd2ee6c99b0b21e79389503ba5059f86a852', 'a7ea00bdc8f1e36221a99c7c413f613015b29106fee2340372ab3a577b5bca2a', NULL, '2026-10-17 10:11:39'),
(13, NULL, NULL, 'account_registered', 'user', 2, '2f0e44b71242630ff46ba5acf8bdbd2ee6c99b0b21e79389503ba5059f86a852', 'ee52e23671fb67d2e9e704b6d59885a548dd5468debc37d5ece24be66cd5fc10', NULL, '2026-10-18 11:06:19'),
(14, NULL, NULL, 'otp_failed', 'user', 2, '2f0e44b71242630ff46ba5acf8bdbd2ee6c99b0b21e79389503ba5059f86a852', 'ee52e23671fb67d2e9e704b6d59885a548dd5468debc37d5ece24be66cd5fc10', NULL, '2026-10-18 11:31:17'),
(15, 3, NULL, 'account_registered', 'user', 3, '2f0e44b71242630ff46ba5acf8bdbd2ee6c99b0b21e79389503ba5059f86a852', 'ee52e23671fb67d2e9e704b6d59885a548dd5468debc37d5ece24be66cd5fc10', NULL, '2026-10-18 12:17:33'),
(16, 3, NULL, 'otp_verified', 'user', 3, '2f0e44b71242630ff46ba5acf8bdbd2ee6c99b0b21e79389503ba5059f86a852', 'ee52e23671fb67d2e9e704b6d59885a548dd5468debc37d5ece24be66cd5fc10', NULL, '2026-10-18 12:18:10'),
(17, 1, NULL, 'login_success', 'user', 1, '2f0e44b71242630ff46ba5acf8bdbd2ee6c99b0b21e79389503ba5059f86a852', 'a7ea00bdc8f1e36221a99c7c413f613015b29106fee2340372ab3a577b5bca2a', NULL, '2026-10-18 12:20:08'),
(18, 3, NULL, 'login_failed', 'user', 3, '2f0e44b71242630ff46ba5acf8bdbd2ee6c99b0b21e79389503ba5059f86a852', 'ee52e23671fb67d2e9e704b6d59885a548dd5468debc37d5ece24be66cd5fc10', NULL, '2026-10-18 12:41:56'),
(19, 3, NULL, 'login_failed', 'user', 3, '2f0e44b71242630ff46ba5acf8bdbd2ee6c99b0b21e79389503ba5059f86a852', 'ee52e23671fb67d2e9e704b6d59885a548dd5468debc37d5ece24be66cd5fc10', NULL, '2026-10-18 12:42:19'),
(20, 3, NULL, 'login_failed', 'user', 3, '2f0e44b71242630ff46ba5acf8bdbd2ee6c99b0b21e79389503ba5059f86a852', 'ee52e23671fb67d2e9e704b6d59885a548dd5468debc37d5ece24be66cd5fc10', NULL, '2026-10-18 12:52:48'),
(21, 3, NULL, 'login_failed', 'user', 3, '2f0e44b71242630ff46ba5acf8bdbd2ee6c99b0b21e79389503ba5059f86a852', 'ee52e23671fb67d2e9e704b6d59885a548dd5468debc37d5ece24be66cd5fc10', NULL, '2026-10-18 12:53:04'),
(22, 3, NULL, 'login_success', 'user', 3, '2f0e44b71242630ff46ba5acf8bdbd2ee6c99b0b21e79389503ba5059f86a852', 'ee52e23671fb67d2e9e704b6d59885a548dd5468debc37d5ece24be66cd5fc10', NULL, '2026-10-18 13:36:06'),
(23, 1, NULL, 'login_success', 'user', 1, '2f0e44b71242630ff46ba5acf8bdbd2ee6c99b0b21e79389503ba5059f86a852', 'a7ea00bdc8f1e36221a99c7c413f613015b29106fee2340372ab3a577b5bca2a', NULL, '2026-10-18 13:39:29'),
(24, 1, NULL, 'login_success', 'user', 1, '2f0e44b71242630ff46ba5acf8bdbd2ee6c99b0b21e79389503ba5059f86a852', 'bae691be7b79c0cbfc6c1bc84c58e24609b9b159a1d01ca4592b491debff6dd9', NULL, '2026-10-18 14:59:32'),
(25, 1, NULL, 'login_success', 'user', 1, '2f0e44b71242630ff46ba5acf8bdbd2ee6c99b0b21e79389503ba5059f86a852', 'bae691be7b79c0cbfc6c1bc84c58e24609b9b159a1d01ca4592b491debff6dd9', NULL, '2026-10-18 15:00:07'),
(26, 1, NULL, 'login_success', 'user', 1, '2f0e44b71242630ff46ba5acf8bdbd2ee6c99b0b21e79389503ba5059f86a852', 'a7ea00bdc8f1e36221a99c7c413f613015b29106fee2340372ab3a577b5bca2a', NULL, '2026-10-18 15:01:33'),
(27, 1, 1, 'superadmin_family_created', 'family', 1, '2f0e44b71242630ff46ba5acf8bdbd2ee6c99b0b21e79389503ba5059f86a852', 'a7ea00bdc8f1e36221a99c7c413f613015b29106fee2340372ab3a577b5bca2a', '{\"family_name\":\"jibe kitupi\"}', '2026-10-18 15:07:02'),
(28, 1, 1, 'family_admin_invitation_created', 'family_admin_invitation', 1, '2f0e44b71242630ff46ba5acf8bdbd2ee6c99b0b21e79389503ba5059f86a852', 'a7ea00bdc8f1e36221a99c7c413f613015b29106fee2340372ab3a577b5bca2a', '{\"invited_user_id\":3}', '2026-10-18 15:17:26'),
(29, 3, NULL, 'login_success', 'user', 3, '2f0e44b71242630ff46ba5acf8bdbd2ee6c99b0b21e79389503ba5059f86a852', 'ee52e23671fb67d2e9e704b6d59885a548dd5468debc37d5ece24be66cd5fc10', NULL, '2026-10-18 15:18:39'),
(30, 3, 1, 'family_admin_invitation_accepted', 'family_admin_invitation', 1, '2f0e44b71242630ff46ba5acf8bdbd2ee6c99b0b21e79389503ba5059f86a852', 'ee52e23671fb67d2e9e704b6d59885a548dd5468debc37d5ece24be66cd5fc10', '{\"member_id\":1}', '2026-10-18 15:19:31'),
(31, 3, 1, 'member_updated', 'family_member', 1, '2f0e44b71242630ff46ba5acf8bdbd2ee6c99b0b21e79389503ba5059f86a852', 'ee52e23671fb67d2e9e704b6d59885a548dd5468debc37d5ece24be66cd5fc10', NULL, '2026-10-18 15:21:43'),
(32, 3, 1, 'media_uploaded', 'media', 1, '2f0e44b71242630ff46ba5acf8bdbd2ee6c99b0b21e79389503ba5059f86a852', 'ee52e23671fb67d2e9e704b6d59885a548dd5468debc37d5ece24be66cd5fc10', '{\"media_type\":\"photo\"}', '2026-10-18 15:24:12'),
(33, 3, 1, 'media_uploaded', 'media', 2, '2f0e44b71242630ff46ba5acf8bdbd2ee6c99b0b21e79389503ba5059f86a852', 'ee52e23671fb67d2e9e704b6d59885a548dd5468debc37d5ece24be66cd5fc10', '{\"media_type\":\"photo\"}', '2026-10-18 15:24:30'),
(34, 3, 1, 'media_uploaded', 'media', 3, '2f0e44b71242630ff46ba5acf8bdbd2ee6c99b0b21e79389503ba5059f86a852', 'ee52e23671fb67d2e9e704b6d59885a548dd5468debc37d5ece24be66cd5fc10', '{\"media_type\":\"photo\"}', '2026-10-18 15:24:41'),
(35, 3, 1, 'media_uploaded', 'media', 4, '2f0e44b71242630ff46ba5acf8bdbd2ee6c99b0b21e79389503ba5059f86a852', 'ee52e23671fb67d2e9e704b6d59885a548dd5468debc37d5ece24be66cd5fc10', '{\"media_type\":\"photo\"}', '2026-10-18 15:24:49'),
(36, 3, 1, 'media_uploaded', 'media', 5, '2f0e44b71242630ff46ba5acf8bdbd2ee6c99b0b21e79389503ba5059f86a852', 'ee52e23671fb67d2e9e704b6d59885a548dd5468debc37d5ece24be66cd5fc10', '{\"media_type\":\"video\"}', '2026-10-18 15:25:05'),
(37, 3, 1, 'media_uploaded', 'media', 6, '2f0e44b71242630ff46ba5acf8bdbd2ee6c99b0b21e79389503ba5059f86a852', 'ee52e23671fb67d2e9e704b6d59885a548dd5468debc37d5ece24be66cd5fc10', '{\"media_type\":\"document\"}', '2026-10-18 15:26:30'),
(38, 3, 1, 'member_updated', 'family_member', 1, '2f0e44b71242630ff46ba5acf8bdbd2ee6c99b0b21e79389503ba5059f86a852', 'ee52e23671fb67d2e9e704b6d59885a548dd5468debc37d5ece24be66cd5fc10', NULL, '2026-10-18 15:27:45'),
(39, 3, 1, 'member_updated', 'family_member', 1, '2f0e44b71242630ff46ba5acf8bdbd2ee6c99b0b21e79389503ba5059f86a852', 'ee52e23671fb67d2e9e704b6d59885a548dd5468debc37d5ece24be66cd5fc10', NULL, '2026-10-18 15:28:18'),
(40, 4, NULL, 'account_registered', 'user', 4, '2f0e44b71242630ff46ba5acf8bdbd2ee6c99b0b21e79389503ba5059f86a852', 'ee52e23671fb67d2e9e704b6d59885a548dd5468debc37d5ece24be66cd5fc10', NULL, '2026-10-18 15:35:02'),
(41, 4, NULL, 'otp_resend_requested', 'user', 4, '2f0e44b71242630ff46ba5acf8bdbd2ee6c99b0b21e79389503ba5059f86a852', 'ee52e23671fb67d2e9e704b6d59885a548dd5468debc37d5ece24be66cd5fc10', NULL, '2026-10-18 15:36:10'),
(42, 4, NULL, 'otp_verified', 'user', 4, '2f0e44b71242630ff46ba5acf8bdbd2ee6c99b0b21e79389503ba5059f86a852', 'ee52e23671fb67d2e9e704b6d59885a548dd5468debc37d5ece24be66cd5fc10', NULL, '2026-10-18 15:36:34'),
(43, 4, NULL, 'login_success', 'user', 4, '2f0e44b71242630ff46ba5acf8bdbd2ee6c99b0b21e79389503ba5059f86a852', 'ee52e23671fb67d2e9e704b6d59885a548dd5468debc37d5ece24be66cd5fc10', NULL, '2026-10-18 15:40:50'),
(44, 3, NULL, 'login_success', 'user', 3, '2f0e44b71242630ff46ba5acf8bdbd2ee6c99b0b21e79389503ba5059f86a852', 'ee52e23671fb67d2e9e704b6d59885a548dd5468debc37d5ece24be66cd5fc10', NULL, '2026-10-18 15:48:46'),
(45, 4, NULL, 'login_success', 'user', 4, '2f0e44b71242630ff46ba5acf8bdbd2ee6c99b0b21e79389503ba5059f86a852', 'ee52e23671fb67d2e9e704b6d59885a548dd5468debc37d5ece24be66cd5fc10', NULL, '2026-10-19 09:23:30'),
(46, NULL, NULL, 'login_failed', 'user', 4, '2f0e44b71242630ff46ba5acf8bdbd2ee6c99b0b21e79389503ba5059f86a852', 'a7ea00bdc8f1e36221a99c7c413f613015b29106fee2340372ab3a577b5bca2a', NULL, '2026-10-19 09:25:31'),
(47, NULL, NULL, 'login_failed', 'user', NULL, '2f0e44b71242630ff46ba5acf8bdbd2ee6c99b0b21e79389503ba5059f86a852', 'a7ea00bdc8f1e36221a99c7c413f613015b29106fee2340372ab3a577b5bca2a', NULL, '2026-10-19 09:25:43'),
(48, NULL, NULL, 'login_failed', 'user', NULL, '2f0e44b71242630ff46ba5acf8bdbd2ee6c99b0b21e79389503ba5059f86a852', 'a7ea00bdc8f1e36221a99c7c413f613015b29106fee2340372ab3a577b5bca2a', NULL, '2026-10-19 09:25:45'),
(49, NULL, NULL, 'login_failed', 'user', NULL, '2f0e44b71242630ff46ba5acf8bdbd2ee6c99b0b21e79389503ba5059f86a852', 'a7ea00bdc8f1e36221a99c7c413f613015b29106fee2340372ab3a577b5bca2a', NULL, '2026-10-19 09:25:46'),
(50, NULL, NULL, 'login_failed', 'user', NULL, '2f0e44b71242630ff46ba5acf8bdbd2ee6c99b0b21e79389503ba5059f86a852', 'a7ea00bdc8f1e36221a99c7c413f613015b29106fee2340372ab3a577b5bca2a', NULL, '2026-10-19 09:25:47'),
(51, 4, NULL, 'login_success', 'user', 4, '2f0e44b71242630ff46ba5acf8bdbd2ee6c99b0b21e79389503ba5059f86a852', 'ee52e23671fb67d2e9e704b6d59885a548dd5468debc37d5ece24be66cd5fc10', NULL, '2026-10-19 09:27:03'),
(52, 3, NULL, 'login_success', 'user', 3, '2f0e44b71242630ff46ba5acf8bdbd2ee6c99b0b21e79389503ba5059f86a852', 'ee52e23671fb67d2e9e704b6d59885a548dd5468debc37d5ece24be66cd5fc10', NULL, '2026-10-19 09:27:56'),
(53, 3, 1, 'member_created', 'family_member', 2, '2f0e44b71242630ff46ba5acf8bdbd2ee6c99b0b21e79389503ba5059f86a852', 'ee52e23671fb67d2e9e704b6d59885a548dd5468debc37d5ece24be66cd5fc10', NULL, '2026-10-19 09:30:26'),
(54, 3, 1, 'member_created', 'family_member', 3, '2f0e44b71242630ff46ba5acf8bdbd2ee6c99b0b21e79389503ba5059f86a852', 'ee52e23671fb67d2e9e704b6d59885a548dd5468debc37d5ece24be66cd5fc10', NULL, '2026-10-19 09:31:21'),
(55, 1, NULL, 'login_success', 'user', 1, '2f0e44b71242630ff46ba5acf8bdbd2ee6c99b0b21e79389503ba5059f86a852', 'a7ea00bdc8f1e36221a99c7c413f613015b29106fee2340372ab3a577b5bca2a', NULL, '2026-10-19 09:37:04');

-- --------------------------------------------------------

--
-- Table structure for table `families`
--

CREATE TABLE `families` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `family_name` varchar(190) NOT NULL,
  `created_by_user_id` bigint(20) UNSIGNED NOT NULL,
  `status` enum('active','suspended','archived') NOT NULL DEFAULT 'active',
  `is_discoverable` tinyint(1) NOT NULL DEFAULT 0,
  `created_at` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `families`
--

INSERT INTO `families` (`id`, `family_name`, `created_by_user_id`, `status`, `created_at`) VALUES
(1, 'jibe kitupi', 1, 'active', '2026-10-18 15:07:02');

-- --------------------------------------------------------

--
-- Table structure for table `family_admin_invitations`
--

CREATE TABLE `family_admin_invitations` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `family_id` bigint(20) UNSIGNED NOT NULL,
  `invited_user_id` bigint(20) UNSIGNED NOT NULL,
  `invited_by_user_id` bigint(20) UNSIGNED DEFAULT NULL,
  `status` enum('pending','accepted','revoked','expired') NOT NULL DEFAULT 'pending',
  `pending_user_id` bigint(20) UNSIGNED GENERATED ALWAYS AS (case when `status` = 'pending' then `invited_user_id` else NULL end) STORED,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `expires_at` datetime NOT NULL,
  `accepted_at` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `family_admin_invitations`
--

INSERT INTO `family_admin_invitations` (`id`, `family_id`, `invited_user_id`, `invited_by_user_id`, `status`, `created_at`, `expires_at`, `accepted_at`) VALUES
(1, 1, 3, 1, 'accepted', '2026-10-18 15:17:26', '2026-10-25 15:17:26', '2026-10-18 15:19:31');

-- --------------------------------------------------------

--
-- Table structure for table `family_invitations`
--

CREATE TABLE `family_invitations` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `family_id` bigint(20) UNSIGNED NOT NULL,
  `invitee_email` varchar(190) DEFAULT NULL,
  `invitee_phone` varchar(30) DEFAULT NULL,
  `invited_user_id` bigint(20) UNSIGNED DEFAULT NULL,
  `invited_by_user_id` bigint(20) UNSIGNED NOT NULL,
  `invited_role` enum('admin','member') NOT NULL,
  `token_hash` char(64) CHARACTER SET ascii COLLATE ascii_bin NOT NULL,
  `status` enum('pending','accepted','revoked','expired') NOT NULL DEFAULT 'pending',
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `expires_at` datetime NOT NULL,
  `accepted_at` datetime DEFAULT NULL,
  `revoked_at` datetime DEFAULT NULL,
  `pending_email` varchar(190) GENERATED ALWAYS AS (case when `status` = 'pending' and `invitee_email` is not null then lcase(`invitee_email`) else NULL end) STORED,
  `pending_phone` varchar(30) GENERATED ALWAYS AS (case when `status` = 'pending' and `invitee_phone` is not null then `invitee_phone` else NULL end) STORED
) ;

-- --------------------------------------------------------

--
-- Table structure for table `family_members`
--

CREATE TABLE `family_members` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `family_id` bigint(20) UNSIGNED NOT NULL,
  `user_id` bigint(20) UNSIGNED DEFAULT NULL,
  `first_name` varchar(100) NOT NULL,
  `middle_name` varchar(100) DEFAULT NULL,
  `preferred_name` varchar(100) DEFAULT NULL,
  `last_name` varchar(100) NOT NULL,
  `gender` enum('male','female','other','unspecified') NOT NULL DEFAULT 'unspecified',
  `date_of_birth` date DEFAULT NULL,
  `bio` text DEFAULT NULL,
  `phone` varchar(30) DEFAULT NULL,
  `preferred_contact_method` enum('email','phone','either','none') DEFAULT NULL,
  `email` varchar(190) DEFAULT NULL,
  `profile_photo_media_id` bigint(20) UNSIGNED DEFAULT NULL,
  `member_status` enum('pending','active','suspended','removed','unclaimed') NOT NULL DEFAULT 'pending',
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `family_members`
--

INSERT INTO `family_members` (`id`, `family_id`, `user_id`, `first_name`, `middle_name`, `last_name`, `gender`, `date_of_birth`, `bio`, `phone`, `email`, `profile_photo_media_id`, `member_status`, `created_at`, `updated_at`) VALUES
(1, 1, 3, 'JACKSON', 'PETER', 'KITUPI', 'unspecified', NULL, 'nothing', '0664384727', 'jacksonkitupip@gmail.com', NULL, 'active', '2026-10-18 15:19:31', '2026-10-18 15:28:18'),
(2, 1, NULL, 'agustino', 'joseph', 'msabila', 'unspecified', '2006-12-02', NULL, NULL, NULL, NULL, 'unclaimed', '2026-10-19 09:30:26', '2026-10-19 09:30:26'),
(3, 1, NULL, 'agustino', 'joseph', 'Jackson', 'male', '2006-12-02', NULL, NULL, NULL, NULL, 'unclaimed', '2026-10-19 09:31:21', '2026-10-19 09:31:21');

-- --------------------------------------------------------

--
-- Table structure for table `family_relationships`
--

CREATE TABLE `family_relationships` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `family_id` bigint(20) UNSIGNED NOT NULL,
  `person_id` bigint(20) UNSIGNED NOT NULL,
  `related_person_id` bigint(20) UNSIGNED NOT NULL,
  `relationship_type` enum('parent','child','spouse','guardian') NOT NULL,
  `status` enum('pending','approved','rejected') NOT NULL DEFAULT 'pending',
  `created_by_member_id` bigint(20) UNSIGNED NOT NULL,
  `approved_by_member_id` bigint(20) UNSIGNED DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `approved_at` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `family_roles`
--

CREATE TABLE `family_roles` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `family_id` bigint(20) UNSIGNED NOT NULL,
  `member_id` bigint(20) UNSIGNED NOT NULL,
  `role` enum('admin','member','viewer') NOT NULL DEFAULT 'member',
  `created_at` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `family_roles`
--

INSERT INTO `family_roles` (`id`, `family_id`, `member_id`, `role`, `created_at`) VALUES
(1, 1, 1, 'admin', '2026-10-18 15:19:31');

-- --------------------------------------------------------

--
-- Table structure for table `identity_verifications`
--

CREATE TABLE `identity_verifications` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `user_id` bigint(20) UNSIGNED NOT NULL,
  `member_id` bigint(20) UNSIGNED DEFAULT NULL,
  `document_type` varchar(50) NOT NULL,
  `document_number_encrypted` text DEFAULT NULL,
  `document_number_hash` char(64) DEFAULT NULL,
  `document_media_id` bigint(20) UNSIGNED DEFAULT NULL,
  `status` enum('pending','verified','rejected') NOT NULL DEFAULT 'pending',
  `reviewer_user_id` bigint(20) UNSIGNED DEFAULT NULL,
  `rejection_reason` varchar(500) DEFAULT NULL,
  `submitted_at` datetime NOT NULL DEFAULT current_timestamp(),
  `reviewed_at` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `login_attempts`
--

CREATE TABLE `login_attempts` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `identifier_hash` char(64) NOT NULL,
  `ip_hash` char(64) NOT NULL,
  `success` tinyint(1) NOT NULL DEFAULT 0,
  `created_at` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `login_attempts`
--

INSERT INTO `login_attempts` (`id`, `identifier_hash`, `ip_hash`, `success`, `created_at`) VALUES
(1, 'cf1b7edb42d078e8d73844322245535f03acd84748cb6b727b0bff0a4281d0a1', '2f0e44b71242630ff46ba5acf8bdbd2ee6c99b0b21e79389503ba5059f86a852', 1, '2026-10-15 22:23:00'),
(2, 'cf1b7edb42d078e8d73844322245535f03acd84748cb6b727b0bff0a4281d0a1', '2f0e44b71242630ff46ba5acf8bdbd2ee6c99b0b21e79389503ba5059f86a852', 1, '2026-10-16 12:05:38'),
(3, 'cf1b7edb42d078e8d73844322245535f03acd84748cb6b727b0bff0a4281d0a1', '2f0e44b71242630ff46ba5acf8bdbd2ee6c99b0b21e79389503ba5059f86a852', 1, '2026-10-16 12:30:39'),
(4, 'cf1b7edb42d078e8d73844322245535f03acd84748cb6b727b0bff0a4281d0a1', '2f0e44b71242630ff46ba5acf8bdbd2ee6c99b0b21e79389503ba5059f86a852', 1, '2026-10-16 15:19:41'),
(5, 'cf1b7edb42d078e8d73844322245535f03acd84748cb6b727b0bff0a4281d0a1', '2f0e44b71242630ff46ba5acf8bdbd2ee6c99b0b21e79389503ba5059f86a852', 1, '2026-10-16 16:56:50'),
(6, 'cf1b7edb42d078e8d73844322245535f03acd84748cb6b727b0bff0a4281d0a1', '2f0e44b71242630ff46ba5acf8bdbd2ee6c99b0b21e79389503ba5059f86a852', 1, '2026-10-16 17:10:03'),
(7, 'cf1b7edb42d078e8d73844322245535f03acd84748cb6b727b0bff0a4281d0a1', '2f0e44b71242630ff46ba5acf8bdbd2ee6c99b0b21e79389503ba5059f86a852', 1, '2026-10-16 18:20:13'),
(8, 'cf1b7edb42d078e8d73844322245535f03acd84748cb6b727b0bff0a4281d0a1', '2f0e44b71242630ff46ba5acf8bdbd2ee6c99b0b21e79389503ba5059f86a852', 1, '2026-10-16 20:34:36'),
(9, 'cf1b7edb42d078e8d73844322245535f03acd84748cb6b727b0bff0a4281d0a1', '2f0e44b71242630ff46ba5acf8bdbd2ee6c99b0b21e79389503ba5059f86a852', 1, '2026-10-16 20:39:50'),
(10, 'cf1b7edb42d078e8d73844322245535f03acd84748cb6b727b0bff0a4281d0a1', '2f0e44b71242630ff46ba5acf8bdbd2ee6c99b0b21e79389503ba5059f86a852', 1, '2026-10-16 22:02:23'),
(11, 'cf1b7edb42d078e8d73844322245535f03acd84748cb6b727b0bff0a4281d0a1', '2f0e44b71242630ff46ba5acf8bdbd2ee6c99b0b21e79389503ba5059f86a852', 1, '2026-10-17 09:06:38'),
(12, 'cf1b7edb42d078e8d73844322245535f03acd84748cb6b727b0bff0a4281d0a1', '2f0e44b71242630ff46ba5acf8bdbd2ee6c99b0b21e79389503ba5059f86a852', 1, '2026-10-17 10:11:39'),
(13, 'cf1b7edb42d078e8d73844322245535f03acd84748cb6b727b0bff0a4281d0a1', '2f0e44b71242630ff46ba5acf8bdbd2ee6c99b0b21e79389503ba5059f86a852', 1, '2026-10-18 12:20:08'),
(14, '2ceeb6936d3341588dc92df89dc979a0e69591269c97db0e4deb8b835a102c0a', '2f0e44b71242630ff46ba5acf8bdbd2ee6c99b0b21e79389503ba5059f86a852', 0, '2026-10-18 12:41:56'),
(15, '2ceeb6936d3341588dc92df89dc979a0e69591269c97db0e4deb8b835a102c0a', '2f0e44b71242630ff46ba5acf8bdbd2ee6c99b0b21e79389503ba5059f86a852', 0, '2026-10-18 12:42:19'),
(16, '2ceeb6936d3341588dc92df89dc979a0e69591269c97db0e4deb8b835a102c0a', '2f0e44b71242630ff46ba5acf8bdbd2ee6c99b0b21e79389503ba5059f86a852', 0, '2026-10-18 12:52:48'),
(17, '2ceeb6936d3341588dc92df89dc979a0e69591269c97db0e4deb8b835a102c0a', '2f0e44b71242630ff46ba5acf8bdbd2ee6c99b0b21e79389503ba5059f86a852', 0, '2026-10-18 12:53:04'),
(18, '2ceeb6936d3341588dc92df89dc979a0e69591269c97db0e4deb8b835a102c0a', '2f0e44b71242630ff46ba5acf8bdbd2ee6c99b0b21e79389503ba5059f86a852', 1, '2026-10-18 13:36:06'),
(19, 'cf1b7edb42d078e8d73844322245535f03acd84748cb6b727b0bff0a4281d0a1', '2f0e44b71242630ff46ba5acf8bdbd2ee6c99b0b21e79389503ba5059f86a852', 1, '2026-10-18 13:39:29'),
(20, 'cf1b7edb42d078e8d73844322245535f03acd84748cb6b727b0bff0a4281d0a1', '2f0e44b71242630ff46ba5acf8bdbd2ee6c99b0b21e79389503ba5059f86a852', 1, '2026-10-18 14:59:32'),
(21, 'cf1b7edb42d078e8d73844322245535f03acd84748cb6b727b0bff0a4281d0a1', '2f0e44b71242630ff46ba5acf8bdbd2ee6c99b0b21e79389503ba5059f86a852', 1, '2026-10-18 15:00:07'),
(22, 'cf1b7edb42d078e8d73844322245535f03acd84748cb6b727b0bff0a4281d0a1', '2f0e44b71242630ff46ba5acf8bdbd2ee6c99b0b21e79389503ba5059f86a852', 1, '2026-10-18 15:01:33'),
(23, '2ceeb6936d3341588dc92df89dc979a0e69591269c97db0e4deb8b835a102c0a', '2f0e44b71242630ff46ba5acf8bdbd2ee6c99b0b21e79389503ba5059f86a852', 1, '2026-10-18 15:18:39'),
(24, 'b69ed51c8451bfaf86b63c9217701d11db9701419283fa09184753848dc3a0fb', '2f0e44b71242630ff46ba5acf8bdbd2ee6c99b0b21e79389503ba5059f86a852', 1, '2026-10-18 15:40:50'),
(25, '2ceeb6936d3341588dc92df89dc979a0e69591269c97db0e4deb8b835a102c0a', '2f0e44b71242630ff46ba5acf8bdbd2ee6c99b0b21e79389503ba5059f86a852', 1, '2026-10-18 15:48:46'),
(26, 'b69ed51c8451bfaf86b63c9217701d11db9701419283fa09184753848dc3a0fb', '2f0e44b71242630ff46ba5acf8bdbd2ee6c99b0b21e79389503ba5059f86a852', 1, '2026-10-19 09:23:30'),
(27, 'b69ed51c8451bfaf86b63c9217701d11db9701419283fa09184753848dc3a0fb', '2f0e44b71242630ff46ba5acf8bdbd2ee6c99b0b21e79389503ba5059f86a852', 0, '2026-10-19 09:25:31'),
(28, '20f5fc3fe79a1442c71beaf7469a8d342e7cf6f3860c596017992cd0ab7de875', '2f0e44b71242630ff46ba5acf8bdbd2ee6c99b0b21e79389503ba5059f86a852', 0, '2026-10-19 09:25:43'),
(29, '20f5fc3fe79a1442c71beaf7469a8d342e7cf6f3860c596017992cd0ab7de875', '2f0e44b71242630ff46ba5acf8bdbd2ee6c99b0b21e79389503ba5059f86a852', 0, '2026-10-19 09:25:45'),
(30, '20f5fc3fe79a1442c71beaf7469a8d342e7cf6f3860c596017992cd0ab7de875', '2f0e44b71242630ff46ba5acf8bdbd2ee6c99b0b21e79389503ba5059f86a852', 0, '2026-10-19 09:25:46'),
(31, '20f5fc3fe79a1442c71beaf7469a8d342e7cf6f3860c596017992cd0ab7de875', '2f0e44b71242630ff46ba5acf8bdbd2ee6c99b0b21e79389503ba5059f86a852', 0, '2026-10-19 09:25:47'),
(32, 'b69ed51c8451bfaf86b63c9217701d11db9701419283fa09184753848dc3a0fb', '2f0e44b71242630ff46ba5acf8bdbd2ee6c99b0b21e79389503ba5059f86a852', 1, '2026-10-19 09:27:03'),
(33, '2ceeb6936d3341588dc92df89dc979a0e69591269c97db0e4deb8b835a102c0a', '2f0e44b71242630ff46ba5acf8bdbd2ee6c99b0b21e79389503ba5059f86a852', 1, '2026-10-19 09:27:56'),
(34, 'cf1b7edb42d078e8d73844322245535f03acd84748cb6b727b0bff0a4281d0a1', '2f0e44b71242630ff46ba5acf8bdbd2ee6c99b0b21e79389503ba5059f86a852', 1, '2026-10-19 09:37:04');

-- --------------------------------------------------------

--
-- Table structure for table `media`
--

CREATE TABLE `media` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `member_id` bigint(20) UNSIGNED NOT NULL,
  `media_type` enum('photo','video','document','audio') NOT NULL,
  `original_name` varchar(255) NOT NULL,
  `stored_name` varchar(255) NOT NULL,
  `mime_type` varchar(100) NOT NULL,
  `file_size` bigint(20) UNSIGNED NOT NULL,
  `sha256` char(64) NOT NULL,
  `storage_path` varchar(500) NOT NULL,
  `visibility` enum('private','family','permissioned') NOT NULL DEFAULT 'private',
  `created_at` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `media`
--

INSERT INTO `media` (`id`, `member_id`, `media_type`, `original_name`, `stored_name`, `mime_type`, `file_size`, `sha256`, `storage_path`, `visibility`, `created_at`) VALUES
(1, 1, 'photo', 'kit 1.jpeg', '3a47dee8341952faa19c1c2975bcba5f4ca905149fd22177.jpeg', 'image/jpeg', 101672, '12809960b9181dbf407301fbde0a89e72a06535a7749ded638b23ef1e15408d3', 'C:/xampp/family_private_storage\\family_1\\3a47dee8341952faa19c1c2975bcba5f4ca905149fd22177.jpeg', 'private', '2026-10-18 15:24:12'),
(2, 1, 'photo', 'jibe.jpeg', '3edf1be63c077cff7a4a2bb101210f19cfe4a40151260c89.jpeg', 'image/jpeg', 56499, '209321714ee210546ef6ea0dd843941d82e4095c93501a1f138080db33ec1b02', 'C:/xampp/family_private_storage\\family_1\\3edf1be63c077cff7a4a2bb101210f19cfe4a40151260c89.jpeg', 'private', '2026-10-18 15:24:30'),
(3, 1, 'photo', 'redemtha.jpeg', '7be646547b83e9e8c1958c930a590b97d0df664075eb364d.jpeg', 'image/jpeg', 43320, '1be1c2e6b538441fb23ae4ff28b439a59795d096db25aecbef58f8704f79d864', 'C:/xampp/family_private_storage\\family_1\\7be646547b83e9e8c1958c930a590b97d0df664075eb364d.jpeg', 'private', '2026-10-18 15:24:41'),
(4, 1, 'photo', 'soja.png', 'b34b518a20d270ea61c660547b5c7570af2734410dbc313b.png', 'image/png', 535047, '9f4b2bf15264600dc3dcdf423e7f6e99cb93bedea2a585a83ef44831468e91b6', 'C:/xampp/family_private_storage\\family_1\\b34b518a20d270ea61c660547b5c7570af2734410dbc313b.png', 'private', '2026-10-18 15:24:49'),
(5, 1, 'video', 'Download (30).mp4', '0e273f7677d9b4e11e328744fc4ab659a9f8cb966395726b.mp4', 'video/mp4', 18439794, 'ae24df1af6b4d7ec32585340f0e82b2e8a29d313c6b8c420a51d704a018d4baf', 'C:/xampp/family_private_storage\\family_1\\0e273f7677d9b4e11e328744fc4ab659a9f8cb966395726b.mp4', 'private', '2026-10-18 15:25:05'),
(6, 1, 'document', 'ADMISSION-LETTER-S4181-0161-2022--041020261536.pdf', '04a7811f5512c3b92861326d0b9669316c47bd1abe6292d4.pdf', 'application/pdf', 211801, 'c3d5980b8a45c5063832c72f6897f05a5e9449428f0e9a126ab93b3c742d4068', 'C:/xampp/family_private_storage\\family_1\\04a7811f5512c3b92861326d0b9669316c47bd1abe6292d4.pdf', 'private', '2026-10-18 15:26:30');

-- --------------------------------------------------------

--
-- Table structure for table `membership_requests`
--

CREATE TABLE `membership_requests` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `family_id` bigint(20) UNSIGNED NOT NULL,
  `applicant_member_id` bigint(20) UNSIGNED NOT NULL,
  `target_member_id` bigint(20) UNSIGNED DEFAULT NULL,
  `claimed_relationship` varchar(50) NOT NULL,
  `reason` varchar(500) DEFAULT NULL,
  `status` enum('pending','approved','rejected','cancelled') NOT NULL DEFAULT 'pending',
  `reviewed_by_member_id` bigint(20) UNSIGNED DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `reviewed_at` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `otp_challenges`
--

CREATE TABLE `otp_challenges` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `user_id` bigint(20) UNSIGNED NOT NULL,
  `channel` enum('email','sms') NOT NULL,
  `destination` varchar(190) NOT NULL,
  `code_hash` varchar(255) NOT NULL,
  `attempts` tinyint(3) UNSIGNED NOT NULL DEFAULT 0,
  `expires_at` datetime NOT NULL,
  `consumed_at` datetime DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `otp_challenges`
--

INSERT INTO `otp_challenges` (`id`, `user_id`, `channel`, `destination`, `code_hash`, `attempts`, `expires_at`, `consumed_at`, `created_at`) VALUES
(2, 3, 'email', 'jacksonkitupip@gmail.com', '$2y$10$Yg.QfNGWI855ieTU6N46VeCMWO6hwWH2.alKNZEEOVEUac6H2eVFa', 0, '2026-10-18 12:27:33', '2026-10-18 12:18:10', '2026-10-18 12:17:33'),
(3, 4, 'email', 'mabala0155@gmai.com', '$2y$10$4ppdu9pyNuPECW5bBxSwRuJBWn3MKa8CYLUuaGCrn/tk7n7sWmBpa', 0, '2026-10-18 15:45:02', '2026-10-18 15:36:10', '2026-10-18 15:35:02'),
(4, 4, 'email', 'mabala0155@gmai.com', '$2y$10$rGl9Lu55qQtnQPSDXI8/KOL4MXHryhLUEyTD6ZwFV6gUh1BHMLp1G', 0, '2026-10-18 15:46:10', '2026-10-18 15:36:34', '2026-10-18 15:36:10');

-- --------------------------------------------------------

--
-- Table structure for table `password_reset_tokens`
--

CREATE TABLE `password_reset_tokens` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `user_id` bigint(20) UNSIGNED NOT NULL,
  `token_hash` char(64) NOT NULL,
  `expires_at` datetime NOT NULL,
  `consumed_at` datetime DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `permissions`
--

CREATE TABLE `permissions` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `family_id` bigint(20) UNSIGNED NOT NULL,
  `owner_member_id` bigint(20) UNSIGNED NOT NULL,
  `requester_member_id` bigint(20) UNSIGNED NOT NULL,
  `resource_type` enum('profile','identity','document','photo','video','address','education','employment') NOT NULL,
  `resource_id` bigint(20) UNSIGNED DEFAULT NULL,
  `purpose` varchar(500) DEFAULT NULL,
  `status` enum('pending','approved','rejected','revoked','expired') NOT NULL DEFAULT 'pending',
  `expires_at` datetime DEFAULT NULL,
  `decided_at` datetime DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `email` varchar(190) NOT NULL,
  `phone` varchar(30) DEFAULT NULL,
  `password_hash` varchar(255) NOT NULL,
  `status` enum('pending','active','locked','suspended','deleted') NOT NULL DEFAULT 'pending',
  `email_verified_at` datetime DEFAULT NULL,
  `phone_verified_at` datetime DEFAULT NULL,
  `last_login_at` datetime DEFAULT NULL,
  `failed_login_count` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `locked_until` datetime DEFAULT NULL,
  `mfa_enabled` tinyint(1) NOT NULL DEFAULT 0,
  `is_admin` tinyint(1) NOT NULL DEFAULT 0,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `email`, `phone`, `password_hash`, `status`, `email_verified_at`, `phone_verified_at`, `last_login_at`, `failed_login_count`, `locked_until`, `mfa_enabled`, `is_admin`, `created_at`, `updated_at`) VALUES
(1, 'kaemba155@gmail.com', NULL, '$argon2id$v=19$m=65536,t=4,p=1$aEZBN1pPNHM1a2t2TGJ6Tg$5G4AggrtdsmW46sQSNpBgYlCqWbgbpONPT+FztGx/+4', 'active', '2026-10-15 21:40:25', NULL, '2026-10-19 09:37:04', 0, NULL, 0, 1, '2026-10-15 21:40:25', '2026-10-19 09:37:04'),
(3, 'jacksonkitupip@gmail.com', '+255664384727', '$argon2id$v=19$m=65536,t=4,p=1$UlFMb3Z6dHFsSGo4OXh3Lw$IJQfLuPLtuEWeXMmkvDYeqXiJ42oG1IY9+w0wm/5m7E', 'active', '2026-10-18 12:18:10', NULL, '2026-10-19 09:27:56', 0, NULL, 0, 0, '2026-10-18 12:17:33', '2026-10-19 09:27:56'),
(4, 'mabala0155@gmai.com', '+255712041015', '$argon2id$v=19$m=65536,t=4,p=1$VjROelQ1UmRkaFFuQktNQQ$COeh6qf/7JbpnuoK0sheMtw8RJc4Eu+aLRxLKrxggqs', 'active', '2026-10-18 15:36:34', NULL, '2026-10-19 09:27:03', 0, NULL, 0, 0, '2026-10-18 15:35:02', '2026-10-19 09:27:03');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `audit_logs`
--
ALTER TABLE `audit_logs`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idx_audit_family_time` (`family_id`,`created_at`),
  ADD KEY `idx_audit_actor_time` (`actor_user_id`,`created_at`);

--
-- Indexes for table `families`
--
ALTER TABLE `families`
  ADD PRIMARY KEY (`id`),
  ADD KEY `created_by_user_id` (`created_by_user_id`);

--
-- Indexes for table `family_admin_invitations`
--
ALTER TABLE `family_admin_invitations`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `uq_pending_family_admin_invitation` (`family_id`,`pending_user_id`),
  ADD KEY `idx_family_admin_invitation_user` (`invited_user_id`,`status`,`expires_at`),
  ADD KEY `idx_family_admin_invitation_family` (`family_id`,`status`,`expires_at`),
  ADD KEY `invited_by_user_id` (`invited_by_user_id`);

--
-- Indexes for table `family_invitations`
--
ALTER TABLE `family_invitations`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `uq_family_invitation_token_hash` (`token_hash`),
  ADD UNIQUE KEY `uq_family_pending_invitation_email` (`family_id`,`pending_email`),
  ADD UNIQUE KEY `uq_family_pending_invitation_phone` (`family_id`,`pending_phone`),
  ADD KEY `idx_family_invitation_status` (`family_id`,`status`,`expires_at`),
  ADD KEY `invited_user_id` (`invited_user_id`),
  ADD KEY `invited_by_user_id` (`invited_by_user_id`);

--
-- Indexes for table `family_members`
--
ALTER TABLE `family_members`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idx_family_member` (`family_id`),
  ADD KEY `idx_user` (`user_id`);

--
-- Indexes for table `family_relationships`
--
ALTER TABLE `family_relationships`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idx_relationship_person` (`person_id`),
  ADD KEY `idx_relationship_related` (`related_person_id`),
  ADD KEY `family_id` (`family_id`),
  ADD KEY `created_by_member_id` (`created_by_member_id`),
  ADD KEY `approved_by_member_id` (`approved_by_member_id`);

--
-- Indexes for table `family_roles`
--
ALTER TABLE `family_roles`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `uq_family_member_role` (`family_id`,`member_id`),
  ADD KEY `member_id` (`member_id`);

--
-- Indexes for table `identity_verifications`
--
ALTER TABLE `identity_verifications`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idx_identity_user` (`user_id`),
  ADD KEY `idx_identity_hash` (`document_number_hash`),
  ADD KEY `member_id` (`member_id`),
  ADD KEY `reviewer_user_id` (`reviewer_user_id`);

--
-- Indexes for table `login_attempts`
--
ALTER TABLE `login_attempts`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idx_login_identifier_time` (`identifier_hash`,`created_at`),
  ADD KEY `idx_login_ip_time` (`ip_hash`,`created_at`);

--
-- Indexes for table `media`
--
ALTER TABLE `media`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `stored_name` (`stored_name`),
  ADD KEY `idx_media_member` (`member_id`);

--
-- Indexes for table `membership_requests`
--
ALTER TABLE `membership_requests`
  ADD PRIMARY KEY (`id`),
  ADD KEY `family_id` (`family_id`),
  ADD KEY `applicant_member_id` (`applicant_member_id`),
  ADD KEY `target_member_id` (`target_member_id`),
  ADD KEY `reviewed_by_member_id` (`reviewed_by_member_id`);

--
-- Indexes for table `otp_challenges`
--
ALTER TABLE `otp_challenges`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idx_otp_user` (`user_id`);

--
-- Indexes for table `password_reset_tokens`
--
ALTER TABLE `password_reset_tokens`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `token_hash` (`token_hash`),
  ADD KEY `user_id` (`user_id`);

--
-- Indexes for table `permissions`
--
ALTER TABLE `permissions`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idx_permission_owner` (`owner_member_id`),
  ADD KEY `idx_permission_requester` (`requester_member_id`),
  ADD KEY `family_id` (`family_id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `email` (`email`),
  ADD UNIQUE KEY `phone` (`phone`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `audit_logs`
--
ALTER TABLE `audit_logs`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=56;

--
-- AUTO_INCREMENT for table `families`
--
ALTER TABLE `families`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `family_admin_invitations`
--
ALTER TABLE `family_admin_invitations`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `family_invitations`
--
ALTER TABLE `family_invitations`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `family_members`
--
ALTER TABLE `family_members`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `family_relationships`
--
ALTER TABLE `family_relationships`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `family_roles`
--
ALTER TABLE `family_roles`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `identity_verifications`
--
ALTER TABLE `identity_verifications`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `login_attempts`
--
ALTER TABLE `login_attempts`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=35;

--
-- AUTO_INCREMENT for table `media`
--
ALTER TABLE `media`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `membership_requests`
--
ALTER TABLE `membership_requests`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `otp_challenges`
--
ALTER TABLE `otp_challenges`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `password_reset_tokens`
--
ALTER TABLE `password_reset_tokens`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `permissions`
--
ALTER TABLE `permissions`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `audit_logs`
--
ALTER TABLE `audit_logs`
  ADD CONSTRAINT `audit_logs_ibfk_1` FOREIGN KEY (`actor_user_id`) REFERENCES `users` (`id`) ON DELETE SET NULL,
  ADD CONSTRAINT `audit_logs_ibfk_2` FOREIGN KEY (`family_id`) REFERENCES `families` (`id`) ON DELETE SET NULL;

--
-- Constraints for table `families`
--
ALTER TABLE `families`
  ADD CONSTRAINT `families_ibfk_1` FOREIGN KEY (`created_by_user_id`) REFERENCES `users` (`id`);

--
-- Constraints for table `family_admin_invitations`
--
ALTER TABLE `family_admin_invitations`
  ADD CONSTRAINT `family_admin_invitations_ibfk_1` FOREIGN KEY (`family_id`) REFERENCES `families` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `family_admin_invitations_ibfk_2` FOREIGN KEY (`invited_user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `family_admin_invitations_ibfk_3` FOREIGN KEY (`invited_by_user_id`) REFERENCES `users` (`id`) ON DELETE SET NULL;

--
-- Constraints for table `family_invitations`
--
ALTER TABLE `family_invitations`
  ADD CONSTRAINT `family_invitations_ibfk_1` FOREIGN KEY (`family_id`) REFERENCES `families` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `family_invitations_ibfk_2` FOREIGN KEY (`invited_user_id`) REFERENCES `users` (`id`) ON DELETE SET NULL,
  ADD CONSTRAINT `family_invitations_ibfk_3` FOREIGN KEY (`invited_by_user_id`) REFERENCES `users` (`id`);

--
-- Constraints for table `family_members`
--
ALTER TABLE `family_members`
  ADD CONSTRAINT `family_members_ibfk_1` FOREIGN KEY (`family_id`) REFERENCES `families` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `family_members_ibfk_2` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE SET NULL;

--
-- Constraints for table `family_relationships`
--
ALTER TABLE `family_relationships`
  ADD CONSTRAINT `family_relationships_ibfk_1` FOREIGN KEY (`family_id`) REFERENCES `families` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `family_relationships_ibfk_2` FOREIGN KEY (`person_id`) REFERENCES `family_members` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `family_relationships_ibfk_3` FOREIGN KEY (`related_person_id`) REFERENCES `family_members` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `family_relationships_ibfk_4` FOREIGN KEY (`created_by_member_id`) REFERENCES `family_members` (`id`),
  ADD CONSTRAINT `family_relationships_ibfk_5` FOREIGN KEY (`approved_by_member_id`) REFERENCES `family_members` (`id`) ON DELETE SET NULL;

--
-- Constraints for table `family_roles`
--
ALTER TABLE `family_roles`
  ADD CONSTRAINT `family_roles_ibfk_1` FOREIGN KEY (`family_id`) REFERENCES `families` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `family_roles_ibfk_2` FOREIGN KEY (`member_id`) REFERENCES `family_members` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `identity_verifications`
--
ALTER TABLE `identity_verifications`
  ADD CONSTRAINT `identity_verifications_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `identity_verifications_ibfk_2` FOREIGN KEY (`member_id`) REFERENCES `family_members` (`id`) ON DELETE SET NULL,
  ADD CONSTRAINT `identity_verifications_ibfk_3` FOREIGN KEY (`reviewer_user_id`) REFERENCES `users` (`id`) ON DELETE SET NULL;

--
-- Constraints for table `media`
--
ALTER TABLE `media`
  ADD CONSTRAINT `media_ibfk_1` FOREIGN KEY (`member_id`) REFERENCES `family_members` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `membership_requests`
--
ALTER TABLE `membership_requests`
  ADD CONSTRAINT `membership_requests_ibfk_1` FOREIGN KEY (`family_id`) REFERENCES `families` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `membership_requests_ibfk_2` FOREIGN KEY (`applicant_member_id`) REFERENCES `family_members` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `membership_requests_ibfk_3` FOREIGN KEY (`target_member_id`) REFERENCES `family_members` (`id`) ON DELETE SET NULL,
  ADD CONSTRAINT `membership_requests_ibfk_4` FOREIGN KEY (`reviewed_by_member_id`) REFERENCES `family_members` (`id`) ON DELETE SET NULL;

--
-- Constraints for table `otp_challenges`
--
ALTER TABLE `otp_challenges`
  ADD CONSTRAINT `otp_challenges_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `password_reset_tokens`
--
ALTER TABLE `password_reset_tokens`
  ADD CONSTRAINT `password_reset_tokens_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `permissions`
--
ALTER TABLE `permissions`
  ADD CONSTRAINT `permissions_ibfk_1` FOREIGN KEY (`family_id`) REFERENCES `families` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `permissions_ibfk_2` FOREIGN KEY (`owner_member_id`) REFERENCES `family_members` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `permissions_ibfk_3` FOREIGN KEY (`requester_member_id`) REFERENCES `family_members` (`id`) ON DELETE CASCADE;

-- Per-family display and access defaults added by migration_005.sql.
CREATE TABLE `family_settings` (
  `family_id` bigint(20) UNSIGNED NOT NULL,
  `home_region` varchar(190) DEFAULT NULL,
  `profile_visibility` enum('family','private') NOT NULL DEFAULT 'family',
  `permission_expiry_days` smallint(5) UNSIGNED NOT NULL DEFAULT 30,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`family_id`),
  CONSTRAINT `fk_family_settings_family` FOREIGN KEY (`family_id`) REFERENCES `families` (`id`) ON DELETE CASCADE,
  CONSTRAINT `chk_family_permission_expiry` CHECK (`permission_expiry_days` IN (7,30,90))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Authenticator-app enrollment state added by migration_006.sql.
CREATE TABLE `user_mfa` (
  `user_id` bigint(20) UNSIGNED NOT NULL,
  `secret_encrypted` text DEFAULT NULL,
  `pending_secret_encrypted` text DEFAULT NULL,
  `pending_expires_at` datetime DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `confirmed_at` datetime DEFAULT NULL,
  `last_used_step` bigint(20) UNSIGNED NOT NULL DEFAULT 0,
  PRIMARY KEY (`user_id`),
  CONSTRAINT `fk_user_mfa_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Server-side session revocation metadata added by migration_007.sql.
CREATE TABLE `user_sessions` (
  `session_hash` char(64) NOT NULL,
  `user_id` bigint(20) UNSIGNED NOT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `last_seen_at` datetime NOT NULL DEFAULT current_timestamp(),
  `revoked_at` datetime DEFAULT NULL,
  PRIMARY KEY (`session_hash`),
  KEY `idx_user_sessions_user_active` (`user_id`,`revoked_at`),
  CONSTRAINT `fk_user_sessions_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
