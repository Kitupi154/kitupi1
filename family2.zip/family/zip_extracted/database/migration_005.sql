-- Migration 005: persisted family region and privacy defaults.
-- Apply only to an existing database based on the pre-005 schema. The current
-- schema.sql already includes this table, so do not apply this migration after
-- creating a database from that updated schema. This file is never auto-run.
CREATE TABLE family_settings (
    family_id BIGINT UNSIGNED NOT NULL PRIMARY KEY,
    home_region VARCHAR(190) NULL,
    profile_visibility ENUM('family', 'private') NOT NULL DEFAULT 'family',
    permission_expiry_days SMALLINT UNSIGNED NOT NULL DEFAULT 30,
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    CONSTRAINT fk_family_settings_family
        FOREIGN KEY (family_id) REFERENCES families(id) ON DELETE CASCADE,
    CONSTRAINT chk_family_permission_expiry
        CHECK (permission_expiry_days IN (7, 30, 90))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
