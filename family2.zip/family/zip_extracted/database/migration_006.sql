-- Migration 006: encrypted authenticator-app MFA enrollment state.
-- Apply once to an existing database that does not already contain user_mfa.
CREATE TABLE user_mfa (
    user_id BIGINT UNSIGNED NOT NULL PRIMARY KEY,
    secret_encrypted TEXT DEFAULT NULL,
    pending_secret_encrypted TEXT DEFAULT NULL,
    pending_expires_at DATETIME DEFAULT NULL,
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    confirmed_at DATETIME DEFAULT NULL,
    last_used_step BIGINT UNSIGNED NOT NULL DEFAULT 0,
    CONSTRAINT fk_user_mfa_user
        FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
