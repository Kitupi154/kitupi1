-- Migration 004: secure, email-based family invitations.
-- Apply after database/schema.sql and migration_003.sql.
-- This migration adds no invitation records and does not change existing memberships.

CREATE TABLE family_invitations (
    id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    family_id BIGINT UNSIGNED NOT NULL,
    invitee_email VARCHAR(190) NULL,
    invitee_phone VARCHAR(30) NULL,
    invited_user_id BIGINT UNSIGNED NULL,
    invited_by_user_id BIGINT UNSIGNED NOT NULL,
    invited_role ENUM('admin','member') NOT NULL,
    token_hash CHAR(64) CHARACTER SET ascii COLLATE ascii_bin NOT NULL,
    status ENUM('pending','accepted','revoked','expired') NOT NULL DEFAULT 'pending',
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    expires_at DATETIME NOT NULL,
    accepted_at DATETIME NULL,
    revoked_at DATETIME NULL,
    pending_email VARCHAR(190)
        GENERATED ALWAYS AS (
            CASE WHEN status = 'pending' AND invitee_email IS NOT NULL
                THEN LOWER(invitee_email) ELSE NULL END
        ) STORED,
    pending_phone VARCHAR(30)
        GENERATED ALWAYS AS (
            CASE WHEN status = 'pending' AND invitee_phone IS NOT NULL
                THEN invitee_phone ELSE NULL END
        ) STORED,
    UNIQUE KEY uq_family_invitation_token_hash (token_hash),
    UNIQUE KEY uq_family_pending_invitation_email (family_id, pending_email),
    UNIQUE KEY uq_family_pending_invitation_phone (family_id, pending_phone),
    INDEX idx_family_invitation_status (family_id, status, expires_at),
    FOREIGN KEY (family_id) REFERENCES families(id) ON DELETE CASCADE,
    FOREIGN KEY (invited_user_id) REFERENCES users(id) ON DELETE SET NULL,
    FOREIGN KEY (invited_by_user_id) REFERENCES users(id),
    CONSTRAINT chk_family_invitation_recipient CHECK (
        (invitee_email IS NOT NULL AND invitee_phone IS NULL)
        OR (invitee_email IS NULL AND invitee_phone IS NOT NULL)
    )
) ENGINE=InnoDB;
