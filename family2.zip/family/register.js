'use strict';

const API_ROOT = 'zip_extracted/public';

const form = document.querySelector('#register-form');
const submitButton = document.querySelector('#register-submit');
const statusMessage = document.querySelector('#connection-status');
const feedback = document.querySelector('#register-message');
const passwordInput = document.querySelector('#password');
const passwordVisibilityButton = document.querySelector('#password-visibility');
const eyeIcon = passwordVisibilityButton.querySelector('.eye-icon');
const eyeOffIcon = passwordVisibilityButton.querySelector('.eye-off-icon');
const hrefParams = new URLSearchParams(window.location.hash.slice(1));
const invitationToken = hrefParams.get('invitation') || hrefParams.get('token') || '';
const hasInvitationContext = hrefParams.has('invitation') || hrefParams.has('token');
const validInvitationToken = /^[a-f0-9]{64}$/i.test(invitationToken);
const invitationFragment = /^[a-f0-9]{64}$/i.test(invitationToken)
  ? `#invitation=${encodeURIComponent(invitationToken)}`
  : '';
let csrfToken = '';

passwordVisibilityButton.addEventListener('click', () => {
  const isVisible = passwordInput.type === 'password';
  passwordInput.type = isVisible ? 'text' : 'password';
  passwordVisibilityButton.setAttribute('aria-pressed', String(isVisible));
  passwordVisibilityButton.setAttribute('aria-label', isVisible ? 'Hide password' : 'Show password');
  eyeIcon.hidden = isVisible;
  eyeOffIcon.hidden = !isVisible;
});

async function loadCsrfToken() {
  const response = await fetch(`${API_ROOT}/index.php`, {
    method: 'GET',
    credentials: 'same-origin',
    cache: 'no-store'
  });
  const result = await response.json().catch(() => null);

  if (!response.ok || result?.success !== true || typeof result.csrf_token !== 'string') {
    throw new Error('Secure registration is temporarily unavailable. Please try again later.');
  }

  csrfToken = result.csrf_token;
}

function showError(message) {
  feedback.textContent = message;
  feedback.hidden = false;
}

function registrationError(response, result) {
  if (hasInvitationContext && typeof result?.error === 'string') {
    return result.error;
  }
  if (response.status === 403) {
    return 'Your security check expired. Reload this page and try again.';
  }
  if (response.status === 409) {
    return 'An account already uses this email address or phone number. If this is your account, contact the site administrator.';
  }
  if (response.status === 422) {
    return 'Enter a valid email and phone number, and meet all password requirements.';
  }
  if (response.status >= 500) {
    return 'Registration could not be completed. A pending account may already have been created if email delivery failed; contact the site administrator before retrying.';
  }
  if (result?.error === 'POST required') {
    return 'The registration request could not be processed. Reload this page and try again.';
  }
  return 'Registration could not be completed. Please try again later.';
}

form.addEventListener('submit', async (event) => {
  event.preventDefault();
  feedback.hidden = true;

  if (!form.reportValidity()) {
    return;
  }

  if (hasInvitationContext && !validInvitationToken) {
    showError('This invitation link is invalid. Open the original invitation email for a fresh link.');
    return;
  }

  const email = form.elements.email.value.trim();
  const phone = form.elements.phone.value.trim();
  const password = form.elements.password.value;
  const confirmation = form.elements['password-confirm'].value;

  if (
    password.length < 12 ||
    !/[A-Z]/.test(password) ||
    !/[a-z]/.test(password) ||
    !/[0-9]/.test(password) ||
    !/[^A-Za-z0-9]/.test(password)
  ) {
    showError('Use at least 12 characters, with uppercase and lowercase letters, a number, and a symbol.');
    return;
  }

  if (password !== confirmation) {
    showError('The passwords do not match.');
    return;
  }

  if (!csrfToken) {
    showError('The secure session is unavailable. Reload this page and try again.');
    return;
  }

  submitButton.disabled = true;

  try {
    const registration = { email, phone, password };
    if (hasInvitationContext) {
      registration.invitation_token = invitationToken;
    }
    const response = await fetch(`${API_ROOT}/api/auth/register.php`, {
      method: 'POST',
      credentials: 'same-origin',
      headers: {
        'Content-Type': 'application/json',
        'X-CSRF-Token': csrfToken
      },
      body: JSON.stringify(registration)
    });
    const result = await response.json().catch(() => null);

    if (!response.ok || result?.success !== true) {
      showError(registrationError(response, result));
      return;
    }

    window.location.assign(`verify-email.html${invitationFragment}`);
  } catch {
    showError('A network error interrupted registration. Contact the site administrator before retrying, as the request may have reached the server.');
  } finally {
    form.elements.password.value = '';
    form.elements['password-confirm'].value = '';
    submitButton.disabled = !csrfToken;
  }
});

loadCsrfToken()
  .then(() => {
    if (hasInvitationContext && !validInvitationToken) {
      statusMessage.textContent = 'This invitation link is invalid. Open the original invitation email for a fresh link.';
      return;
    }
    statusMessage.textContent = 'Secure connection ready.';
    submitButton.disabled = false;
  })
  .catch((error) => {
    statusMessage.textContent = error instanceof Error
      ? error.message
      : 'Secure registration is temporarily unavailable. Please try again later.';
  });
