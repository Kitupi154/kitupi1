-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Oct 30, 2026 at 01:36 PM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `family`
--

-- --------------------------------------------------------

--
-- Table structure for table `audit_logs`
--

CREATE TABLE `audit_logs` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `actor_user_id` bigint(20) UNSIGNED DEFAULT NULL,
  `family_id` bigint(20) UNSIGNED DEFAULT NULL,
  `action` varchar(100) NOT NULL,
  `target_type` varchar(100) DEFAULT NULL,
  `target_id` bigint(20) UNSIGNED DEFAULT NULL,
  `ip_hash` char(64) DEFAULT NULL,
  `user_agent_hash` char(64) DEFAULT NULL,
  `metadata_json` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`metadata_json`)),
  `created_at` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `audit_logs`
--

INSERT INTO `audit_logs` (`id`, `actor_user_id`, `family_id`, `action`, `target_type`, `target_id`, `ip_hash`, `user_agent_hash`, `metadata_json`, `created_at`) VALUES
(1, 1, NULL, 'login_success', 'user', 1, '2f0e44b71242630ff46ba5acf8bdbd2ee6c99b0b21e79389503ba5059f86a852', 'a7ea00bdc8f1e36221a99c7c413f613015b29106fee2340372ab3a577b5bca2a', NULL, '2026-10-15 22:23:00'),
(2, 1, NULL, 'login_success', 'user', 1, '2f0e44b71242630ff46ba5acf8bdbd2ee6c99b0b21e79389503ba5059f86a852', 'a7ea00bdc8f1e36221a99c7c413f613015b29106fee2340372ab3a577b5bca2a', NULL, '2026-10-16 12:05:38'),
(3, 1, NULL, 'login_success', 'user', 1, '2f0e44b71242630ff46ba5acf8bdbd2ee6c99b0b21e79389503ba5059f86a852', 'ee52e23671fb67d2e9e704b6d59885a548dd5468debc37d5ece24be66cd5fc10', NULL, '2026-10-16 12:30:39'),
(4, 1, NULL, 'login_success', 'user', 1, '2f0e44b71242630ff46ba5acf8bdbd2ee6c99b0b21e79389503ba5059f86a852', 'ee52e23671fb67d2e9e704b6d59885a548dd5468debc37d5ece24be66cd5fc10', NULL, '2026-10-16 15:19:41'),
(5, 1, NULL, 'login_success', 'user', 1, '2f0e44b71242630ff46ba5acf8bdbd2ee6c99b0b21e79389503ba5059f86a852', 'ee52e23671fb67d2e9e704b6d59885a548dd5468debc37d5ece24be66cd5fc10', NULL, '2026-10-16 16:56:50'),
(6, 1, NULL, 'login_success', 'user', 1, '2f0e44b71242630ff46ba5acf8bdbd2ee6c99b0b21e79389503ba5059f86a852', 'a7ea00bdc8f1e36221a99c7c413f613015b29106fee2340372ab3a577b5bca2a', NULL, '2026-10-16 17:10:03'),
(7, 1, NULL, 'login_success', 'user', 1, '2f0e44b71242630ff46ba5acf8bdbd2ee6c99b0b21e79389503ba5059f86a852', 'ee52e23671fb67d2e9e704b6d59885a548dd5468debc37d5ece24be66cd5fc10', NULL, '2026-10-16 18:20:13'),
(8, 1, NULL, 'login_success', 'user', 1, '2f0e44b71242630ff46ba5acf8bdbd2ee6c99b0b21e79389503ba5059f86a852', 'a7ea00bdc8f1e36221a99c7c413f613015b29106fee2340372ab3a577b5bca2a', NULL, '2026-10-16 20:34:37'),
(9, 1, NULL, 'login_success', 'user', 1, '2f0e44b71242630ff46ba5acf8bdbd2ee6c99b0b21e79389503ba5059f86a852', 'ee52e23671fb67d2e9e704b6d59885a548dd5468debc37d5ece24be66cd5fc10', NULL, '2026-10-16 20:39:50'),
(10, 1, NULL, 'login_success', 'user', 1, '2f0e44b71242630ff46ba5acf8bdbd2ee6c99b0b21e79389503ba5059f86a852', 'a7ea00bdc8f1e36221a99c7c413f613015b29106fee2340372ab3a577b5bca2a', NULL, '2026-10-16 22:02:23'),
(11, 1, NULL, 'login_success', 'user', 1, '2f0e44b71242630ff46ba5acf8bdbd2ee6c99b0b21e79389503ba5059f86a852', 'a7ea00bdc8f1e36221a99c7c413f613015b29106fee2340372ab3a577b5bca2a', NULL, '2026-10-17 09:06:38'),
(12, 1, NULL, 'login_success', 'user', 1, '2f0e44b71242630ff46ba5acf8bdbd2ee6c99b0b21e79389503ba5059f86a852', 'a7ea00bdc8f1e36221a99c7c413f613015b29106fee2340372ab3a577b5bca2a', NULL, '2026-10-17 10:11:39'),
(13, NULL, NULL, 'account_registered', 'user', 2, '2f0e44b71242630ff46ba5acf8bdbd2ee6c99b0b21e79389503ba5059f86a852', 'ee52e23671fb67d2e9e704b6d59885a548dd5468debc37d5ece24be66cd5fc10', NULL, '2026-10-18 11:06:19'),
(14, NULL, NULL, 'otp_failed', 'user', 2, '2f0e44b71242630ff46ba5acf8bdbd2ee6c99b0b21e79389503ba5059f86a852', 'ee52e23671fb67d2e9e704b6d59885a548dd5468debc37d5ece24be66cd5fc10', NULL, '2026-10-18 11:31:17'),
(15, 3, NULL, 'account_registered', 'user', 3, '2f0e44b71242630ff46ba5acf8bdbd2ee6c99b0b21e79389503ba5059f86a852', 'ee52e23671fb67d2e9e704b6d59885a548dd5468debc37d5ece24be66cd5fc10', NULL, '2026-10-18 12:17:33'),
(16, 3, NULL, 'otp_verified', 'user', 3, '2f0e44b71242630ff46ba5acf8bdbd2ee6c99b0b21e79389503ba5059f86a852', 'ee52e23671fb67d2e9e704b6d59885a548dd5468debc37d5ece24be66cd5fc10', NULL, '2026-10-18 12:18:10'),
(17, 1, NULL, 'login_success', 'user', 1, '2f0e44b71242630ff46ba5acf8bdbd2ee6c99b0b21e79389503ba5059f86a852', 'a7ea00bdc8f1e36221a99c7c413f613015b29106fee2340372ab3a577b5bca2a', NULL, '2026-10-18 12:20:08'),
(18, 3, NULL, 'login_failed', 'user', 3, '2f0e44b71242630ff46ba5acf8bdbd2ee6c99b0b21e79389503ba5059f86a852', 'ee52e23671fb67d2e9e704b6d59885a548dd5468debc37d5ece24be66cd5fc10', NULL, '2026-10-18 12:41:56'),
(19, 3, NULL, 'login_failed', 'user', 3, '2f0e44b71242630ff46ba5acf8bdbd2ee6c99b0b21e79389503ba5059f86a852', 'ee52e23671fb67d2e9e704b6d59885a548dd5468debc37d5ece24be66cd5fc10', NULL, '2026-10-18 12:42:19'),
(20, 3, NULL, 'login_failed', 'user', 3, '2f0e44b71242630ff46ba5acf8bdbd2ee6c99b0b21e79389503ba5059f86a852', 'ee52e23671fb67d2e9e704b6d59885a548dd5468debc37d5ece24be66cd5fc10', NULL, '2026-10-18 12:52:48'),
(21, 3, NULL, 'login_failed', 'user', 3, '2f0e44b71242630ff46ba5acf8bdbd2ee6c99b0b21e79389503ba5059f86a852', 'ee52e23671fb67d2e9e704b6d59885a548dd5468debc37d5ece24be66cd5fc10', NULL, '2026-10-18 12:53:04'),
(22, 3, NULL, 'login_success', 'user', 3, '2f0e44b71242630ff46ba5acf8bdbd2ee6c99b0b21e79389503ba5059f86a852', 'ee52e23671fb67d2e9e704b6d59885a548dd5468debc37d5ece24be66cd5fc10', NULL, '2026-10-18 13:36:06'),
(23, 1, NULL, 'login_success', 'user', 1, '2f0e44b71242630ff46ba5acf8bdbd2ee6c99b0b21e79389503ba5059f86a852', 'a7ea00bdc8f1e36221a99c7c413f613015b29106fee2340372ab3a577b5bca2a', NULL, '2026-10-18 13:39:29'),
(24, 1, NULL, 'login_success', 'user', 1, '2f0e44b71242630ff46ba5acf8bdbd2ee6c99b0b21e79389503ba5059f86a852', 'bae691be7b79c0cbfc6c1bc84c58e24609b9b159a1d01ca4592b491debff6dd9', NULL, '2026-10-18 14:59:32'),
(25, 1, NULL, 'login_success', 'user', 1, '2f0e44b71242630ff46ba5acf8bdbd2ee6c99b0b21e79389503ba5059f86a852', 'bae691be7b79c0cbfc6c1bc84c58e24609b9b159a1d01ca4592b491debff6dd9', NULL, '2026-10-18 15:00:07'),
(26, 1, NULL, 'login_success', 'user', 1, '2f0e44b71242630ff46ba5acf8bdbd2ee6c99b0b21e79389503ba5059f86a852', 'a7ea00bdc8f1e36221a99c7c413f613015b29106fee2340372ab3a577b5bca2a', NULL, '2026-10-18 15:01:33'),
(27, 1, 1, 'superadmin_family_created', 'family', 1, '2f0e44b71242630ff46ba5acf8bdbd2ee6c99b0b21e79389503ba5059f86a852', 'a7ea00bdc8f1e36221a99c7c413f613015b29106fee2340372ab3a577b5bca2a', '{\"family_name\":\"jibe kitupi\"}', '2026-10-18 15:07:02'),
(28, 1, 1, 'family_admin_invitation_created', 'family_admin_invitation', 1, '2f0e44b71242630ff46ba5acf8bdbd2ee6c99b0b21e79389503ba5059f86a852', 'a7ea00bdc8f1e36221a99c7c413f613015b29106fee2340372ab3a577b5bca2a', '{\"invited_user_id\":3}', '2026-10-18 15:17:26'),
(29, 3, NULL, 'login_success', 'user', 3, '2f0e44b71242630ff46ba5acf8bdbd2ee6c99b0b21e79389503ba5059f86a852', 'ee52e23671fb67d2e9e704b6d59885a548dd5468debc37d5ece24be66cd5fc10', NULL, '2026-10-18 15:18:39'),
(30, 3, 1, 'family_admin_invitation_accepted', 'family_admin_invitation', 1, '2f0e44b71242630ff46ba5acf8bdbd2ee6c99b0b21e79389503ba5059f86a852', 'ee52e23671fb67d2e9e704b6d59885a548dd5468debc37d5ece24be66cd5fc10', '{\"member_id\":1}', '2026-10-18 15:19:31'),
(31, 3, 1, 'member_updated', 'family_member', 1, '2f0e44b71242630ff46ba5acf8bdbd2ee6c99b0b21e79389503ba5059f86a852', 'ee52e23671fb67d2e9e704b6d59885a548dd5468debc37d5ece24be66cd5fc10', NULL, '2026-10-18 15:21:43'),
(32, 3, 1, 'media_uploaded', 'media', 1, '2f0e44b71242630ff46ba5acf8bdbd2ee6c99b0b21e79389503ba5059f86a852', 'ee52e23671fb67d2e9e704b6d59885a548dd5468debc37d5ece24be66cd5fc10', '{\"media_type\":\"photo\"}', '2026-10-18 15:24:12'),
(33, 3, 1, 'media_uploaded', 'media', 2, '2f0e44b71242630ff46ba5acf8bdbd2ee6c99b0b21e79389503ba5059f86a852', 'ee52e23671fb67d2e9e704b6d59885a548dd5468debc37d5ece24be66cd5fc10', '{\"media_type\":\"photo\"}', '2026-10-18 15:24:30'),
(34, 3, 1, 'media_uploaded', 'media', 3, '2f0e44b71242630ff46ba5acf8bdbd2ee6c99b0b21e79389503ba5059f86a852', 'ee52e23671fb67d2e9e704b6d59885a548dd5468debc37d5ece24be66cd5fc10', '{\"media_type\":\"photo\"}', '2026-10-18 15:24:41'),
(35, 3, 1, 'media_uploaded', 'media', 4, '2f0e44b71242630ff46ba5acf8bdbd2ee6c99b0b21e79389503ba5059f86a852', 'ee52e23671fb67d2e9e704b6d59885a548dd5468debc37d5ece24be66cd5fc10', '{\"media_type\":\"photo\"}', '2026-10-18 15:24:49'),
(36, 3, 1, 'media_uploaded', 'media', 5, '2f0e44b71242630ff46ba5acf8bdbd2ee6c99b0b21e79389503ba5059f86a852', 'ee52e23671fb67d2e9e704b6d59885a548dd5468debc37d5ece24be66cd5fc10', '{\"media_type\":\"video\"}', '2026-10-18 15:25:05'),
(37, 3, 1, 'media_uploaded', 'media', 6, '2f0e44b71242630ff46ba5acf8bdbd2ee6c99b0b21e79389503ba5059f86a852', 'ee52e23671fb67d2e9e704b6d59885a548dd5468debc37d5ece24be66cd5fc10', '{\"media_type\":\"document\"}', '2026-10-18 15:26:30'),
(38, 3, 1, 'member_updated', 'family_member', 1, '2f0e44b71242630ff46ba5acf8bdbd2ee6c99b0b21e79389503ba5059f86a852', 'ee52e23671fb67d2e9e704b6d59885a548dd5468debc37d5ece24be66cd5fc10', NULL, '2026-10-18 15:27:45'),
(39, 3, 1, 'member_updated', 'family_member', 1, '2f0e44b71242630ff46ba5acf8bdbd2ee6c99b0b21e79389503ba5059f86a852', 'ee52e23671fb67d2e9e704b6d59885a548dd5468debc37d5ece24be66cd5fc10', NULL, '2026-10-18 15:28:18'),
(40, 4, NULL, 'account_registered', 'user', 4, '2f0e44b71242630ff46ba5acf8bdbd2ee6c99b0b21e79389503ba5059f86a852', 'ee52e23671fb67d2e9e704b6d59885a548dd5468debc37d5ece24be66cd5fc10', NULL, '2026-10-18 15:35:02'),
(41, 4, NULL, 'otp_resend_requested', 'user', 4, '2f0e44b71242630ff46ba5acf8bdbd2ee6c99b0b21e79389503ba5059f86a852', 'ee52e23671fb67d2e9e704b6d59885a548dd5468debc37d5ece24be66cd5fc10', NULL, '2026-10-18 15:36:10'),
(42, 4, NULL, 'otp_verified', 'user', 4, '2f0e44b71242630ff46ba5acf8bdbd2ee6c99b0b21e79389503ba5059f86a852', 'ee52e23671fb67d2e9e704b6d59885a548dd5468debc37d5ece24be66cd5fc10', NULL, '2026-10-18 15:36:34'),
(43, 4, NULL, 'login_success', 'user', 4, '2f0e44b71242630ff46ba5acf8bdbd2ee6c99b0b21e79389503ba5059f86a852', 'ee52e23671fb67d2e9e704b6d59885a548dd5468debc37d5ece24be66cd5fc10', NULL, '2026-10-18 15:40:50'),
(44, 3, NULL, 'login_success', 'user', 3, '2f0e44b71242630ff46ba5acf8bdbd2ee6c99b0b21e79389503ba5059f86a852', 'ee52e23671fb67d2e9e704b6d59885a548dd5468debc37d5ece24be66cd5fc10', NULL, '2026-10-18 15:48:46'),
(45, 4, NULL, 'login_success', 'user', 4, '2f0e44b71242630ff46ba5acf8bdbd2ee6c99b0b21e79389503ba5059f86a852', 'ee52e23671fb67d2e9e704b6d59885a548dd5468debc37d5ece24be66cd5fc10', NULL, '2026-10-19 09:23:30'),
(46, NULL, NULL, 'login_failed', 'user', 4, '2f0e44b71242630ff46ba5acf8bdbd2ee6c99b0b21e79389503ba5059f86a852', 'a7ea00bdc8f1e36221a99c7c413f613015b29106fee2340372ab3a577b5bca2a', NULL, '2026-10-19 09:25:31'),
(47, NULL, NULL, 'login_failed', 'user', NULL, '2f0e44b71242630ff46ba5acf8bdbd2ee6c99b0b21e79389503ba5059f86a852', 'a7ea00bdc8f1e36221a99c7c413f613015b29106fee2340372ab3a577b5bca2a', NULL, '2026-10-19 09:25:43'),
(48, NULL, NULL, 'login_failed', 'user', NULL, '2f0e44b71242630ff46ba5acf8bdbd2ee6c99b0b21e79389503ba5059f86a852', 'a7ea00bdc8f1e36221a99c7c413f613015b29106fee2340372ab3a577b5bca2a', NULL, '2026-10-19 09:25:45'),
(49, NULL, NULL, 'login_failed', 'user', NULL, '2f0e44b71242630ff46ba5acf8bdbd2ee6c99b0b21e79389503ba5059f86a852', 'a7ea00bdc8f1e36221a99c7c413f613015b29106fee2340372ab3a577b5bca2a', NULL, '2026-10-19 09:25:46'),
(50, NULL, NULL, 'login_failed', 'user', NULL, '2f0e44b71242630ff46ba5acf8bdbd2ee6c99b0b21e79389503ba5059f86a852', 'a7ea00bdc8f1e36221a99c7c413f613015b29106fee2340372ab3a577b5bca2a', NULL, '2026-10-19 09:25:47'),
(51, 4, NULL, 'login_success', 'user', 4, '2f0e44b71242630ff46ba5acf8bdbd2ee6c99b0b21e79389503ba5059f86a852', 'ee52e23671fb67d2e9e704b6d59885a548dd5468debc37d5ece24be66cd5fc10', NULL, '2026-10-19 09:27:03'),
(52, 3, NULL, 'login_success', 'user', 3, '2f0e44b71242630ff46ba5acf8bdbd2ee6c99b0b21e79389503ba5059f86a852', 'ee52e23671fb67d2e9e704b6d59885a548dd5468debc37d5ece24be66cd5fc10', NULL, '2026-10-19 09:27:56'),
(53, 3, 1, 'member_created', 'family_member', 2, '2f0e44b71242630ff46ba5acf8bdbd2ee6c99b0b21e79389503ba5059f86a852', 'ee52e23671fb67d2e9e704b6d59885a548dd5468debc37d5ece24be66cd5fc10', NULL, '2026-10-19 09:30:26'),
(54, 3, 1, 'member_created', 'family_member', 3, '2f0e44b71242630ff46ba5acf8bdbd2ee6c99b0b21e79389503ba5059f86a852', 'ee52e23671fb67d2e9e704b6d59885a548dd5468debc37d5ece24be66cd5fc10', NULL, '2026-10-19 09:31:21'),
(55, 1, NULL, 'login_success', 'user', 1, '2f0e44b71242630ff46ba5acf8bdbd2ee6c99b0b21e79389503ba5059f86a852', 'a7ea00bdc8f1e36221a99c7c413f613015b29106fee2340372ab3a577b5bca2a', NULL, '2026-10-19 09:37:04'),
(56, 3, NULL, 'login_success', 'user', 3, '2f0e44b71242630ff46ba5acf8bdbd2ee6c99b0b21e79389503ba5059f86a852', '4a3b9fc238c18725ff86e6b67eba1aa5638ed31a4641f3f5d7a337dbe484765f', NULL, '2026-10-20 08:37:18'),
(57, NULL, NULL, 'login_failed', 'user', NULL, '2f0e44b71242630ff46ba5acf8bdbd2ee6c99b0b21e79389503ba5059f86a852', 'ee52e23671fb67d2e9e704b6d59885a548dd5468debc37d5ece24be66cd5fc10', NULL, '2026-10-20 10:38:29'),
(58, NULL, NULL, 'login_failed', 'user', NULL, '2f0e44b71242630ff46ba5acf8bdbd2ee6c99b0b21e79389503ba5059f86a852', 'ee52e23671fb67d2e9e704b6d59885a548dd5468debc37d5ece24be66cd5fc10', NULL, '2026-10-20 10:40:28'),
(59, NULL, NULL, 'login_failed', 'user', NULL, '2f0e44b71242630ff46ba5acf8bdbd2ee6c99b0b21e79389503ba5059f86a852', 'ee52e23671fb67d2e9e704b6d59885a548dd5468debc37d5ece24be66cd5fc10', NULL, '2026-10-20 10:40:29'),
(60, NULL, NULL, 'login_failed', 'user', NULL, '2f0e44b71242630ff46ba5acf8bdbd2ee6c99b0b21e79389503ba5059f86a852', 'ee52e23671fb67d2e9e704b6d59885a548dd5468debc37d5ece24be66cd5fc10', NULL, '2026-10-20 10:40:31'),
(61, NULL, NULL, 'login_failed', 'user', NULL, '2f0e44b71242630ff46ba5acf8bdbd2ee6c99b0b21e79389503ba5059f86a852', 'ee52e23671fb67d2e9e704b6d59885a548dd5468debc37d5ece24be66cd5fc10', NULL, '2026-10-20 10:41:39'),
(62, NULL, NULL, 'login_failed', 'user', NULL, '2f0e44b71242630ff46ba5acf8bdbd2ee6c99b0b21e79389503ba5059f86a852', 'ee52e23671fb67d2e9e704b6d59885a548dd5468debc37d5ece24be66cd5fc10', NULL, '2026-10-20 10:48:49'),
(63, NULL, NULL, 'login_failed', 'user', NULL, '2f0e44b71242630ff46ba5acf8bdbd2ee6c99b0b21e79389503ba5059f86a852', 'ee52e23671fb67d2e9e704b6d59885a548dd5468debc37d5ece24be66cd5fc10', NULL, '2026-10-20 11:01:54'),
(64, NULL, NULL, 'login_failed', 'user', NULL, '2f0e44b71242630ff46ba5acf8bdbd2ee6c99b0b21e79389503ba5059f86a852', 'ee52e23671fb67d2e9e704b6d59885a548dd5468debc37d5ece24be66cd5fc10', NULL, '2026-10-20 11:01:55'),
(65, NULL, NULL, 'login_failed', 'user', NULL, '2f0e44b71242630ff46ba5acf8bdbd2ee6c99b0b21e79389503ba5059f86a852', 'ee52e23671fb67d2e9e704b6d59885a548dd5468debc37d5ece24be66cd5fc10', NULL, '2026-10-20 11:01:56'),
(66, NULL, NULL, 'login_failed', 'user', NULL, '2f0e44b71242630ff46ba5acf8bdbd2ee6c99b0b21e79389503ba5059f86a852', 'ee52e23671fb67d2e9e704b6d59885a548dd5468debc37d5ece24be66cd5fc10', NULL, '2026-10-20 11:02:54'),
(67, 4, NULL, 'login_success', 'user', 4, '2f0e44b71242630ff46ba5acf8bdbd2ee6c99b0b21e79389503ba5059f86a852', 'ee52e23671fb67d2e9e704b6d59885a548dd5468debc37d5ece24be66cd5fc10', NULL, '2026-10-20 11:12:04'),
(68, 1, NULL, 'login_success', 'user', 1, '2f0e44b71242630ff46ba5acf8bdbd2ee6c99b0b21e79389503ba5059f86a852', 'ee52e23671fb67d2e9e704b6d59885a548dd5468debc37d5ece24be66cd5fc10', NULL, '2026-10-20 11:15:04'),
(69, 3, NULL, 'login_success', 'user', 3, '2f0e44b71242630ff46ba5acf8bdbd2ee6c99b0b21e79389503ba5059f86a852', '4a3b9fc238c18725ff86e6b67eba1aa5638ed31a4641f3f5d7a337dbe484765f', NULL, '2026-10-20 11:16:12'),
(70, 4, NULL, 'login_success', 'user', 4, '2f0e44b71242630ff46ba5acf8bdbd2ee6c99b0b21e79389503ba5059f86a852', 'ee52e23671fb67d2e9e704b6d59885a548dd5468debc37d5ece24be66cd5fc10', NULL, '2026-10-20 14:54:52'),
(71, 3, NULL, 'login_success', 'user', 3, '2f0e44b71242630ff46ba5acf8bdbd2ee6c99b0b21e79389503ba5059f86a852', 'fb02a615275ee2b7c294d510a5b71b62cf3a5600f823d6e5b3ac671bd2631bff', NULL, '2026-10-27 12:39:48'),
(72, 1, NULL, 'login_success', 'user', 1, '2f0e44b71242630ff46ba5acf8bdbd2ee6c99b0b21e79389503ba5059f86a852', 'ee52e23671fb67d2e9e704b6d59885a548dd5468debc37d5ece24be66cd5fc10', NULL, '2026-10-27 12:40:27'),
(73, 3, NULL, 'login_success', 'user', 3, '2f0e44b71242630ff46ba5acf8bdbd2ee6c99b0b21e79389503ba5059f86a852', 'fb02a615275ee2b7c294d510a5b71b62cf3a5600f823d6e5b3ac671bd2631bff', NULL, '2026-10-27 13:29:06'),
(74, 4, NULL, 'login_success', 'user', 4, '2f0e44b71242630ff46ba5acf8bdbd2ee6c99b0b21e79389503ba5059f86a852', 'ee52e23671fb67d2e9e704b6d59885a548dd5468debc37d5ece24be66cd5fc10', NULL, '2026-10-27 13:36:28'),
(75, 4, 1, 'membership_requested', 'membership_request', 1, '2f0e44b71242630ff46ba5acf8bdbd2ee6c99b0b21e79389503ba5059f86a852', 'ee52e23671fb67d2e9e704b6d59885a548dd5468debc37d5ece24be66cd5fc10', NULL, '2026-10-27 13:37:49'),
(76, 5, NULL, 'account_registered', 'user', 5, '2f0e44b71242630ff46ba5acf8bdbd2ee6c99b0b21e79389503ba5059f86a852', 'ee52e23671fb67d2e9e704b6d59885a548dd5468debc37d5ece24be66cd5fc10', NULL, '2026-10-27 13:48:12'),
(77, 5, NULL, 'otp_verified', 'user', 5, '2f0e44b71242630ff46ba5acf8bdbd2ee6c99b0b21e79389503ba5059f86a852', 'ee52e23671fb67d2e9e704b6d59885a548dd5468debc37d5ece24be66cd5fc10', NULL, '2026-10-27 13:49:09'),
(78, 5, NULL, 'login_success', 'user', 5, '2f0e44b71242630ff46ba5acf8bdbd2ee6c99b0b21e79389503ba5059f86a852', 'ee52e23671fb67d2e9e704b6d59885a548dd5468debc37d5ece24be66cd5fc10', NULL, '2026-10-27 13:54:13'),
(79, 3, NULL, 'login_success', 'user', 3, '2f0e44b71242630ff46ba5acf8bdbd2ee6c99b0b21e79389503ba5059f86a852', 'fb02a615275ee2b7c294d510a5b71b62cf3a5600f823d6e5b3ac671bd2631bff', NULL, '2026-10-27 14:50:42'),
(80, 3, 1, 'membership_approved', 'membership_request', 1, '2f0e44b71242630ff46ba5acf8bdbd2ee6c99b0b21e79389503ba5059f86a852', 'fb02a615275ee2b7c294d510a5b71b62cf3a5600f823d6e5b3ac671bd2631bff', NULL, '2026-10-27 14:52:54'),
(81, 4, NULL, 'login_success', 'user', 4, '2f0e44b71242630ff46ba5acf8bdbd2ee6c99b0b21e79389503ba5059f86a852', 'ee52e23671fb67d2e9e704b6d59885a548dd5468debc37d5ece24be66cd5fc10', NULL, '2026-10-27 14:54:03'),
(82, 4, 1, 'media_uploaded', 'media', 7, '2f0e44b71242630ff46ba5acf8bdbd2ee6c99b0b21e79389503ba5059f86a852', 'ee52e23671fb67d2e9e704b6d59885a548dd5468debc37d5ece24be66cd5fc10', '{\"media_type\":\"document\"}', '2026-10-27 15:00:33'),
(83, 4, 1, 'media_visibility_changed', 'media', 7, '2f0e44b71242630ff46ba5acf8bdbd2ee6c99b0b21e79389503ba5059f86a852', 'ee52e23671fb67d2e9e704b6d59885a548dd5468debc37d5ece24be66cd5fc10', '{\"visibility\":\"family\"}', '2026-10-27 15:01:02'),
(84, 4, 1, 'media_uploaded', 'media', 8, '2f0e44b71242630ff46ba5acf8bdbd2ee6c99b0b21e79389503ba5059f86a852', 'ee52e23671fb67d2e9e704b6d59885a548dd5468debc37d5ece24be66cd5fc10', '{\"media_type\":\"photo\"}', '2026-10-27 15:01:20'),
(85, 4, 1, 'media_uploaded', 'media', 9, '2f0e44b71242630ff46ba5acf8bdbd2ee6c99b0b21e79389503ba5059f86a852', 'ee52e23671fb67d2e9e704b6d59885a548dd5468debc37d5ece24be66cd5fc10', '{\"media_type\":\"video\"}', '2026-10-27 15:01:43'),
(86, 4, 1, 'member_updated', 'family_member', 4, '2f0e44b71242630ff46ba5acf8bdbd2ee6c99b0b21e79389503ba5059f86a852', 'ee52e23671fb67d2e9e704b6d59885a548dd5468debc37d5ece24be66cd5fc10', NULL, '2026-10-27 15:05:03'),
(87, 4, 1, 'permission_requested', 'permission', 1, '2f0e44b71242630ff46ba5acf8bdbd2ee6c99b0b21e79389503ba5059f86a852', 'ee52e23671fb67d2e9e704b6d59885a548dd5468debc37d5ece24be66cd5fc10', NULL, '2026-10-27 15:07:30'),
(88, 5, NULL, 'login_success', 'user', 5, '2f0e44b71242630ff46ba5acf8bdbd2ee6c99b0b21e79389503ba5059f86a852', 'ee52e23671fb67d2e9e704b6d59885a548dd5468debc37d5ece24be66cd5fc10', NULL, '2026-10-27 15:51:48'),
(89, 4, NULL, 'login_success', 'user', 4, '2f0e44b71242630ff46ba5acf8bdbd2ee6c99b0b21e79389503ba5059f86a852', 'ee52e23671fb67d2e9e704b6d59885a548dd5468debc37d5ece24be66cd5fc10', NULL, '2026-10-27 15:53:23'),
(90, 3, NULL, 'login_success', 'user', 3, '2f0e44b71242630ff46ba5acf8bdbd2ee6c99b0b21e79389503ba5059f86a852', 'fb02a615275ee2b7c294d510a5b71b62cf3a5600f823d6e5b3ac671bd2631bff', NULL, '2026-10-27 15:53:38'),
(91, 3, NULL, 'login_success', 'user', 3, '2f0e44b71242630ff46ba5acf8bdbd2ee6c99b0b21e79389503ba5059f86a852', 'fb02a615275ee2b7c294d510a5b71b62cf3a5600f823d6e5b3ac671bd2631bff', NULL, '2026-10-27 16:35:20'),
(92, 3, 1, 'member_created', 'family_member', 5, '2f0e44b71242630ff46ba5acf8bdbd2ee6c99b0b21e79389503ba5059f86a852', 'fb02a615275ee2b7c294d510a5b71b62cf3a5600f823d6e5b3ac671bd2631bff', NULL, '2026-10-27 16:43:00'),
(93, 3, 1, 'family_invitation_created', 'family_invitation', 1, '2f0e44b71242630ff46ba5acf8bdbd2ee6c99b0b21e79389503ba5059f86a852', 'fb02a615275ee2b7c294d510a5b71b62cf3a5600f823d6e5b3ac671bd2631bff', '{\"member_id\":5,\"role\":\"member\"}', '2026-10-27 16:43:00'),
(94, 3, 1, 'family_invitation_delivery_failed', 'family_invitation', 1, '2f0e44b71242630ff46ba5acf8bdbd2ee6c99b0b21e79389503ba5059f86a852', 'fb02a615275ee2b7c294d510a5b71b62cf3a5600f823d6e5b3ac671bd2631bff', '{\"member_id\":5}', '2026-10-27 16:43:00'),
(95, 3, 1, 'member_created', 'family_member', 6, '2f0e44b71242630ff46ba5acf8bdbd2ee6c99b0b21e79389503ba5059f86a852', 'fb02a615275ee2b7c294d510a5b71b62cf3a5600f823d6e5b3ac671bd2631bff', NULL, '2026-10-27 16:43:12'),
(96, 3, 1, 'family_invitation_created', 'family_invitation', 2, '2f0e44b71242630ff46ba5acf8bdbd2ee6c99b0b21e79389503ba5059f86a852', 'fb02a615275ee2b7c294d510a5b71b62cf3a5600f823d6e5b3ac671bd2631bff', '{\"member_id\":6,\"role\":\"member\"}', '2026-10-27 16:43:12'),
(97, 3, 1, 'family_invitation_delivery_failed', 'family_invitation', 2, '2f0e44b71242630ff46ba5acf8bdbd2ee6c99b0b21e79389503ba5059f86a852', 'fb02a615275ee2b7c294d510a5b71b62cf3a5600f823d6e5b3ac671bd2631bff', '{\"member_id\":6}', '2026-10-27 16:43:12'),
(98, 5, NULL, 'login_success', 'user', 5, '2f0e44b71242630ff46ba5acf8bdbd2ee6c99b0b21e79389503ba5059f86a852', '3b24d27af19e225726d3f4384fd22a6ac10efc8dd22886a1755d9503c85cf240', NULL, '2026-10-29 13:38:25'),
(99, 3, NULL, 'login_success', 'user', 3, '2f0e44b71242630ff46ba5acf8bdbd2ee6c99b0b21e79389503ba5059f86a852', 'fb02a615275ee2b7c294d510a5b71b62cf3a5600f823d6e5b3ac671bd2631bff', NULL, '2026-10-29 13:38:55'),
(100, 3, 1, 'family_settings_updated', 'family', 1, '2f0e44b71242630ff46ba5acf8bdbd2ee6c99b0b21e79389503ba5059f86a852', 'fb02a615275ee2b7c294d510a5b71b62cf3a5600f823d6e5b3ac671bd2631bff', '{\"profile_visibility\":\"family\",\"permission_expiry_days\":30,\"home_region_changed\":false}', '2026-10-29 13:39:29'),
(101, 4, NULL, 'login_success', 'user', 4, '2f0e44b71242630ff46ba5acf8bdbd2ee6c99b0b21e79389503ba5059f86a852', '3b24d27af19e225726d3f4384fd22a6ac10efc8dd22886a1755d9503c85cf240', NULL, '2026-10-29 13:55:02'),
(102, 3, NULL, 'login_success', 'user', 3, '2f0e44b71242630ff46ba5acf8bdbd2ee6c99b0b21e79389503ba5059f86a852', 'fb02a615275ee2b7c294d510a5b71b62cf3a5600f823d6e5b3ac671bd2631bff', NULL, '2026-10-29 14:34:13'),
(103, 3, NULL, 'login_success', 'user', 3, '2f0e44b71242630ff46ba5acf8bdbd2ee6c99b0b21e79389503ba5059f86a852', 'fb02a615275ee2b7c294d510a5b71b62cf3a5600f823d6e5b3ac671bd2631bff', NULL, '2026-10-29 15:36:34'),
(104, 3, 1, 'member_created', 'family_member', 7, '2f0e44b71242630ff46ba5acf8bdbd2ee6c99b0b21e79389503ba5059f86a852', 'fb02a615275ee2b7c294d510a5b71b62cf3a5600f823d6e5b3ac671bd2631bff', NULL, '2026-10-29 15:37:34'),
(105, 3, 1, 'family_invitation_created', 'family_invitation', 3, '2f0e44b71242630ff46ba5acf8bdbd2ee6c99b0b21e79389503ba5059f86a852', 'fb02a615275ee2b7c294d510a5b71b62cf3a5600f823d6e5b3ac671bd2631bff', '{\"member_id\":7,\"role\":\"member\"}', '2026-10-29 15:37:34'),
(106, 3, 1, 'member_created', 'family_member', 8, '2f0e44b71242630ff46ba5acf8bdbd2ee6c99b0b21e79389503ba5059f86a852', 'fb02a615275ee2b7c294d510a5b71b62cf3a5600f823d6e5b3ac671bd2631bff', NULL, '2026-10-29 16:04:50'),
(107, 3, 1, 'family_invitation_created', 'family_invitation', 4, '2f0e44b71242630ff46ba5acf8bdbd2ee6c99b0b21e79389503ba5059f86a852', 'fb02a615275ee2b7c294d510a5b71b62cf3a5600f823d6e5b3ac671bd2631bff', '{\"member_id\":8,\"role\":\"member\"}', '2026-10-29 16:04:50'),
(108, 6, NULL, 'account_registered', 'user', 6, '2f0e44b71242630ff46ba5acf8bdbd2ee6c99b0b21e79389503ba5059f86a852', '3b24d27af19e225726d3f4384fd22a6ac10efc8dd22886a1755d9503c85cf240', NULL, '2026-10-29 16:06:43'),
(109, 6, NULL, 'otp_verified', 'user', 6, '2f0e44b71242630ff46ba5acf8bdbd2ee6c99b0b21e79389503ba5059f86a852', '3b24d27af19e225726d3f4384fd22a6ac10efc8dd22886a1755d9503c85cf240', NULL, '2026-10-29 16:07:09'),
(110, 6, NULL, 'login_success', 'user', 6, '2f0e44b71242630ff46ba5acf8bdbd2ee6c99b0b21e79389503ba5059f86a852', '3b24d27af19e225726d3f4384fd22a6ac10efc8dd22886a1755d9503c85cf240', NULL, '2026-10-29 16:09:35'),
(111, 6, 1, 'membership_requested', 'membership_request', 2, '2f0e44b71242630ff46ba5acf8bdbd2ee6c99b0b21e79389503ba5059f86a852', '3b24d27af19e225726d3f4384fd22a6ac10efc8dd22886a1755d9503c85cf240', NULL, '2026-10-29 16:10:23'),
(112, 3, 1, 'membership_approved', 'membership_request', 2, '2f0e44b71242630ff46ba5acf8bdbd2ee6c99b0b21e79389503ba5059f86a852', 'fb02a615275ee2b7c294d510a5b71b62cf3a5600f823d6e5b3ac671bd2631bff', NULL, '2026-10-29 16:10:59'),
(113, 3, 1, 'member_created', 'family_member', 10, '2f0e44b71242630ff46ba5acf8bdbd2ee6c99b0b21e79389503ba5059f86a852', 'fb02a615275ee2b7c294d510a5b71b62cf3a5600f823d6e5b3ac671bd2631bff', NULL, '2026-10-29 16:34:50'),
(114, 3, 1, 'family_invitation_created', 'family_invitation', 5, '2f0e44b71242630ff46ba5acf8bdbd2ee6c99b0b21e79389503ba5059f86a852', 'fb02a615275ee2b7c294d510a5b71b62cf3a5600f823d6e5b3ac671bd2631bff', '{\"member_id\":10,\"role\":\"member\"}', '2026-10-29 16:34:50'),
(117, 3, 1, 'member_created', 'family_member', 13, '2f0e44b71242630ff46ba5acf8bdbd2ee6c99b0b21e79389503ba5059f86a852', 'fb02a615275ee2b7c294d510a5b71b62cf3a5600f823d6e5b3ac671bd2631bff', NULL, '2026-10-29 16:56:37'),
(118, 3, 1, 'family_invitation_created', 'family_invitation', 6, '2f0e44b71242630ff46ba5acf8bdbd2ee6c99b0b21e79389503ba5059f86a852', 'fb02a615275ee2b7c294d510a5b71b62cf3a5600f823d6e5b3ac671bd2631bff', '{\"member_id\":13,\"role\":\"member\"}', '2026-10-29 16:56:37'),
(119, 3, 1, 'member_created', 'family_member', 14, '2f0e44b71242630ff46ba5acf8bdbd2ee6c99b0b21e79389503ba5059f86a852', 'fb02a615275ee2b7c294d510a5b71b62cf3a5600f823d6e5b3ac671bd2631bff', NULL, '2026-10-29 17:00:14'),
(120, 3, 1, 'family_invitation_created', 'family_invitation', 7, '2f0e44b71242630ff46ba5acf8bdbd2ee6c99b0b21e79389503ba5059f86a852', 'fb02a615275ee2b7c294d510a5b71b62cf3a5600f823d6e5b3ac671bd2631bff', '{\"member_id\":14,\"role\":\"member\"}', '2026-10-29 17:00:14'),
(121, 3, 1, 'member_created', 'family_member', 15, '2f0e44b71242630ff46ba5acf8bdbd2ee6c99b0b21e79389503ba5059f86a852', 'fb02a615275ee2b7c294d510a5b71b62cf3a5600f823d6e5b3ac671bd2631bff', NULL, '2026-10-29 17:09:39'),
(122, 3, 1, 'family_invitation_created', 'family_invitation', 8, '2f0e44b71242630ff46ba5acf8bdbd2ee6c99b0b21e79389503ba5059f86a852', 'fb02a615275ee2b7c294d510a5b71b62cf3a5600f823d6e5b3ac671bd2631bff', '{\"member_id\":15,\"role\":\"member\"}', '2026-10-29 17:09:39'),
(123, 7, 1, 'invitation_account_created', 'family_invitation', 8, '2f0e44b71242630ff46ba5acf8bdbd2ee6c99b0b21e79389503ba5059f86a852', '3b24d27af19e225726d3f4384fd22a6ac10efc8dd22886a1755d9503c85cf240', '{\"member_id\":15}', '2026-10-29 17:12:10'),
(124, 7, NULL, 'otp_verified', 'user', 7, '2f0e44b71242630ff46ba5acf8bdbd2ee6c99b0b21e79389503ba5059f86a852', '3b24d27af19e225726d3f4384fd22a6ac10efc8dd22886a1755d9503c85cf240', NULL, '2026-10-29 17:13:18'),
(125, 7, NULL, 'login_success', 'user', 7, '2f0e44b71242630ff46ba5acf8bdbd2ee6c99b0b21e79389503ba5059f86a852', '3b24d27af19e225726d3f4384fd22a6ac10efc8dd22886a1755d9503c85cf240', NULL, '2026-10-29 17:14:56'),
(126, 3, NULL, 'login_success', 'user', 3, '2f0e44b71242630ff46ba5acf8bdbd2ee6c99b0b21e79389503ba5059f86a852', 'fb02a615275ee2b7c294d510a5b71b62cf3a5600f823d6e5b3ac671bd2631bff', NULL, '2026-10-30 09:30:38'),
(128, 3, 1, 'member_created', 'family_member', 17, '2f0e44b71242630ff46ba5acf8bdbd2ee6c99b0b21e79389503ba5059f86a852', 'fb02a615275ee2b7c294d510a5b71b62cf3a5600f823d6e5b3ac671bd2631bff', NULL, '2026-10-30 09:33:35'),
(129, 3, 1, 'family_invitation_created', 'family_invitation', 9, '2f0e44b71242630ff46ba5acf8bdbd2ee6c99b0b21e79389503ba5059f86a852', 'fb02a615275ee2b7c294d510a5b71b62cf3a5600f823d6e5b3ac671bd2631bff', '{\"member_id\":17,\"role\":\"member\"}', '2026-10-30 09:33:35'),
(130, 8, 1, 'invitation_account_created', 'family_invitation', 9, '2f0e44b71242630ff46ba5acf8bdbd2ee6c99b0b21e79389503ba5059f86a852', '3b24d27af19e225726d3f4384fd22a6ac10efc8dd22886a1755d9503c85cf240', '{\"member_id\":17}', '2026-10-30 09:36:04'),
(131, 8, NULL, 'otp_verified', 'user', 8, '2f0e44b71242630ff46ba5acf8bdbd2ee6c99b0b21e79389503ba5059f86a852', '3b24d27af19e225726d3f4384fd22a6ac10efc8dd22886a1755d9503c85cf240', NULL, '2026-10-30 09:36:38'),
(132, 8, NULL, 'login_success', 'user', 8, '2f0e44b71242630ff46ba5acf8bdbd2ee6c99b0b21e79389503ba5059f86a852', '3b24d27af19e225726d3f4384fd22a6ac10efc8dd22886a1755d9503c85cf240', NULL, '2026-10-30 09:39:16'),
(133, 3, NULL, 'login_success', 'user', 3, '2f0e44b71242630ff46ba5acf8bdbd2ee6c99b0b21e79389503ba5059f86a852', 'fb02a615275ee2b7c294d510a5b71b62cf3a5600f823d6e5b3ac671bd2631bff', NULL, '2026-10-30 10:18:02'),
(134, 8, NULL, 'login_success', 'user', 8, '2f0e44b71242630ff46ba5acf8bdbd2ee6c99b0b21e79389503ba5059f86a852', '3b24d27af19e225726d3f4384fd22a6ac10efc8dd22886a1755d9503c85cf240', NULL, '2026-10-30 10:20:00'),
(135, 3, 1, 'member_created', 'family_member', 18, '2f0e44b71242630ff46ba5acf8bdbd2ee6c99b0b21e79389503ba5059f86a852', 'fb02a615275ee2b7c294d510a5b71b62cf3a5600f823d6e5b3ac671bd2631bff', NULL, '2026-10-30 10:26:22'),
(136, 3, 1, 'family_invitation_created', 'family_invitation', 10, '2f0e44b71242630ff46ba5acf8bdbd2ee6c99b0b21e79389503ba5059f86a852', 'fb02a615275ee2b7c294d510a5b71b62cf3a5600f823d6e5b3ac671bd2631bff', '{\"member_id\":18,\"role\":\"member\"}', '2026-10-30 10:26:22'),
(137, 9, 1, 'invitation_account_created', 'family_invitation', 10, '2f0e44b71242630ff46ba5acf8bdbd2ee6c99b0b21e79389503ba5059f86a852', '3b24d27af19e225726d3f4384fd22a6ac10efc8dd22886a1755d9503c85cf240', '{\"member_id\":18}', '2026-10-30 10:27:48'),
(138, 9, NULL, 'otp_verified', 'user', 9, '2f0e44b71242630ff46ba5acf8bdbd2ee6c99b0b21e79389503ba5059f86a852', '3b24d27af19e225726d3f4384fd22a6ac10efc8dd22886a1755d9503c85cf240', NULL, '2026-10-30 10:28:08'),
(139, 9, 1, 'family_invitation_accepted', 'family_invitation', 10, '2f0e44b71242630ff46ba5acf8bdbd2ee6c99b0b21e79389503ba5059f86a852', '3b24d27af19e225726d3f4384fd22a6ac10efc8dd22886a1755d9503c85cf240', '{\"member_id\":18,\"role\":\"member\"}', '2026-10-30 10:28:08'),
(140, 3, NULL, 'login_success', 'user', 3, '2f0e44b71242630ff46ba5acf8bdbd2ee6c99b0b21e79389503ba5059f86a852', 'fb02a615275ee2b7c294d510a5b71b62cf3a5600f823d6e5b3ac671bd2631bff', NULL, '2026-10-30 10:58:17'),
(141, 9, NULL, 'login_success', 'user', 9, '2f0e44b71242630ff46ba5acf8bdbd2ee6c99b0b21e79389503ba5059f86a852', '3b24d27af19e225726d3f4384fd22a6ac10efc8dd22886a1755d9503c85cf240', NULL, '2026-10-30 11:00:30'),
(142, 10, NULL, 'account_registered', 'user', 10, '2f0e44b71242630ff46ba5acf8bdbd2ee6c99b0b21e79389503ba5059f86a852', '3b24d27af19e225726d3f4384fd22a6ac10efc8dd22886a1755d9503c85cf240', NULL, '2026-10-30 11:41:52'),
(143, 10, NULL, 'otp_verified', 'user', 10, '2f0e44b71242630ff46ba5acf8bdbd2ee6c99b0b21e79389503ba5059f86a852', '3b24d27af19e225726d3f4384fd22a6ac10efc8dd22886a1755d9503c85cf240', NULL, '2026-10-30 11:42:14'),
(144, 10, NULL, 'login_success', 'user', 10, '2f0e44b71242630ff46ba5acf8bdbd2ee6c99b0b21e79389503ba5059f86a852', '3b24d27af19e225726d3f4384fd22a6ac10efc8dd22886a1755d9503c85cf240', NULL, '2026-10-30 14:43:15'),
(145, 10, NULL, 'logout', 'user', 10, '2f0e44b71242630ff46ba5acf8bdbd2ee6c99b0b21e79389503ba5059f86a852', '3b24d27af19e225726d3f4384fd22a6ac10efc8dd22886a1755d9503c85cf240', NULL, '2026-10-30 14:44:10'),
(146, 3, NULL, 'login_success', 'user', 3, '2f0e44b71242630ff46ba5acf8bdbd2ee6c99b0b21e79389503ba5059f86a852', 'fb02a615275ee2b7c294d510a5b71b62cf3a5600f823d6e5b3ac671bd2631bff', NULL, '2026-10-30 14:44:32'),
(147, 1, NULL, 'login_success', 'user', 1, '2f0e44b71242630ff46ba5acf8bdbd2ee6c99b0b21e79389503ba5059f86a852', 'fb02a615275ee2b7c294d510a5b71b62cf3a5600f823d6e5b3ac671bd2631bff', NULL, '2026-10-30 15:31:13'),
(148, 1, 1, 'family_invitation_revoked', 'family_invitation', 8, '2f0e44b71242630ff46ba5acf8bdbd2ee6c99b0b21e79389503ba5059f86a852', 'fb02a615275ee2b7c294d510a5b71b62cf3a5600f823d6e5b3ac671bd2631bff', NULL, '2026-10-30 15:33:27');

-- --------------------------------------------------------

--
-- Table structure for table `families`
--

CREATE TABLE `families` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `family_name` varchar(190) NOT NULL,
  `created_by_user_id` bigint(20) UNSIGNED NOT NULL,
  `status` enum('active','suspended','archived') NOT NULL DEFAULT 'active',
  `created_at` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `families`
--

INSERT INTO `families` (`id`, `family_name`, `created_by_user_id`, `status`, `created_at`) VALUES
(1, 'GILBERT KITUPI', 1, 'active', '2026-10-18 15:07:02');

-- --------------------------------------------------------

--
-- Table structure for table `family_admin_invitations`
--

CREATE TABLE `family_admin_invitations` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `family_id` bigint(20) UNSIGNED NOT NULL,
  `invited_user_id` bigint(20) UNSIGNED NOT NULL,
  `invited_by_user_id` bigint(20) UNSIGNED DEFAULT NULL,
  `status` enum('pending','accepted','revoked','expired') NOT NULL DEFAULT 'pending',
  `pending_user_id` bigint(20) UNSIGNED GENERATED ALWAYS AS (case when `status` = 'pending' then `invited_user_id` else NULL end) STORED,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `expires_at` datetime NOT NULL,
  `accepted_at` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `family_admin_invitations`
--

INSERT INTO `family_admin_invitations` (`id`, `family_id`, `invited_user_id`, `invited_by_user_id`, `status`, `created_at`, `expires_at`, `accepted_at`) VALUES
(1, 1, 3, 1, 'accepted', '2026-10-18 15:17:26', '2026-10-25 15:17:26', '2026-10-18 15:19:31');

-- --------------------------------------------------------

--
-- Table structure for table `family_invitations`
--

CREATE TABLE `family_invitations` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `family_id` bigint(20) UNSIGNED NOT NULL,
  `member_id` bigint(20) UNSIGNED DEFAULT NULL,
  `pending_member_ref` varchar(64) GENERATED ALWAYS AS (case when `status` = 'pending' and `member_id` is not null then concat(cast(`family_id` as char charset utf8mb4),':',cast(`member_id` as char charset utf8mb4)) else NULL end) STORED,
  `invitee_email` varchar(190) DEFAULT NULL,
  `invitee_phone` varchar(30) DEFAULT NULL,
  `invited_user_id` bigint(20) UNSIGNED DEFAULT NULL,
  `invited_by_user_id` bigint(20) UNSIGNED NOT NULL,
  `invited_role` enum('admin','member') NOT NULL,
  `token_hash` char(64) CHARACTER SET ascii COLLATE ascii_bin NOT NULL,
  `status` enum('pending','accepted','revoked','expired') NOT NULL DEFAULT 'pending',
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `expires_at` datetime NOT NULL,
  `accepted_at` datetime DEFAULT NULL,
  `revoked_at` datetime DEFAULT NULL,
  `pending_email` varchar(190) GENERATED ALWAYS AS (case when `status` = 'pending' and `invitee_email` is not null then lcase(`invitee_email`) else NULL end) STORED,
  `pending_phone` varchar(30) GENERATED ALWAYS AS (case when `status` = 'pending' and `invitee_phone` is not null then `invitee_phone` else NULL end) STORED
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `family_invitations`
--

INSERT INTO `family_invitations` (`id`, `family_id`, `member_id`, `invitee_email`, `invitee_phone`, `invited_user_id`, `invited_by_user_id`, `invited_role`, `token_hash`, `status`, `created_at`, `expires_at`, `accepted_at`, `revoked_at`) VALUES
(1, 1, NULL, 'kaemba155@gmail.com', NULL, 1, 3, 'member', '35c07b8348a5b1b4b961892a3f43573045ee2d31c9a3e145d3d24b539ec99a57', 'revoked', '2026-10-27 16:43:00', '2026-11-03 16:43:00', NULL, '2026-10-27 16:43:00'),
(2, 1, NULL, 'kaemba155@gmail.com', NULL, 1, 3, 'member', '11e3690c7879f3427bf551072d27853d95476e37ab0ae1961dfd312253f422b0', 'revoked', '2026-10-27 16:43:12', '2026-11-03 16:43:12', NULL, '2026-10-27 16:43:12'),
(3, 1, NULL, 'kaemba155@gmail.com', NULL, 1, 3, 'member', '2dffbdff3573fe4268bc7f2ae39be3202307c9c1b5209ccbb5f643f4cecb3c8d', 'pending', '2026-10-29 15:37:34', '2026-11-05 15:37:34', NULL, NULL),
(4, 1, NULL, 'kitupijackson@gmail.com', NULL, NULL, 3, 'member', '93c8e2fd0e2071b08ff62761db41c39394ed103074b29e70e34b7cdb564b98bb', 'pending', '2026-10-29 16:04:50', '2026-11-05 16:04:50', NULL, NULL),
(5, 1, NULL, 'kitupijacksoni@gmail.com', NULL, NULL, 3, 'member', '6474b053389a4fbb04ca87f37ce845c6f0fb1c36c96efb7b4bea6a3bb6a0626d', 'pending', '2026-10-29 16:34:50', '2026-11-05 16:34:50', NULL, NULL),
(6, 1, NULL, 'peterkitupi2@gmail.com', NULL, 5, 3, 'member', '8fa008c8404fab84772f87d684ea8cd1dabb21d29d0da07fca8ed53f710410fa', 'pending', '2026-10-29 16:56:37', '2026-11-05 16:56:37', NULL, NULL),
(7, 1, NULL, 'amanimpanda2005@gmail.com', NULL, NULL, 3, 'member', 'e2a80308acedf7ea789529da93403e49b9e1e9dfd818ec57b3c7048608a933a6', 'pending', '2026-10-29 17:00:14', '2026-11-05 17:00:14', NULL, NULL),
(8, 1, NULL, 'salhalulu123@gmail.com', NULL, 7, 3, 'member', 'f92c70987a48f1cafb1e3216e712445945a08f4baef9e35fe0f9898bce12d32e', 'revoked', '2026-10-29 17:09:39', '2026-11-05 17:09:39', NULL, '2026-10-30 15:33:27'),
(9, 1, 17, 'oscar155@gmail.com', NULL, 8, 3, 'member', 'b5213cf5d02b2c2d6026ee0ffb4278159c1a97f3cb6cf3539a9bdb11c7beac2a', 'pending', '2026-10-30 09:33:35', '2026-11-06 09:33:35', NULL, NULL),
(10, 1, 18, 'elisha155@gmail.com', NULL, 9, 3, 'member', 'e685875b538f5488cc5ad93e77fb4edf34f8368e51e585f4f564fd1194f512f8', 'accepted', '2026-10-30 10:26:22', '2026-11-06 10:26:22', '2026-10-30 10:28:08', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `family_members`
--

CREATE TABLE `family_members` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `family_id` bigint(20) UNSIGNED NOT NULL,
  `user_id` bigint(20) UNSIGNED DEFAULT NULL,
  `first_name` varchar(100) NOT NULL,
  `middle_name` varchar(100) DEFAULT NULL,
  `preferred_name` varchar(100) DEFAULT NULL,
  `last_name` varchar(100) NOT NULL,
  `gender` enum('male','female','other','unspecified') NOT NULL DEFAULT 'unspecified',
  `date_of_birth` date DEFAULT NULL,
  `bio` text DEFAULT NULL,
  `phone` varchar(30) DEFAULT NULL,
  `preferred_contact_method` enum('email','phone','either','none') DEFAULT NULL,
  `email` varchar(190) DEFAULT NULL,
  `profile_photo_media_id` bigint(20) UNSIGNED DEFAULT NULL,
  `member_status` enum('pending','active','suspended','removed','unclaimed') NOT NULL DEFAULT 'pending',
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `family_members`
--

INSERT INTO `family_members` (`id`, `family_id`, `user_id`, `first_name`, `middle_name`, `preferred_name`, `last_name`, `gender`, `date_of_birth`, `bio`, `phone`, `preferred_contact_method`, `email`, `profile_photo_media_id`, `member_status`, `created_at`, `updated_at`) VALUES
(1, 1, 3, 'JACKSON', 'PETER', NULL, 'KITUPI', 'unspecified', NULL, 'nothing', '0664384727', NULL, 'jacksonkitupip@gmail.com', NULL, 'active', '2026-10-18 15:19:31', '2026-10-18 15:28:18'),
(4, 1, 4, 'emmanuel', NULL, NULL, 'mabala', 'unspecified', NULL, NULL, NULL, NULL, 'mabala0155@gmai.com', NULL, 'active', '2026-10-27 13:37:49', '2026-10-27 15:05:03'),
(17, 1, NULL, 'oscar', 'gilbert', 'oscar', 'kitupi', 'male', '2002-12-11', NULL, NULL, NULL, NULL, NULL, 'unclaimed', '2026-10-30 09:33:35', '2026-10-30 09:33:35'),
(18, 1, 9, 'elisha', 'gilbert', 'elisha', 'kitupi', 'male', '2002-02-02', NULL, NULL, NULL, NULL, NULL, 'active', '2026-10-30 10:26:22', '2026-10-30 10:28:08');

-- --------------------------------------------------------

--
-- Table structure for table `family_relationships`
--

CREATE TABLE `family_relationships` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `family_id` bigint(20) UNSIGNED NOT NULL,
  `person_id` bigint(20) UNSIGNED NOT NULL,
  `related_person_id` bigint(20) UNSIGNED NOT NULL,
  `relationship_type` enum('parent','child','spouse','guardian') NOT NULL,
  `status` enum('pending','approved','rejected') NOT NULL DEFAULT 'pending',
  `created_by_member_id` bigint(20) UNSIGNED NOT NULL,
  `approved_by_member_id` bigint(20) UNSIGNED DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `approved_at` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `family_roles`
--

CREATE TABLE `family_roles` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `family_id` bigint(20) UNSIGNED NOT NULL,
  `member_id` bigint(20) UNSIGNED NOT NULL,
  `role` enum('admin','member','viewer') NOT NULL DEFAULT 'member',
  `created_at` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `family_roles`
--

INSERT INTO `family_roles` (`id`, `family_id`, `member_id`, `role`, `created_at`) VALUES
(1, 1, 1, 'admin', '2026-10-18 15:19:31'),
(2, 1, 4, 'member', '2026-10-27 14:52:54'),
(4, 1, 18, 'member', '2026-10-30 10:28:08');

-- --------------------------------------------------------

--
-- Table structure for table `family_settings`
--

CREATE TABLE `family_settings` (
  `family_id` bigint(20) UNSIGNED NOT NULL,
  `home_region` varchar(190) DEFAULT NULL,
  `profile_visibility` enum('family','private') NOT NULL DEFAULT 'family',
  `permission_expiry_days` smallint(5) UNSIGNED NOT NULL DEFAULT 30,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ;

--
-- Dumping data for table `family_settings`
--

INSERT INTO `family_settings` (`family_id`, `home_region`, `profile_visibility`, `permission_expiry_days`, `created_at`, `updated_at`) VALUES
(1, NULL, 'family', 30, '2026-10-29 13:39:29', '2026-10-29 13:39:29');

-- --------------------------------------------------------

--
-- Table structure for table `identity_verifications`
--

CREATE TABLE `identity_verifications` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `user_id` bigint(20) UNSIGNED NOT NULL,
  `member_id` bigint(20) UNSIGNED DEFAULT NULL,
  `document_type` varchar(50) NOT NULL,
  `document_number_encrypted` text DEFAULT NULL,
  `document_number_hash` char(64) DEFAULT NULL,
  `document_media_id` bigint(20) UNSIGNED DEFAULT NULL,
  `status` enum('pending','verified','rejected') NOT NULL DEFAULT 'pending',
  `reviewer_user_id` bigint(20) UNSIGNED DEFAULT NULL,
  `rejection_reason` varchar(500) DEFAULT NULL,
  `submitted_at` datetime NOT NULL DEFAULT current_timestamp(),
  `reviewed_at` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `login_attempts`
--

CREATE TABLE `login_attempts` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `identifier_hash` char(64) NOT NULL,
  `ip_hash` char(64) NOT NULL,
  `success` tinyint(1) NOT NULL DEFAULT 0,
  `created_at` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `login_attempts`
--

INSERT INTO `login_attempts` (`id`, `identifier_hash`, `ip_hash`, `success`, `created_at`) VALUES
(1, 'cf1b7edb42d078e8d73844322245535f03acd84748cb6b727b0bff0a4281d0a1', '2f0e44b71242630ff46ba5acf8bdbd2ee6c99b0b21e79389503ba5059f86a852', 1, '2026-10-15 22:23:00'),
(2, 'cf1b7edb42d078e8d73844322245535f03acd84748cb6b727b0bff0a4281d0a1', '2f0e44b71242630ff46ba5acf8bdbd2ee6c99b0b21e79389503ba5059f86a852', 1, '2026-10-16 12:05:38'),
(3, 'cf1b7edb42d078e8d73844322245535f03acd84748cb6b727b0bff0a4281d0a1', '2f0e44b71242630ff46ba5acf8bdbd2ee6c99b0b21e79389503ba5059f86a852', 1, '2026-10-16 12:30:39'),
(4, 'cf1b7edb42d078e8d73844322245535f03acd84748cb6b727b0bff0a4281d0a1', '2f0e44b71242630ff46ba5acf8bdbd2ee6c99b0b21e79389503ba5059f86a852', 1, '2026-10-16 15:19:41'),
(5, 'cf1b7edb42d078e8d73844322245535f03acd84748cb6b727b0bff0a4281d0a1', '2f0e44b71242630ff46ba5acf8bdbd2ee6c99b0b21e79389503ba5059f86a852', 1, '2026-10-16 16:56:50'),
(6, 'cf1b7edb42d078e8d73844322245535f03acd84748cb6b727b0bff0a4281d0a1', '2f0e44b71242630ff46ba5acf8bdbd2ee6c99b0b21e79389503ba5059f86a852', 1, '2026-10-16 17:10:03'),
(7, 'cf1b7edb42d078e8d73844322245535f03acd84748cb6b727b0bff0a4281d0a1', '2f0e44b71242630ff46ba5acf8bdbd2ee6c99b0b21e79389503ba5059f86a852', 1, '2026-10-16 18:20:13'),
(8, 'cf1b7edb42d078e8d73844322245535f03acd84748cb6b727b0bff0a4281d0a1', '2f0e44b71242630ff46ba5acf8bdbd2ee6c99b0b21e79389503ba5059f86a852', 1, '2026-10-16 20:34:36'),
(9, 'cf1b7edb42d078e8d73844322245535f03acd84748cb6b727b0bff0a4281d0a1', '2f0e44b71242630ff46ba5acf8bdbd2ee6c99b0b21e79389503ba5059f86a852', 1, '2026-10-16 20:39:50'),
(10, 'cf1b7edb42d078e8d73844322245535f03acd84748cb6b727b0bff0a4281d0a1', '2f0e44b71242630ff46ba5acf8bdbd2ee6c99b0b21e79389503ba5059f86a852', 1, '2026-10-16 22:02:23'),
(11, 'cf1b7edb42d078e8d73844322245535f03acd84748cb6b727b0bff0a4281d0a1', '2f0e44b71242630ff46ba5acf8bdbd2ee6c99b0b21e79389503ba5059f86a852', 1, '2026-10-17 09:06:38'),
(12, 'cf1b7edb42d078e8d73844322245535f03acd84748cb6b727b0bff0a4281d0a1', '2f0e44b71242630ff46ba5acf8bdbd2ee6c99b0b21e79389503ba5059f86a852', 1, '2026-10-17 10:11:39'),
(13, 'cf1b7edb42d078e8d73844322245535f03acd84748cb6b727b0bff0a4281d0a1', '2f0e44b71242630ff46ba5acf8bdbd2ee6c99b0b21e79389503ba5059f86a852', 1, '2026-10-18 12:20:08'),
(14, '2ceeb6936d3341588dc92df89dc979a0e69591269c97db0e4deb8b835a102c0a', '2f0e44b71242630ff46ba5acf8bdbd2ee6c99b0b21e79389503ba5059f86a852', 0, '2026-10-18 12:41:56'),
(15, '2ceeb6936d3341588dc92df89dc979a0e69591269c97db0e4deb8b835a102c0a', '2f0e44b71242630ff46ba5acf8bdbd2ee6c99b0b21e79389503ba5059f86a852', 0, '2026-10-18 12:42:19'),
(16, '2ceeb6936d3341588dc92df89dc979a0e69591269c97db0e4deb8b835a102c0a', '2f0e44b71242630ff46ba5acf8bdbd2ee6c99b0b21e79389503ba5059f86a852', 0, '2026-10-18 12:52:48'),
(17, '2ceeb6936d3341588dc92df89dc979a0e69591269c97db0e4deb8b835a102c0a', '2f0e44b71242630ff46ba5acf8bdbd2ee6c99b0b21e79389503ba5059f86a852', 0, '2026-10-18 12:53:04'),
(18, '2ceeb6936d3341588dc92df89dc979a0e69591269c97db0e4deb8b835a102c0a', '2f0e44b71242630ff46ba5acf8bdbd2ee6c99b0b21e79389503ba5059f86a852', 1, '2026-10-18 13:36:06'),
(19, 'cf1b7edb42d078e8d73844322245535f03acd84748cb6b727b0bff0a4281d0a1', '2f0e44b71242630ff46ba5acf8bdbd2ee6c99b0b21e79389503ba5059f86a852', 1, '2026-10-18 13:39:29'),
(20, 'cf1b7edb42d078e8d73844322245535f03acd84748cb6b727b0bff0a4281d0a1', '2f0e44b71242630ff46ba5acf8bdbd2ee6c99b0b21e79389503ba5059f86a852', 1, '2026-10-18 14:59:32'),
(21, 'cf1b7edb42d078e8d73844322245535f03acd84748cb6b727b0bff0a4281d0a1', '2f0e44b71242630ff46ba5acf8bdbd2ee6c99b0b21e79389503ba5059f86a852', 1, '2026-10-18 15:00:07'),
(22, 'cf1b7edb42d078e8d73844322245535f03acd84748cb6b727b0bff0a4281d0a1', '2f0e44b71242630ff46ba5acf8bdbd2ee6c99b0b21e79389503ba5059f86a852', 1, '2026-10-18 15:01:33'),
(23, '2ceeb6936d3341588dc92df89dc979a0e69591269c97db0e4deb8b835a102c0a', '2f0e44b71242630ff46ba5acf8bdbd2ee6c99b0b21e79389503ba5059f86a852', 1, '2026-10-18 15:18:39'),
(24, 'b69ed51c8451bfaf86b63c9217701d11db9701419283fa09184753848dc3a0fb', '2f0e44b71242630ff46ba5acf8bdbd2ee6c99b0b21e79389503ba5059f86a852', 1, '2026-10-18 15:40:50'),
(25, '2ceeb6936d3341588dc92df89dc979a0e69591269c97db0e4deb8b835a102c0a', '2f0e44b71242630ff46ba5acf8bdbd2ee6c99b0b21e79389503ba5059f86a852', 1, '2026-10-18 15:48:46'),
(26, 'b69ed51c8451bfaf86b63c9217701d11db9701419283fa09184753848dc3a0fb', '2f0e44b71242630ff46ba5acf8bdbd2ee6c99b0b21e79389503ba5059f86a852', 1, '2026-10-19 09:23:30'),
(27, 'b69ed51c8451bfaf86b63c9217701d11db9701419283fa09184753848dc3a0fb', '2f0e44b71242630ff46ba5acf8bdbd2ee6c99b0b21e79389503ba5059f86a852', 0, '2026-10-19 09:25:31'),
(28, '20f5fc3fe79a1442c71beaf7469a8d342e7cf6f3860c596017992cd0ab7de875', '2f0e44b71242630ff46ba5acf8bdbd2ee6c99b0b21e79389503ba5059f86a852', 0, '2026-10-19 09:25:43'),
(29, '20f5fc3fe79a1442c71beaf7469a8d342e7cf6f3860c596017992cd0ab7de875', '2f0e44b71242630ff46ba5acf8bdbd2ee6c99b0b21e79389503ba5059f86a852', 0, '2026-10-19 09:25:45'),
(30, '20f5fc3fe79a1442c71beaf7469a8d342e7cf6f3860c596017992cd0ab7de875', '2f0e44b71242630ff46ba5acf8bdbd2ee6c99b0b21e79389503ba5059f86a852', 0, '2026-10-19 09:25:46'),
(31, '20f5fc3fe79a1442c71beaf7469a8d342e7cf6f3860c596017992cd0ab7de875', '2f0e44b71242630ff46ba5acf8bdbd2ee6c99b0b21e79389503ba5059f86a852', 0, '2026-10-19 09:25:47'),
(32, 'b69ed51c8451bfaf86b63c9217701d11db9701419283fa09184753848dc3a0fb', '2f0e44b71242630ff46ba5acf8bdbd2ee6c99b0b21e79389503ba5059f86a852', 1, '2026-10-19 09:27:03'),
(33, '2ceeb6936d3341588dc92df89dc979a0e69591269c97db0e4deb8b835a102c0a', '2f0e44b71242630ff46ba5acf8bdbd2ee6c99b0b21e79389503ba5059f86a852', 1, '2026-10-19 09:27:56'),
(34, 'cf1b7edb42d078e8d73844322245535f03acd84748cb6b727b0bff0a4281d0a1', '2f0e44b71242630ff46ba5acf8bdbd2ee6c99b0b21e79389503ba5059f86a852', 1, '2026-10-19 09:37:04'),
(35, '2ceeb6936d3341588dc92df89dc979a0e69591269c97db0e4deb8b835a102c0a', '2f0e44b71242630ff46ba5acf8bdbd2ee6c99b0b21e79389503ba5059f86a852', 1, '2026-10-20 08:37:18'),
(36, '3a43d085bd6ca8923f0a30cd511967c18c617df2a44db41f1f0b94f901602d74', '2f0e44b71242630ff46ba5acf8bdbd2ee6c99b0b21e79389503ba5059f86a852', 0, '2026-10-20 10:38:29'),
(37, '03f37acef6ca2f78f1eec7eb52134d6954854adf3a28b57bed82537f9532a9bd', '2f0e44b71242630ff46ba5acf8bdbd2ee6c99b0b21e79389503ba5059f86a852', 0, '2026-10-20 10:40:28'),
(38, '03f37acef6ca2f78f1eec7eb52134d6954854adf3a28b57bed82537f9532a9bd', '2f0e44b71242630ff46ba5acf8bdbd2ee6c99b0b21e79389503ba5059f86a852', 0, '2026-10-20 10:40:29'),
(39, '03f37acef6ca2f78f1eec7eb52134d6954854adf3a28b57bed82537f9532a9bd', '2f0e44b71242630ff46ba5acf8bdbd2ee6c99b0b21e79389503ba5059f86a852', 0, '2026-10-20 10:40:31'),
(40, '03f37acef6ca2f78f1eec7eb52134d6954854adf3a28b57bed82537f9532a9bd', '2f0e44b71242630ff46ba5acf8bdbd2ee6c99b0b21e79389503ba5059f86a852', 0, '2026-10-20 10:41:39'),
(41, '03f37acef6ca2f78f1eec7eb52134d6954854adf3a28b57bed82537f9532a9bd', '2f0e44b71242630ff46ba5acf8bdbd2ee6c99b0b21e79389503ba5059f86a852', 0, '2026-10-20 10:48:49'),
(42, '03f37acef6ca2f78f1eec7eb52134d6954854adf3a28b57bed82537f9532a9bd', '2f0e44b71242630ff46ba5acf8bdbd2ee6c99b0b21e79389503ba5059f86a852', 0, '2026-10-20 11:01:54'),
(43, '03f37acef6ca2f78f1eec7eb52134d6954854adf3a28b57bed82537f9532a9bd', '2f0e44b71242630ff46ba5acf8bdbd2ee6c99b0b21e79389503ba5059f86a852', 0, '2026-10-20 11:01:55'),
(44, '03f37acef6ca2f78f1eec7eb52134d6954854adf3a28b57bed82537f9532a9bd', '2f0e44b71242630ff46ba5acf8bdbd2ee6c99b0b21e79389503ba5059f86a852', 0, '2026-10-20 11:01:56'),
(45, '03f37acef6ca2f78f1eec7eb52134d6954854adf3a28b57bed82537f9532a9bd', '2f0e44b71242630ff46ba5acf8bdbd2ee6c99b0b21e79389503ba5059f86a852', 0, '2026-10-20 11:02:54'),
(46, 'b69ed51c8451bfaf86b63c9217701d11db9701419283fa09184753848dc3a0fb', '2f0e44b71242630ff46ba5acf8bdbd2ee6c99b0b21e79389503ba5059f86a852', 1, '2026-10-20 11:12:04'),
(47, 'cf1b7edb42d078e8d73844322245535f03acd84748cb6b727b0bff0a4281d0a1', '2f0e44b71242630ff46ba5acf8bdbd2ee6c99b0b21e79389503ba5059f86a852', 1, '2026-10-20 11:15:04'),
(48, '2ceeb6936d3341588dc92df89dc979a0e69591269c97db0e4deb8b835a102c0a', '2f0e44b71242630ff46ba5acf8bdbd2ee6c99b0b21e79389503ba5059f86a852', 1, '2026-10-20 11:16:12'),
(49, 'b69ed51c8451bfaf86b63c9217701d11db9701419283fa09184753848dc3a0fb', '2f0e44b71242630ff46ba5acf8bdbd2ee6c99b0b21e79389503ba5059f86a852', 1, '2026-10-20 14:54:52'),
(50, '2ceeb6936d3341588dc92df89dc979a0e69591269c97db0e4deb8b835a102c0a', '2f0e44b71242630ff46ba5acf8bdbd2ee6c99b0b21e79389503ba5059f86a852', 1, '2026-10-27 12:39:48'),
(51, 'cf1b7edb42d078e8d73844322245535f03acd84748cb6b727b0bff0a4281d0a1', '2f0e44b71242630ff46ba5acf8bdbd2ee6c99b0b21e79389503ba5059f86a852', 1, '2026-10-27 12:40:27'),
(52, '2ceeb6936d3341588dc92df89dc979a0e69591269c97db0e4deb8b835a102c0a', '2f0e44b71242630ff46ba5acf8bdbd2ee6c99b0b21e79389503ba5059f86a852', 1, '2026-10-27 13:29:06'),
(53, 'b69ed51c8451bfaf86b63c9217701d11db9701419283fa09184753848dc3a0fb', '2f0e44b71242630ff46ba5acf8bdbd2ee6c99b0b21e79389503ba5059f86a852', 1, '2026-10-27 13:36:28'),
(54, 'ffc9a607f9a8262a4d13c4c5689c8572782e2a816408b1f238c8677e7d1f6241', '2f0e44b71242630ff46ba5acf8bdbd2ee6c99b0b21e79389503ba5059f86a852', 1, '2026-10-27 13:54:13'),
(55, '2ceeb6936d3341588dc92df89dc979a0e69591269c97db0e4deb8b835a102c0a', '2f0e44b71242630ff46ba5acf8bdbd2ee6c99b0b21e79389503ba5059f86a852', 1, '2026-10-27 14:50:42'),
(56, 'b69ed51c8451bfaf86b63c9217701d11db9701419283fa09184753848dc3a0fb', '2f0e44b71242630ff46ba5acf8bdbd2ee6c99b0b21e79389503ba5059f86a852', 1, '2026-10-27 14:54:03'),
(57, 'ffc9a607f9a8262a4d13c4c5689c8572782e2a816408b1f238c8677e7d1f6241', '2f0e44b71242630ff46ba5acf8bdbd2ee6c99b0b21e79389503ba5059f86a852', 1, '2026-10-27 15:51:48'),
(58, 'b69ed51c8451bfaf86b63c9217701d11db9701419283fa09184753848dc3a0fb', '2f0e44b71242630ff46ba5acf8bdbd2ee6c99b0b21e79389503ba5059f86a852', 1, '2026-10-27 15:53:22'),
(59, '2ceeb6936d3341588dc92df89dc979a0e69591269c97db0e4deb8b835a102c0a', '2f0e44b71242630ff46ba5acf8bdbd2ee6c99b0b21e79389503ba5059f86a852', 1, '2026-10-27 15:53:38'),
(60, '2ceeb6936d3341588dc92df89dc979a0e69591269c97db0e4deb8b835a102c0a', '2f0e44b71242630ff46ba5acf8bdbd2ee6c99b0b21e79389503ba5059f86a852', 1, '2026-10-27 16:35:20'),
(61, 'ffc9a607f9a8262a4d13c4c5689c8572782e2a816408b1f238c8677e7d1f6241', '2f0e44b71242630ff46ba5acf8bdbd2ee6c99b0b21e79389503ba5059f86a852', 1, '2026-10-29 13:38:25'),
(62, '2ceeb6936d3341588dc92df89dc979a0e69591269c97db0e4deb8b835a102c0a', '2f0e44b71242630ff46ba5acf8bdbd2ee6c99b0b21e79389503ba5059f86a852', 1, '2026-10-29 13:38:55'),
(63, 'b69ed51c8451bfaf86b63c9217701d11db9701419283fa09184753848dc3a0fb', '2f0e44b71242630ff46ba5acf8bdbd2ee6c99b0b21e79389503ba5059f86a852', 1, '2026-10-29 13:55:02'),
(64, '2ceeb6936d3341588dc92df89dc979a0e69591269c97db0e4deb8b835a102c0a', '2f0e44b71242630ff46ba5acf8bdbd2ee6c99b0b21e79389503ba5059f86a852', 1, '2026-10-29 14:34:13'),
(65, '2ceeb6936d3341588dc92df89dc979a0e69591269c97db0e4deb8b835a102c0a', '2f0e44b71242630ff46ba5acf8bdbd2ee6c99b0b21e79389503ba5059f86a852', 1, '2026-10-29 15:36:34'),
(66, 'a3a6e40b1df727461735db21c1834464789075521c618ae763f29449b606c207', '2f0e44b71242630ff46ba5acf8bdbd2ee6c99b0b21e79389503ba5059f86a852', 1, '2026-10-29 16:09:35'),
(67, 'a1a37d5e1a5ec690dd2868c655f432cb999f83e3134c565825e681b75028548a', '2f0e44b71242630ff46ba5acf8bdbd2ee6c99b0b21e79389503ba5059f86a852', 1, '2026-10-29 17:14:56'),
(68, '2ceeb6936d3341588dc92df89dc979a0e69591269c97db0e4deb8b835a102c0a', '2f0e44b71242630ff46ba5acf8bdbd2ee6c99b0b21e79389503ba5059f86a852', 1, '2026-10-30 09:30:38'),
(69, '87e4687091059a0c1c754cccdd275b2e0acdd6997470f723c6bbafeacf415fa7', '2f0e44b71242630ff46ba5acf8bdbd2ee6c99b0b21e79389503ba5059f86a852', 1, '2026-10-30 09:39:16'),
(70, '2ceeb6936d3341588dc92df89dc979a0e69591269c97db0e4deb8b835a102c0a', '2f0e44b71242630ff46ba5acf8bdbd2ee6c99b0b21e79389503ba5059f86a852', 1, '2026-10-30 10:18:02'),
(71, 'a2efeb6682c10725fa82617ec1f5920a01b4f07a5f47db6e95b4007d43e1b707', '2f0e44b71242630ff46ba5acf8bdbd2ee6c99b0b21e79389503ba5059f86a852', 1, '2026-10-30 10:20:00'),
(72, '2ceeb6936d3341588dc92df89dc979a0e69591269c97db0e4deb8b835a102c0a', '2f0e44b71242630ff46ba5acf8bdbd2ee6c99b0b21e79389503ba5059f86a852', 1, '2026-10-30 10:58:17'),
(73, '158ec7b64baae91cbc3662b9a9705d3638c81dad0ea785042fae4e2076828e0c', '2f0e44b71242630ff46ba5acf8bdbd2ee6c99b0b21e79389503ba5059f86a852', 1, '2026-10-30 11:00:30'),
(74, '02fa42fb3501a8afbe6bd5975bcc063d19d5478709d70473a777d7e61ea6831e', '2f0e44b71242630ff46ba5acf8bdbd2ee6c99b0b21e79389503ba5059f86a852', 1, '2026-10-30 14:43:15'),
(75, '2ceeb6936d3341588dc92df89dc979a0e69591269c97db0e4deb8b835a102c0a', '2f0e44b71242630ff46ba5acf8bdbd2ee6c99b0b21e79389503ba5059f86a852', 1, '2026-10-30 14:44:32'),
(76, 'cf1b7edb42d078e8d73844322245535f03acd84748cb6b727b0bff0a4281d0a1', '2f0e44b71242630ff46ba5acf8bdbd2ee6c99b0b21e79389503ba5059f86a852', 1, '2026-10-30 15:31:12');

-- --------------------------------------------------------

--
-- Table structure for table `media`
--

CREATE TABLE `media` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `member_id` bigint(20) UNSIGNED NOT NULL,
  `media_type` enum('photo','video','document','audio') NOT NULL,
  `original_name` varchar(255) NOT NULL,
  `stored_name` varchar(255) NOT NULL,
  `mime_type` varchar(100) NOT NULL,
  `file_size` bigint(20) UNSIGNED NOT NULL,
  `sha256` char(64) NOT NULL,
  `storage_path` varchar(500) NOT NULL,
  `visibility` enum('private','family','permissioned') NOT NULL DEFAULT 'private',
  `created_at` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `media`
--

INSERT INTO `media` (`id`, `member_id`, `media_type`, `original_name`, `stored_name`, `mime_type`, `file_size`, `sha256`, `storage_path`, `visibility`, `created_at`) VALUES
(1, 1, 'photo', 'kit 1.jpeg', '3a47dee8341952faa19c1c2975bcba5f4ca905149fd22177.jpeg', 'image/jpeg', 101672, '12809960b9181dbf407301fbde0a89e72a06535a7749ded638b23ef1e15408d3', 'C:/xampp/family_private_storage\\family_1\\3a47dee8341952faa19c1c2975bcba5f4ca905149fd22177.jpeg', 'private', '2026-10-18 15:24:12'),
(2, 1, 'photo', 'jibe.jpeg', '3edf1be63c077cff7a4a2bb101210f19cfe4a40151260c89.jpeg', 'image/jpeg', 56499, '209321714ee210546ef6ea0dd843941d82e4095c93501a1f138080db33ec1b02', 'C:/xampp/family_private_storage\\family_1\\3edf1be63c077cff7a4a2bb101210f19cfe4a40151260c89.jpeg', 'private', '2026-10-18 15:24:30'),
(3, 1, 'photo', 'redemtha.jpeg', '7be646547b83e9e8c1958c930a590b97d0df664075eb364d.jpeg', 'image/jpeg', 43320, '1be1c2e6b538441fb23ae4ff28b439a59795d096db25aecbef58f8704f79d864', 'C:/xampp/family_private_storage\\family_1\\7be646547b83e9e8c1958c930a590b97d0df664075eb364d.jpeg', 'private', '2026-10-18 15:24:41'),
(4, 1, 'photo', 'soja.png', 'b34b518a20d270ea61c660547b5c7570af2734410dbc313b.png', 'image/png', 535047, '9f4b2bf15264600dc3dcdf423e7f6e99cb93bedea2a585a83ef44831468e91b6', 'C:/xampp/family_private_storage\\family_1\\b34b518a20d270ea61c660547b5c7570af2734410dbc313b.png', 'private', '2026-10-18 15:24:49'),
(5, 1, 'video', 'Download (30).mp4', '0e273f7677d9b4e11e328744fc4ab659a9f8cb966395726b.mp4', 'video/mp4', 18439794, 'ae24df1af6b4d7ec32585340f0e82b2e8a29d313c6b8c420a51d704a018d4baf', 'C:/xampp/family_private_storage\\family_1\\0e273f7677d9b4e11e328744fc4ab659a9f8cb966395726b.mp4', 'private', '2026-10-18 15:25:05'),
(6, 1, 'document', 'ADMISSION-LETTER-S4181-0161-2022--041020261536.pdf', '04a7811f5512c3b92861326d0b9669316c47bd1abe6292d4.pdf', 'application/pdf', 211801, 'c3d5980b8a45c5063832c72f6897f05a5e9449428f0e9a126ab93b3c742d4068', 'C:/xampp/family_private_storage\\family_1\\04a7811f5512c3b92861326d0b9669316c47bd1abe6292d4.pdf', 'private', '2026-10-18 15:26:30'),
(7, 4, 'document', 'ya mwish.pdf', '3b857226987c7b4868c3396c972d97fb2f28b73d16d91933.pdf', 'application/pdf', 1284393, 'df6d46353f1486af19d2a23fcbcad8915767f4f6d104761a7478041ab0981c9c', 'C:\\xampp\\family_private_storage\\family_1\\3b857226987c7b4868c3396c972d97fb2f28b73d16d91933.pdf', 'family', '2026-10-27 15:00:33'),
(8, 4, 'photo', 'Screenshot_20260726_215900.jpg', '3af44dceb07a99f91bd511773e4ec479c7fc8d16b34d0a47.jpg', 'image/jpeg', 1195618, 'b425ea35aa70554ad1421b14a4e4d08290ed5e091aadf09eed59410ab65f195a', 'C:\\xampp\\family_private_storage\\family_1\\3af44dceb07a99f91bd511773e4ec479c7fc8d16b34d0a47.jpg', 'private', '2026-10-27 15:01:20'),
(9, 4, 'video', 'Download.mp4', 'f10e01aef46c599d3b1ecb992e544ab6b98d49fdfc3a06be.mp4', 'video/mp4', 2055999, 'fe06e70153218450cb00183c55024835d076220cfee5498c9131c3207508f060', 'C:\\xampp\\family_private_storage\\family_1\\f10e01aef46c599d3b1ecb992e544ab6b98d49fdfc3a06be.mp4', 'private', '2026-10-27 15:01:43');

-- --------------------------------------------------------

--
-- Table structure for table `membership_requests`
--

CREATE TABLE `membership_requests` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `family_id` bigint(20) UNSIGNED NOT NULL,
  `applicant_member_id` bigint(20) UNSIGNED NOT NULL,
  `target_member_id` bigint(20) UNSIGNED DEFAULT NULL,
  `claimed_relationship` varchar(50) NOT NULL,
  `reason` varchar(500) DEFAULT NULL,
  `status` enum('pending','approved','rejected','cancelled') NOT NULL DEFAULT 'pending',
  `reviewed_by_member_id` bigint(20) UNSIGNED DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `reviewed_at` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `membership_requests`
--

INSERT INTO `membership_requests` (`id`, `family_id`, `applicant_member_id`, `target_member_id`, `claimed_relationship`, `reason`, `status`, `reviewed_by_member_id`, `created_at`, `reviewed_at`) VALUES
(1, 1, 4, NULL, 'child', 'child', 'approved', 1, '2026-10-27 13:37:49', '2026-10-27 14:52:54');

-- --------------------------------------------------------

--
-- Table structure for table `otp_challenges`
--

CREATE TABLE `otp_challenges` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `user_id` bigint(20) UNSIGNED NOT NULL,
  `channel` enum('email','sms') NOT NULL,
  `destination` varchar(190) NOT NULL,
  `code_hash` varchar(255) NOT NULL,
  `attempts` tinyint(3) UNSIGNED NOT NULL DEFAULT 0,
  `expires_at` datetime NOT NULL,
  `consumed_at` datetime DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `otp_challenges`
--

INSERT INTO `otp_challenges` (`id`, `user_id`, `channel`, `destination`, `code_hash`, `attempts`, `expires_at`, `consumed_at`, `created_at`) VALUES
(2, 3, 'email', 'jacksonkitupip@gmail.com', '$2y$10$Yg.QfNGWI855ieTU6N46VeCMWO6hwWH2.alKNZEEOVEUac6H2eVFa', 0, '2026-10-18 12:27:33', '2026-10-18 12:18:10', '2026-10-18 12:17:33'),
(3, 4, 'email', 'mabala0155@gmai.com', '$2y$10$4ppdu9pyNuPECW5bBxSwRuJBWn3MKa8CYLUuaGCrn/tk7n7sWmBpa', 0, '2026-10-18 15:45:02', '2026-10-18 15:36:10', '2026-10-18 15:35:02'),
(4, 4, 'email', 'mabala0155@gmai.com', '$2y$10$rGl9Lu55qQtnQPSDXI8/KOL4MXHryhLUEyTD6ZwFV6gUh1BHMLp1G', 0, '2026-10-18 15:46:10', '2026-10-18 15:36:34', '2026-10-18 15:36:10'),
(5, 5, 'email', 'peterkitupi2@gmail.com', '$2y$10$E0JJHsvTlMbUu6ClR15N2OtzQ/E4jQ3FyYVk/M3s4JDBbpzdjTIDK', 0, '2026-10-27 13:58:12', '2026-10-27 13:49:09', '2026-10-27 13:48:12'),
(6, 6, 'email', 'kitupijackson@gmail.com', '$2y$10$O7lKAGNF3ObHHbWcf7Gw3u4XmisaRFuRRrhEcXnQc6anyO6VUVRLC', 0, '2026-10-29 16:16:43', '2026-10-29 16:07:09', '2026-10-29 16:06:43'),
(7, 7, 'email', 'salhalulu123@gmail.com', '$2y$10$J4AGb2U9lZg5N0W2zvnDKOpNOeoLuSyycPEHq.6CLIjojuPzVOAK2', 0, '2026-10-29 17:22:10', '2026-10-29 17:13:18', '2026-10-29 17:12:10'),
(8, 8, 'email', 'oscar155@gmail.com', '$2y$10$fJXXylNQ28AO1GhG9MxA4ulHsWaX3umW5qY7SgpEr/fADuhLaxu3K', 0, '2026-10-30 09:46:04', '2026-10-30 09:36:38', '2026-10-30 09:36:04'),
(9, 9, 'email', 'elisha155@gmail.com', '$2y$10$FgawZDQQ8QUjJbs/QBnglulLn0hwgjXTTd2BWZcAi3.66TIVqqVY.', 0, '2026-10-30 10:37:48', '2026-10-30 10:28:08', '2026-10-30 10:27:48'),
(10, 10, 'email', 'mathias155@gmail.com', '$2y$10$Yo1iASi8R4l.g/f5gsoZP.Lk2aQmh.Ajm4kAIlf.9aME2JkezROQu', 0, '2026-10-30 11:51:52', '2026-10-30 11:42:14', '2026-10-30 11:41:52');

-- --------------------------------------------------------

--
-- Table structure for table `password_reset_tokens`
--

CREATE TABLE `password_reset_tokens` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `user_id` bigint(20) UNSIGNED NOT NULL,
  `token_hash` char(64) NOT NULL,
  `expires_at` datetime NOT NULL,
  `consumed_at` datetime DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `permissions`
--

CREATE TABLE `permissions` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `family_id` bigint(20) UNSIGNED NOT NULL,
  `owner_member_id` bigint(20) UNSIGNED NOT NULL,
  `requester_member_id` bigint(20) UNSIGNED NOT NULL,
  `resource_type` enum('profile','identity','document','photo','video','address','education','employment') NOT NULL,
  `resource_id` bigint(20) UNSIGNED DEFAULT NULL,
  `purpose` varchar(500) DEFAULT NULL,
  `status` enum('pending','approved','rejected','revoked','expired') NOT NULL DEFAULT 'pending',
  `expires_at` datetime DEFAULT NULL,
  `decided_at` datetime DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `permissions`
--

INSERT INTO `permissions` (`id`, `family_id`, `owner_member_id`, `requester_member_id`, `resource_type`, `resource_id`, `purpose`, `status`, `expires_at`, `decided_at`, `created_at`) VALUES
(1, 1, 1, 4, 'document', NULL, 'learning', 'pending', '2026-11-26 15:07:30', NULL, '2026-10-27 15:07:30');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `email` varchar(190) NOT NULL,
  `phone` varchar(30) DEFAULT NULL,
  `password_hash` varchar(255) NOT NULL,
  `status` enum('pending','active','locked','suspended','deleted') NOT NULL DEFAULT 'pending',
  `email_verified_at` datetime DEFAULT NULL,
  `phone_verified_at` datetime DEFAULT NULL,
  `last_login_at` datetime DEFAULT NULL,
  `failed_login_count` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `locked_until` datetime DEFAULT NULL,
  `mfa_enabled` tinyint(1) NOT NULL DEFAULT 0,
  `is_admin` tinyint(1) NOT NULL DEFAULT 0,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `email`, `phone`, `password_hash`, `status`, `email_verified_at`, `phone_verified_at`, `last_login_at`, `failed_login_count`, `locked_until`, `mfa_enabled`, `is_admin`, `created_at`, `updated_at`) VALUES
(1, 'kaemba155@gmail.com', NULL, '$argon2id$v=19$m=65536,t=4,p=1$aEZBN1pPNHM1a2t2TGJ6Tg$5G4AggrtdsmW46sQSNpBgYlCqWbgbpONPT+FztGx/+4', 'active', '2026-10-15 21:40:25', NULL, '2026-10-30 15:31:13', 0, NULL, 0, 1, '2026-10-15 21:40:25', '2026-10-30 15:31:13'),
(3, 'jacksonkitupip@gmail.com', '+255664384727', '$argon2id$v=19$m=65536,t=4,p=1$UlFMb3Z6dHFsSGo4OXh3Lw$IJQfLuPLtuEWeXMmkvDYeqXiJ42oG1IY9+w0wm/5m7E', 'active', '2026-10-18 12:18:10', NULL, '2026-10-30 14:44:32', 0, NULL, 0, 0, '2026-10-18 12:17:33', '2026-10-30 14:44:32'),
(4, 'mabala0155@gmai.com', '+255712041015', '$argon2id$v=19$m=65536,t=4,p=1$VjROelQ1UmRkaFFuQktNQQ$COeh6qf/7JbpnuoK0sheMtw8RJc4Eu+aLRxLKrxggqs', 'active', '2026-10-18 15:36:34', NULL, '2026-10-29 13:55:02', 0, NULL, 0, 0, '2026-10-18 15:35:02', '2026-10-29 13:55:02'),
(5, 'peterkitupi2@gmail.com', '+255616012527', '$argon2id$v=19$m=65536,t=4,p=1$VjR1bVR2VEtRUkovazM2aA$cpAdv6K3JITWxROiNH1ZvFiiPPvrqMJrIkjAiSn/GwY', 'active', '2026-10-27 13:49:09', NULL, '2026-10-29 13:38:25', 0, NULL, 0, 0, '2026-10-27 13:48:12', '2026-10-29 13:38:25'),
(6, 'kitupijackson@gmail.com', '+255742473726', '$argon2id$v=19$m=65536,t=4,p=1$WjhiTnIveHFmMFhEbTRBcg$uhE1e/hlvrV6vW8zFo17ZdcoP1s8rdCw+REgD3e/mt0', 'active', '2026-10-29 16:07:09', NULL, '2026-10-29 16:09:35', 0, NULL, 0, 0, '2026-10-29 16:06:43', '2026-10-29 16:09:35'),
(7, 'salhalulu123@gmail.com', '0749657512', '$argon2id$v=19$m=65536,t=4,p=1$Wnh4ZUlsQ25RRG40YlVNRA$jzyAUXxe9BPE5SQR3o5JD9SLJbFhwA6Lk7JJE29RxA0', 'active', '2026-10-29 17:13:18', NULL, '2026-10-29 17:14:56', 0, NULL, 0, 0, '2026-10-29 17:12:10', '2026-10-29 17:14:56'),
(8, 'oscar155@gmail.com', '0756565656', '$argon2id$v=19$m=65536,t=4,p=1$VWoxS1FwQVhiTGE1a3Y3Mg$JUK4/yuDnXVLsq43Ydr36Qd+5OowrQrzDy2gC6s5EZM', 'active', '2026-10-30 09:36:38', NULL, '2026-10-30 10:20:00', 0, NULL, 0, 0, '2026-10-30 09:36:04', '2026-10-30 10:20:00'),
(9, 'elisha155@gmail.com', '0734343434', '$argon2id$v=19$m=65536,t=4,p=1$VS9TMGVXOUJtTy93WEVTOA$YI+iazOeTqiDRpPDxwU31+Beze+DFPH0LPVK6qG7eII', 'active', '2026-10-30 10:28:08', NULL, '2026-10-30 11:00:30', 0, NULL, 0, 0, '2026-10-30 10:27:48', '2026-10-30 11:00:30'),
(10, 'mathias155@gmail.com', '0654545454', '$argon2id$v=19$m=65536,t=4,p=1$MC5hRy52T0hKdjZMZmtXTw$8AC75eK481FodQpueYBASzJCVfZrUJEMItWtFqe8Ybw', 'active', '2026-10-30 11:42:14', NULL, '2026-10-30 14:43:15', 0, NULL, 0, 0, '2026-10-30 11:41:52', '2026-10-30 14:43:15');

-- --------------------------------------------------------

--
-- Table structure for table `user_mfa`
--

CREATE TABLE `user_mfa` (
  `user_id` bigint(20) UNSIGNED NOT NULL,
  `secret_encrypted` text DEFAULT NULL,
  `pending_secret_encrypted` text DEFAULT NULL,
  `pending_expires_at` datetime DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `confirmed_at` datetime DEFAULT NULL,
  `last_used_step` bigint(20) UNSIGNED NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `user_sessions`
--

CREATE TABLE `user_sessions` (
  `session_hash` char(64) NOT NULL,
  `user_id` bigint(20) UNSIGNED NOT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `last_seen_at` datetime NOT NULL DEFAULT current_timestamp(),
  `revoked_at` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `user_sessions`
--

INSERT INTO `user_sessions` (`session_hash`, `user_id`, `created_at`, `last_seen_at`, `revoked_at`) VALUES
('00439e593fcc353279c84bd3113ca28659416c80ff904c807cd2d24f8c2bd57a', 3, '2026-10-29 15:36:34', '2026-10-29 17:15:33', NULL),
('01f4c04e3d45b7f6a625f44e0cc846e20e9bd0022339f36828892d398caae998', 3, '2026-10-30 10:18:02', '2026-10-30 10:26:22', NULL),
('0c5badc3f6992159087dec5c98d3edc1c46730bfef83189adc39015efc99c231', 3, '2026-10-30 10:58:17', '2026-10-30 10:58:17', NULL),
('1bdb290e872857eb684c0044a93231c8edc5e0577b2e56e814ba24836770f0f2', 3, '2026-10-20 08:37:18', '2026-10-20 08:37:18', NULL),
('2d65a20f3aaeef2d1d3000f5827dd9f2f59cd529b4de78ba3e6b1db4e4d85b45', 4, '2026-10-27 13:36:28', '2026-10-27 13:36:28', NULL),
('30fd9d9bc6b1a62f3a7a09b05a7fe3d760b237452cad967aecd91361de8b5c8d', 3, '2026-10-27 15:53:38', '2026-10-27 15:53:38', NULL),
('3475aca99315fcf41281ee0d096fe4670a47551c04ed1c9fd66a8ce8ff5e685f', 1, '2026-10-27 12:40:27', '2026-10-27 12:40:27', NULL),
('3e093438768030dbd98b203a82614d3ab91a2dc82b8c4899856da6d7f994224c', 8, '2026-10-30 09:39:16', '2026-10-30 09:39:16', NULL),
('57751940594028873af6fb2f4f2b7e4576fb7e86ee002c64586cef9548401f63', 3, '2026-10-30 09:30:38', '2026-10-30 09:30:38', NULL),
('5cedf7efca3c6a61ab0f363095a29d964b4b80b43e5afc7ddf92df6c9882d52b', 8, '2026-10-30 10:20:00', '2026-10-30 10:20:00', NULL),
('60876ee177d87fa9ae4758075f48bbec766d4f9a5f0a0e9dd92b05ece220b5b3', 7, '2026-10-29 17:14:56', '2026-10-29 17:14:56', NULL),
('61a364f752f148818bbe5f7fc080020f5d5f2c4930138f007d3bb4de42746cfe', 3, '2026-10-27 13:29:06', '2026-10-27 13:29:06', NULL),
('64b4cc2b782d2b88953899eb76877160ba01e7f59b9531ab847378dcc9e46b6f', 5, '2026-10-29 13:38:25', '2026-10-29 13:54:20', NULL),
('6baff738db549000a1acd8268c4a5a5ae13ef555b9c11fba1fa224c7a524c45f', 1, '2026-10-20 11:15:04', '2026-10-20 11:15:04', NULL),
('707911fdf2d174fc3f33fa65bd573411304820a1fbb829a2ae7626db06aae7ed', 3, '2026-10-20 11:16:12', '2026-10-20 11:16:12', NULL),
('858a1faf8f1e603de3a34c46d3beab05fec1bac5a990f78250874e8ad4615697', 9, '2026-10-30 10:27:48', '2026-10-30 10:27:48', NULL),
('89ca81feb489d927f93883a70ad3cb07b6f1287c36f230a5937052a075b3cd91', 10, '2026-10-30 14:43:15', '2026-10-30 14:44:10', '2026-10-30 14:44:10'),
('8efb7dd3b547a79ea1af9a6491fe056e73887e0bce02783d0b95851659d1432f', 3, '2026-10-27 12:39:48', '2026-10-27 12:39:48', NULL),
('91de96167f6d76a4fbf31c7cf68e26f6b45a301aaa80c55da49ba7eba41871e1', 3, '2026-10-27 14:50:42', '2026-10-27 15:07:42', NULL),
('95ef75fa9a3d2038ad9e7674413816b53829ffe17d0a9f436e1862337cde40a8', 5, '2026-10-27 15:51:48', '2026-10-27 15:51:48', NULL),
('9f09377c4f4a3eff8d6e239e926ae773ed03238d7185133a9dfb10e6206b2b92', 3, '2026-10-29 14:34:13', '2026-10-29 14:34:13', NULL),
('a0394b9b63949442d208d0433667abf0751a551850b068fc443b5da66770dcde', 4, '2026-10-29 13:55:02', '2026-10-29 13:55:02', NULL),
('af1319a7970cd6936a686c289dadcd4741b6fc2f2d744832c1c00af5bc4dfab2', 3, '2026-10-27 16:35:20', '2026-10-27 16:41:40', NULL),
('b0950bc7362bf56d0de8021d714c7f7699d5cefcafabaee96d9315e5bab19f12', 4, '2026-10-20 11:12:04', '2026-10-20 11:12:04', NULL),
('b6ba87dc88cbf7b37435337a2fa35acc0e687d79d6ee4c098406fc2af299f1d8', 7, '2026-10-29 17:12:10', '2026-10-29 17:12:10', NULL),
('bbc1a6dadb01fdbccabe73bc52fb7225f54fb47be3bc902731060d82295e1c91', 6, '2026-10-29 16:09:35', '2026-10-29 17:00:49', NULL),
('c055092244e9dde8121ef054a4bf691c230ca5f6b7baf973125b0f497dde9317', 8, '2026-10-30 09:36:04', '2026-10-30 09:36:04', NULL),
('c127ac07af1d0220fe9add682484ee8f484bf9f6206bb51b7dbc0618a95acd07', 3, '2026-10-29 13:38:55', '2026-10-29 13:52:33', NULL),
('c3909f4be2b609c552dd4d58d0b70e66417c134925317ca0815d6ddc52db6e7c', 1, '2026-10-30 15:31:13', '2026-10-30 15:31:13', NULL),
('c9f3ad76f86a179343abc876977e6da917f1515e11563157b64cceec837e4c81', 9, '2026-10-30 11:00:30', '2026-10-30 11:00:30', NULL),
('ccfc1437af60502a1fa9538c0203f51e0f1ff05346c54b4b38b7c0985da9bd07', 4, '2026-10-27 15:53:22', '2026-10-27 15:53:22', NULL),
('cf5b2704462511f7342f59b60f1070bfdf2f50ab77d12fc54035b38ce34f1501', 4, '2026-10-20 14:54:52', '2026-10-20 14:54:52', NULL),
('d8204d9a81ff34451e339a9388ed82609ae24e797a25d18a054668a5f9a9057e', 10, '2026-10-30 11:41:52', '2026-10-30 11:41:52', NULL),
('ef2c8c9eb145e64813f17a782c8cffcc73b07ac64b24a2a470728c54629c0623', 5, '2026-10-27 13:54:13', '2026-10-27 14:11:34', NULL),
('f07a8876287d60f398bd22723d3332f25eab3a35d89c5298bf3afe32116fd2ef', 5, '2026-10-27 13:48:12', '2026-10-27 13:53:17', NULL),
('f0e6abd17b870a867a375415f4cda3e0d001c6d5f9d6e2a36bb929b566186968', 3, '2026-10-30 14:44:32', '2026-10-30 14:44:32', NULL),
('f7760bbc8443469f6fca2631ac7f28527a3b152f675310ab4a5cdde5de5328ca', 4, '2026-10-27 14:54:03', '2026-10-27 15:06:35', NULL),
('fd9a11c0e8b1b61563847f2f7e0ac61982b4ad2227a8538f5c259313e30786ee', 6, '2026-10-29 16:06:43', '2026-10-29 16:06:43', NULL);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `audit_logs`
--
ALTER TABLE `audit_logs`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idx_audit_family_time` (`family_id`,`created_at`),
  ADD KEY `idx_audit_actor_time` (`actor_user_id`,`created_at`);

--
-- Indexes for table `families`
--
ALTER TABLE `families`
  ADD PRIMARY KEY (`id`),
  ADD KEY `created_by_user_id` (`created_by_user_id`);

--
-- Indexes for table `family_admin_invitations`
--
ALTER TABLE `family_admin_invitations`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `uq_pending_family_admin_invitation` (`family_id`,`pending_user_id`),
  ADD KEY `idx_family_admin_invitation_user` (`invited_user_id`,`status`,`expires_at`),
  ADD KEY `idx_family_admin_invitation_family` (`family_id`,`status`,`expires_at`),
  ADD KEY `invited_by_user_id` (`invited_by_user_id`);

--
-- Indexes for table `family_invitations`
--
ALTER TABLE `family_invitations`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `uq_family_invitation_token_hash` (`token_hash`),
  ADD UNIQUE KEY `uq_family_pending_invitation_email` (`family_id`,`pending_email`),
  ADD UNIQUE KEY `uq_family_pending_invitation_phone` (`family_id`,`pending_phone`),
  ADD UNIQUE KEY `uq_pending_member_invitation` (`pending_member_ref`),
  ADD KEY `idx_family_invitation_status` (`family_id`,`status`,`expires_at`),
  ADD KEY `invited_user_id` (`invited_user_id`),
  ADD KEY `invited_by_user_id` (`invited_by_user_id`),
  ADD KEY `idx_family_invitations_member` (`member_id`,`status`,`expires_at`);

--
-- Indexes for table `family_members`
--
ALTER TABLE `family_members`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idx_family_member` (`family_id`),
  ADD KEY `idx_user` (`user_id`);

--
-- Indexes for table `family_relationships`
--
ALTER TABLE `family_relationships`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idx_relationship_person` (`person_id`),
  ADD KEY `idx_relationship_related` (`related_person_id`),
  ADD KEY `family_id` (`family_id`),
  ADD KEY `created_by_member_id` (`created_by_member_id`),
  ADD KEY `approved_by_member_id` (`approved_by_member_id`);

--
-- Indexes for table `family_roles`
--
ALTER TABLE `family_roles`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `uq_family_member_role` (`family_id`,`member_id`),
  ADD KEY `member_id` (`member_id`);

--
-- Indexes for table `family_settings`
--
ALTER TABLE `family_settings`
  ADD PRIMARY KEY (`family_id`);

--
-- Indexes for table `identity_verifications`
--
ALTER TABLE `identity_verifications`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idx_identity_user` (`user_id`),
  ADD KEY `idx_identity_hash` (`document_number_hash`),
  ADD KEY `member_id` (`member_id`),
  ADD KEY `reviewer_user_id` (`reviewer_user_id`);

--
-- Indexes for table `login_attempts`
--
ALTER TABLE `login_attempts`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idx_login_identifier_time` (`identifier_hash`,`created_at`),
  ADD KEY `idx_login_ip_time` (`ip_hash`,`created_at`);

--
-- Indexes for table `media`
--
ALTER TABLE `media`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `stored_name` (`stored_name`),
  ADD KEY `idx_media_member` (`member_id`);

--
-- Indexes for table `membership_requests`
--
ALTER TABLE `membership_requests`
  ADD PRIMARY KEY (`id`),
  ADD KEY `family_id` (`family_id`),
  ADD KEY `applicant_member_id` (`applicant_member_id`),
  ADD KEY `target_member_id` (`target_member_id`),
  ADD KEY `reviewed_by_member_id` (`reviewed_by_member_id`);

--
-- Indexes for table `otp_challenges`
--
ALTER TABLE `otp_challenges`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idx_otp_user` (`user_id`);

--
-- Indexes for table `password_reset_tokens`
--
ALTER TABLE `password_reset_tokens`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `token_hash` (`token_hash`),
  ADD KEY `user_id` (`user_id`);

--
-- Indexes for table `permissions`
--
ALTER TABLE `permissions`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idx_permission_owner` (`owner_member_id`),
  ADD KEY `idx_permission_requester` (`requester_member_id`),
  ADD KEY `family_id` (`family_id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `email` (`email`),
  ADD UNIQUE KEY `phone` (`phone`);

--
-- Indexes for table `user_mfa`
--
ALTER TABLE `user_mfa`
  ADD PRIMARY KEY (`user_id`);

--
-- Indexes for table `user_sessions`
--
ALTER TABLE `user_sessions`
  ADD PRIMARY KEY (`session_hash`),
  ADD KEY `idx_user_sessions_user_active` (`user_id`,`revoked_at`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `audit_logs`
--
ALTER TABLE `audit_logs`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=149;

--
-- AUTO_INCREMENT for table `families`
--
ALTER TABLE `families`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `family_admin_invitations`
--
ALTER TABLE `family_admin_invitations`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `family_invitations`
--
ALTER TABLE `family_invitations`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `family_members`
--
ALTER TABLE `family_members`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=19;

--
-- AUTO_INCREMENT for table `family_relationships`
--
ALTER TABLE `family_relationships`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `family_roles`
--
ALTER TABLE `family_roles`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `identity_verifications`
--
ALTER TABLE `identity_verifications`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `login_attempts`
--
ALTER TABLE `login_attempts`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=77;

--
-- AUTO_INCREMENT for table `media`
--
ALTER TABLE `media`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `membership_requests`
--
ALTER TABLE `membership_requests`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `otp_challenges`
--
ALTER TABLE `otp_challenges`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `password_reset_tokens`
--
ALTER TABLE `password_reset_tokens`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `permissions`
--
ALTER TABLE `permissions`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `audit_logs`
--
ALTER TABLE `audit_logs`
  ADD CONSTRAINT `audit_logs_ibfk_1` FOREIGN KEY (`actor_user_id`) REFERENCES `users` (`id`) ON DELETE SET NULL,
  ADD CONSTRAINT `audit_logs_ibfk_2` FOREIGN KEY (`family_id`) REFERENCES `families` (`id`) ON DELETE SET NULL;

--
-- Constraints for table `families`
--
ALTER TABLE `families`
  ADD CONSTRAINT `families_ibfk_1` FOREIGN KEY (`created_by_user_id`) REFERENCES `users` (`id`);

--
-- Constraints for table `family_admin_invitations`
--
ALTER TABLE `family_admin_invitations`
  ADD CONSTRAINT `family_admin_invitations_ibfk_1` FOREIGN KEY (`family_id`) REFERENCES `families` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `family_admin_invitations_ibfk_2` FOREIGN KEY (`invited_user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `family_admin_invitations_ibfk_3` FOREIGN KEY (`invited_by_user_id`) REFERENCES `users` (`id`) ON DELETE SET NULL;

--
-- Constraints for table `family_invitations`
--
ALTER TABLE `family_invitations`
  ADD CONSTRAINT `family_invitations_ibfk_1` FOREIGN KEY (`family_id`) REFERENCES `families` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `family_invitations_ibfk_2` FOREIGN KEY (`invited_user_id`) REFERENCES `users` (`id`) ON DELETE SET NULL,
  ADD CONSTRAINT `family_invitations_ibfk_3` FOREIGN KEY (`invited_by_user_id`) REFERENCES `users` (`id`),
  ADD CONSTRAINT `family_invitations_ibfk_member` FOREIGN KEY (`member_id`) REFERENCES `family_members` (`id`) ON DELETE SET NULL;

--
-- Constraints for table `family_members`
--
ALTER TABLE `family_members`
  ADD CONSTRAINT `family_members_ibfk_1` FOREIGN KEY (`family_id`) REFERENCES `families` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `family_members_ibfk_2` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE SET NULL;

--
-- Constraints for table `family_relationships`
--
ALTER TABLE `family_relationships`
  ADD CONSTRAINT `family_relationships_ibfk_1` FOREIGN KEY (`family_id`) REFERENCES `families` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `family_relationships_ibfk_2` FOREIGN KEY (`person_id`) REFERENCES `family_members` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `family_relationships_ibfk_3` FOREIGN KEY (`related_person_id`) REFERENCES `family_members` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `family_relationships_ibfk_4` FOREIGN KEY (`created_by_member_id`) REFERENCES `family_members` (`id`),
  ADD CONSTRAINT `family_relationships_ibfk_5` FOREIGN KEY (`approved_by_member_id`) REFERENCES `family_members` (`id`) ON DELETE SET NULL;

--
-- Constraints for table `family_roles`
--
ALTER TABLE `family_roles`
  ADD CONSTRAINT `family_roles_ibfk_1` FOREIGN KEY (`family_id`) REFERENCES `families` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `family_roles_ibfk_2` FOREIGN KEY (`member_id`) REFERENCES `family_members` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `family_settings`
--
ALTER TABLE `family_settings`
  ADD CONSTRAINT `fk_family_settings_family` FOREIGN KEY (`family_id`) REFERENCES `families` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `identity_verifications`
--
ALTER TABLE `identity_verifications`
  ADD CONSTRAINT `identity_verifications_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `identity_verifications_ibfk_2` FOREIGN KEY (`member_id`) REFERENCES `family_members` (`id`) ON DELETE SET NULL,
  ADD CONSTRAINT `identity_verifications_ibfk_3` FOREIGN KEY (`reviewer_user_id`) REFERENCES `users` (`id`) ON DELETE SET NULL;

--
-- Constraints for table `media`
--
ALTER TABLE `media`
  ADD CONSTRAINT `media_ibfk_1` FOREIGN KEY (`member_id`) REFERENCES `family_members` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `membership_requests`
--
ALTER TABLE `membership_requests`
  ADD CONSTRAINT `membership_requests_ibfk_1` FOREIGN KEY (`family_id`) REFERENCES `families` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `membership_requests_ibfk_2` FOREIGN KEY (`applicant_member_id`) REFERENCES `family_members` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `membership_requests_ibfk_3` FOREIGN KEY (`target_member_id`) REFERENCES `family_members` (`id`) ON DELETE SET NULL,
  ADD CONSTRAINT `membership_requests_ibfk_4` FOREIGN KEY (`reviewed_by_member_id`) REFERENCES `family_members` (`id`) ON DELETE SET NULL;

--
-- Constraints for table `otp_challenges`
--
ALTER TABLE `otp_challenges`
  ADD CONSTRAINT `otp_challenges_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `password_reset_tokens`
--
ALTER TABLE `password_reset_tokens`
  ADD CONSTRAINT `password_reset_tokens_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `permissions`
--
ALTER TABLE `permissions`
  ADD CONSTRAINT `permissions_ibfk_1` FOREIGN KEY (`family_id`) REFERENCES `families` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `permissions_ibfk_2` FOREIGN KEY (`owner_member_id`) REFERENCES `family_members` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `permissions_ibfk_3` FOREIGN KEY (`requester_member_id`) REFERENCES `family_members` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `user_mfa`
--
ALTER TABLE `user_mfa`
  ADD CONSTRAINT `fk_user_mfa_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `user_sessions`
--
ALTER TABLE `user_sessions`
  ADD CONSTRAINT `fk_user_sessions_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
