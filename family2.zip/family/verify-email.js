'use strict';

const API_ROOT = 'zip_extracted/public';

const form = document.querySelector('#verify-form');
const submitButton = document.querySelector('#verify-submit');
const resendButton = document.querySelector('#resend-submit');
const statusMessage = document.querySelector('#connection-status');
const feedback = document.querySelector('#verify-message');
const resendMessage = document.querySelector('#resend-message');
const verifiedMessage = document.querySelector('#verified-message');
const deliveryNote = document.querySelector('#delivery-note');
const invitationContinue = document.querySelector('#invitation-continue');
const hrefParams = new URLSearchParams(window.location.hash.slice(1));
const invitationToken = hrefParams.get('invitation') || hrefParams.get('token') || '';
let csrfToken = '';

async function loadCsrfToken() {
  const response = await fetch(`${API_ROOT}/index.php`, {
    method: 'GET',
    credentials: 'same-origin',
    cache: 'no-store'
  });
  const result = await response.json().catch(() => null);

  if (!response.ok || result?.success !== true || typeof result.csrf_token !== 'string') {
    throw new Error('Secure verification is temporarily unavailable. Please try again later.');
  }

  csrfToken = result.csrf_token;
}

function showError(message) {
  feedback.textContent = message;
  feedback.hidden = false;
}

function showResendMessage(message, isError = false) {
  resendMessage.textContent = message;
  resendMessage.classList.toggle('resend-error', isError);
  resendMessage.hidden = false;
}

function verificationError(response) {
  if (response.status === 401) {
    return /^[a-f0-9]{64}$/i.test(invitationToken)
      ? 'Your verification session expired. Return to the invitation and sign in with the invited email address to resume.'
      : 'The registration session is no longer available. Start registration again or contact the site administrator.';
  }
  if (response.status === 403) {
    return 'This account cannot be verified in its current state. Contact the site administrator.';
  }
  if (response.status === 422) {
    return 'This code is invalid or expired. Check the digits or request a new verification code.';
  }
  if (response.status === 429) {
    return 'Too many attempts were made and this code is no longer usable. Request a new verification code.';
  }
  if (response.status >= 500) {
    return 'Verification could not be completed. Your account has not been confirmed as verified; please try again later.';
  }
  return 'Verification could not be completed. Please try again later.';
}

form.addEventListener('submit', async (event) => {
  event.preventDefault();
  feedback.hidden = true;

  if (!form.reportValidity()) {
    return;
  }

  const code = form.elements.code.value.replace(/\D/g, '');
  if (!/^\d{6}$/.test(code)) {
    showError('Enter the six-digit code exactly as received.');
    return;
  }

  if (!csrfToken) {
    showError('The secure session is unavailable. Reload this page and try again.');
    return;
  }

  submitButton.disabled = true;

  try {
    const response = await fetch(`${API_ROOT}/api/auth/verify_otp.php`, {
      method: 'POST',
      credentials: 'same-origin',
      headers: {
        'Content-Type': 'application/json',
        'X-CSRF-Token': csrfToken
      },
      body: JSON.stringify({ code })
    });
    const result = await response.json().catch(() => null);

    if (!response.ok || result?.success !== true) {
      showError(verificationError(response));
      if (response.status === 401 && /^[a-f0-9]{64}$/i.test(invitationToken)) {
        invitationContinue.href = `accept-invitation.html#invitation=${encodeURIComponent(invitationToken)}`;
        invitationContinue.textContent = 'Return to your invitation and sign in';
        invitationContinue.hidden = false;
      }
      return;
    }

    form.hidden = true;
    deliveryNote.hidden = true;
    resendButton.hidden = true;
    resendMessage.hidden = true;
    verifiedMessage.hidden = false;
    if (result.invitation_accepted === true) {
      verifiedMessage.textContent = 'Your family invitation has been accepted. Your family membership is now active.';
      const familyId = Number(result.family_id);
      if (Number.isSafeInteger(familyId) && familyId > 0) {
        invitationContinue.href = `family%20member/dashboard.php?family_id=${encodeURIComponent(familyId)}`;
        invitationContinue.textContent = 'Continue to your family dashboard';
        invitationContinue.hidden = false;
        window.setTimeout(() => window.location.assign(invitationContinue.href), 2000);
      }
      statusMessage.textContent = 'Email verified and family invitation accepted.';
    } else if (result.email_verified === true && result.invitation_accepted === false) {
      verifiedMessage.textContent = `Your email has been verified, but your family invitation could not be accepted. ${result.invitation_error || 'Return to the invitation and try again.'}`;
      if (/^[a-f0-9]{64}$/i.test(invitationToken)) {
        invitationContinue.href = `accept-invitation.html#invitation=${encodeURIComponent(invitationToken)}`;
        invitationContinue.textContent = 'Return to your family invitation';
        invitationContinue.hidden = false;
      }
      statusMessage.textContent = 'Email verified; family invitation acceptance needs attention.';
    } else if (/^[a-f0-9]{64}$/i.test(invitationToken)) {
      verifiedMessage.textContent = 'Your email has been verified. Continue to accept your family invitation.';
      invitationContinue.href = `accept-invitation.html#invitation=${encodeURIComponent(invitationToken)}`;
      invitationContinue.textContent = 'Continue to your family invitation';
      invitationContinue.hidden = false;
      statusMessage.textContent = 'Verification completed.';
    } else if (result.membership_onboarding === true) {
      verifiedMessage.textContent = 'Your email is verified. Request approval to join a family before accessing family records.';
      invitationContinue.href = 'family%20member/membership-onboarding.php';
      invitationContinue.textContent = 'Continue to family membership';
      invitationContinue.hidden = false;
      statusMessage.textContent = 'Email verified. Continue to family membership onboarding.';
      window.setTimeout(() => window.location.assign(invitationContinue.href), 1500);
    } else {
      verifiedMessage.textContent = 'Your email has been verified and your account is active. Sign in to continue.';
      statusMessage.textContent = 'Verification completed.';
    }
  } catch {
    showError('A network error interrupted verification. The account has not been confirmed as verified; check the result before trying again.');
  } finally {
    submitButton.disabled = !csrfToken || form.hidden;
  }
});

resendButton.addEventListener('click', async () => {
  resendMessage.hidden = true;
  feedback.hidden = true;

  if (!csrfToken) {
    showResendMessage('The secure session is unavailable. Reload this page and try again.', true);
    return;
  }

  resendButton.disabled = true;

  try {
    const response = await fetch(`${API_ROOT}/api/auth/resend_otp.php`, {
      method: 'POST',
      credentials: 'same-origin',
      headers: {
        'Content-Type': 'application/json',
        'X-CSRF-Token': csrfToken
      },
      body: JSON.stringify({})
    });
    const result = await response.json().catch(() => null);

    if (!response.ok || result?.success !== true) {
      let message;
      if (response.status === 401) {
        message = 'Your registration session has expired. Start registration again or contact the site administrator.';
      } else if (response.status === 403) {
        message = response.statusText && result?.error === 'Invalid CSRF token'
          ? 'Your security check expired. Reload this page and try again.'
          : result?.error || 'This account cannot request another verification code.';
      } else if (response.status === 429) {
        const retryAfter = Number(result?.retry_after_seconds);
        message = result?.error || 'Too many requests. Please try again later.';
        if (Number.isFinite(retryAfter) && retryAfter > 0) {
          message += ` Try again in ${retryAfter} seconds.`;
        }
      } else if (response.status === 409) {
        message = result?.error || 'This account is already verified.';
      } else if (response.status >= 500) {
        message = result?.error || 'The code could not be sent. Please try again later.';
      } else {
        message = result?.error || 'The code could not be requested. Please try again.';
      }
      showResendMessage(message, true);
      return;
    }

    if (result.delivery_mode === 'log') {
      showResendMessage(result.message || 'The code was recorded in the development mail log; it was not delivered to a real inbox.');
    } else {
      showResendMessage(result.message || 'A new verification code was sent to the email address on file.');
    }
    form.elements.code.value = '';
    form.elements.code.focus();
  } catch {
    showResendMessage('A network error interrupted the request. The code was not confirmed as sent; please check before trying again.', true);
  } finally {
    resendButton.disabled = !csrfToken || form.hidden;
  }
});

loadCsrfToken()
  .then(() => {
    statusMessage.textContent = 'Secure connection ready.';
    submitButton.disabled = false;
    resendButton.disabled = false;
  })
  .catch((error) => {
    statusMessage.textContent = error instanceof Error
      ? error.message
      : 'Secure verification is temporarily unavailable. Please try again later.';
    resendButton.disabled = true;
  });
