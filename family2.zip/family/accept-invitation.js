'use strict';

const API_ROOT = 'zip_extracted/public';
const hrefParams = new URLSearchParams(window.location.hash.slice(1));
const token = hrefParams.get('invitation') || hrefParams.get('token') || '';
const statusMessage = document.querySelector('#invitation-status');
const signInHelp = document.querySelector('#sign-in-help');
const registerLink = document.querySelector('#invitation-register');
const signInLink = document.querySelector('#invitation-sign-in');
const verificationHelp = document.querySelector('#verification-help');
const verifyLink = document.querySelector('#invitation-verify');
const retryButton = document.querySelector('#retry-auth');
const claimForm = document.querySelector('#claim-account-form');
const claimEmailInput = document.querySelector('#claim-email');
const claimPhoneInput = document.querySelector('#claim-phone');
const claimPasswordInput = document.querySelector('#claim-password');
const claimPasswordConfirmInput = document.querySelector('#claim-password-confirm');
const claimError = document.querySelector('#claim-error');
const claimSubmitButton = document.querySelector('#claim-submit');
const form = document.querySelector('#accept-form');
const submitButton = document.querySelector('#accept-submit');
const feedback = document.querySelector('#accept-error');
const successPanel = document.querySelector('#accept-success');
const successText = document.querySelector('#success-text');
const dashboardLink = document.querySelector('#dashboard-link');
let csrfToken = '';

function showStatus(message) {
  statusMessage.textContent = message;
}

async function requestJson(path, options = {}) {
  const response = await fetch(`${API_ROOT}/${path}`, {
    ...options,
    credentials: 'same-origin',
    cache: 'no-store',
    headers: { 'Accept': 'application/json', ...(options.headers || {}) }
  });
  const result = await response.json().catch(() => null);
  return { response, result };
}

async function loadInvitationDetails() {
  if (!/^[a-f0-9]{64}$/i.test(token)) {
    return null;
  }
  const { response, result } = await requestJson(`api/family/accept_invitation.php?token=${encodeURIComponent(token)}`);
  if (!response.ok || result?.success !== true) {
    return null;
  }
  return result;
}

function showClaimAccount(email) {
  claimForm.hidden = false;
  claimEmailInput.value = email || '';
  claimPhoneInput.value = '';
  claimPasswordInput.value = '';
  claimPasswordConfirmInput.value = '';
  claimError.hidden = true;
  form.hidden = true;
  signInHelp.hidden = true;
  verificationHelp.hidden = true;
  successPanel.hidden = true;
  showStatus('Create your invitation account to continue.');
}

async function checkSession() {
  signInHelp.hidden = true;
  verificationHelp.hidden = true;
  form.hidden = true;
  claimForm.hidden = true;
  claimError.hidden = true;
  if (!/^[a-f0-9]{64}$/i.test(token)) {
    showStatus('This invitation link is missing or invalid. Open the original invitation email for a fresh link.');
    return;
  }

  try {
    const csrf = await requestJson('index.php');
    if (!csrf.response.ok || csrf.result?.success !== true
      || typeof csrf.result.csrf_token !== 'string' || csrf.result.csrf_token.length < 32) {
      showStatus('A secure session could not be started. Reload this page or try again later.');
      return;
    }
    csrfToken = csrf.result.csrf_token;

    const session = await requestJson('api/auth/me.php');
    if (session.response.status === 401) {
      const details = await loadInvitationDetails();
      signInLink.href = `super%20admin/login.php#invitation=${encodeURIComponent(token)}`;
      if (details?.requires_account_creation) {
        showClaimAccount(details.invitee_email || '');
        return;
      }
      showStatus('Sign in or create your invitation account with the invited email address to continue.');
      registerLink.href = `register.html#invitation=${encodeURIComponent(token)}`;
      signInHelp.hidden = false;
      return;
    }
    if (!session.response.ok || session.result?.success !== true) {
      if (session.response.status === 403
        && session.result?.error === 'Account verification required') {
        verifyLink.href = `verify-email.html#invitation=${encodeURIComponent(token)}`;
        verificationHelp.hidden = false;
      }
      showStatus(session.result?.error || 'Your account is not ready to accept this invitation. Verify your email and sign in.');
      return;
    }
    if (!session.result.user?.email_verified_at) {
      showStatus('Verify your email before accepting a family invitation.');
      verifyLink.href = `verify-email.html#invitation=${encodeURIComponent(token)}`;
      verificationHelp.hidden = false;
      return;
    }

    showStatus('Your verified session is ready. Accept the invitation to activate family access.');
    form.hidden = false;
    await acceptInvitation();
  } catch {
    showStatus('A network error prevented the invitation from being checked. Please try again.');
  }
}

retryButton.addEventListener('click', checkSession);

claimForm.addEventListener('submit', async (event) => {
  event.preventDefault();
  claimError.hidden = true;
  claimSubmitButton.disabled = true;
  showStatus('Creating your invitation account…');

  const phone = claimPhoneInput.value.trim();
  const password = claimPasswordInput.value;
  const passwordConfirm = claimPasswordConfirmInput.value;
  if (!phone) {
    claimError.textContent = 'Enter a phone number for the new account.';
    claimError.hidden = false;
    claimSubmitButton.disabled = false;
    return;
  }
  if (!password || !passwordConfirm) {
    claimError.textContent = 'Enter and confirm your new password.';
    claimError.hidden = false;
    claimSubmitButton.disabled = false;
    return;
  }
  if (password.length < 12 || !/[A-Z]/.test(password) || !/[a-z]/.test(password) || !/[0-9]/.test(password) || !/[^A-Za-z0-9]/.test(password)) {
    claimError.textContent = 'Use at least 12 characters, including uppercase and lowercase letters, a number, and a symbol.';
    claimError.hidden = false;
    claimSubmitButton.disabled = false;
    return;
  }
  if (password !== passwordConfirm) {
    claimError.textContent = 'The passwords do not match.';
    claimError.hidden = false;
    claimSubmitButton.disabled = false;
    return;
  }

  try {
    const { response, result } = await requestJson('api/family/accept_invitation.php', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'X-CSRF-Token': csrfToken
      },
      body: JSON.stringify({
        action: 'claim_account',
        token,
        phone,
        password,
        password_confirm: passwordConfirm
      })
    });
    if (!response.ok || result?.success !== true) {
      const message = result?.error || 'The invitation account could not be created.';
      claimError.textContent = message;
      claimError.hidden = false;
      showStatus('Account activation did not complete.');
      return;
    }
    if (result.redirect === 'verify-email') {
      window.location.assign(`verify-email.html#invitation=${encodeURIComponent(token)}`);
      return;
    }
    window.location.assign(`verify-email.html#invitation=${encodeURIComponent(token)}`);
  } catch {
    claimError.textContent = 'A network error prevented account creation. Please try again.';
    claimError.hidden = false;
    showStatus('Account activation did not complete.');
  } finally {
    claimSubmitButton.disabled = false;
  }
});

async function acceptInvitation() {
  feedback.hidden = true;
  submitButton.disabled = true;
  showStatus('Checking and accepting the invitation…');
  try {
    const { response, result } = await requestJson('api/family/accept_invitation.php', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'X-CSRF-Token': csrfToken
      },
      body: JSON.stringify({
        token
      })
    });
    if (!response.ok || result?.success !== true) {
      const errors = {
        401: 'Your sign-in session expired. Sign in again to resume this invitation.',
        403: result?.error || 'This invitation is only valid for its intended verified email account.',
        404: 'This invitation link is invalid or no longer available.',
        409: result?.error || 'This invitation has already been used, revoked, or cannot be applied.',
        410: 'This invitation has expired. Ask the family administrator to send a new invitation.',
        422: result?.error || 'This invitation request is invalid or does not match the original family member profile.'
      };
      feedback.textContent = errors[response.status] || result?.error || 'The invitation could not be accepted. Please try again.';
      if (response.status === 401) {
        signInLink.href = `super%20admin/login.php#invitation=${encodeURIComponent(token)}`;
        signInHelp.hidden = false;
        form.hidden = true;
        showStatus('Your sign-in session expired. Sign in to resume this invitation.');
      } else {
        feedback.hidden = false;
        showStatus('Family access has not been changed.');
      }
      return;
    }

    form.hidden = true;
    signInHelp.hidden = true;
    successPanel.hidden = false;
    showStatus('Invitation accepted.');
    successText.textContent = 'Your family invitation has been accepted. Your family membership is now active.';
    const familyQuery = `?family_id=${encodeURIComponent(result.family_id)}`;
    dashboardLink.href = `family%20member/dashboard.php${familyQuery}`;
    dashboardLink.hidden = false;
    window.setTimeout(() => window.location.assign(dashboardLink.href), 2000);
  } catch {
    feedback.textContent = 'A network error interrupted the request. The server did not confirm acceptance; reopen this page to check the invitation.';
    feedback.hidden = false;
    showStatus('Family access has not been confirmed.');
  } finally {
    submitButton.disabled = form.hidden;
  }
}

form.addEventListener('submit', async (event) => {
  event.preventDefault();
  await acceptInvitation();
});

checkSession();
